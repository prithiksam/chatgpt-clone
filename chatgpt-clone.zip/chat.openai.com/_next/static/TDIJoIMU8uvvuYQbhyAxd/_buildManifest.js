self.__BUILD_MANIFEST = function(a, c, s, t, e, u, n, h, i, d, f, k, l) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [a, t, n, h, i, c, e, d, f, s, u, k, "static/chunks/pages/index-cdf94a9e9b4c79dc.js"],
        "/_error": ["static/chunks/pages/_error-fdab57c4b88e5b1c.js"],
        "/account/cancel": ["static/chunks/pages/account/cancel-164e4ecc13479ecd.js"],
        "/account/manage": ["static/chunks/pages/account/manage-c7a1640505b9cfd2.js"],
        "/account/upgrade": [t, u, "static/chunks/pages/account/upgrade-f7775b17108942f6.js"],
        "/admin": [a, c, e, "static/chunks/238-882950710bdd3e1e.js", s, "static/chunks/pages/admin-d2b4a20bdbdbff21.js"],
        "/admin/AdminPageLayout": [a, c, s, "static/chunks/pages/admin/AdminPageLayout-ce372de9645c11ef.js"],
        "/admin/analytics": [a, "static/chunks/3a34cc27-c52661d0ee7d7b3d.js", c, "static/chunks/930-f22053ce64d5a9eb.js", s, "static/chunks/pages/admin/analytics-6cdbd3098f320e55.js"],
        "/aip/[pluginId]/oauth/callback": ["static/chunks/pages/aip/[pluginId]/oauth/callback-b7d4a081f7ad5b5b.js"],
        "/auth/error": ["static/chunks/pages/auth/error-4e3425abbb9e84c0.js"],
        "/auth/ext_callback": ["static/chunks/pages/auth/ext_callback-7b50f284300a7ff6.js"],
        "/auth/ext_callback_refresh": ["static/chunks/pages/auth/ext_callback_refresh-47f3cd5abd2d99b6.js"],
        "/auth/login": [l, "static/chunks/pages/auth/login-4c126b1d4f200503.js"],
        "/auth/logout": ["static/chunks/pages/auth/logout-fae271d7aebb5e23.js"],
        "/auth/mocked_login": ["static/chunks/pages/auth/mocked_login-060c0092bc682b49.js"],
        "/bypass": ["static/chunks/pages/bypass-979cf95f72688cf4.js"],
        "/c/[chatId]": ["static/chunks/pages/c/[chatId]-a7250ba221ea5fd0.js"],
        "/payments/success": ["static/chunks/pages/payments/success-a86ae956e75e1aa4.js"],
        "/share/[[...shareParams]]": [a, t, n, h, i, c, e, d, f, s, u, k, "static/chunks/pages/share/[[...shareParams]]-2d1bfa98f820051f.js"],
        "/status": [l, "static/chunks/pages/status-9047ec54adb32ef3.js"],
        sortedPages: ["/", "/_app", "/_error", "/account/cancel", "/account/manage", "/account/upgrade", "/admin", "/admin/AdminPageLayout", "/admin/analytics", "/aip/[pluginId]/oauth/callback", "/auth/error", "/auth/ext_callback", "/auth/ext_callback_refresh", "/auth/login", "/auth/logout", "/auth/mocked_login", "/bypass", "/c/[chatId]", "/payments/success", "/share/[[...shareParams]]", "/status"]
    }
}("static/chunks/68a27ff6-b1db347c50639918.js", "static/chunks/983-33d35c39a73606c3.js", "static/chunks/493-d7689066182cf238.js", "static/chunks/012ff928-bcfa62e3ac82441c.js", "static/chunks/924-d1b63621e1cb69c3.js", "static/chunks/937-edd834a8db5cd2db.js", "static/chunks/2802bd5f-15923fb46be55b45.js", "static/chunks/bd26816a-7ae54dd3357d90b4.js", "static/chunks/1f110208-cda4026aba1898fb.js", "static/chunks/984-1278472924e49180.js", "static/chunks/108-802ce3037f92d8c4.js", "static/chunks/851-f5936c81005e64d8.js", "static/chunks/564-b7382407c3702e55.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();