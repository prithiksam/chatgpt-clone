"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [786], {
        54655: function(t, n, r) {
            r.d(n, {
                DcN: function() {
                    return o
                },
                Ny3: function() {
                    return e
                }
            });
            var a = r(50913);

            function e(t) {
                return (0, a.w_)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24",
                        strokeWidth: "2",
                        stroke: "currentColor",
                        fill: "none",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    },
                    child: [{
                        tag: "desc",
                        attr: {},
                        child: []
                    }, {
                        tag: "path",
                        attr: {
                            stroke: "none",
                            d: "M0 0h24v24H0z",
                            fill: "none"
                        }
                    }, {
                        tag: "path",
                        attr: {
                            d: "M5 9h14m-14 6h14"
                        }
                    }]
                })(t)
            }

            function o(t) {
                return (0, a.w_)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24",
                        strokeWidth: "2",
                        stroke: "currentColor",
                        fill: "none",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    },
                    child: [{
                        tag: "desc",
                        attr: {},
                        child: []
                    }, {
                        tag: "path",
                        attr: {
                            stroke: "none",
                            d: "M0 0h24v24H0z",
                            fill: "none"
                        }
                    }, {
                        tag: "polyline",
                        attr: {
                            points: "6 21 21 6 18 3 3 18 6 21"
                        }
                    }, {
                        tag: "line",
                        attr: {
                            x1: "15",
                            y1: "6",
                            x2: "18",
                            y2: "9"
                        }
                    }, {
                        tag: "path",
                        attr: {
                            d: "M9 3a2 2 0 0 0 2 2a2 2 0 0 0 -2 2a2 2 0 0 0 -2 -2a2 2 0 0 0 2 -2"
                        }
                    }, {
                        tag: "path",
                        attr: {
                            d: "M19 13a2 2 0 0 0 2 2a2 2 0 0 0 -2 2a2 2 0 0 0 -2 -2a2 2 0 0 0 2 -2"
                        }
                    }]
                })(t)
            }
        }
    }
]);