(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [924], {
        93865: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return K
                }
            });
            var r = function() {
                    function e(e) {
                        var t = this;
                        this._insertTag = function(e) {
                            var n;
                            n = 0 === t.tags.length ? t.insertionPoint ? t.insertionPoint.nextSibling : t.prepend ? t.container.firstChild : t.before : t.tags[t.tags.length - 1].nextSibling, t.container.insertBefore(e, n), t.tags.push(e)
                        }, this.isSpeedy = void 0 === e.speedy || e.speedy, this.tags = [], this.ctr = 0, this.nonce = e.nonce, this.key = e.key, this.container = e.container, this.prepend = e.prepend, this.insertionPoint = e.insertionPoint, this.before = null
                    }
                    var t = e.prototype;
                    return t.hydrate = function(e) {
                        e.forEach(this._insertTag)
                    }, t.insert = function(e) {
                        if (this.ctr % (this.isSpeedy ? 65e3 : 1) == 0) {
                            var t;
                            this._insertTag(((t = document.createElement("style")).setAttribute("data-emotion", this.key), void 0 !== this.nonce && t.setAttribute("nonce", this.nonce), t.appendChild(document.createTextNode("")), t.setAttribute("data-s", ""), t))
                        }
                        var n = this.tags[this.tags.length - 1];
                        if (this.isSpeedy) {
                            var r = function(e) {
                                if (e.sheet) return e.sheet;
                                for (var t = 0; t < document.styleSheets.length; t++)
                                    if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
                            }(n);
                            try {
                                r.insertRule(e, r.cssRules.length)
                            } catch (e) {}
                        } else n.appendChild(document.createTextNode(e));
                        this.ctr++
                    }, t.flush = function() {
                        this.tags.forEach(function(e) {
                            return e.parentNode && e.parentNode.removeChild(e)
                        }), this.tags = [], this.ctr = 0
                    }, e
                }(),
                o = Math.abs,
                i = String.fromCharCode,
                l = Object.assign;

            function a(e, t, n) {
                return e.replace(t, n)
            }

            function u(e, t) {
                return e.indexOf(t)
            }

            function c(e, t) {
                return 0 | e.charCodeAt(t)
            }

            function s(e, t, n) {
                return e.slice(t, n)
            }

            function d(e) {
                return e.length
            }

            function f(e, t) {
                return t.push(e), e
            }
            var p = 1,
                m = 1,
                h = 0,
                v = 0,
                g = 0,
                y = "";

            function w(e, t, n, r, o, i, l) {
                return {
                    value: e,
                    root: t,
                    parent: n,
                    type: r,
                    props: o,
                    children: i,
                    line: p,
                    column: m,
                    length: l,
                    return: ""
                }
            }

            function b(e, t) {
                return l(w("", null, null, "", null, null, 0), e, {
                    length: -e.length
                }, t)
            }

            function x() {
                return g = v < h ? c(y, v++) : 0, m++, 10 === g && (m = 1, p++), g
            }

            function E() {
                return c(y, v)
            }

            function C(e) {
                switch (e) {
                    case 0:
                    case 9:
                    case 10:
                    case 13:
                    case 32:
                        return 5;
                    case 33:
                    case 43:
                    case 44:
                    case 47:
                    case 62:
                    case 64:
                    case 126:
                    case 59:
                    case 123:
                    case 125:
                        return 4;
                    case 58:
                        return 3;
                    case 34:
                    case 39:
                    case 40:
                    case 91:
                        return 2;
                    case 41:
                    case 93:
                        return 1
                }
                return 0
            }

            function R(e) {
                return p = m = 1, h = d(y = e), v = 0, []
            }

            function M(e) {
                var t, n;
                return (t = v - 1, n = function e(t) {
                    for (; x();) switch (g) {
                        case t:
                            return v;
                        case 34:
                        case 39:
                            34 !== t && 39 !== t && e(g);
                            break;
                        case 40:
                            41 === t && e(t);
                            break;
                        case 92:
                            x()
                    }
                    return v
                }(91 === e ? e + 2 : 40 === e ? e + 1 : e), s(y, t, n)).trim()
            }
            var S = "-ms-",
                k = "-moz-",
                P = "-webkit-",
                _ = "comm",
                T = "rule",
                O = "decl",
                D = "@keyframes";

            function A(e, t) {
                for (var n = "", r = e.length, o = 0; o < r; o++) n += t(e[o], o, e, t) || "";
                return n
            }

            function I(e, t, n, r) {
                switch (e.type) {
                    case "@layer":
                        if (e.children.length) break;
                    case "@import":
                    case O:
                        return e.return = e.return || e.value;
                    case _:
                        return "";
                    case D:
                        return e.return = e.value + "{" + A(e.children, r) + "}";
                    case T:
                        e.value = e.props.join(",")
                }
                return d(n = A(e.children, r)) ? e.return = e.value + "{" + n + "}" : ""
            }

            function L(e, t, n, r, i, l, u, c, d, f, p) {
                for (var m = i - 1, h = 0 === i ? l : [""], v = h.length, g = 0, y = 0, b = 0; g < r; ++g)
                    for (var x = 0, E = s(e, m + 1, m = o(y = u[g])), C = e; x < v; ++x)(C = (y > 0 ? h[x] + " " + E : a(E, /&\f/g, h[x])).trim()) && (d[b++] = C);
                return w(e, t, n, 0 === i ? T : c, d, f, p)
            }

            function F(e, t, n, r) {
                return w(e, t, n, O, s(e, 0, r), s(e, r + 1, -1), r)
            }
            var W = function(e, t, n) {
                    for (var r = 0, o = 0; r = o, o = E(), 38 === r && 12 === o && (t[n] = 1), !C(o);) x();
                    return s(y, e, v)
                },
                V = function(e, t) {
                    var n = -1,
                        r = 44;
                    do switch (C(r)) {
                        case 0:
                            38 === r && 12 === E() && (t[n] = 1), e[n] += W(v - 1, t, n);
                            break;
                        case 2:
                            e[n] += M(r);
                            break;
                        case 4:
                            if (44 === r) {
                                e[++n] = 58 === E() ? "&\f" : "", t[n] = e[n].length;
                                break
                            }
                        default:
                            e[n] += i(r)
                    }
                    while (r = x());
                    return e
                },
                Z = function(e, t) {
                    var n;
                    return n = V(R(e), t), y = "", n
                },
                $ = new WeakMap,
                N = function(e) {
                    if ("rule" === e.type && e.parent && !(e.length < 1)) {
                        for (var t = e.value, n = e.parent, r = e.column === n.column && e.line === n.line;
                            "rule" !== n.type;)
                            if (!(n = n.parent)) return;
                        if ((1 !== e.props.length || 58 === t.charCodeAt(0) || $.get(n)) && !r) {
                            $.set(e, !0);
                            for (var o = [], i = Z(t, o), l = n.props, a = 0, u = 0; a < i.length; a++)
                                for (var c = 0; c < l.length; c++, u++) e.props[u] = o[a] ? i[a].replace(/&\f/g, l[c]) : l[c] + " " + i[a]
                        }
                    }
                },
                B = function(e) {
                    if ("decl" === e.type) {
                        var t = e.value;
                        108 === t.charCodeAt(0) && 98 === t.charCodeAt(2) && (e.return = "", e.value = "")
                    }
                },
                H = [function(e, t, n, r) {
                    if (e.length > -1 && !e.return) switch (e.type) {
                        case O:
                            e.return = function e(t, n) {
                                switch (45 ^ c(t, 0) ? (((n << 2 ^ c(t, 0)) << 2 ^ c(t, 1)) << 2 ^ c(t, 2)) << 2 ^ c(t, 3) : 0) {
                                    case 5103:
                                        return P + "print-" + t + t;
                                    case 5737:
                                    case 4201:
                                    case 3177:
                                    case 3433:
                                    case 1641:
                                    case 4457:
                                    case 2921:
                                    case 5572:
                                    case 6356:
                                    case 5844:
                                    case 3191:
                                    case 6645:
                                    case 3005:
                                    case 6391:
                                    case 5879:
                                    case 5623:
                                    case 6135:
                                    case 4599:
                                    case 4855:
                                    case 4215:
                                    case 6389:
                                    case 5109:
                                    case 5365:
                                    case 5621:
                                    case 3829:
                                        return P + t + t;
                                    case 5349:
                                    case 4246:
                                    case 4810:
                                    case 6968:
                                    case 2756:
                                        return P + t + k + t + S + t + t;
                                    case 6828:
                                    case 4268:
                                        return P + t + S + t + t;
                                    case 6165:
                                        return P + t + S + "flex-" + t + t;
                                    case 5187:
                                        return P + t + a(t, /(\w+).+(:[^]+)/, P + "box-$1$2" + S + "flex-$1$2") + t;
                                    case 5443:
                                        return P + t + S + "flex-item-" + a(t, /flex-|-self/, "") + t;
                                    case 4675:
                                        return P + t + S + "flex-line-pack" + a(t, /align-content|flex-|-self/, "") + t;
                                    case 5548:
                                        return P + t + S + a(t, "shrink", "negative") + t;
                                    case 5292:
                                        return P + t + S + a(t, "basis", "preferred-size") + t;
                                    case 6060:
                                        return P + "box-" + a(t, "-grow", "") + P + t + S + a(t, "grow", "positive") + t;
                                    case 4554:
                                        return P + a(t, /([^-])(transform)/g, "$1" + P + "$2") + t;
                                    case 6187:
                                        return a(a(a(t, /(zoom-|grab)/, P + "$1"), /(image-set)/, P + "$1"), t, "") + t;
                                    case 5495:
                                    case 3959:
                                        return a(t, /(image-set\([^]*)/, P + "$1$`$1");
                                    case 4968:
                                        return a(a(t, /(.+:)(flex-)?(.*)/, P + "box-pack:$3" + S + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + P + t + t;
                                    case 4095:
                                    case 3583:
                                    case 4068:
                                    case 2532:
                                        return a(t, /(.+)-inline(.+)/, P + "$1$2") + t;
                                    case 8116:
                                    case 7059:
                                    case 5753:
                                    case 5535:
                                    case 5445:
                                    case 5701:
                                    case 4933:
                                    case 4677:
                                    case 5533:
                                    case 5789:
                                    case 5021:
                                    case 4765:
                                        if (d(t) - 1 - n > 6) switch (c(t, n + 1)) {
                                            case 109:
                                                if (45 !== c(t, n + 4)) break;
                                            case 102:
                                                return a(t, /(.+:)(.+)-([^]+)/, "$1" + P + "$2-$3$1" + k + (108 == c(t, n + 3) ? "$3" : "$2-$3")) + t;
                                            case 115:
                                                return ~u(t, "stretch") ? e(a(t, "stretch", "fill-available"), n) + t : t
                                        }
                                        break;
                                    case 4949:
                                        if (115 !== c(t, n + 1)) break;
                                    case 6444:
                                        switch (c(t, d(t) - 3 - (~u(t, "!important") && 10))) {
                                            case 107:
                                                return a(t, ":", ":" + P) + t;
                                            case 101:
                                                return a(t, /(.+:)([^;!]+)(;|!.+)?/, "$1" + P + (45 === c(t, 14) ? "inline-" : "") + "box$3$1" + P + "$2$3$1" + S + "$2box$3") + t
                                        }
                                        break;
                                    case 5936:
                                        switch (c(t, n + 11)) {
                                            case 114:
                                                return P + t + S + a(t, /[svh]\w+-[tblr]{2}/, "tb") + t;
                                            case 108:
                                                return P + t + S + a(t, /[svh]\w+-[tblr]{2}/, "tb-rl") + t;
                                            case 45:
                                                return P + t + S + a(t, /[svh]\w+-[tblr]{2}/, "lr") + t
                                        }
                                        return P + t + S + t + t
                                }
                                return t
                            }(e.value, e.length);
                            break;
                        case D:
                            return A([b(e, {
                                value: a(e.value, "@", "@" + P)
                            })], r);
                        case T:
                            if (e.length) return e.props.map(function(t) {
                                var n;
                                switch (n = t, (n = /(::plac\w+|:read-\w+)/.exec(n)) ? n[0] : n) {
                                    case ":read-only":
                                    case ":read-write":
                                        return A([b(e, {
                                            props: [a(t, /:(read-\w+)/, ":" + k + "$1")]
                                        })], r);
                                    case "::placeholder":
                                        return A([b(e, {
                                            props: [a(t, /:(plac\w+)/, ":" + P + "input-$1")]
                                        }), b(e, {
                                            props: [a(t, /:(plac\w+)/, ":" + k + "$1")]
                                        }), b(e, {
                                            props: [a(t, /:(plac\w+)/, S + "input-$1")]
                                        })], r)
                                }
                                return ""
                            }).join("")
                    }
                }],
                K = function(e) {
                    var t, n, o, l, h, b = e.key;
                    if ("css" === b) {
                        var S = document.querySelectorAll("style[data-emotion]:not([data-s])");
                        Array.prototype.forEach.call(S, function(e) {
                            -1 !== e.getAttribute("data-emotion").indexOf(" ") && (document.head.appendChild(e), e.setAttribute("data-s", ""))
                        })
                    }
                    var k = e.stylisPlugins || H,
                        P = {},
                        T = [];
                    l = e.container || document.head, Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="' + b + ' "]'), function(e) {
                        for (var t = e.getAttribute("data-emotion").split(" "), n = 1; n < t.length; n++) P[t[n]] = !0;
                        T.push(e)
                    });
                    var O = (n = (t = [N, B].concat(k, [I, (o = function(e) {
                            h.insert(e)
                        }, function(e) {
                            !e.root && (e = e.return) && o(e)
                        })])).length, function(e, r, o, i) {
                            for (var l = "", a = 0; a < n; a++) l += t[a](e, r, o, i) || "";
                            return l
                        }),
                        D = function(e) {
                            var t, n;
                            return A((n = function e(t, n, r, o, l, h, b, R, S) {
                                for (var k, P = 0, T = 0, O = b, D = 0, A = 0, I = 0, W = 1, V = 1, Z = 1, $ = 0, N = "", B = l, H = h, K = o, z = N; V;) switch (I = $, $ = x()) {
                                    case 40:
                                        if (108 != I && 58 == c(z, O - 1)) {
                                            -1 != u(z += a(M($), "&", "&\f"), "&\f") && (Z = -1);
                                            break
                                        }
                                    case 34:
                                    case 39:
                                    case 91:
                                        z += M($);
                                        break;
                                    case 9:
                                    case 10:
                                    case 13:
                                    case 32:
                                        z += function(e) {
                                            for (; g = E();)
                                                if (g < 33) x();
                                                else break;
                                            return C(e) > 2 || C(g) > 3 ? "" : " "
                                        }(I);
                                        break;
                                    case 92:
                                        z += function(e, t) {
                                            for (var n; --t && x() && !(g < 48) && !(g > 102) && (!(g > 57) || !(g < 65)) && (!(g > 70) || !(g < 97)););
                                            return n = v + (t < 6 && 32 == E() && 32 == x()), s(y, e, n)
                                        }(v - 1, 7);
                                        continue;
                                    case 47:
                                        switch (E()) {
                                            case 42:
                                            case 47:
                                                f(w(k = function(e, t) {
                                                    for (; x();)
                                                        if (e + g === 57) break;
                                                        else if (e + g === 84 && 47 === E()) break;
                                                    return "/*" + s(y, t, v - 1) + "*" + i(47 === e ? e : x())
                                                }(x(), v), n, r, _, i(g), s(k, 2, -2), 0), S);
                                                break;
                                            default:
                                                z += "/"
                                        }
                                        break;
                                    case 123 * W:
                                        R[P++] = d(z) * Z;
                                    case 125 * W:
                                    case 59:
                                    case 0:
                                        switch ($) {
                                            case 0:
                                            case 125:
                                                V = 0;
                                            case 59 + T:
                                                -1 == Z && (z = a(z, /\f/g, "")), A > 0 && d(z) - O && f(A > 32 ? F(z + ";", o, r, O - 1) : F(a(z, " ", "") + ";", o, r, O - 2), S);
                                                break;
                                            case 59:
                                                z += ";";
                                            default:
                                                if (f(K = L(z, n, r, P, T, l, R, N, B = [], H = [], O), h), 123 === $) {
                                                    if (0 === T) e(z, n, K, K, B, h, O, R, H);
                                                    else switch (99 === D && 110 === c(z, 3) ? 100 : D) {
                                                        case 100:
                                                        case 108:
                                                        case 109:
                                                        case 115:
                                                            e(t, K, K, o && f(L(t, K, K, 0, 0, l, R, N, l, B = [], O), H), l, H, O, R, o ? B : H);
                                                            break;
                                                        default:
                                                            e(z, K, K, K, [""], H, 0, R, H)
                                                    }
                                                }
                                        }
                                        P = T = A = 0, W = Z = 1, N = z = "", O = b;
                                        break;
                                    case 58:
                                        O = 1 + d(z), A = I;
                                    default:
                                        if (W < 1) {
                                            if (123 == $) --W;
                                            else if (125 == $ && 0 == W++ && 125 == (g = v > 0 ? c(y, --v) : 0, m--, 10 === g && (m = 1, p--), g)) continue
                                        }
                                        switch (z += i($), $ * W) {
                                            case 38:
                                                Z = T > 0 ? 1 : (z += "\f", -1);
                                                break;
                                            case 44:
                                                R[P++] = (d(z) - 1) * Z, Z = 1;
                                                break;
                                            case 64:
                                                45 === E() && (z += M(x())), D = E(), T = O = d(N = z += function(e) {
                                                    for (; !C(E());) x();
                                                    return s(y, e, v)
                                                }(v)), $++;
                                                break;
                                            case 45:
                                                45 === I && 2 == d(z) && (W = 0)
                                        }
                                }
                                return h
                            }("", null, null, null, [""], t = R(t = e), 0, [0], t), y = "", n), O)
                        },
                        W = {
                            key: b,
                            sheet: new r({
                                key: b,
                                container: l,
                                nonce: e.nonce,
                                speedy: e.speedy,
                                prepend: e.prepend,
                                insertionPoint: e.insertionPoint
                            }),
                            nonce: e.nonce,
                            inserted: P,
                            registered: {},
                            insert: function(e, t, n, r) {
                                h = n, D(e ? e + "{" + t.styles + "}" : t.styles), r && (W.inserted[t.name] = !0)
                            }
                        };
                    return W.sheet.hydrate(T), W
                }
        },
        61404: function(e, t, n) {
            "use strict";
            n.d(t, {
                O: function() {
                    return m
                }
            });
            var r, o, i = {
                    animationIterationCount: 1,
                    aspectRatio: 1,
                    borderImageOutset: 1,
                    borderImageSlice: 1,
                    borderImageWidth: 1,
                    boxFlex: 1,
                    boxFlexGroup: 1,
                    boxOrdinalGroup: 1,
                    columnCount: 1,
                    columns: 1,
                    flex: 1,
                    flexGrow: 1,
                    flexPositive: 1,
                    flexShrink: 1,
                    flexNegative: 1,
                    flexOrder: 1,
                    gridRow: 1,
                    gridRowEnd: 1,
                    gridRowSpan: 1,
                    gridRowStart: 1,
                    gridColumn: 1,
                    gridColumnEnd: 1,
                    gridColumnSpan: 1,
                    gridColumnStart: 1,
                    msGridRow: 1,
                    msGridRowSpan: 1,
                    msGridColumn: 1,
                    msGridColumnSpan: 1,
                    fontWeight: 1,
                    lineHeight: 1,
                    opacity: 1,
                    order: 1,
                    orphans: 1,
                    tabSize: 1,
                    widows: 1,
                    zIndex: 1,
                    zoom: 1,
                    WebkitLineClamp: 1,
                    fillOpacity: 1,
                    floodOpacity: 1,
                    stopOpacity: 1,
                    strokeDasharray: 1,
                    strokeDashoffset: 1,
                    strokeMiterlimit: 1,
                    strokeOpacity: 1,
                    strokeWidth: 1
                },
                l = /[A-Z]|^ms/g,
                a = /_EMO_([^_]+?)_([^]*?)_EMO_/g,
                u = function(e) {
                    return 45 === e.charCodeAt(1)
                },
                c = function(e) {
                    return null != e && "boolean" != typeof e
                },
                s = (r = Object.create(null), function(e) {
                    return void 0 === r[e] && (r[e] = u(e) ? e : e.replace(l, "-$&").toLowerCase()), r[e]
                }),
                d = function(e, t) {
                    switch (e) {
                        case "animation":
                        case "animationName":
                            if ("string" == typeof t) return t.replace(a, function(e, t, n) {
                                return o = {
                                    name: t,
                                    styles: n,
                                    next: o
                                }, t
                            })
                    }
                    return 1 === i[e] || u(e) || "number" != typeof t || 0 === t ? t : t + "px"
                };

            function f(e, t, n) {
                if (null == n) return "";
                if (void 0 !== n.__emotion_styles) return n;
                switch (typeof n) {
                    case "boolean":
                        return "";
                    case "object":
                        if (1 === n.anim) return o = {
                            name: n.name,
                            styles: n.styles,
                            next: o
                        }, n.name;
                        if (void 0 !== n.styles) {
                            var r = n.next;
                            if (void 0 !== r)
                                for (; void 0 !== r;) o = {
                                    name: r.name,
                                    styles: r.styles,
                                    next: o
                                }, r = r.next;
                            return n.styles + ";"
                        }
                        return function(e, t, n) {
                            var r = "";
                            if (Array.isArray(n))
                                for (var o = 0; o < n.length; o++) r += f(e, t, n[o]) + ";";
                            else
                                for (var i in n) {
                                    var l = n[i];
                                    if ("object" != typeof l) null != t && void 0 !== t[l] ? r += i + "{" + t[l] + "}" : c(l) && (r += s(i) + ":" + d(i, l) + ";");
                                    else if (Array.isArray(l) && "string" == typeof l[0] && (null == t || void 0 === t[l[0]]))
                                        for (var a = 0; a < l.length; a++) c(l[a]) && (r += s(i) + ":" + d(i, l[a]) + ";");
                                    else {
                                        var u = f(e, t, l);
                                        switch (i) {
                                            case "animation":
                                            case "animationName":
                                                r += s(i) + ":" + u + ";";
                                                break;
                                            default:
                                                r += i + "{" + u + "}"
                                        }
                                    }
                                }
                            return r
                        }(e, t, n);
                    case "function":
                        if (void 0 !== e) {
                            var i = o,
                                l = n(e);
                            return o = i, f(e, t, l)
                        }
                }
                if (null == t) return n;
                var a = t[n];
                return void 0 !== a ? a : n
            }
            var p = /label:\s*([^\s;\n{]+)\s*(;|$)/g,
                m = function(e, t, n) {
                    if (1 === e.length && "object" == typeof e[0] && null !== e[0] && void 0 !== e[0].styles) return e[0];
                    var r, i = !0,
                        l = "";
                    o = void 0;
                    var a = e[0];
                    null == a || void 0 === a.raw ? (i = !1, l += f(n, t, a)) : l += a[0];
                    for (var u = 1; u < e.length; u++) l += f(n, t, e[u]), i && (l += a[u]);
                    p.lastIndex = 0;
                    for (var c = ""; null !== (r = p.exec(l));) c += "-" + r[1];
                    return {
                        name: function(e) {
                            for (var t, n = 0, r = 0, o = e.length; o >= 4; ++r, o -= 4) t = (65535 & (t = 255 & e.charCodeAt(r) | (255 & e.charCodeAt(++r)) << 8 | (255 & e.charCodeAt(++r)) << 16 | (255 & e.charCodeAt(++r)) << 24)) * 1540483477 + ((t >>> 16) * 59797 << 16), t ^= t >>> 24, n = (65535 & t) * 1540483477 + ((t >>> 16) * 59797 << 16) ^ (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16);
                            switch (o) {
                                case 3:
                                    n ^= (255 & e.charCodeAt(r + 2)) << 16;
                                case 2:
                                    n ^= (255 & e.charCodeAt(r + 1)) << 8;
                                case 1:
                                    n ^= 255 & e.charCodeAt(r), n = (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16)
                            }
                            return n ^= n >>> 13, (((n = (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16)) ^ n >>> 15) >>> 0).toString(36)
                        }(l) + c,
                        styles: l,
                        next: o
                    }
                }
        },
        66347: function(e, t, n) {
            "use strict";

            function r(e, t, n) {
                var r = "";
                return n.split(" ").forEach(function(n) {
                    void 0 !== e[n] ? t.push(e[n] + ";") : r += n + " "
                }), r
            }
            n.d(t, {
                My: function() {
                    return i
                },
                fp: function() {
                    return r
                },
                hC: function() {
                    return o
                }
            });
            var o = function(e, t, n) {
                    var r = e.key + "-" + t.name;
                    !1 === n && void 0 === e.registered[r] && (e.registered[r] = t.styles)
                },
                i = function(e, t, n) {
                    o(e, t, n);
                    var r = e.key + "-" + t.name;
                    if (void 0 === e.inserted[t.name]) {
                        var i = t;
                        do e.insert(t === i ? "." + r : "", i, e.sheet, !0), i = i.next; while (void 0 !== i)
                    }
                }
        },
        68539: function(e, t, n) {
            "use strict";
            n.d(t, {
                B: function() {
                    return a
                }
            });
            var r = n(70079),
                o = n(36646),
                i = n(49270),
                l = n(94251);

            function a(e) {
                let t = e + "CollectionProvider",
                    [n, a] = (0, o.b)(t),
                    [u, c] = n(t, {
                        collectionRef: {
                            current: null
                        },
                        itemMap: new Map
                    }),
                    s = e => {
                        let {
                            scope: t,
                            children: n
                        } = e, o = r.useRef(null), i = r.useRef(new Map).current;
                        return r.createElement(u, {
                            scope: t,
                            itemMap: i,
                            collectionRef: o
                        }, n)
                    },
                    d = e + "CollectionSlot",
                    f = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o
                        } = e, a = c(d, n), u = (0, i.e)(t, a.collectionRef);
                        return r.createElement(l.g7, {
                            ref: u
                        }, o)
                    }),
                    p = e + "CollectionItemSlot",
                    m = "data-radix-collection-item",
                    h = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o,
                            ...a
                        } = e, u = r.useRef(null), s = (0, i.e)(t, u), d = c(p, n);
                        return r.useEffect(() => (d.itemMap.set(u, {
                            ref: u,
                            ...a
                        }), () => void d.itemMap.delete(u))), r.createElement(l.g7, {
                            [m]: "",
                            ref: s
                        }, o)
                    });
                return [{
                    Provider: s,
                    Slot: f,
                    ItemSlot: h
                }, function(t) {
                    let n = c(e + "CollectionConsumer", t),
                        o = r.useCallback(() => {
                            let e = n.collectionRef.current;
                            if (!e) return [];
                            let t = Array.from(e.querySelectorAll(`[${m}]`)),
                                r = Array.from(n.itemMap.values()),
                                o = r.sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
                            return o
                        }, [n.collectionRef, n.itemMap]);
                    return o
                }, a]
            }
        },
        28036: function(e, t, n) {
            "use strict";
            n.d(t, {
                gm: function() {
                    return i
                }
            });
            var r = n(70079);
            let o = (0, r.createContext)(void 0);

            function i(e) {
                let t = (0, r.useContext)(o);
                return e || t || "ltr"
            }
        },
        47428: function(e, t, n) {
            "use strict";
            n.d(t, {
                VY: function() {
                    return eW
                },
                ck: function() {
                    return eZ
                },
                __: function() {
                    return eV
                },
                Uv: function() {
                    return eF
                },
                Ee: function() {
                    return e$
                },
                Rk: function() {
                    return eN
                },
                fC: function() {
                    return eI
                },
                xz: function() {
                    return eL
                }
            });
            var r = n(45675),
                o = n(70079),
                i = n(72901),
                l = n(49270),
                a = n(36646),
                u = n(86004),
                c = n(39073),
                s = n(68539),
                d = n(28036),
                f = n(49515),
                p = n(54386),
                m = n(44480),
                h = n(88817),
                v = n(25373),
                g = n(67323),
                y = n(55691),
                w = n(83208),
                b = n(94251),
                x = n(9137),
                E = n(66546),
                C = n(54239);
            let R = ["Enter", " "],
                M = ["ArrowUp", "PageDown", "End"],
                S = ["ArrowDown", "PageUp", "Home", ...M],
                k = {
                    ltr: [...R, "ArrowRight"],
                    rtl: [...R, "ArrowLeft"]
                },
                P = {
                    ltr: ["ArrowLeft"],
                    rtl: ["ArrowRight"]
                },
                _ = "Menu",
                [T, O, D] = (0, s.B)(_),
                [A, I] = (0, a.b)(_, [D, v.D7, w.Pc]),
                L = (0, v.D7)(),
                F = (0, w.Pc)(),
                [W, V] = A(_),
                [Z, $] = A(_),
                N = e => {
                    let {
                        __scopeMenu: t,
                        open: n = !1,
                        children: r,
                        dir: i,
                        onOpenChange: l,
                        modal: a = !0
                    } = e, u = L(t), [c, s] = (0, o.useState)(null), f = (0, o.useRef)(!1), p = (0, x.W)(l), m = (0, d.gm)(i);
                    return (0, o.useEffect)(() => {
                        let e = () => {
                                f.current = !0, document.addEventListener("pointerdown", t, {
                                    capture: !0,
                                    once: !0
                                }), document.addEventListener("pointermove", t, {
                                    capture: !0,
                                    once: !0
                                })
                            },
                            t = () => f.current = !1;
                        return document.addEventListener("keydown", e, {
                            capture: !0
                        }), () => {
                            document.removeEventListener("keydown", e, {
                                capture: !0
                            }), document.removeEventListener("pointerdown", t, {
                                capture: !0
                            }), document.removeEventListener("pointermove", t, {
                                capture: !0
                            })
                        }
                    }, []), (0, o.createElement)(v.fC, u, (0, o.createElement)(W, {
                        scope: t,
                        open: n,
                        onOpenChange: p,
                        content: c,
                        onContentChange: s
                    }, (0, o.createElement)(Z, {
                        scope: t,
                        onClose: (0, o.useCallback)(() => p(!1), [p]),
                        isUsingKeyboardRef: f,
                        dir: m,
                        modal: a
                    }, r)))
                },
                B = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...i
                    } = e, l = L(n);
                    return (0, o.createElement)(v.ee, (0, r.Z)({}, l, i, {
                        ref: t
                    }))
                }),
                H = "MenuPortal",
                [K, z] = A(H, {
                    forceMount: void 0
                }),
                j = e => {
                    let {
                        __scopeMenu: t,
                        forceMount: n,
                        children: r,
                        container: i
                    } = e, l = V(H, t);
                    return (0, o.createElement)(K, {
                        scope: t,
                        forceMount: n
                    }, (0, o.createElement)(y.z, {
                        present: n || l.open
                    }, (0, o.createElement)(g.h, {
                        asChild: !0,
                        container: i
                    }, r)))
                },
                U = "MenuContent",
                [G, q] = A(U),
                X = (0, o.forwardRef)((e, t) => {
                    let n = z(U, e.__scopeMenu),
                        {
                            forceMount: i = n.forceMount,
                            ...l
                        } = e,
                        a = V(U, e.__scopeMenu),
                        u = $(U, e.__scopeMenu);
                    return (0, o.createElement)(T.Provider, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(y.z, {
                        present: i || a.open
                    }, (0, o.createElement)(T.Slot, {
                        scope: e.__scopeMenu
                    }, u.modal ? (0, o.createElement)(Y, (0, r.Z)({}, l, {
                        ref: t
                    })) : (0, o.createElement)(J, (0, r.Z)({}, l, {
                        ref: t
                    })))))
                }),
                Y = (0, o.forwardRef)((e, t) => {
                    let n = V(U, e.__scopeMenu),
                        a = (0, o.useRef)(null),
                        u = (0, l.e)(t, a);
                    return (0, o.useEffect)(() => {
                        let e = a.current;
                        if (e) return (0, E.Ry)(e)
                    }, []), (0, o.createElement)(Q, (0, r.Z)({}, e, {
                        ref: u,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: n.open,
                        disableOutsideScroll: !0,
                        onFocusOutside: (0, i.M)(e.onFocusOutside, e => e.preventDefault(), {
                            checkForDefaultPrevented: !1
                        }),
                        onDismiss: () => n.onOpenChange(!1)
                    }))
                }),
                J = (0, o.forwardRef)((e, t) => {
                    let n = V(U, e.__scopeMenu);
                    return (0, o.createElement)(Q, (0, r.Z)({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        onDismiss: () => n.onOpenChange(!1)
                    }))
                }),
                Q = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        loop: a = !1,
                        trapFocus: u,
                        onOpenAutoFocus: c,
                        onCloseAutoFocus: s,
                        disableOutsidePointerEvents: d,
                        onEntryFocus: h,
                        onEscapeKeyDown: g,
                        onPointerDownOutside: y,
                        onFocusOutside: x,
                        onInteractOutside: E,
                        onDismiss: R,
                        disableOutsideScroll: k,
                        ...P
                    } = e, _ = V(U, n), T = $(U, n), D = L(n), A = F(n), I = O(n), [W, Z] = (0, o.useState)(null), N = (0, o.useRef)(null), B = (0, l.e)(t, N, _.onContentChange), H = (0, o.useRef)(0), K = (0, o.useRef)(""), z = (0, o.useRef)(0), j = (0, o.useRef)(null), q = (0, o.useRef)("right"), X = (0, o.useRef)(0), Y = k ? C.Z : o.Fragment, J = k ? {
                        as: b.g7,
                        allowPinchZoom: !0
                    } : void 0, Q = e => {
                        var t, n;
                        let r = K.current + e,
                            o = I().filter(e => !e.disabled),
                            i = document.activeElement,
                            l = null === (t = o.find(e => e.ref.current === i)) || void 0 === t ? void 0 : t.textValue,
                            a = o.map(e => e.textValue),
                            u = function(e, t, n) {
                                var r;
                                let o = t.length > 1 && Array.from(t).every(e => e === t[0]),
                                    i = o ? t[0] : t,
                                    l = n ? e.indexOf(n) : -1,
                                    a = (r = Math.max(l, 0), e.map((t, n) => e[(r + n) % e.length])),
                                    u = 1 === i.length;
                                u && (a = a.filter(e => e !== n));
                                let c = a.find(e => e.toLowerCase().startsWith(i.toLowerCase()));
                                return c !== n ? c : void 0
                            }(a, r, l),
                            c = null === (n = o.find(e => e.textValue === u)) || void 0 === n ? void 0 : n.ref.current;
                        ! function e(t) {
                            K.current = t, window.clearTimeout(H.current), "" !== t && (H.current = window.setTimeout(() => e(""), 1e3))
                        }(r), c && setTimeout(() => c.focus())
                    };
                    (0, o.useEffect)(() => () => window.clearTimeout(H.current), []), (0, p.EW)();
                    let ee = (0, o.useCallback)(e => {
                        var t, n;
                        let r = q.current === (null === (t = j.current) || void 0 === t ? void 0 : t.side);
                        return r && function(e, t) {
                            if (!t) return !1;
                            let n = {
                                x: e.clientX,
                                y: e.clientY
                            };
                            return function(e, t) {
                                let {
                                    x: n,
                                    y: r
                                } = e, o = !1;
                                for (let e = 0, i = t.length - 1; e < t.length; i = e++) {
                                    let l = t[e].x,
                                        a = t[e].y,
                                        u = t[i].x,
                                        c = t[i].y,
                                        s = a > r != c > r && n < (u - l) * (r - a) / (c - a) + l;
                                    s && (o = !o)
                                }
                                return o
                            }(n, t)
                        }(e, null === (n = j.current) || void 0 === n ? void 0 : n.area)
                    }, []);
                    return (0, o.createElement)(G, {
                        scope: n,
                        searchRef: K,
                        onItemEnter: (0, o.useCallback)(e => {
                            ee(e) && e.preventDefault()
                        }, [ee]),
                        onItemLeave: (0, o.useCallback)(e => {
                            var t;
                            ee(e) || (null === (t = N.current) || void 0 === t || t.focus(), Z(null))
                        }, [ee]),
                        onTriggerLeave: (0, o.useCallback)(e => {
                            ee(e) && e.preventDefault()
                        }, [ee]),
                        pointerGraceTimerRef: z,
                        onPointerGraceIntentChange: (0, o.useCallback)(e => {
                            j.current = e
                        }, [])
                    }, (0, o.createElement)(Y, J, (0, o.createElement)(m.M, {
                        asChild: !0,
                        trapped: u,
                        onMountAutoFocus: (0, i.M)(c, e => {
                            var t;
                            e.preventDefault(), null === (t = N.current) || void 0 === t || t.focus()
                        }),
                        onUnmountAutoFocus: s
                    }, (0, o.createElement)(f.XB, {
                        asChild: !0,
                        disableOutsidePointerEvents: d,
                        onEscapeKeyDown: g,
                        onPointerDownOutside: y,
                        onFocusOutside: x,
                        onInteractOutside: E,
                        onDismiss: R
                    }, (0, o.createElement)(w.fC, (0, r.Z)({
                        asChild: !0
                    }, A, {
                        dir: T.dir,
                        orientation: "vertical",
                        loop: a,
                        currentTabStopId: W,
                        onCurrentTabStopIdChange: Z,
                        onEntryFocus: (0, i.M)(h, e => {
                            T.isUsingKeyboardRef.current || e.preventDefault()
                        })
                    }), (0, o.createElement)(v.VY, (0, r.Z)({
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": ev(_.open),
                        "data-radix-menu-content": "",
                        dir: T.dir
                    }, D, P, {
                        ref: B,
                        style: {
                            outline: "none",
                            ...P.style
                        },
                        onKeyDown: (0, i.M)(P.onKeyDown, e => {
                            let t = e.target,
                                n = t.closest("[data-radix-menu-content]") === e.currentTarget,
                                r = e.ctrlKey || e.altKey || e.metaKey,
                                o = 1 === e.key.length;
                            n && ("Tab" === e.key && e.preventDefault(), !r && o && Q(e.key));
                            let i = N.current;
                            if (e.target !== i || !S.includes(e.key)) return;
                            e.preventDefault();
                            let l = I().filter(e => !e.disabled),
                                a = l.map(e => e.ref.current);
                            M.includes(e.key) && a.reverse(),
                                function(e) {
                                    let t = document.activeElement;
                                    for (let n of e)
                                        if (n === t || (n.focus(), document.activeElement !== t)) return
                                }(a)
                        }),
                        onBlur: (0, i.M)(e.onBlur, e => {
                            e.currentTarget.contains(e.target) || (window.clearTimeout(H.current), K.current = "")
                        }),
                        onPointerMove: (0, i.M)(e.onPointerMove, ew(e => {
                            let t = e.target,
                                n = X.current !== e.clientX;
                            if (e.currentTarget.contains(t) && n) {
                                let t = e.clientX > X.current ? "right" : "left";
                                q.current = t, X.current = e.clientX
                            }
                        }))
                    })))))))
                }),
                ee = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...i
                    } = e;
                    return (0, o.createElement)(c.WV.div, (0, r.Z)({
                        role: "group"
                    }, i, {
                        ref: t
                    }))
                }),
                et = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...i
                    } = e;
                    return (0, o.createElement)(c.WV.div, (0, r.Z)({}, i, {
                        ref: t
                    }))
                }),
                en = "MenuItem",
                er = "menu.itemSelect",
                eo = (0, o.forwardRef)((e, t) => {
                    let {
                        disabled: n = !1,
                        onSelect: a,
                        ...u
                    } = e, s = (0, o.useRef)(null), d = $(en, e.__scopeMenu), f = q(en, e.__scopeMenu), p = (0, l.e)(t, s), m = (0, o.useRef)(!1), h = () => {
                        let e = s.current;
                        if (!n && e) {
                            let t = new CustomEvent(er, {
                                bubbles: !0,
                                cancelable: !0
                            });
                            e.addEventListener(er, e => null == a ? void 0 : a(e), {
                                once: !0
                            }), (0, c.jH)(e, t), t.defaultPrevented ? m.current = !1 : d.onClose()
                        }
                    };
                    return (0, o.createElement)(ei, (0, r.Z)({}, u, {
                        ref: p,
                        disabled: n,
                        onClick: (0, i.M)(e.onClick, h),
                        onPointerDown: t => {
                            var n;
                            null === (n = e.onPointerDown) || void 0 === n || n.call(e, t), m.current = !0
                        },
                        onPointerUp: (0, i.M)(e.onPointerUp, e => {
                            var t;
                            m.current || null === (t = e.currentTarget) || void 0 === t || t.click()
                        }),
                        onKeyDown: (0, i.M)(e.onKeyDown, e => {
                            let t = "" !== f.searchRef.current;
                            !n && (!t || " " !== e.key) && R.includes(e.key) && (e.currentTarget.click(), e.preventDefault())
                        })
                    }))
                }),
                ei = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        disabled: a = !1,
                        textValue: u,
                        ...s
                    } = e, d = q(en, n), f = F(n), p = (0, o.useRef)(null), m = (0, l.e)(t, p), [h, v] = (0, o.useState)(!1), [g, y] = (0, o.useState)("");
                    return (0, o.useEffect)(() => {
                        let e = p.current;
                        if (e) {
                            var t;
                            y((null !== (t = e.textContent) && void 0 !== t ? t : "").trim())
                        }
                    }, [s.children]), (0, o.createElement)(T.ItemSlot, {
                        scope: n,
                        disabled: a,
                        textValue: null != u ? u : g
                    }, (0, o.createElement)(w.ck, (0, r.Z)({
                        asChild: !0
                    }, f, {
                        focusable: !a
                    }), (0, o.createElement)(c.WV.div, (0, r.Z)({
                        role: "menuitem",
                        "data-highlighted": h ? "" : void 0,
                        "aria-disabled": a || void 0,
                        "data-disabled": a ? "" : void 0
                    }, s, {
                        ref: m,
                        onPointerMove: (0, i.M)(e.onPointerMove, ew(e => {
                            if (a) d.onItemLeave(e);
                            else if (d.onItemEnter(e), !e.defaultPrevented) {
                                let t = e.currentTarget;
                                t.focus()
                            }
                        })),
                        onPointerLeave: (0, i.M)(e.onPointerLeave, ew(e => d.onItemLeave(e))),
                        onFocus: (0, i.M)(e.onFocus, () => v(!0)),
                        onBlur: (0, i.M)(e.onBlur, () => v(!1))
                    }))))
                }),
                [el, ea] = ((e, t) => {
                    let {
                        checked: n = !1,
                        onCheckedChange: l,
                        ...a
                    } = e;
                    return (0, o.createElement)(ed, {
                        scope: e.__scopeMenu,
                        checked: n
                    }, (0, o.createElement)(eo, (0, r.Z)({
                        role: "menuitemcheckbox",
                        "aria-checked": eg(n) ? "mixed" : n
                    }, a, {
                        ref: t,
                        "data-state": ey(n),
                        onSelect: (0, i.M)(a.onSelect, () => null == l ? void 0 : l(!!eg(n) || !n), {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }, A("MenuRadioGroup", {
                    value: void 0,
                    onValueChange: () => {}
                })),
                eu = (0, o.forwardRef)((e, t) => {
                    let {
                        value: n,
                        onValueChange: i,
                        ...l
                    } = e, a = (0, x.W)(i);
                    return (0, o.createElement)(el, {
                        scope: e.__scopeMenu,
                        value: n,
                        onValueChange: a
                    }, (0, o.createElement)(ee, (0, r.Z)({}, l, {
                        ref: t
                    })))
                }),
                ec = (0, o.forwardRef)((e, t) => {
                    let {
                        value: n,
                        ...l
                    } = e, a = ea("MenuRadioItem", e.__scopeMenu), u = n === a.value;
                    return (0, o.createElement)(ed, {
                        scope: e.__scopeMenu,
                        checked: u
                    }, (0, o.createElement)(eo, (0, r.Z)({
                        role: "menuitemradio",
                        "aria-checked": u
                    }, l, {
                        ref: t,
                        "data-state": ey(u),
                        onSelect: (0, i.M)(l.onSelect, () => {
                            var e;
                            return null === (e = a.onValueChange) || void 0 === e ? void 0 : e.call(a, n)
                        }, {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                es = "MenuItemIndicator",
                [ed, ef] = A(es, {
                    checked: !1
                }),
                [ep, em] = ((e, t) => {
                    let {
                        __scopeMenu: n,
                        forceMount: i,
                        ...l
                    } = e, a = ef(es, n);
                    return (0, o.createElement)(y.z, {
                        present: i || eg(a.checked) || !0 === a.checked
                    }, (0, o.createElement)(c.WV.span, (0, r.Z)({}, l, {
                        ref: t,
                        "data-state": ey(a.checked)
                    })))
                }, A("MenuSub")),
                eh = "MenuSubTrigger";

            function ev(e) {
                return e ? "open" : "closed"
            }

            function eg(e) {
                return "indeterminate" === e
            }

            function ey(e) {
                return eg(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }

            function ew(e) {
                return t => "mouse" === t.pointerType ? e(t) : void 0
            }(e, t) => {
                let n = V(eh, e.__scopeMenu),
                    a = $(eh, e.__scopeMenu),
                    u = em(eh, e.__scopeMenu),
                    c = q(eh, e.__scopeMenu),
                    s = (0, o.useRef)(null),
                    {
                        pointerGraceTimerRef: d,
                        onPointerGraceIntentChange: f
                    } = c,
                    p = {
                        __scopeMenu: e.__scopeMenu
                    },
                    m = (0, o.useCallback)(() => {
                        s.current && window.clearTimeout(s.current), s.current = null
                    }, []);
                return (0, o.useEffect)(() => m, [m]), (0, o.useEffect)(() => {
                    let e = d.current;
                    return () => {
                        window.clearTimeout(e), f(null)
                    }
                }, [d, f]), (0, o.createElement)(B, (0, r.Z)({
                    asChild: !0
                }, p), (0, o.createElement)(ei, (0, r.Z)({
                    id: u.triggerId,
                    "aria-haspopup": "menu",
                    "aria-expanded": n.open,
                    "aria-controls": u.contentId,
                    "data-state": ev(n.open)
                }, e, {
                    ref: (0, l.F)(t, u.onTriggerChange),
                    onClick: t => {
                        var r;
                        null === (r = e.onClick) || void 0 === r || r.call(e, t), e.disabled || t.defaultPrevented || (t.currentTarget.focus(), n.open || n.onOpenChange(!0))
                    },
                    onPointerMove: (0, i.M)(e.onPointerMove, ew(t => {
                        c.onItemEnter(t), t.defaultPrevented || e.disabled || n.open || s.current || (c.onPointerGraceIntentChange(null), s.current = window.setTimeout(() => {
                            n.onOpenChange(!0), m()
                        }, 100))
                    })),
                    onPointerLeave: (0, i.M)(e.onPointerLeave, ew(e => {
                        var t, r;
                        m();
                        let o = null === (t = n.content) || void 0 === t ? void 0 : t.getBoundingClientRect();
                        if (o) {
                            let t = null === (r = n.content) || void 0 === r ? void 0 : r.dataset.side,
                                i = "right" === t,
                                l = o[i ? "left" : "right"],
                                a = o[i ? "right" : "left"];
                            c.onPointerGraceIntentChange({
                                area: [{
                                    x: e.clientX + (i ? -5 : 5),
                                    y: e.clientY
                                }, {
                                    x: l,
                                    y: o.top
                                }, {
                                    x: a,
                                    y: o.top
                                }, {
                                    x: a,
                                    y: o.bottom
                                }, {
                                    x: l,
                                    y: o.bottom
                                }],
                                side: t
                            }), window.clearTimeout(d.current), d.current = window.setTimeout(() => c.onPointerGraceIntentChange(null), 300)
                        } else {
                            if (c.onTriggerLeave(e), e.defaultPrevented) return;
                            c.onPointerGraceIntentChange(null)
                        }
                    })),
                    onKeyDown: (0, i.M)(e.onKeyDown, t => {
                        let r = "" !== c.searchRef.current;
                        if (!e.disabled && (!r || " " !== t.key) && k[a.dir].includes(t.key)) {
                            var o;
                            n.onOpenChange(!0), null === (o = n.content) || void 0 === o || o.focus(), t.preventDefault()
                        }
                    })
                })))
            }, (e, t) => {
                let n = z(U, e.__scopeMenu),
                    {
                        forceMount: a = n.forceMount,
                        ...u
                    } = e,
                    c = V(U, e.__scopeMenu),
                    s = $(U, e.__scopeMenu),
                    d = em("MenuSubContent", e.__scopeMenu),
                    f = (0, o.useRef)(null),
                    p = (0, l.e)(t, f);
                return (0, o.createElement)(T.Provider, {
                    scope: e.__scopeMenu
                }, (0, o.createElement)(y.z, {
                    present: a || c.open
                }, (0, o.createElement)(T.Slot, {
                    scope: e.__scopeMenu
                }, (0, o.createElement)(Q, (0, r.Z)({
                    id: d.contentId,
                    "aria-labelledby": d.triggerId
                }, u, {
                    ref: p,
                    align: "start",
                    side: "rtl" === s.dir ? "left" : "right",
                    disableOutsidePointerEvents: !1,
                    disableOutsideScroll: !1,
                    trapFocus: !1,
                    onOpenAutoFocus: e => {
                        var t;
                        s.isUsingKeyboardRef.current && (null === (t = f.current) || void 0 === t || t.focus()), e.preventDefault()
                    },
                    onCloseAutoFocus: e => e.preventDefault(),
                    onFocusOutside: (0, i.M)(e.onFocusOutside, e => {
                        e.target !== d.trigger && c.onOpenChange(!1)
                    }),
                    onEscapeKeyDown: (0, i.M)(e.onEscapeKeyDown, e => {
                        s.onClose(), e.preventDefault()
                    }),
                    onKeyDown: (0, i.M)(e.onKeyDown, e => {
                        let t = e.currentTarget.contains(e.target),
                            n = P[s.dir].includes(e.key);
                        if (t && n) {
                            var r;
                            c.onOpenChange(!1), null === (r = d.trigger) || void 0 === r || r.focus(), e.preventDefault()
                        }
                    })
                })))))
            };
            let eb = "DropdownMenu",
                [ex, eE] = (0, a.b)(eb, [I]),
                eC = I(),
                [eR, eM] = ex(eb),
                eS = e => {
                    let {
                        __scopeDropdownMenu: t,
                        children: n,
                        dir: i,
                        open: l,
                        defaultOpen: a,
                        onOpenChange: c,
                        modal: s = !0
                    } = e, d = eC(t), f = (0, o.useRef)(null), [p = !1, m] = (0, u.T)({
                        prop: l,
                        defaultProp: a,
                        onChange: c
                    });
                    return (0, o.createElement)(eR, {
                        scope: t,
                        triggerId: (0, h.M)(),
                        triggerRef: f,
                        contentId: (0, h.M)(),
                        open: p,
                        onOpenChange: m,
                        onOpenToggle: (0, o.useCallback)(() => m(e => !e), [m]),
                        modal: s
                    }, (0, o.createElement)(N, (0, r.Z)({}, d, {
                        open: p,
                        onOpenChange: m,
                        dir: i,
                        modal: s
                    }), n))
                },
                ek = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        disabled: a = !1,
                        ...u
                    } = e, s = eM("DropdownMenuTrigger", n), d = eC(n);
                    return (0, o.createElement)(B, (0, r.Z)({
                        asChild: !0
                    }, d), (0, o.createElement)(c.WV.button, (0, r.Z)({
                        type: "button",
                        id: s.triggerId,
                        "aria-haspopup": "menu",
                        "aria-expanded": s.open,
                        "aria-controls": s.open ? s.contentId : void 0,
                        "data-state": s.open ? "open" : "closed",
                        "data-disabled": a ? "" : void 0,
                        disabled: a
                    }, u, {
                        ref: (0, l.F)(t, s.triggerRef),
                        onPointerDown: (0, i.M)(e.onPointerDown, e => {
                            a || 0 !== e.button || !1 !== e.ctrlKey || (s.onOpenToggle(), s.open || e.preventDefault())
                        }),
                        onKeyDown: (0, i.M)(e.onKeyDown, e => {
                            !a && (["Enter", " "].includes(e.key) && s.onOpenToggle(), "ArrowDown" === e.key && s.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(e.key) && e.preventDefault())
                        })
                    })))
                }),
                eP = e => {
                    let {
                        __scopeDropdownMenu: t,
                        ...n
                    } = e, i = eC(t);
                    return (0, o.createElement)(j, (0, r.Z)({}, i, n))
                },
                e_ = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        ...l
                    } = e, a = eM("DropdownMenuContent", n), u = eC(n), c = (0, o.useRef)(!1);
                    return (0, o.createElement)(X, (0, r.Z)({
                        id: a.contentId,
                        "aria-labelledby": a.triggerId
                    }, u, l, {
                        ref: t,
                        onCloseAutoFocus: (0, i.M)(e.onCloseAutoFocus, e => {
                            var t;
                            c.current || null === (t = a.triggerRef.current) || void 0 === t || t.focus(), c.current = !1, e.preventDefault()
                        }),
                        onInteractOutside: (0, i.M)(e.onInteractOutside, e => {
                            let t = e.detail.originalEvent,
                                n = 0 === t.button && !0 === t.ctrlKey,
                                r = 2 === t.button || n;
                            (!a.modal || r) && (c.current = !0)
                        }),
                        style: { ...e.style,
                            "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                }),
                eT = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        ...i
                    } = e, l = eC(n);
                    return (0, o.createElement)(et, (0, r.Z)({}, l, i, {
                        ref: t
                    }))
                }),
                eO = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        ...i
                    } = e, l = eC(n);
                    return (0, o.createElement)(eo, (0, r.Z)({}, l, i, {
                        ref: t
                    }))
                }),
                eD = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        ...i
                    } = e, l = eC(n);
                    return (0, o.createElement)(eu, (0, r.Z)({}, l, i, {
                        ref: t
                    }))
                }),
                eA = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeDropdownMenu: n,
                        ...i
                    } = e, l = eC(n);
                    return (0, o.createElement)(ec, (0, r.Z)({}, l, i, {
                        ref: t
                    }))
                }),
                eI = eS,
                eL = ek,
                eF = eP,
                eW = e_,
                eV = eT,
                eZ = eO,
                e$ = eD,
                eN = eA
        },
        83208: function(e, t, n) {
            "use strict";
            n.d(t, {
                Pc: function() {
                    return x
                },
                ck: function() {
                    return T
                },
                fC: function() {
                    return _
                }
            });
            var r = n(45675),
                o = n(70079),
                i = n(72901),
                l = n(68539),
                a = n(49270),
                u = n(36646),
                c = n(88817),
                s = n(39073),
                d = n(9137),
                f = n(86004),
                p = n(28036);
            let m = "rovingFocusGroup.onEntryFocus",
                h = {
                    bubbles: !1,
                    cancelable: !0
                },
                v = "RovingFocusGroup",
                [g, y, w] = (0, l.B)(v),
                [b, x] = (0, u.b)(v, [w]),
                [E, C] = b(v),
                R = (0, o.forwardRef)((e, t) => (0, o.createElement)(g.Provider, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(g.Slot, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(M, (0, r.Z)({}, e, {
                    ref: t
                }))))),
                M = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        orientation: l,
                        loop: u = !1,
                        dir: c,
                        currentTabStopId: v,
                        defaultCurrentTabStopId: g,
                        onCurrentTabStopIdChange: w,
                        onEntryFocus: b,
                        ...x
                    } = e, C = (0, o.useRef)(null), R = (0, a.e)(t, C), M = (0, p.gm)(c), [S = null, k] = (0, f.T)({
                        prop: v,
                        defaultProp: g,
                        onChange: w
                    }), [_, T] = (0, o.useState)(!1), O = (0, d.W)(b), D = y(n), A = (0, o.useRef)(!1), [I, L] = (0, o.useState)(0);
                    return (0, o.useEffect)(() => {
                        let e = C.current;
                        if (e) return e.addEventListener(m, O), () => e.removeEventListener(m, O)
                    }, [O]), (0, o.createElement)(E, {
                        scope: n,
                        orientation: l,
                        dir: M,
                        loop: u,
                        currentTabStopId: S,
                        onItemFocus: (0, o.useCallback)(e => k(e), [k]),
                        onItemShiftTab: (0, o.useCallback)(() => T(!0), []),
                        onFocusableItemAdd: (0, o.useCallback)(() => L(e => e + 1), []),
                        onFocusableItemRemove: (0, o.useCallback)(() => L(e => e - 1), [])
                    }, (0, o.createElement)(s.WV.div, (0, r.Z)({
                        tabIndex: _ || 0 === I ? -1 : 0,
                        "data-orientation": l
                    }, x, {
                        ref: R,
                        style: {
                            outline: "none",
                            ...e.style
                        },
                        onMouseDown: (0, i.M)(e.onMouseDown, () => {
                            A.current = !0
                        }),
                        onFocus: (0, i.M)(e.onFocus, e => {
                            let t = !A.current;
                            if (e.target === e.currentTarget && t && !_) {
                                let t = new CustomEvent(m, h);
                                if (e.currentTarget.dispatchEvent(t), !t.defaultPrevented) {
                                    let e = D().filter(e => e.focusable),
                                        t = e.find(e => e.active),
                                        n = e.find(e => e.id === S),
                                        r = [t, n, ...e].filter(Boolean),
                                        o = r.map(e => e.ref.current);
                                    P(o)
                                }
                            }
                            A.current = !1
                        }),
                        onBlur: (0, i.M)(e.onBlur, () => T(!1))
                    })))
                }),
                S = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        focusable: l = !0,
                        active: a = !1,
                        tabStopId: u,
                        ...d
                    } = e, f = (0, c.M)(), p = u || f, m = C("RovingFocusGroupItem", n), h = m.currentTabStopId === p, v = y(n), {
                        onFocusableItemAdd: w,
                        onFocusableItemRemove: b
                    } = m;
                    return (0, o.useEffect)(() => {
                        if (l) return w(), () => b()
                    }, [l, w, b]), (0, o.createElement)(g.ItemSlot, {
                        scope: n,
                        id: p,
                        focusable: l,
                        active: a
                    }, (0, o.createElement)(s.WV.span, (0, r.Z)({
                        tabIndex: h ? 0 : -1,
                        "data-orientation": m.orientation
                    }, d, {
                        ref: t,
                        onMouseDown: (0, i.M)(e.onMouseDown, e => {
                            l ? m.onItemFocus(p) : e.preventDefault()
                        }),
                        onFocus: (0, i.M)(e.onFocus, () => m.onItemFocus(p)),
                        onKeyDown: (0, i.M)(e.onKeyDown, e => {
                            if ("Tab" === e.key && e.shiftKey) {
                                m.onItemShiftTab();
                                return
                            }
                            if (e.target !== e.currentTarget) return;
                            let t = function(e, t, n) {
                                var r;
                                let o = (r = e.key, "rtl" !== n ? r : "ArrowLeft" === r ? "ArrowRight" : "ArrowRight" === r ? "ArrowLeft" : r);
                                if (!("vertical" === t && ["ArrowLeft", "ArrowRight"].includes(o)) && !("horizontal" === t && ["ArrowUp", "ArrowDown"].includes(o))) return k[o]
                            }(e, m.orientation, m.dir);
                            if (void 0 !== t) {
                                e.preventDefault();
                                let o = v().filter(e => e.focusable),
                                    i = o.map(e => e.ref.current);
                                if ("last" === t) i.reverse();
                                else if ("prev" === t || "next" === t) {
                                    var n, r;
                                    "prev" === t && i.reverse();
                                    let o = i.indexOf(e.currentTarget);
                                    i = m.loop ? (n = i, r = o + 1, n.map((e, t) => n[(r + t) % n.length])) : i.slice(o + 1)
                                }
                                setTimeout(() => P(i))
                            }
                        })
                    })))
                }),
                k = {
                    ArrowLeft: "prev",
                    ArrowUp: "prev",
                    ArrowRight: "next",
                    ArrowDown: "next",
                    PageUp: "first",
                    Home: "first",
                    PageDown: "last",
                    End: "last"
                };

            function P(e) {
                let t = document.activeElement;
                for (let n of e)
                    if (n === t || (n.focus(), document.activeElement !== t)) return
            }
            let _ = R,
                T = S
        },
        51516: function(e, t, n) {
            "use strict";

            function r(e, t) {
                if (t.length < e) throw TypeError(e + " argument" + (e > 1 ? "s" : "") + " required, but only " + t.length + " present")
            }
            n.d(t, {
                Z: function() {
                    return r
                }
            })
        },
        17224: function(e, t, n) {
            "use strict";

            function r(e) {
                if (null === e || !0 === e || !1 === e) return NaN;
                var t = Number(e);
                return isNaN(t) ? t : t < 0 ? Math.ceil(t) : Math.floor(t)
            }
            n.d(t, {
                Z: function() {
                    return r
                }
            })
        },
        66293: function(e, t, n) {
            var r = n(73401).Symbol;
            e.exports = r
        },
        70331: function(e) {
            e.exports = function(e, t, n) {
                return e == e && (void 0 !== n && (e = e <= n ? e : n), void 0 !== t && (e = e >= t ? e : t)), e
            }
        },
        57398: function(e, t, n) {
            var r = n(66293),
                o = n(46945),
                i = n(51584),
                l = r ? r.toStringTag : void 0;
            e.exports = function(e) {
                return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : l && l in Object(e) ? o(e) : i(e)
            }
        },
        33897: function(e, t, n) {
            var r = n(15012),
                o = /^\s+/;
            e.exports = function(e) {
                return e ? e.slice(0, r(e) + 1).replace(o, "") : e
            }
        },
        40151: function(e, t, n) {
            var r = "object" == typeof n.g && n.g && n.g.Object === Object && n.g;
            e.exports = r
        },
        46945: function(e, t, n) {
            var r = n(66293),
                o = Object.prototype,
                i = o.hasOwnProperty,
                l = o.toString,
                a = r ? r.toStringTag : void 0;
            e.exports = function(e) {
                var t = i.call(e, a),
                    n = e[a];
                try {
                    e[a] = void 0;
                    var r = !0
                } catch (e) {}
                var o = l.call(e);
                return r && (t ? e[a] = n : delete e[a]), o
            }
        },
        51584: function(e) {
            var t = Object.prototype.toString;
            e.exports = function(e) {
                return t.call(e)
            }
        },
        73401: function(e, t, n) {
            var r = n(40151),
                o = "object" == typeof self && self && self.Object === Object && self,
                i = r || o || Function("return this")();
            e.exports = i
        },
        15012: function(e) {
            var t = /\s/;
            e.exports = function(e) {
                for (var n = e.length; n-- && t.test(e.charAt(n)););
                return n
            }
        },
        95182: function(e, t, n) {
            var r = n(70331),
                o = n(67948);
            e.exports = function(e, t, n) {
                return void 0 === n && (n = t, t = void 0), void 0 !== n && (n = (n = o(n)) == n ? n : 0), void 0 !== t && (t = (t = o(t)) == t ? t : 0), r(o(e), t, n)
            }
        },
        6627: function(e) {
            e.exports = function(e) {
                var t = typeof e;
                return null != e && ("object" == t || "function" == t)
            }
        },
        89109: function(e) {
            e.exports = function(e) {
                return null != e && "object" == typeof e
            }
        },
        42848: function(e, t, n) {
            var r = n(57398),
                o = n(89109);
            e.exports = function(e) {
                return "symbol" == typeof e || o(e) && "[object Symbol]" == r(e)
            }
        },
        67948: function(e, t, n) {
            var r = n(33897),
                o = n(6627),
                i = n(42848),
                l = 0 / 0,
                a = /^[-+]0x[0-9a-f]+$/i,
                u = /^0b[01]+$/i,
                c = /^0o[0-7]+$/i,
                s = parseInt;
            e.exports = function(e) {
                if ("number" == typeof e) return e;
                if (i(e)) return l;
                if (o(e)) {
                    var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                    e = o(t) ? t + "" : t
                }
                if ("string" != typeof e) return 0 === e ? e : +e;
                e = r(e);
                var n = u.test(e);
                return n || c.test(e) ? s(e.slice(2), n ? 2 : 8) : a.test(e) ? l : +e
            }
        },
        84256: function(e, t, n) {
            "use strict";

            function r(e) {
                return e.split("-")[1]
            }

            function o(e) {
                return "y" === e ? "height" : "width"
            }

            function i(e) {
                return e.split("-")[0]
            }

            function l(e) {
                return ["top", "bottom"].includes(i(e)) ? "x" : "y"
            }

            function a(e, t, n) {
                let a, {
                        reference: u,
                        floating: c
                    } = e,
                    s = u.x + u.width / 2 - c.width / 2,
                    d = u.y + u.height / 2 - c.height / 2,
                    f = l(t),
                    p = o(f),
                    m = u[p] / 2 - c[p] / 2,
                    h = "x" === f;
                switch (i(t)) {
                    case "top":
                        a = {
                            x: s,
                            y: u.y - c.height
                        };
                        break;
                    case "bottom":
                        a = {
                            x: s,
                            y: u.y + u.height
                        };
                        break;
                    case "right":
                        a = {
                            x: u.x + u.width,
                            y: d
                        };
                        break;
                    case "left":
                        a = {
                            x: u.x - c.width,
                            y: d
                        };
                        break;
                    default:
                        a = {
                            x: u.x,
                            y: u.y
                        }
                }
                switch (r(t)) {
                    case "start":
                        a[f] -= m * (n && h ? -1 : 1);
                        break;
                    case "end":
                        a[f] += m * (n && h ? -1 : 1)
                }
                return a
            }
            n.d(t, {
                Cp: function() {
                    return C
                },
                JB: function() {
                    return s
                },
                RR: function() {
                    return b
                },
                cv: function() {
                    return R
                },
                dp: function() {
                    return P
                },
                dr: function() {
                    return k
                },
                oo: function() {
                    return u
                },
                uY: function() {
                    return S
                },
                x7: function() {
                    return m
                }
            });
            let u = async (e, t, n) => {
                let {
                    placement: r = "bottom",
                    strategy: o = "absolute",
                    middleware: i = [],
                    platform: l
                } = n, u = i.filter(Boolean), c = await (null == l.isRTL ? void 0 : l.isRTL(t)), s = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: o
                }), {
                    x: d,
                    y: f
                } = a(s, r, c), p = r, m = {}, h = 0;
                for (let n = 0; n < u.length; n++) {
                    let {
                        name: i,
                        fn: v
                    } = u[n], {
                        x: g,
                        y: y,
                        data: w,
                        reset: b
                    } = await v({
                        x: d,
                        y: f,
                        initialPlacement: r,
                        placement: p,
                        strategy: o,
                        middlewareData: m,
                        rects: s,
                        platform: l,
                        elements: {
                            reference: e,
                            floating: t
                        }
                    });
                    d = null != g ? g : d, f = null != y ? y : f, m = { ...m,
                        [i]: { ...m[i],
                            ...w
                        }
                    }, b && h <= 50 && (h++, "object" == typeof b && (b.placement && (p = b.placement), b.rects && (s = !0 === b.rects ? await l.getElementRects({
                        reference: e,
                        floating: t,
                        strategy: o
                    }) : b.rects), {
                        x: d,
                        y: f
                    } = a(s, p, c)), n = -1)
                }
                return {
                    x: d,
                    y: f,
                    placement: p,
                    strategy: o,
                    middlewareData: m
                }
            };

            function c(e) {
                return "number" != typeof e ? {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    ...e
                } : {
                    top: e,
                    right: e,
                    bottom: e,
                    left: e
                }
            }

            function s(e) {
                return { ...e,
                    top: e.y,
                    left: e.x,
                    right: e.x + e.width,
                    bottom: e.y + e.height
                }
            }
            async function d(e, t) {
                var n;
                void 0 === t && (t = {});
                let {
                    x: r,
                    y: o,
                    platform: i,
                    rects: l,
                    elements: a,
                    strategy: u
                } = e, {
                    boundary: d = "clippingAncestors",
                    rootBoundary: f = "viewport",
                    elementContext: p = "floating",
                    altBoundary: m = !1,
                    padding: h = 0
                } = t, v = c(h), g = a[m ? "floating" === p ? "reference" : "floating" : p], y = s(await i.getClippingRect({
                    element: null == (n = await (null == i.isElement ? void 0 : i.isElement(g))) || n ? g : g.contextElement || await (null == i.getDocumentElement ? void 0 : i.getDocumentElement(a.floating)),
                    boundary: d,
                    rootBoundary: f,
                    strategy: u
                })), w = "floating" === p ? { ...l.floating,
                    x: r,
                    y: o
                } : l.reference, b = await (null == i.getOffsetParent ? void 0 : i.getOffsetParent(a.floating)), x = await (null == i.isElement ? void 0 : i.isElement(b)) && await (null == i.getScale ? void 0 : i.getScale(b)) || {
                    x: 1,
                    y: 1
                }, E = s(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
                    rect: w,
                    offsetParent: b,
                    strategy: u
                }) : w);
                return {
                    top: (y.top - E.top + v.top) / x.y,
                    bottom: (E.bottom - y.bottom + v.bottom) / x.y,
                    left: (y.left - E.left + v.left) / x.x,
                    right: (E.right - y.right + v.right) / x.x
                }
            }
            let f = Math.min,
                p = Math.max,
                m = e => ({
                    name: "arrow",
                    options: e,
                    async fn(t) {
                        let {
                            element: n,
                            padding: i = 0
                        } = e || {}, {
                            x: a,
                            y: u,
                            placement: s,
                            rects: d,
                            platform: m,
                            elements: h
                        } = t;
                        if (null == n) return {};
                        let v = c(i),
                            g = {
                                x: a,
                                y: u
                            },
                            y = l(s),
                            w = o(y),
                            b = await m.getDimensions(n),
                            x = "y" === y,
                            E = x ? "top" : "left",
                            C = x ? "bottom" : "right",
                            R = x ? "clientHeight" : "clientWidth",
                            M = d.reference[w] + d.reference[y] - g[y] - d.floating[w],
                            S = g[y] - d.reference[y],
                            k = await (null == m.getOffsetParent ? void 0 : m.getOffsetParent(n)),
                            P = k ? k[R] : 0;
                        P && await (null == m.isElement ? void 0 : m.isElement(k)) || (P = h.floating[R] || d.floating[w]);
                        let _ = v[E],
                            T = P - b[w] - v[C],
                            O = P / 2 - b[w] / 2 + (M / 2 - S / 2),
                            D = p(_, f(O, T)),
                            A = null != r(s) && O != D && d.reference[w] / 2 - (O < _ ? v[E] : v[C]) - b[w] / 2 < 0;
                        return {
                            [y]: g[y] - (A ? O < _ ? _ - O : T - O : 0),
                            data: {
                                [y]: D,
                                centerOffset: O - D
                            }
                        }
                    }
                }),
                h = ["top", "right", "bottom", "left"],
                v = (h.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []), {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                });

            function g(e) {
                return e.replace(/left|right|bottom|top/g, e => v[e])
            }
            let y = {
                start: "end",
                end: "start"
            };

            function w(e) {
                return e.replace(/start|end/g, e => y[e])
            }
            let b = function(e) {
                return void 0 === e && (e = {}), {
                    name: "flip",
                    options: e,
                    async fn(t) {
                        var n, a, u, c;
                        let {
                            placement: s,
                            middlewareData: f,
                            rects: p,
                            initialPlacement: m,
                            platform: h,
                            elements: v
                        } = t, {
                            mainAxis: y = !0,
                            crossAxis: b = !0,
                            fallbackPlacements: x,
                            fallbackStrategy: E = "bestFit",
                            fallbackAxisSideDirection: C = "none",
                            flipAlignment: R = !0,
                            ...M
                        } = e, S = i(s), k = i(m) === m, P = await (null == h.isRTL ? void 0 : h.isRTL(v.floating)), _ = x || (k || !R ? [g(m)] : function(e) {
                            let t = g(e);
                            return [w(e), t, w(t)]
                        }(m));
                        x || "none" === C || _.push(... function(e, t, n, o) {
                            let l = r(e),
                                a = function(e, t, n) {
                                    let r = ["left", "right"],
                                        o = ["right", "left"];
                                    switch (e) {
                                        case "top":
                                        case "bottom":
                                            return n ? t ? o : r : t ? r : o;
                                        case "left":
                                        case "right":
                                            return t ? ["top", "bottom"] : ["bottom", "top"];
                                        default:
                                            return []
                                    }
                                }(i(e), "start" === n, o);
                            return l && (a = a.map(e => e + "-" + l), t && (a = a.concat(a.map(w)))), a
                        }(m, R, C, P));
                        let T = [m, ..._],
                            O = await d(t, M),
                            D = [],
                            A = (null == (n = f.flip) ? void 0 : n.overflows) || [];
                        if (y && D.push(O[S]), b) {
                            let {
                                main: e,
                                cross: t
                            } = function(e, t, n) {
                                void 0 === n && (n = !1);
                                let i = r(e),
                                    a = l(e),
                                    u = o(a),
                                    c = "x" === a ? i === (n ? "end" : "start") ? "right" : "left" : "start" === i ? "bottom" : "top";
                                return t.reference[u] > t.floating[u] && (c = g(c)), {
                                    main: c,
                                    cross: g(c)
                                }
                            }(s, p, P);
                            D.push(O[e], O[t])
                        }
                        if (A = [...A, {
                                placement: s,
                                overflows: D
                            }], !D.every(e => e <= 0)) {
                            let e = ((null == (a = f.flip) ? void 0 : a.index) || 0) + 1,
                                t = T[e];
                            if (t) return {
                                data: {
                                    index: e,
                                    overflows: A
                                },
                                reset: {
                                    placement: t
                                }
                            };
                            let n = null == (u = A.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]) ? void 0 : u.placement;
                            if (!n) switch (E) {
                                case "bestFit":
                                    {
                                        let e = null == (c = A.map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]) ? void 0 : c[0];e && (n = e);
                                        break
                                    }
                                case "initialPlacement":
                                    n = m
                            }
                            if (s !== n) return {
                                reset: {
                                    placement: n
                                }
                            }
                        }
                        return {}
                    }
                }
            };

            function x(e, t) {
                return {
                    top: e.top - t.height,
                    right: e.right - t.width,
                    bottom: e.bottom - t.height,
                    left: e.left - t.width
                }
            }

            function E(e) {
                return h.some(t => e[t] >= 0)
            }
            let C = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "hide",
                        options: e,
                        async fn(t) {
                            let {
                                strategy: n = "referenceHidden",
                                ...r
                            } = e, {
                                rects: o
                            } = t;
                            switch (n) {
                                case "referenceHidden":
                                    {
                                        let e = x(await d(t, { ...r,
                                            elementContext: "reference"
                                        }), o.reference);
                                        return {
                                            data: {
                                                referenceHiddenOffsets: e,
                                                referenceHidden: E(e)
                                            }
                                        }
                                    }
                                case "escaped":
                                    {
                                        let e = x(await d(t, { ...r,
                                            altBoundary: !0
                                        }), o.floating);
                                        return {
                                            data: {
                                                escapedOffsets: e,
                                                escaped: E(e)
                                            }
                                        }
                                    }
                                default:
                                    return {}
                            }
                        }
                    }
                },
                R = function(e) {
                    return void 0 === e && (e = 0), {
                        name: "offset",
                        options: e,
                        async fn(t) {
                            let {
                                x: n,
                                y: o
                            } = t, a = await async function(e, t) {
                                let {
                                    placement: n,
                                    platform: o,
                                    elements: a
                                } = e, u = await (null == o.isRTL ? void 0 : o.isRTL(a.floating)), c = i(n), s = r(n), d = "x" === l(n), f = ["left", "top"].includes(c) ? -1 : 1, p = u && d ? -1 : 1, m = "function" == typeof t ? t(e) : t, {
                                    mainAxis: h,
                                    crossAxis: v,
                                    alignmentAxis: g
                                } = "number" == typeof m ? {
                                    mainAxis: m,
                                    crossAxis: 0,
                                    alignmentAxis: null
                                } : {
                                    mainAxis: 0,
                                    crossAxis: 0,
                                    alignmentAxis: null,
                                    ...m
                                };
                                return s && "number" == typeof g && (v = "end" === s ? -1 * g : g), d ? {
                                    x: v * p,
                                    y: h * f
                                } : {
                                    x: h * f,
                                    y: v * p
                                }
                            }(t, e);
                            return {
                                x: n + a.x,
                                y: o + a.y,
                                data: a
                            }
                        }
                    }
                };

            function M(e) {
                return "x" === e ? "y" : "x"
            }
            let S = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "shift",
                        options: e,
                        async fn(t) {
                            let {
                                x: n,
                                y: r,
                                placement: o
                            } = t, {
                                mainAxis: a = !0,
                                crossAxis: u = !1,
                                limiter: c = {
                                    fn: e => {
                                        let {
                                            x: t,
                                            y: n
                                        } = e;
                                        return {
                                            x: t,
                                            y: n
                                        }
                                    }
                                },
                                ...s
                            } = e, m = {
                                x: n,
                                y: r
                            }, h = await d(t, s), v = l(i(o)), g = M(v), y = m[v], w = m[g];
                            a && (y = p(y + h["y" === v ? "top" : "left"], f(y, y - h["y" === v ? "bottom" : "right"]))), u && (w = p(w + h["y" === g ? "top" : "left"], f(w, w - h["y" === g ? "bottom" : "right"])));
                            let b = c.fn({ ...t,
                                [v]: y,
                                [g]: w
                            });
                            return { ...b,
                                data: {
                                    x: b.x - n,
                                    y: b.y - r
                                }
                            }
                        }
                    }
                },
                k = function(e) {
                    return void 0 === e && (e = {}), {
                        options: e,
                        fn(t) {
                            let {
                                x: n,
                                y: r,
                                placement: o,
                                rects: a,
                                middlewareData: u
                            } = t, {
                                offset: c = 0,
                                mainAxis: s = !0,
                                crossAxis: d = !0
                            } = e, f = {
                                x: n,
                                y: r
                            }, p = l(o), m = M(p), h = f[p], v = f[m], g = "function" == typeof c ? c(t) : c, y = "number" == typeof g ? {
                                mainAxis: g,
                                crossAxis: 0
                            } : {
                                mainAxis: 0,
                                crossAxis: 0,
                                ...g
                            };
                            if (s) {
                                let e = "y" === p ? "height" : "width",
                                    t = a.reference[p] - a.floating[e] + y.mainAxis,
                                    n = a.reference[p] + a.reference[e] - y.mainAxis;
                                h < t ? h = t : h > n && (h = n)
                            }
                            if (d) {
                                var w, b;
                                let e = "y" === p ? "width" : "height",
                                    t = ["top", "left"].includes(i(o)),
                                    n = a.reference[m] - a.floating[e] + (t && (null == (w = u.offset) ? void 0 : w[m]) || 0) + (t ? 0 : y.crossAxis),
                                    r = a.reference[m] + a.reference[e] + (t ? 0 : (null == (b = u.offset) ? void 0 : b[m]) || 0) - (t ? y.crossAxis : 0);
                                v < n ? v = n : v > r && (v = r)
                            }
                            return {
                                [p]: h,
                                [m]: v
                            }
                        }
                    }
                },
                P = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "size",
                        options: e,
                        async fn(t) {
                            let n, o;
                            let {
                                placement: a,
                                rects: u,
                                platform: c,
                                elements: s
                            } = t, {
                                apply: m = () => {},
                                ...h
                            } = e, v = await d(t, h), g = i(a), y = r(a), w = "x" === l(a), {
                                width: b,
                                height: x
                            } = u.floating;
                            "top" === g || "bottom" === g ? (n = g, o = y === (await (null == c.isRTL ? void 0 : c.isRTL(s.floating)) ? "start" : "end") ? "left" : "right") : (o = g, n = "end" === y ? "top" : "bottom");
                            let E = x - v[n],
                                C = b - v[o],
                                R = !t.middlewareData.shift,
                                M = E,
                                S = C;
                            if (w) {
                                let e = b - v.left - v.right;
                                S = y || R ? f(C, e) : e
                            } else {
                                let e = x - v.top - v.bottom;
                                M = y || R ? f(E, e) : e
                            }
                            if (R && !y) {
                                let e = p(v.left, 0),
                                    t = p(v.right, 0),
                                    n = p(v.top, 0),
                                    r = p(v.bottom, 0);
                                w ? S = b - 2 * (0 !== e || 0 !== t ? e + t : p(v.left, v.right)) : M = x - 2 * (0 !== n || 0 !== r ? n + r : p(v.top, v.bottom))
                            }
                            await m({ ...t,
                                availableWidth: S,
                                availableHeight: M
                            });
                            let k = await c.getDimensions(s.floating);
                            return b !== k.width || x !== k.height ? {
                                reset: {
                                    rects: !0
                                }
                            } : {}
                        }
                    }
                }
        },
        88905: function(e, t, n) {
            "use strict";
            n.d(t, {
                Me: function() {
                    return I
                },
                oo: function() {
                    return L
                }
            });
            var r = n(84256);

            function o(e) {
                var t;
                return (null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function i(e) {
                return o(e).getComputedStyle(e)
            }

            function l(e) {
                return e instanceof o(e).Node
            }

            function a(e) {
                return l(e) ? (e.nodeName || "").toLowerCase() : ""
            }

            function u(e) {
                return e instanceof o(e).HTMLElement
            }

            function c(e) {
                return e instanceof o(e).Element
            }

            function s(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof o(e).ShadowRoot || e instanceof ShadowRoot)
            }

            function d(e) {
                let {
                    overflow: t,
                    overflowX: n,
                    overflowY: r,
                    display: o
                } = i(e);
                return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !["inline", "contents"].includes(o)
            }

            function f(e) {
                let t = p(),
                    n = i(e);
                return "none" !== n.transform || "none" !== n.perspective || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "perspective", "filter"].some(e => (n.willChange || "").includes(e)) || ["paint", "layout", "strict", "content"].some(e => (n.contain || "").includes(e))
            }

            function p() {
                return !("undefined" == typeof CSS || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none")
            }

            function m(e) {
                return ["html", "body", "#document"].includes(a(e))
            }
            let h = Math.min,
                v = Math.max,
                g = Math.round;

            function y(e) {
                let t = i(e),
                    n = parseFloat(t.width) || 0,
                    r = parseFloat(t.height) || 0,
                    o = u(e),
                    l = o ? e.offsetWidth : n,
                    a = o ? e.offsetHeight : r,
                    c = g(n) !== l || g(r) !== a;
                return c && (n = l, r = a), {
                    width: n,
                    height: r,
                    fallback: c
                }
            }

            function w(e) {
                return c(e) ? e : e.contextElement
            }
            let b = {
                x: 1,
                y: 1
            };

            function x(e) {
                let t = w(e);
                if (!u(t)) return b;
                let n = t.getBoundingClientRect(),
                    {
                        width: r,
                        height: o,
                        fallback: i
                    } = y(t),
                    l = (i ? g(n.width) : n.width) / r,
                    a = (i ? g(n.height) : n.height) / o;
                return l && Number.isFinite(l) || (l = 1), a && Number.isFinite(a) || (a = 1), {
                    x: l,
                    y: a
                }
            }
            let E = {
                x: 0,
                y: 0
            };

            function C(e, t, n) {
                var r, i;
                if (void 0 === t && (t = !0), !p()) return E;
                let l = e ? o(e) : window;
                return !n || t && n !== l ? E : {
                    x: (null == (r = l.visualViewport) ? void 0 : r.offsetLeft) || 0,
                    y: (null == (i = l.visualViewport) ? void 0 : i.offsetTop) || 0
                }
            }

            function R(e, t, n, i) {
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                let l = e.getBoundingClientRect(),
                    a = w(e),
                    u = b;
                t && (i ? c(i) && (u = x(i)) : u = x(e));
                let s = C(a, n, i),
                    d = (l.left + s.x) / u.x,
                    f = (l.top + s.y) / u.y,
                    p = l.width / u.x,
                    m = l.height / u.y;
                if (a) {
                    let e = o(a),
                        t = i && c(i) ? o(i) : i,
                        n = e.frameElement;
                    for (; n && i && t !== e;) {
                        let e = x(n),
                            t = n.getBoundingClientRect(),
                            r = getComputedStyle(n);
                        t.x += (n.clientLeft + parseFloat(r.paddingLeft)) * e.x, t.y += (n.clientTop + parseFloat(r.paddingTop)) * e.y, d *= e.x, f *= e.y, p *= e.x, m *= e.y, d += t.x, f += t.y, n = o(n).frameElement
                    }
                }
                return (0, r.JB)({
                    width: p,
                    height: m,
                    x: d,
                    y: f
                })
            }

            function M(e) {
                return ((l(e) ? e.ownerDocument : e.document) || window.document).documentElement
            }

            function S(e) {
                return c(e) ? {
                    scrollLeft: e.scrollLeft,
                    scrollTop: e.scrollTop
                } : {
                    scrollLeft: e.pageXOffset,
                    scrollTop: e.pageYOffset
                }
            }

            function k(e) {
                return R(M(e)).left + S(e).scrollLeft
            }

            function P(e) {
                if ("html" === a(e)) return e;
                let t = e.assignedSlot || e.parentNode || s(e) && e.host || M(e);
                return s(t) ? t.host : t
            }

            function _(e, t) {
                var n;
                void 0 === t && (t = []);
                let r = function e(t) {
                        let n = P(t);
                        return m(n) ? n.ownerDocument.body : u(n) && d(n) ? n : e(n)
                    }(e),
                    i = r === (null == (n = e.ownerDocument) ? void 0 : n.body),
                    l = o(r);
                return i ? t.concat(l, l.visualViewport || [], d(r) ? r : []) : t.concat(r, _(r))
            }

            function T(e, t, n) {
                let l;
                if ("viewport" === t) l = function(e, t) {
                    let n = o(e),
                        r = M(e),
                        i = n.visualViewport,
                        l = r.clientWidth,
                        a = r.clientHeight,
                        u = 0,
                        c = 0;
                    if (i) {
                        l = i.width, a = i.height;
                        let e = p();
                        (!e || e && "fixed" === t) && (u = i.offsetLeft, c = i.offsetTop)
                    }
                    return {
                        width: l,
                        height: a,
                        x: u,
                        y: c
                    }
                }(e, n);
                else if ("document" === t) l = function(e) {
                    let t = M(e),
                        n = S(e),
                        r = e.ownerDocument.body,
                        o = v(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth),
                        l = v(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight),
                        a = -n.scrollLeft + k(e),
                        u = -n.scrollTop;
                    return "rtl" === i(r).direction && (a += v(t.clientWidth, r.clientWidth) - o), {
                        width: o,
                        height: l,
                        x: a,
                        y: u
                    }
                }(M(e));
                else if (c(t)) l = function(e, t) {
                    let n = R(e, !0, "fixed" === t),
                        r = n.top + e.clientTop,
                        o = n.left + e.clientLeft,
                        i = u(e) ? x(e) : {
                            x: 1,
                            y: 1
                        };
                    return {
                        width: e.clientWidth * i.x,
                        height: e.clientHeight * i.y,
                        x: o * i.x,
                        y: r * i.y
                    }
                }(t, n);
                else {
                    let n = C(e);
                    l = { ...t,
                        x: t.x - n.x,
                        y: t.y - n.y
                    }
                }
                return (0, r.JB)(l)
            }

            function O(e, t) {
                return u(e) && "fixed" !== i(e).position ? t ? t(e) : e.offsetParent : null
            }

            function D(e, t) {
                let n = o(e);
                if (!u(e)) return n;
                let r = O(e, t);
                for (; r && ["table", "td", "th"].includes(a(r)) && "static" === i(r).position;) r = O(r, t);
                return r && ("html" === a(r) || "body" === a(r) && "static" === i(r).position && !f(r)) ? n : r || function(e) {
                    let t = P(e);
                    for (; u(t) && !m(t);) {
                        if (f(t)) return t;
                        t = P(t)
                    }
                    return null
                }(e) || n
            }
            let A = {
                getClippingRect: function(e) {
                    let {
                        element: t,
                        boundary: n,
                        rootBoundary: r,
                        strategy: o
                    } = e, l = "clippingAncestors" === n ? function(e, t) {
                        let n = t.get(e);
                        if (n) return n;
                        let r = _(e).filter(e => c(e) && "body" !== a(e)),
                            o = null,
                            l = "fixed" === i(e).position,
                            u = l ? P(e) : e;
                        for (; c(u) && !m(u);) {
                            let t = i(u),
                                n = f(u);
                            n || "fixed" !== t.position || (o = null), (l ? !n && !o : !n && "static" === t.position && o && ["absolute", "fixed"].includes(o.position) || d(u) && !n && function e(t, n) {
                                let r = P(t);
                                return !(r === n || !c(r) || m(r)) && ("fixed" === i(r).position || e(r, n))
                            }(e, u)) ? r = r.filter(e => e !== u) : o = t, u = P(u)
                        }
                        return t.set(e, r), r
                    }(t, this._c) : [].concat(n), u = [...l, r], s = u[0], p = u.reduce((e, n) => {
                        let r = T(t, n, o);
                        return e.top = v(r.top, e.top), e.right = h(r.right, e.right), e.bottom = h(r.bottom, e.bottom), e.left = v(r.left, e.left), e
                    }, T(t, s, o));
                    return {
                        width: p.right - p.left,
                        height: p.bottom - p.top,
                        x: p.left,
                        y: p.top
                    }
                },
                convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
                    let {
                        rect: t,
                        offsetParent: n,
                        strategy: r
                    } = e, o = u(n), i = M(n);
                    if (n === i) return t;
                    let l = {
                            scrollLeft: 0,
                            scrollTop: 0
                        },
                        c = {
                            x: 1,
                            y: 1
                        },
                        s = {
                            x: 0,
                            y: 0
                        };
                    if ((o || !o && "fixed" !== r) && (("body" !== a(n) || d(i)) && (l = S(n)), u(n))) {
                        let e = R(n);
                        c = x(n), s.x = e.x + n.clientLeft, s.y = e.y + n.clientTop
                    }
                    return {
                        width: t.width * c.x,
                        height: t.height * c.y,
                        x: t.x * c.x - l.scrollLeft * c.x + s.x,
                        y: t.y * c.y - l.scrollTop * c.y + s.y
                    }
                },
                isElement: c,
                getDimensions: function(e) {
                    return y(e)
                },
                getOffsetParent: D,
                getDocumentElement: M,
                getScale: x,
                async getElementRects(e) {
                    let {
                        reference: t,
                        floating: n,
                        strategy: r
                    } = e, o = this.getOffsetParent || D, i = this.getDimensions;
                    return {
                        reference: function(e, t, n) {
                            let r = u(t),
                                o = M(t),
                                i = "fixed" === n,
                                l = R(e, !0, i, t),
                                c = {
                                    scrollLeft: 0,
                                    scrollTop: 0
                                },
                                s = {
                                    x: 0,
                                    y: 0
                                };
                            if (r || !r && !i) {
                                if (("body" !== a(t) || d(o)) && (c = S(t)), u(t)) {
                                    let e = R(t, !0, i, t);
                                    s.x = e.x + t.clientLeft, s.y = e.y + t.clientTop
                                } else o && (s.x = k(o))
                            }
                            return {
                                x: l.left + c.scrollLeft - s.x,
                                y: l.top + c.scrollTop - s.y,
                                width: l.width,
                                height: l.height
                            }
                        }(t, await o(n), r),
                        floating: {
                            x: 0,
                            y: 0,
                            ...await i(n)
                        }
                    }
                },
                getClientRects: e => Array.from(e.getClientRects()),
                isRTL: e => "rtl" === i(e).direction
            };

            function I(e, t, n, r) {
                void 0 === r && (r = {});
                let {
                    ancestorScroll: o = !0,
                    ancestorResize: i = !0,
                    elementResize: l = !0,
                    animationFrame: a = !1
                } = r, u = o || i ? [...c(e) ? _(e) : e.contextElement ? _(e.contextElement) : [], ..._(t)] : [];
                u.forEach(e => {
                    let t = !c(e) && e.toString().includes("V");
                    o && (!a || t) && e.addEventListener("scroll", n, {
                        passive: !0
                    }), i && e.addEventListener("resize", n)
                });
                let s, d = null;
                l && (d = new ResizeObserver(() => {
                    n()
                }), c(e) && !a && d.observe(e), c(e) || !e.contextElement || a || d.observe(e.contextElement), d.observe(t));
                let f = a ? R(e) : null;
                return a && function t() {
                    let r = R(e);
                    f && (r.x !== f.x || r.y !== f.y || r.width !== f.width || r.height !== f.height) && n(), f = r, s = requestAnimationFrame(t)
                }(), n(), () => {
                    var e;
                    u.forEach(e => {
                        o && e.removeEventListener("scroll", n), i && e.removeEventListener("resize", n)
                    }), null == (e = d) || e.disconnect(), d = null, a && cancelAnimationFrame(s)
                }
            }
            let L = (e, t, n) => {
                let o = new Map,
                    i = {
                        platform: A,
                        ...n
                    },
                    l = { ...i.platform,
                        _c: o
                    };
                return (0, r.oo)(e, t, { ...i,
                    platform: l
                })
            }
        },
        10132: function(e, t, n) {
            "use strict";

            function r(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }
            n.d(t, {
                M: function() {
                    return r
                }
            })
        },
        89340: function(e, t, n) {
            "use strict";
            n.d(t, {
                B: function() {
                    return a
                }
            });
            var r = n(70079),
                o = n(53559),
                i = n(68469),
                l = n(26739);

            function a(e) {
                let t = e + "CollectionProvider",
                    [n, a] = (0, o.b)(t),
                    [u, c] = n(t, {
                        collectionRef: {
                            current: null
                        },
                        itemMap: new Map
                    }),
                    s = e => {
                        let {
                            scope: t,
                            children: n
                        } = e, o = r.useRef(null), i = r.useRef(new Map).current;
                        return r.createElement(u, {
                            scope: t,
                            itemMap: i,
                            collectionRef: o
                        }, n)
                    },
                    d = e + "CollectionSlot",
                    f = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o
                        } = e, a = c(d, n), u = (0, i.e)(t, a.collectionRef);
                        return r.createElement(l.g7, {
                            ref: u
                        }, o)
                    }),
                    p = e + "CollectionItemSlot",
                    m = "data-radix-collection-item",
                    h = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o,
                            ...a
                        } = e, u = r.useRef(null), s = (0, i.e)(t, u), d = c(p, n);
                        return r.useEffect(() => (d.itemMap.set(u, {
                            ref: u,
                            ...a
                        }), () => void d.itemMap.delete(u))), r.createElement(l.g7, {
                            [m]: "",
                            ref: s
                        }, o)
                    });
                return [{
                    Provider: s,
                    Slot: f,
                    ItemSlot: h
                }, function(t) {
                    let n = c(e + "CollectionConsumer", t),
                        o = r.useCallback(() => {
                            let e = n.collectionRef.current;
                            if (!e) return [];
                            let t = Array.from(e.querySelectorAll(`[${m}]`)),
                                r = Array.from(n.itemMap.values()),
                                o = r.sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
                            return o
                        }, [n.collectionRef, n.itemMap]);
                    return o
                }, a]
            }
        },
        53559: function(e, t, n) {
            "use strict";
            n.d(t, {
                b: function() {
                    return o
                }
            });
            var r = n(70079);

            function o(e, t = []) {
                let n = [],
                    o = () => {
                        let t = n.map(e => (0, r.createContext)(e));
                        return function(n) {
                            let o = (null == n ? void 0 : n[e]) || t;
                            return (0, r.useMemo)(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: o
                                }
                            }), [n, o])
                        }
                    };
                return o.scopeName = e, [function(t, o) {
                    let i = (0, r.createContext)(o),
                        l = n.length;

                    function a(t) {
                        let {
                            scope: n,
                            children: o,
                            ...a
                        } = t, u = (null == n ? void 0 : n[e][l]) || i, c = (0, r.useMemo)(() => a, Object.values(a));
                        return (0, r.createElement)(u.Provider, {
                            value: c
                        }, o)
                    }
                    return n = [...n, o], a.displayName = t + "Provider", [a, function(n, a) {
                        let u = (null == a ? void 0 : a[e][l]) || i,
                            c = (0, r.useContext)(u);
                        if (c) return c;
                        if (void 0 !== o) return o;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let o = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e),
                                    i = o[`__scope${r}`];
                                return { ...t,
                                    ...i
                                }
                            }, {});
                            return (0, r.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: o
                            }), [o])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(o, ...t)]
            }
        },
        93372: function(e, t, n) {
            "use strict";
            let r;
            n.d(t, {
                I0: function() {
                    return g
                },
                XB: function() {
                    return f
                },
                fC: function() {
                    return v
                }
            });
            var o = n(45675),
                i = n(70079),
                l = n(10132),
                a = n(8859),
                u = n(68469),
                c = n(51629);
            let s = "dismissableLayer.update",
                d = (0, i.createContext)({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                f = (0, i.forwardRef)((e, t) => {
                    var n;
                    let {
                        disableOutsidePointerEvents: f = !1,
                        onEscapeKeyDown: p,
                        onPointerDownOutside: v,
                        onFocusOutside: g,
                        onInteractOutside: y,
                        onDismiss: w,
                        ...b
                    } = e, x = (0, i.useContext)(d), [E, C] = (0, i.useState)(null), R = null !== (n = null == E ? void 0 : E.ownerDocument) && void 0 !== n ? n : null == globalThis ? void 0 : globalThis.document, [, M] = (0, i.useState)({}), S = (0, u.e)(t, e => C(e)), k = Array.from(x.layers), [P] = [...x.layersWithOutsidePointerEventsDisabled].slice(-1), _ = k.indexOf(P), T = E ? k.indexOf(E) : -1, O = x.layersWithOutsidePointerEventsDisabled.size > 0, D = T >= _, A = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e),
                            r = (0, i.useRef)(!1),
                            o = (0, i.useRef)(() => {});
                        return (0, i.useEffect)(() => {
                            let e = e => {
                                    if (e.target && !r.current) {
                                        let r = {
                                            originalEvent: e
                                        };

                                        function i() {
                                            h("dismissableLayer.pointerDownOutside", n, r, {
                                                discrete: !0
                                            })
                                        }
                                        "touch" === e.pointerType ? (t.removeEventListener("click", o.current), o.current = i, t.addEventListener("click", o.current, {
                                            once: !0
                                        })) : i()
                                    }
                                    r.current = !1
                                },
                                i = window.setTimeout(() => {
                                    t.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(i), t.removeEventListener("pointerdown", e), t.removeEventListener("click", o.current)
                            }
                        }, [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...x.branches].some(e => e.contains(t));
                        !D || n || (null == v || v(e), null == y || y(e), e.defaultPrevented || null == w || w())
                    }, R), I = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e),
                            r = (0, i.useRef)(!1);
                        return (0, i.useEffect)(() => {
                            let e = e => {
                                e.target && !r.current && h("dismissableLayer.focusOutside", n, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }, [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }(e => {
                        let t = e.target,
                            n = [...x.branches].some(e => e.contains(t));
                        n || (null == g || g(e), null == y || y(e), e.defaultPrevented || null == w || w())
                    }, R);
                    return ! function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e);
                        (0, i.useEffect)(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e)
                        }, [n, t])
                    }(e => {
                        let t = T === x.layers.size - 1;
                        t && (null == p || p(e), !e.defaultPrevented && w && (e.preventDefault(), w()))
                    }, R), (0, i.useEffect)(() => {
                        if (E) return f && (0 === x.layersWithOutsidePointerEventsDisabled.size && (r = R.body.style.pointerEvents, R.body.style.pointerEvents = "none"), x.layersWithOutsidePointerEventsDisabled.add(E)), x.layers.add(E), m(), () => {
                            f && 1 === x.layersWithOutsidePointerEventsDisabled.size && (R.body.style.pointerEvents = r)
                        }
                    }, [E, R, f, x]), (0, i.useEffect)(() => () => {
                        E && (x.layers.delete(E), x.layersWithOutsidePointerEventsDisabled.delete(E), m())
                    }, [E, x]), (0, i.useEffect)(() => {
                        let e = () => M({});
                        return document.addEventListener(s, e), () => document.removeEventListener(s, e)
                    }, []), (0, i.createElement)(a.WV.div, (0, o.Z)({}, b, {
                        ref: S,
                        style: {
                            pointerEvents: O ? D ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: (0, l.M)(e.onFocusCapture, I.onFocusCapture),
                        onBlurCapture: (0, l.M)(e.onBlurCapture, I.onBlurCapture),
                        onPointerDownCapture: (0, l.M)(e.onPointerDownCapture, A.onPointerDownCapture)
                    }))
                }),
                p = (0, i.forwardRef)((e, t) => {
                    let n = (0, i.useContext)(d),
                        r = (0, i.useRef)(null),
                        l = (0, u.e)(t, r);
                    return (0, i.useEffect)(() => {
                        let e = r.current;
                        if (e) return n.branches.add(e), () => {
                            n.branches.delete(e)
                        }
                    }, [n.branches]), (0, i.createElement)(a.WV.div, (0, o.Z)({}, e, {
                        ref: l
                    }))
                });

            function m() {
                let e = new CustomEvent(s);
                document.dispatchEvent(e)
            }

            function h(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.target,
                    i = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                t && o.addEventListener(e, t, {
                    once: !0
                }), r ? (0, a.jH)(o, i) : o.dispatchEvent(i)
            }
            let v = f,
                g = p
        },
        32768: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return a
                }
            });
            var r = n(45675),
                o = n(70079),
                i = n(99581),
                l = n(8859);
            let a = (0, o.forwardRef)((e, t) => {
                var n;
                let {
                    container: a = null == globalThis ? void 0 : null === (n = globalThis.document) || void 0 === n ? void 0 : n.body,
                    ...u
                } = e;
                return a ? i.createPortal((0, o.createElement)(l.WV.div, (0, r.Z)({}, u, {
                    ref: t
                })), a) : null
            })
        },
        48349: function(e, t, n) {
            "use strict";
            let r;
            n.d(t, {
                VY: function() {
                    return e2
                },
                JO: function() {
                    return e5
                },
                ck: function() {
                    return e9
                },
                eT: function() {
                    return e7
                },
                h_: function() {
                    return e4
                },
                fC: function() {
                    return eQ
                },
                $G: function() {
                    return e8
                },
                u_: function() {
                    return e6
                },
                xz: function() {
                    return e0
                },
                B4: function() {
                    return e1
                },
                l_: function() {
                    return e3
                }
            });
            var o = n(45675),
                i = n(70079),
                l = n.t(i, 2),
                a = n(99581);

            function u(e, [t, n]) {
                return Math.min(n, Math.max(t, e))
            }
            var c = n(10132),
                s = n(89340),
                d = n(68469),
                f = n(53559);
            let p = (0, i.createContext)(void 0);
            var m = n(93372);
            let h = 0;

            function v() {
                let e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
            }
            var g = n(8859),
                y = n(51629);
            let w = "focusScope.autoFocusOnMount",
                b = "focusScope.autoFocusOnUnmount",
                x = {
                    bubbles: !1,
                    cancelable: !0
                },
                E = (0, i.forwardRef)((e, t) => {
                    let {
                        loop: n = !1,
                        trapped: r = !1,
                        onMountAutoFocus: l,
                        onUnmountAutoFocus: a,
                        ...u
                    } = e, [c, s] = (0, i.useState)(null), f = (0, y.W)(l), p = (0, y.W)(a), m = (0, i.useRef)(null), h = (0, d.e)(t, e => s(e)), v = (0, i.useRef)({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    (0, i.useEffect)(() => {
                        if (r) {
                            function e(e) {
                                if (v.paused || !c) return;
                                let t = e.target;
                                c.contains(t) ? m.current = t : M(m.current, {
                                    select: !0
                                })
                            }

                            function t(e) {
                                if (v.paused || !c) return;
                                let t = e.relatedTarget;
                                null === t || c.contains(t) || M(m.current, {
                                    select: !0
                                })
                            }
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            let n = new MutationObserver(function(e) {
                                let t = document.activeElement;
                                for (let n of e) n.removedNodes.length > 0 && !(null != c && c.contains(t)) && M(c)
                            });
                            return c && n.observe(c, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                            }
                        }
                    }, [r, c, v.paused]), (0, i.useEffect)(() => {
                        if (c) {
                            S.add(v);
                            let e = document.activeElement,
                                t = c.contains(e);
                            if (!t) {
                                let t = new CustomEvent(w, x);
                                c.addEventListener(w, f), c.dispatchEvent(t), t.defaultPrevented || (function(e, {
                                    select: t = !1
                                } = {}) {
                                    let n = document.activeElement;
                                    for (let r of e)
                                        if (M(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }(C(c).filter(e => "A" !== e.tagName), {
                                    select: !0
                                }), document.activeElement === e && M(c))
                            }
                            return () => {
                                c.removeEventListener(w, f), setTimeout(() => {
                                    let t = new CustomEvent(b, x);
                                    c.addEventListener(b, p), c.dispatchEvent(t), t.defaultPrevented || M(null != e ? e : document.body, {
                                        select: !0
                                    }), c.removeEventListener(b, p), S.remove(v)
                                }, 0)
                            }
                        }
                    }, [c, f, p, v]);
                    let E = (0, i.useCallback)(e => {
                        if (!n && !r || v.paused) return;
                        let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            o = document.activeElement;
                        if (t && o) {
                            let t = e.currentTarget,
                                [r, i] = function(e) {
                                    let t = C(e),
                                        n = R(t, e),
                                        r = R(t.reverse(), e);
                                    return [n, r]
                                }(t);
                            r && i ? e.shiftKey || o !== i ? e.shiftKey && o === r && (e.preventDefault(), n && M(i, {
                                select: !0
                            })) : (e.preventDefault(), n && M(r, {
                                select: !0
                            })) : o === t && e.preventDefault()
                        }
                    }, [n, r, v.paused]);
                    return (0, i.createElement)(g.WV.div, (0, o.Z)({
                        tabIndex: -1
                    }, u, {
                        ref: h,
                        onKeyDown: E
                    }))
                });

            function C(e) {
                let t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            let t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function R(e, t) {
                for (let n of e)
                    if (! function(e, {
                            upTo: t
                        }) {
                            if ("hidden" === getComputedStyle(e).visibility) return !0;
                            for (; e && (void 0 === t || e !== t);) {
                                if ("none" === getComputedStyle(e).display) return !0;
                                e = e.parentElement
                            }
                            return !1
                        }(n, {
                            upTo: t
                        })) return n
            }

            function M(e, {
                select: t = !1
            } = {}) {
                if (e && e.focus) {
                    var n;
                    let r = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== r && (n = e) instanceof HTMLInputElement && "select" in n && t && e.select()
                }
            }
            let S = (r = [], {
                add(e) {
                    let t = r[0];
                    e !== t && (null == t || t.pause()), (r = k(r, e)).unshift(e)
                },
                remove(e) {
                    var t;
                    null === (t = (r = k(r, e))[0]) || void 0 === t || t.resume()
                }
            });

            function k(e, t) {
                let n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
            var P = n(90671);
            let _ = l["useId".toString()] || (() => void 0),
                T = 0;

            function O(e) {
                let [t, n] = i.useState(_());
                return (0, P.b)(() => {
                    e || n(e => null != e ? e : String(T++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }
            var D = n(84256),
                A = n(88905);
            let I = e => {
                let {
                    element: t,
                    padding: n
                } = e;
                return {
                    name: "arrow",
                    options: e,
                    fn(e) {
                        if (t && ({}).hasOwnProperty.call(t, "current")) {
                            if (null != t.current) return (0, D.x7)({
                                element: t.current,
                                padding: n
                            }).fn(e)
                        } else if (t) return (0, D.x7)({
                            element: t,
                            padding: n
                        }).fn(e);
                        return {}
                    }
                }
            };
            var L = "undefined" != typeof document ? i.useLayoutEffect : i.useEffect;

            function F(e, t) {
                let n, r, o;
                if (e === t) return !0;
                if (typeof e != typeof t) return !1;
                if ("function" == typeof e && e.toString() === t.toString()) return !0;
                if (e && t && "object" == typeof e) {
                    if (Array.isArray(e)) {
                        if ((n = e.length) != t.length) return !1;
                        for (r = n; 0 != r--;)
                            if (!F(e[r], t[r])) return !1;
                        return !0
                    }
                    if ((n = (o = Object.keys(e)).length) !== Object.keys(t).length) return !1;
                    for (r = n; 0 != r--;)
                        if (!({}).hasOwnProperty.call(t, o[r])) return !1;
                    for (r = n; 0 != r--;) {
                        let n = o[r];
                        if (("_owner" !== n || !e.$$typeof) && !F(e[n], t[n])) return !1
                    }
                    return !0
                }
                return e != e && t != t
            }

            function W(e) {
                if ("undefined" == typeof window) return 1;
                let t = e.ownerDocument.defaultView || window;
                return t.devicePixelRatio || 1
            }

            function V(e, t) {
                let n = W(e);
                return Math.round(t * n) / n
            }

            function Z(e) {
                let t = i.useRef(e);
                return L(() => {
                    t.current = e
                }), t
            }
            let $ = (0, i.forwardRef)((e, t) => {
                    let {
                        children: n,
                        width: r = 10,
                        height: l = 5,
                        ...a
                    } = e;
                    return (0, i.createElement)(g.WV.svg, (0, o.Z)({}, a, {
                        ref: t,
                        width: r,
                        height: l,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none"
                    }), e.asChild ? n : (0, i.createElement)("polygon", {
                        points: "0,0 30,0 15,10"
                    }))
                }),
                N = "Popper",
                [B, H] = (0, f.b)(N),
                [K, z] = B(N),
                j = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [r, o] = (0, i.useState)(null);
                    return (0, i.createElement)(K, {
                        scope: t,
                        anchor: r,
                        onAnchorChange: o
                    }, n)
                },
                U = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: r,
                        ...l
                    } = e, a = z("PopperAnchor", n), u = (0, i.useRef)(null), c = (0, d.e)(t, u);
                    return (0, i.useEffect)(() => {
                        a.onAnchorChange((null == r ? void 0 : r.current) || u.current)
                    }), r ? null : (0, i.createElement)(g.WV.div, (0, o.Z)({}, l, {
                        ref: c
                    }))
                }),
                G = "PopperContent",
                [q, X] = B(G),
                Y = (0, i.forwardRef)((e, t) => {
                    var n, r, l, u, c, s, f, p;
                    let {
                        __scopePopper: m,
                        side: h = "bottom",
                        sideOffset: v = 0,
                        align: w = "center",
                        alignOffset: b = 0,
                        arrowPadding: x = 0,
                        collisionBoundary: E = [],
                        collisionPadding: C = 0,
                        sticky: R = "partial",
                        hideWhenDetached: M = !1,
                        avoidCollisions: S = !0,
                        onPlaced: k,
                        ..._
                    } = e, T = z(G, m), [O, $] = (0, i.useState)(null), N = (0, d.e)(t, e => $(e)), [B, H] = (0, i.useState)(null), K = function(e) {
                        let [t, n] = (0, i.useState)(void 0);
                        return (0, P.b)(() => {
                            if (e) {
                                n({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let r, o;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let i = t[0];
                                    if ("borderBoxSize" in i) {
                                        let e = i.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        r = t.inlineSize, o = t.blockSize
                                    } else r = e.offsetWidth, o = e.offsetHeight;
                                    n({
                                        width: r,
                                        height: o
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            n(void 0)
                        }, [e]), t
                    }(B), j = null !== (n = null == K ? void 0 : K.width) && void 0 !== n ? n : 0, U = null !== (r = null == K ? void 0 : K.height) && void 0 !== r ? r : 0, X = "number" == typeof C ? C : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...C
                    }, Y = Array.isArray(E) ? E : [E], J = Y.length > 0, en = {
                        padding: X,
                        boundary: Y.filter(Q),
                        altBoundary: J
                    }, {
                        refs: er,
                        floatingStyles: eo,
                        placement: ei,
                        isPositioned: el,
                        middlewareData: ea
                    } = function(e) {
                        void 0 === e && (e = {});
                        let {
                            placement: t = "bottom",
                            strategy: n = "absolute",
                            middleware: r = [],
                            platform: o,
                            elements: {
                                reference: l,
                                floating: u
                            } = {},
                            transform: c = !0,
                            whileElementsMounted: s,
                            open: d
                        } = e, [f, p] = i.useState({
                            x: 0,
                            y: 0,
                            strategy: n,
                            placement: t,
                            middlewareData: {},
                            isPositioned: !1
                        }), [m, h] = i.useState(r);
                        F(m, r) || h(r);
                        let [v, g] = i.useState(null), [y, w] = i.useState(null), b = i.useCallback(e => {
                            e != R.current && (R.current = e, g(e))
                        }, [g]), x = i.useCallback(e => {
                            e !== M.current && (M.current = e, w(e))
                        }, [w]), E = l || v, C = u || y, R = i.useRef(null), M = i.useRef(null), S = i.useRef(f), k = Z(s), P = Z(o), _ = i.useCallback(() => {
                            if (!R.current || !M.current) return;
                            let e = {
                                placement: t,
                                strategy: n,
                                middleware: m
                            };
                            P.current && (e.platform = P.current), (0, A.oo)(R.current, M.current, e).then(e => {
                                let t = { ...e,
                                    isPositioned: !0
                                };
                                T.current && !F(S.current, t) && (S.current = t, a.flushSync(() => {
                                    p(t)
                                }))
                            })
                        }, [m, t, n, P]);
                        L(() => {
                            !1 === d && S.current.isPositioned && (S.current.isPositioned = !1, p(e => ({ ...e,
                                isPositioned: !1
                            })))
                        }, [d]);
                        let T = i.useRef(!1);
                        L(() => (T.current = !0, () => {
                            T.current = !1
                        }), []), L(() => {
                            if (E && (R.current = E), C && (M.current = C), E && C) {
                                if (k.current) return k.current(E, C, _);
                                _()
                            }
                        }, [E, C, _, k]);
                        let O = i.useMemo(() => ({
                                reference: R,
                                floating: M,
                                setReference: b,
                                setFloating: x
                            }), [b, x]),
                            D = i.useMemo(() => ({
                                reference: E,
                                floating: C
                            }), [E, C]),
                            I = i.useMemo(() => {
                                let e = {
                                    position: n,
                                    left: 0,
                                    top: 0
                                };
                                if (!D.floating) return e;
                                let t = V(D.floating, f.x),
                                    r = V(D.floating, f.y);
                                return c ? { ...e,
                                    transform: "translate(" + t + "px, " + r + "px)",
                                    ...W(D.floating) >= 1.5 && {
                                        willChange: "transform"
                                    }
                                } : {
                                    position: n,
                                    left: t,
                                    top: r
                                }
                            }, [n, c, D.floating, f.x, f.y]);
                        return i.useMemo(() => ({ ...f,
                            update: _,
                            refs: O,
                            elements: D,
                            floatingStyles: I
                        }), [f, _, O, D, I])
                    }({
                        strategy: "fixed",
                        placement: h + ("center" !== w ? "-" + w : ""),
                        whileElementsMounted: A.Me,
                        elements: {
                            reference: T.anchor
                        },
                        middleware: [(0, D.cv)({
                            mainAxis: v + U,
                            alignmentAxis: b
                        }), S && (0, D.uY)({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === R ? (0, D.dr)() : void 0,
                            ...en
                        }), S && (0, D.RR)({ ...en
                        }), (0, D.dp)({ ...en,
                            apply: ({
                                elements: e,
                                rects: t,
                                availableWidth: n,
                                availableHeight: r
                            }) => {
                                let {
                                    width: o,
                                    height: i
                                } = t.reference, l = e.floating.style;
                                l.setProperty("--radix-popper-available-width", `${n}px`), l.setProperty("--radix-popper-available-height", `${r}px`), l.setProperty("--radix-popper-anchor-width", `${o}px`), l.setProperty("--radix-popper-anchor-height", `${i}px`)
                            }
                        }), B && I({
                            element: B,
                            padding: x
                        }), ee({
                            arrowWidth: j,
                            arrowHeight: U
                        }), M && (0, D.Cp)({
                            strategy: "referenceHidden"
                        })]
                    }), [eu, ec] = et(ei), es = (0, y.W)(k);
                    (0, P.b)(() => {
                        el && (null == es || es())
                    }, [el, es]);
                    let ed = null === (l = ea.arrow) || void 0 === l ? void 0 : l.x,
                        ef = null === (u = ea.arrow) || void 0 === u ? void 0 : u.y,
                        ep = (null === (c = ea.arrow) || void 0 === c ? void 0 : c.centerOffset) !== 0,
                        [em, eh] = (0, i.useState)();
                    return (0, P.b)(() => {
                        O && eh(window.getComputedStyle(O).zIndex)
                    }, [O]), (0, i.createElement)("div", {
                        ref: er.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...eo,
                            transform: el ? eo.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: em,
                            "--radix-popper-transform-origin": [null === (s = ea.transformOrigin) || void 0 === s ? void 0 : s.x, null === (f = ea.transformOrigin) || void 0 === f ? void 0 : f.y].join(" ")
                        },
                        dir: e.dir
                    }, (0, i.createElement)(q, {
                        scope: m,
                        placedSide: eu,
                        onArrowChange: H,
                        arrowX: ed,
                        arrowY: ef,
                        shouldHideArrow: ep
                    }, (0, i.createElement)(g.WV.div, (0, o.Z)({
                        "data-side": eu,
                        "data-align": ec
                    }, _, {
                        ref: N,
                        style: { ..._.style,
                            animation: el ? void 0 : "none",
                            opacity: null !== (p = ea.hide) && void 0 !== p && p.referenceHidden ? 0 : void 0
                        }
                    }))))
                }),
                J = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                };

            function Q(e) {
                return null !== e
            }
            let ee = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    var n, r, o, i, l;
                    let {
                        placement: a,
                        rects: u,
                        middlewareData: c
                    } = t, s = (null === (n = c.arrow) || void 0 === n ? void 0 : n.centerOffset) !== 0, d = s ? 0 : e.arrowWidth, f = s ? 0 : e.arrowHeight, [p, m] = et(a), h = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[m], v = (null !== (r = null === (o = c.arrow) || void 0 === o ? void 0 : o.x) && void 0 !== r ? r : 0) + d / 2, g = (null !== (i = null === (l = c.arrow) || void 0 === l ? void 0 : l.y) && void 0 !== i ? i : 0) + f / 2, y = "", w = "";
                    return "bottom" === p ? (y = s ? h : `${v}px`, w = `${-f}px`) : "top" === p ? (y = s ? h : `${v}px`, w = `${u.floating.height+f}px`) : "right" === p ? (y = `${-f}px`, w = s ? h : `${g}px`) : "left" === p && (y = `${u.floating.width+f}px`, w = s ? h : `${g}px`), {
                        data: {
                            x: y,
                            y: w
                        }
                    }
                }
            });

            function et(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            var en = n(32768),
                er = n(26739),
                eo = n(21381),
                ei = n(32148),
                el = n(66546),
                ea = n(54239);
            let eu = [" ", "Enter", "ArrowUp", "ArrowDown"],
                ec = [" ", "Enter"],
                es = "Select",
                [ed, ef, ep] = (0, s.B)(es),
                [em, eh] = (0, f.b)(es, [ep, H]),
                ev = H(),
                [eg, ey] = em(es),
                [ew, eb] = em(es),
                ex = e => {
                    let {
                        __scopeSelect: t,
                        children: n,
                        open: r,
                        defaultOpen: o,
                        onOpenChange: l,
                        value: a,
                        defaultValue: u,
                        onValueChange: c,
                        dir: s,
                        name: d,
                        autoComplete: f,
                        disabled: m,
                        required: h
                    } = e, v = ev(t), [g, y] = (0, i.useState)(null), [w, b] = (0, i.useState)(null), [x, E] = (0, i.useState)(!1), C = function(e) {
                        let t = (0, i.useContext)(p);
                        return e || t || "ltr"
                    }(s), [R = !1, M] = (0, eo.T)({
                        prop: r,
                        defaultProp: o,
                        onChange: l
                    }), [S, k] = (0, eo.T)({
                        prop: a,
                        defaultProp: u,
                        onChange: c
                    }), P = (0, i.useRef)(null), _ = !g || !!g.closest("form"), [T, D] = (0, i.useState)(new Set), A = Array.from(T).map(e => e.props.value).join(";");
                    return (0, i.createElement)(j, v, (0, i.createElement)(eg, {
                        required: h,
                        scope: t,
                        trigger: g,
                        onTriggerChange: y,
                        valueNode: w,
                        onValueNodeChange: b,
                        valueNodeHasChildren: x,
                        onValueNodeHasChildrenChange: E,
                        contentId: O(),
                        value: S,
                        onValueChange: k,
                        open: R,
                        onOpenChange: M,
                        dir: C,
                        triggerPointerDownPosRef: P,
                        disabled: m
                    }, (0, i.createElement)(ed.Provider, {
                        scope: t
                    }, (0, i.createElement)(ew, {
                        scope: e.__scopeSelect,
                        onNativeOptionAdd: (0, i.useCallback)(e => {
                            D(t => new Set(t).add(e))
                        }, []),
                        onNativeOptionRemove: (0, i.useCallback)(e => {
                            D(t => {
                                let n = new Set(t);
                                return n.delete(e), n
                            })
                        }, [])
                    }, n)), _ ? (0, i.createElement)(eX, {
                        key: A,
                        "aria-hidden": !0,
                        required: h,
                        tabIndex: -1,
                        name: d,
                        autoComplete: f,
                        value: S,
                        onChange: e => k(e.target.value),
                        disabled: m
                    }, void 0 === S ? (0, i.createElement)("option", {
                        value: ""
                    }) : null, Array.from(T)) : null))
                },
                eE = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        disabled: r = !1,
                        ...l
                    } = e, a = ev(n), u = ey("SelectTrigger", n), s = u.disabled || r, f = (0, d.e)(t, u.onTriggerChange), p = ef(n), [m, h, v] = eY(e => {
                        let t = p().filter(e => !e.disabled),
                            n = t.find(e => e.value === u.value),
                            r = eJ(t, e, n);
                        void 0 !== r && u.onValueChange(r.value)
                    }), y = () => {
                        s || (u.onOpenChange(!0), v())
                    };
                    return (0, i.createElement)(U, (0, o.Z)({
                        asChild: !0
                    }, a), (0, i.createElement)(g.WV.button, (0, o.Z)({
                        type: "button",
                        role: "combobox",
                        "aria-controls": u.contentId,
                        "aria-expanded": u.open,
                        "aria-required": u.required,
                        "aria-autocomplete": "none",
                        dir: u.dir,
                        "data-state": u.open ? "open" : "closed",
                        disabled: s,
                        "data-disabled": s ? "" : void 0,
                        "data-placeholder": void 0 === u.value ? "" : void 0
                    }, l, {
                        ref: f,
                        onClick: (0, c.M)(l.onClick, e => {
                            e.currentTarget.focus()
                        }),
                        onPointerDown: (0, c.M)(l.onPointerDown, e => {
                            let t = e.target;
                            t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId), 0 === e.button && !1 === e.ctrlKey && (y(), u.triggerPointerDownPosRef.current = {
                                x: Math.round(e.pageX),
                                y: Math.round(e.pageY)
                            }, e.preventDefault())
                        }),
                        onKeyDown: (0, c.M)(l.onKeyDown, e => {
                            let t = "" !== m.current,
                                n = e.ctrlKey || e.altKey || e.metaKey;
                            n || 1 !== e.key.length || h(e.key), (!t || " " !== e.key) && eu.includes(e.key) && (y(), e.preventDefault())
                        })
                    })))
                }),
                eC = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        className: r,
                        style: l,
                        children: a,
                        placeholder: u,
                        ...c
                    } = e, s = ey("SelectValue", n), {
                        onValueNodeHasChildrenChange: f
                    } = s, p = void 0 !== a, m = (0, d.e)(t, s.onValueNodeChange);
                    return (0, P.b)(() => {
                        f(p)
                    }, [f, p]), (0, i.createElement)(g.WV.span, (0, o.Z)({}, c, {
                        ref: m,
                        style: {
                            pointerEvents: "none"
                        }
                    }), void 0 === s.value && void 0 !== u ? u : a)
                }),
                eR = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        children: r,
                        ...l
                    } = e;
                    return (0, i.createElement)(g.WV.span, (0, o.Z)({
                        "aria-hidden": !0
                    }, l, {
                        ref: t
                    }), r || "▼")
                }),
                eM = e => (0, i.createElement)(en.h, (0, o.Z)({
                    asChild: !0
                }, e)),
                eS = "SelectContent",
                ek = (0, i.forwardRef)((e, t) => {
                    let n = ey(eS, e.__scopeSelect),
                        [r, l] = (0, i.useState)();
                    return ((0, P.b)(() => {
                        l(new DocumentFragment)
                    }, []), n.open) ? (0, i.createElement)(eT, (0, o.Z)({}, e, {
                        ref: t
                    })) : r ? (0, a.createPortal)((0, i.createElement)(eP, {
                        scope: e.__scopeSelect
                    }, (0, i.createElement)(ed.Slot, {
                        scope: e.__scopeSelect
                    }, (0, i.createElement)("div", null, e.children))), r) : null
                }),
                [eP, e_] = em(eS),
                eT = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        position: r = "item-aligned",
                        onCloseAutoFocus: l,
                        onEscapeKeyDown: a,
                        onPointerDownOutside: u,
                        side: s,
                        sideOffset: f,
                        align: p,
                        alignOffset: g,
                        arrowPadding: y,
                        collisionBoundary: w,
                        collisionPadding: b,
                        sticky: x,
                        hideWhenDetached: C,
                        avoidCollisions: R,
                        ...M
                    } = e, S = ey(eS, n), [k, P] = (0, i.useState)(null), [_, T] = (0, i.useState)(null), O = (0, d.e)(t, e => P(e)), [D, A] = (0, i.useState)(null), [I, L] = (0, i.useState)(null), F = ef(n), [W, V] = (0, i.useState)(!1), Z = (0, i.useRef)(!1);
                    (0, i.useEffect)(() => {
                        if (k) return (0, el.Ry)(k)
                    }, [k]), (0, i.useEffect)(() => {
                        var e, t;
                        let n = document.querySelectorAll("[data-radix-focus-guard]");
                        return document.body.insertAdjacentElement("afterbegin", null !== (e = n[0]) && void 0 !== e ? e : v()), document.body.insertAdjacentElement("beforeend", null !== (t = n[1]) && void 0 !== t ? t : v()), h++, () => {
                            1 === h && document.querySelectorAll("[data-radix-focus-guard]").forEach(e => e.remove()), h--
                        }
                    }, []);
                    let $ = (0, i.useCallback)(e => {
                            let [t, ...n] = F().map(e => e.ref.current), [r] = n.slice(-1), o = document.activeElement;
                            for (let n of e)
                                if (n === o || (null == n || n.scrollIntoView({
                                        block: "nearest"
                                    }), n === t && _ && (_.scrollTop = 0), n === r && _ && (_.scrollTop = _.scrollHeight), null == n || n.focus(), document.activeElement !== o)) return
                        }, [F, _]),
                        N = (0, i.useCallback)(() => $([D, k]), [$, D, k]);
                    (0, i.useEffect)(() => {
                        W && N()
                    }, [W, N]);
                    let {
                        onOpenChange: B,
                        triggerPointerDownPosRef: H
                    } = S;
                    (0, i.useEffect)(() => {
                        if (k) {
                            let e = {
                                    x: 0,
                                    y: 0
                                },
                                t = t => {
                                    var n, r, o, i;
                                    e = {
                                        x: Math.abs(Math.round(t.pageX) - (null !== (n = null === (r = H.current) || void 0 === r ? void 0 : r.x) && void 0 !== n ? n : 0)),
                                        y: Math.abs(Math.round(t.pageY) - (null !== (o = null === (i = H.current) || void 0 === i ? void 0 : i.y) && void 0 !== o ? o : 0))
                                    }
                                },
                                n = n => {
                                    e.x <= 10 && e.y <= 10 ? n.preventDefault() : k.contains(n.target) || B(!1), document.removeEventListener("pointermove", t), H.current = null
                                };
                            return null !== H.current && (document.addEventListener("pointermove", t), document.addEventListener("pointerup", n, {
                                capture: !0,
                                once: !0
                            })), () => {
                                document.removeEventListener("pointermove", t), document.removeEventListener("pointerup", n, {
                                    capture: !0
                                })
                            }
                        }
                    }, [k, B, H]), (0, i.useEffect)(() => {
                        let e = () => B(!1);
                        return window.addEventListener("blur", e), window.addEventListener("resize", e), () => {
                            window.removeEventListener("blur", e), window.removeEventListener("resize", e)
                        }
                    }, [B]);
                    let [K, z] = eY(e => {
                        let t = F().filter(e => !e.disabled),
                            n = t.find(e => e.ref.current === document.activeElement),
                            r = eJ(t, e, n);
                        r && setTimeout(() => r.ref.current.focus())
                    }), j = (0, i.useCallback)((e, t, n) => {
                        let r = !Z.current && !n,
                            o = void 0 !== S.value && S.value === t;
                        (o || r) && (A(e), r && (Z.current = !0))
                    }, [S.value]), U = (0, i.useCallback)(() => null == k ? void 0 : k.focus(), [k]), G = (0, i.useCallback)((e, t, n) => {
                        let r = !Z.current && !n,
                            o = void 0 !== S.value && S.value === t;
                        (o || r) && L(e)
                    }, [S.value]), q = "popper" === r ? eD : eO;
                    return (0, i.createElement)(eP, {
                        scope: n,
                        content: k,
                        viewport: _,
                        onViewportChange: T,
                        itemRefCallback: j,
                        selectedItem: D,
                        onItemLeave: U,
                        itemTextRefCallback: G,
                        focusSelectedItem: N,
                        selectedItemText: I,
                        position: r,
                        isPositioned: W,
                        searchRef: K
                    }, (0, i.createElement)(ea.Z, {
                        as: er.g7,
                        allowPinchZoom: !0
                    }, (0, i.createElement)(E, {
                        asChild: !0,
                        trapped: S.open,
                        onMountAutoFocus: e => {
                            e.preventDefault()
                        },
                        onUnmountAutoFocus: (0, c.M)(l, e => {
                            var t;
                            null === (t = S.trigger) || void 0 === t || t.focus({
                                preventScroll: !0
                            }), e.preventDefault()
                        })
                    }, (0, i.createElement)(m.XB, {
                        asChild: !0,
                        disableOutsidePointerEvents: !0,
                        onEscapeKeyDown: a,
                        onPointerDownOutside: u,
                        onFocusOutside: e => e.preventDefault(),
                        onDismiss: () => S.onOpenChange(!1)
                    }, (0, i.createElement)(q, (0, o.Z)({
                        role: "listbox",
                        id: S.contentId,
                        "data-state": S.open ? "open" : "closed",
                        dir: S.dir,
                        onContextMenu: e => e.preventDefault()
                    }, M, q === eD ? {
                        side: s,
                        sideOffset: f,
                        align: p,
                        alignOffset: g,
                        arrowPadding: y,
                        collisionBoundary: w,
                        collisionPadding: b,
                        sticky: x,
                        hideWhenDetached: C,
                        avoidCollisions: R
                    } : {}, {
                        onPlaced: () => V(!0),
                        ref: O,
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            outline: "none",
                            ...M.style
                        },
                        onKeyDown: (0, c.M)(M.onKeyDown, e => {
                            let t = e.ctrlKey || e.altKey || e.metaKey;
                            if ("Tab" === e.key && e.preventDefault(), t || 1 !== e.key.length || z(e.key), ["ArrowUp", "ArrowDown", "Home", "End"].includes(e.key)) {
                                let t = F().filter(e => !e.disabled),
                                    n = t.map(e => e.ref.current);
                                if (["ArrowUp", "End"].includes(e.key) && (n = n.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(e.key)) {
                                    let t = e.target,
                                        r = n.indexOf(t);
                                    n = n.slice(r + 1)
                                }
                                setTimeout(() => $(n)), e.preventDefault()
                            }
                        })
                    }))))))
                }),
                eO = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        onPlaced: r,
                        ...l
                    } = e, a = ey(eS, n), c = e_(eS, n), [s, f] = (0, i.useState)(null), [p, m] = (0, i.useState)(null), h = (0, d.e)(t, e => m(e)), v = ef(n), y = (0, i.useRef)(!1), w = (0, i.useRef)(!0), {
                        viewport: b,
                        selectedItem: x,
                        selectedItemText: E,
                        focusSelectedItem: C
                    } = c, R = (0, i.useCallback)(() => {
                        if (a.trigger && a.valueNode && s && p && b && x && E) {
                            let e = a.trigger.getBoundingClientRect(),
                                t = p.getBoundingClientRect(),
                                n = a.valueNode.getBoundingClientRect(),
                                o = E.getBoundingClientRect();
                            if ("rtl" !== a.dir) {
                                let r = o.left - t.left,
                                    i = n.left - r,
                                    l = e.left - i,
                                    a = e.width + l,
                                    c = Math.max(a, t.width),
                                    d = window.innerWidth - 10,
                                    f = u(i, [10, d - c]);
                                s.style.minWidth = a + "px", s.style.left = f + "px"
                            } else {
                                let r = t.right - o.right,
                                    i = window.innerWidth - n.right - r,
                                    l = window.innerWidth - e.right - i,
                                    a = e.width + l,
                                    c = Math.max(a, t.width),
                                    d = window.innerWidth - 10,
                                    f = u(i, [10, d - c]);
                                s.style.minWidth = a + "px", s.style.right = f + "px"
                            }
                            let i = v(),
                                l = window.innerHeight - 20,
                                c = b.scrollHeight,
                                d = window.getComputedStyle(p),
                                f = parseInt(d.borderTopWidth, 10),
                                m = parseInt(d.paddingTop, 10),
                                h = parseInt(d.borderBottomWidth, 10),
                                g = parseInt(d.paddingBottom, 10),
                                w = f + m + c + g + h,
                                C = Math.min(5 * x.offsetHeight, w),
                                R = window.getComputedStyle(b),
                                M = parseInt(R.paddingTop, 10),
                                S = parseInt(R.paddingBottom, 10),
                                k = e.top + e.height / 2 - 10,
                                P = x.offsetHeight / 2,
                                _ = x.offsetTop + P,
                                T = f + m + _;
                            if (T <= k) {
                                let e = x === i[i.length - 1].ref.current;
                                s.style.bottom = "0px";
                                let t = p.clientHeight - b.offsetTop - b.offsetHeight;
                                s.style.height = T + Math.max(l - k, P + (e ? S : 0) + t + h) + "px"
                            } else {
                                let e = x === i[0].ref.current;
                                s.style.top = "0px";
                                let t = Math.max(k, f + b.offsetTop + (e ? M : 0) + P);
                                s.style.height = t + (w - T) + "px", b.scrollTop = T - k + b.offsetTop
                            }
                            s.style.margin = "10px 0", s.style.minHeight = C + "px", s.style.maxHeight = l + "px", null == r || r(), requestAnimationFrame(() => y.current = !0)
                        }
                    }, [v, a.trigger, a.valueNode, s, p, b, x, E, a.dir, r]);
                    (0, P.b)(() => R(), [R]);
                    let [M, S] = (0, i.useState)();
                    (0, P.b)(() => {
                        p && S(window.getComputedStyle(p).zIndex)
                    }, [p]);
                    let k = (0, i.useCallback)(e => {
                        e && !0 === w.current && (R(), null == C || C(), w.current = !1)
                    }, [R, C]);
                    return (0, i.createElement)(eA, {
                        scope: n,
                        contentWrapper: s,
                        shouldExpandOnScrollRef: y,
                        onScrollButtonChange: k
                    }, (0, i.createElement)("div", {
                        ref: f,
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            position: "fixed",
                            zIndex: M
                        }
                    }, (0, i.createElement)(g.WV.div, (0, o.Z)({}, l, {
                        ref: h,
                        style: {
                            boxSizing: "border-box",
                            maxHeight: "100%",
                            ...l.style
                        }
                    }))))
                }),
                eD = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        align: r = "start",
                        collisionPadding: l = 10,
                        ...a
                    } = e, u = ev(n);
                    return (0, i.createElement)(Y, (0, o.Z)({}, u, a, {
                        ref: t,
                        align: r,
                        collisionPadding: l,
                        style: {
                            boxSizing: "border-box",
                            ...a.style,
                            "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-select-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-select-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                }),
                [eA, eI] = em(eS, {}),
                eL = "SelectViewport",
                eF = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        ...r
                    } = e, l = e_(eL, n), a = eI(eL, n), u = (0, d.e)(t, l.onViewportChange), s = (0, i.useRef)(0);
                    return (0, i.createElement)(i.Fragment, null, (0, i.createElement)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
                        }
                    }), (0, i.createElement)(ed.Slot, {
                        scope: n
                    }, (0, i.createElement)(g.WV.div, (0, o.Z)({
                        "data-radix-select-viewport": "",
                        role: "presentation"
                    }, r, {
                        ref: u,
                        style: {
                            position: "relative",
                            flex: 1,
                            overflow: "auto",
                            ...r.style
                        },
                        onScroll: (0, c.M)(r.onScroll, e => {
                            let t = e.currentTarget,
                                {
                                    contentWrapper: n,
                                    shouldExpandOnScrollRef: r
                                } = a;
                            if (null != r && r.current && n) {
                                let e = Math.abs(s.current - t.scrollTop);
                                if (e > 0) {
                                    let r = window.innerHeight - 20,
                                        o = parseFloat(n.style.minHeight),
                                        i = parseFloat(n.style.height),
                                        l = Math.max(o, i);
                                    if (l < r) {
                                        let o = l + e,
                                            i = Math.min(r, o),
                                            a = o - i;
                                        n.style.height = i + "px", "0px" === n.style.bottom && (t.scrollTop = a > 0 ? a : 0, n.style.justifyContent = "flex-end")
                                    }
                                }
                            }
                            s.current = t.scrollTop
                        })
                    }))))
                }),
                [eW, eV] = em("SelectGroup"),
                eZ = "SelectItem",
                [e$, eN] = em(eZ),
                eB = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        value: r,
                        disabled: l = !1,
                        textValue: a,
                        ...u
                    } = e, s = ey(eZ, n), f = e_(eZ, n), p = s.value === r, [m, h] = (0, i.useState)(null != a ? a : ""), [v, y] = (0, i.useState)(!1), w = (0, d.e)(t, e => {
                        var t;
                        return null === (t = f.itemRefCallback) || void 0 === t ? void 0 : t.call(f, e, r, l)
                    }), b = O(), x = () => {
                        l || (s.onValueChange(r), s.onOpenChange(!1))
                    };
                    return (0, i.createElement)(e$, {
                        scope: n,
                        value: r,
                        disabled: l,
                        textId: b,
                        isSelected: p,
                        onItemTextChange: (0, i.useCallback)(e => {
                            h(t => {
                                var n;
                                return t || (null !== (n = null == e ? void 0 : e.textContent) && void 0 !== n ? n : "").trim()
                            })
                        }, [])
                    }, (0, i.createElement)(ed.ItemSlot, {
                        scope: n,
                        value: r,
                        disabled: l,
                        textValue: m
                    }, (0, i.createElement)(g.WV.div, (0, o.Z)({
                        role: "option",
                        "aria-labelledby": b,
                        "data-highlighted": v ? "" : void 0,
                        "aria-selected": p && v,
                        "data-state": p ? "checked" : "unchecked",
                        "aria-disabled": l || void 0,
                        "data-disabled": l ? "" : void 0,
                        tabIndex: l ? void 0 : -1
                    }, u, {
                        ref: w,
                        onFocus: (0, c.M)(u.onFocus, () => y(!0)),
                        onBlur: (0, c.M)(u.onBlur, () => y(!1)),
                        onPointerUp: (0, c.M)(u.onPointerUp, x),
                        onPointerMove: (0, c.M)(u.onPointerMove, e => {
                            if (l) {
                                var t;
                                null === (t = f.onItemLeave) || void 0 === t || t.call(f)
                            } else e.currentTarget.focus({
                                preventScroll: !0
                            })
                        }),
                        onPointerLeave: (0, c.M)(u.onPointerLeave, e => {
                            if (e.currentTarget === document.activeElement) {
                                var t;
                                null === (t = f.onItemLeave) || void 0 === t || t.call(f)
                            }
                        }),
                        onKeyDown: (0, c.M)(u.onKeyDown, e => {
                            var t;
                            let n = (null === (t = f.searchRef) || void 0 === t ? void 0 : t.current) !== "";
                            n && " " === e.key || (ec.includes(e.key) && x(), " " === e.key && e.preventDefault())
                        })
                    }))))
                }),
                eH = "SelectItemText",
                eK = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        className: r,
                        style: l,
                        ...u
                    } = e, c = ey(eH, n), s = e_(eH, n), f = eN(eH, n), p = eb(eH, n), [m, h] = (0, i.useState)(null), v = (0, d.e)(t, e => h(e), f.onItemTextChange, e => {
                        var t;
                        return null === (t = s.itemTextRefCallback) || void 0 === t ? void 0 : t.call(s, e, f.value, f.disabled)
                    }), y = null == m ? void 0 : m.textContent, w = (0, i.useMemo)(() => (0, i.createElement)("option", {
                        key: f.value,
                        value: f.value,
                        disabled: f.disabled
                    }, y), [f.disabled, f.value, y]), {
                        onNativeOptionAdd: b,
                        onNativeOptionRemove: x
                    } = p;
                    return (0, P.b)(() => (b(w), () => x(w)), [b, x, w]), (0, i.createElement)(i.Fragment, null, (0, i.createElement)(g.WV.span, (0, o.Z)({
                        id: f.textId
                    }, u, {
                        ref: v
                    })), f.isSelected && c.valueNode && !c.valueNodeHasChildren ? (0, a.createPortal)(u.children, c.valueNode) : null)
                }),
                ez = "SelectScrollUpButton",
                ej = (0, i.forwardRef)((e, t) => {
                    let n = e_(ez, e.__scopeSelect),
                        r = eI(ez, e.__scopeSelect),
                        [l, a] = (0, i.useState)(!1),
                        u = (0, d.e)(t, r.onScrollButtonChange);
                    return (0, P.b)(() => {
                        if (n.viewport && n.isPositioned) {
                            let t = n.viewport;

                            function e() {
                                let e = t.scrollTop > 0;
                                a(e)
                            }
                            return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e)
                        }
                    }, [n.viewport, n.isPositioned]), l ? (0, i.createElement)(eq, (0, o.Z)({}, e, {
                        ref: u,
                        onAutoScroll: () => {
                            let {
                                viewport: e,
                                selectedItem: t
                            } = n;
                            e && t && (e.scrollTop = e.scrollTop - t.offsetHeight)
                        }
                    })) : null
                }),
                eU = "SelectScrollDownButton",
                eG = (0, i.forwardRef)((e, t) => {
                    let n = e_(eU, e.__scopeSelect),
                        r = eI(eU, e.__scopeSelect),
                        [l, a] = (0, i.useState)(!1),
                        u = (0, d.e)(t, r.onScrollButtonChange);
                    return (0, P.b)(() => {
                        if (n.viewport && n.isPositioned) {
                            let t = n.viewport;

                            function e() {
                                let e = t.scrollHeight - t.clientHeight,
                                    n = Math.ceil(t.scrollTop) < e;
                                a(n)
                            }
                            return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e)
                        }
                    }, [n.viewport, n.isPositioned]), l ? (0, i.createElement)(eq, (0, o.Z)({}, e, {
                        ref: u,
                        onAutoScroll: () => {
                            let {
                                viewport: e,
                                selectedItem: t
                            } = n;
                            e && t && (e.scrollTop = e.scrollTop + t.offsetHeight)
                        }
                    })) : null
                }),
                eq = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeSelect: n,
                        onAutoScroll: r,
                        ...l
                    } = e, a = e_("SelectScrollButton", n), u = (0, i.useRef)(null), s = ef(n), d = (0, i.useCallback)(() => {
                        null !== u.current && (window.clearInterval(u.current), u.current = null)
                    }, []);
                    return (0, i.useEffect)(() => () => d(), [d]), (0, P.b)(() => {
                        var e;
                        let t = s().find(e => e.ref.current === document.activeElement);
                        null == t || null === (e = t.ref.current) || void 0 === e || e.scrollIntoView({
                            block: "nearest"
                        })
                    }, [s]), (0, i.createElement)(g.WV.div, (0, o.Z)({
                        "aria-hidden": !0
                    }, l, {
                        ref: t,
                        style: {
                            flexShrink: 0,
                            ...l.style
                        },
                        onPointerDown: (0, c.M)(l.onPointerDown, () => {
                            null === u.current && (u.current = window.setInterval(r, 50))
                        }),
                        onPointerMove: (0, c.M)(l.onPointerMove, () => {
                            var e;
                            null === (e = a.onItemLeave) || void 0 === e || e.call(a), null === u.current && (u.current = window.setInterval(r, 50))
                        }),
                        onPointerLeave: (0, c.M)(l.onPointerLeave, () => {
                            d()
                        })
                    }))
                }),
                eX = (0, i.forwardRef)((e, t) => {
                    let {
                        value: n,
                        ...r
                    } = e, l = (0, i.useRef)(null), a = (0, d.e)(t, l), u = function(e) {
                        let t = (0, i.useRef)({
                            value: e,
                            previous: e
                        });
                        return (0, i.useMemo)(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e])
                    }(n);
                    return (0, i.useEffect)(() => {
                        let e = l.current,
                            t = window.HTMLSelectElement.prototype,
                            r = Object.getOwnPropertyDescriptor(t, "value"),
                            o = r.set;
                        if (u !== n && o) {
                            let t = new Event("change", {
                                bubbles: !0
                            });
                            o.call(e, n), e.dispatchEvent(t)
                        }
                    }, [u, n]), (0, i.createElement)(ei.T, {
                        asChild: !0
                    }, (0, i.createElement)("select", (0, o.Z)({}, r, {
                        ref: a,
                        defaultValue: n
                    })))
                });

            function eY(e) {
                let t = (0, y.W)(e),
                    n = (0, i.useRef)(""),
                    r = (0, i.useRef)(0),
                    o = (0, i.useCallback)(e => {
                        let o = n.current + e;
                        t(o),
                            function e(t) {
                                n.current = t, window.clearTimeout(r.current), "" !== t && (r.current = window.setTimeout(() => e(""), 1e3))
                            }(o)
                    }, [t]),
                    l = (0, i.useCallback)(() => {
                        n.current = "", window.clearTimeout(r.current)
                    }, []);
                return (0, i.useEffect)(() => () => window.clearTimeout(r.current), []), [n, o, l]
            }

            function eJ(e, t, n) {
                var r;
                let o = t.length > 1 && Array.from(t).every(e => e === t[0]),
                    i = o ? t[0] : t,
                    l = n ? e.indexOf(n) : -1,
                    a = (r = Math.max(l, 0), e.map((t, n) => e[(r + n) % e.length])),
                    u = 1 === i.length;
                u && (a = a.filter(e => e !== n));
                let c = a.find(e => e.textValue.toLowerCase().startsWith(i.toLowerCase()));
                return c !== n ? c : void 0
            }
            eX.displayName = "BubbleSelect";
            let eQ = ex,
                e0 = eE,
                e1 = eC,
                e5 = eR,
                e4 = eM,
                e2 = ek,
                e3 = eF,
                e9 = eB,
                e7 = eK,
                e6 = ej,
                e8 = eG
        },
        51629: function(e, t, n) {
            "use strict";
            n.d(t, {
                W: function() {
                    return o
                }
            });
            var r = n(70079);

            function o(e) {
                let t = (0, r.useRef)(e);
                return (0, r.useEffect)(() => {
                    t.current = e
                }), (0, r.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
        },
        21381: function(e, t, n) {
            "use strict";
            n.d(t, {
                T: function() {
                    return i
                }
            });
            var r = n(70079),
                o = n(51629);

            function i({
                prop: e,
                defaultProp: t,
                onChange: n = () => {}
            }) {
                let [i, l] = function({
                    defaultProp: e,
                    onChange: t
                }) {
                    let n = (0, r.useState)(e),
                        [i] = n,
                        l = (0, r.useRef)(i),
                        a = (0, o.W)(t);
                    return (0, r.useEffect)(() => {
                        l.current !== i && (a(i), l.current = i)
                    }, [i, l, a]), n
                }({
                    defaultProp: t,
                    onChange: n
                }), a = void 0 !== e, u = (0, o.W)(n), c = (0, r.useCallback)(t => {
                    if (a) {
                        let n = "function" == typeof t ? t(e) : t;
                        n !== e && u(n)
                    } else l(t)
                }, [a, e, l, u]);
                return [a ? e : i, c]
            }
        },
        90671: function(e, t, n) {
            "use strict";
            n.d(t, {
                b: function() {
                    return o
                }
            });
            var r = n(70079);
            let o = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {}
        },
        74686: function(e, t, n) {
            "use strict";
            n.d(t, {
                D: function() {
                    return f
                }
            });
            var r = n(70079),
                o = n(71568),
                i = n(16456),
                l = n(57630),
                a = n(84427),
                u = n(28197);
            class c extends u.l {
                constructor(e, t) {
                    super(), this.client = e, this.setOptions(t), this.bindMethods(), this.updateResult()
                }
                bindMethods() {
                    this.mutate = this.mutate.bind(this), this.reset = this.reset.bind(this)
                }
                setOptions(e) {
                    var t;
                    let n = this.options;
                    this.options = this.client.defaultMutationOptions(e), (0, i.VS)(n, this.options) || this.client.getMutationCache().notify({
                        type: "observerOptionsUpdated",
                        mutation: this.currentMutation,
                        observer: this
                    }), null == (t = this.currentMutation) || t.setOptions(this.options)
                }
                onUnsubscribe() {
                    if (!this.listeners.length) {
                        var e;
                        null == (e = this.currentMutation) || e.removeObserver(this)
                    }
                }
                onMutationUpdate(e) {
                    this.updateResult();
                    let t = {
                        listeners: !0
                    };
                    "success" === e.type ? t.onSuccess = !0 : "error" === e.type && (t.onError = !0), this.notify(t)
                }
                getCurrentResult() {
                    return this.currentResult
                }
                reset() {
                    this.currentMutation = void 0, this.updateResult(), this.notify({
                        listeners: !0
                    })
                }
                mutate(e, t) {
                    return this.mutateOptions = t, this.currentMutation && this.currentMutation.removeObserver(this), this.currentMutation = this.client.getMutationCache().build(this.client, { ...this.options,
                        variables: void 0 !== e ? e : this.options.variables
                    }), this.currentMutation.addObserver(this), this.currentMutation.execute()
                }
                updateResult() {
                    let e = this.currentMutation ? this.currentMutation.state : (0, l.R)(),
                        t = { ...e,
                            isLoading: "loading" === e.status,
                            isSuccess: "success" === e.status,
                            isError: "error" === e.status,
                            isIdle: "idle" === e.status,
                            mutate: this.mutate,
                            reset: this.reset
                        };
                    this.currentResult = t
                }
                notify(e) {
                    a.V.batch(() => {
                        if (this.mutateOptions && this.hasListeners()) {
                            var t, n, r, o, i, l, a, u;
                            e.onSuccess ? (null == (t = (n = this.mutateOptions).onSuccess) || t.call(n, this.currentResult.data, this.currentResult.variables, this.currentResult.context), null == (r = (o = this.mutateOptions).onSettled) || r.call(o, this.currentResult.data, null, this.currentResult.variables, this.currentResult.context)) : e.onError && (null == (i = (l = this.mutateOptions).onError) || i.call(l, this.currentResult.error, this.currentResult.variables, this.currentResult.context), null == (a = (u = this.mutateOptions).onSettled) || a.call(u, void 0, this.currentResult.error, this.currentResult.variables, this.currentResult.context))
                        }
                        e.listeners && this.listeners.forEach(e => {
                            e(this.currentResult)
                        })
                    })
                }
            }
            var s = n(13995),
                d = n(18122);

            function f(e, t, n) {
                let l = (0, i.lV)(e, t, n),
                    u = (0, s.NL)({
                        context: l.context
                    }),
                    [f] = r.useState(() => new c(u, l));
                r.useEffect(() => {
                    f.setOptions(l)
                }, [f, l]);
                let m = (0, o.$)(r.useCallback(e => f.subscribe(a.V.batchCalls(e)), [f]), () => f.getCurrentResult(), () => f.getCurrentResult()),
                    h = r.useCallback((e, t) => {
                        f.mutate(e, t).catch(p)
                    }, [f]);
                if (m.error && (0, d.L)(f.options.useErrorBoundary, [m.error])) throw m.error;
                return { ...m,
                    mutate: h,
                    mutateAsync: m.mutate
                }
            }

            function p() {}
        }
    }
]);