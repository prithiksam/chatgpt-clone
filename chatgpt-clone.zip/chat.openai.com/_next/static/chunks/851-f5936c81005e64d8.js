"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [851], {
        95954: function(e, t, n) {
            var r, a, i, o, s, l, u, d, c, f, g, h, m, p, v, x, b;
            n.d(t, {
                Jq: function() {
                    return c
                },
                Os: function() {
                    return i
                },
                PX: function() {
                    return s
                },
                RF: function() {
                    return d
                },
                uU: function() {
                    return o
                }
            }), (f = r || (r = {})).Default = "default", f.Dark = "dark", (a || (a = {})).Retrieval = "retrieval", (g = i || (i = {})).Next = "next", g.Variant = "variant", g.Continue = "continue", (h = o || (o = {})).Unknown = "unknown", h.User = "user", h.Assistant = "assistant", h.System = "system", h.Critic = "critic", h.Tool = "tool", (m = s || (s = {})).Text = "text", m.MultimodalText = "multimodal_text", m.TetherBrowsingCode = "tether_browsing_code", m.Code = "code", m.ExecutionOutput = "execution_output", m.SystemError = "system_error", m.SystemMessage = "system_message", m.TetherBrowsingDisplay = "tether_browsing_display", m.TetherQuote = "tether_quote", m.UserEditableContext = "user_editable_context", (p = l || (l = {})).Search = "search", p.Click = "click", p.OpenUrl = "open_url", p.Quote = "quote", p.QuoteFull = "quote_full", p.Back = "back", p.Scroll = "scroll", (v = u || (u = {})).Running = "running", v.Finished = "finished", (x = d || (d = {})).Starting = "starting", x.Running = "running", x.Done = "done", x.Timeout = "timeout", x.Error = "error", (b = c || (c = {})).Root = "root", b.System = "system", b.Prompt = "prompt", b.Completion = "completion"
        },
        20476: function(e, t, n) {
            var r = n(39324),
                a = n(4337),
                i = n(35250),
                o = n(32004),
                s = n(94968),
                l = n(78931),
                u = n(21389),
                d = n(75641);

            function c() {
                var e = (0, a._)(["bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase"]);
                return c = function() {
                    return e
                }, e
            }

            function f() {
                var e = (0, a._)(["bg-blue-200 text-blue-700"]);
                return f = function() {
                    return e
                }, e
            }
            var g = u.Z.span(c()),
                h = (0, u.Z)(g)(f());
            t.ZP = function() {
                var e = (0, l.ec)(function(e) {
                        return e.currentWorkspace
                    }),
                    t = (0, l.WY)();
                return (null == e ? void 0 : e.structure) === "workspace" ? (0, i.jsx)(h, {
                    children: (0, i.jsx)(o.Z, (0, r._)({}, m.businessPlanName))
                }) : (null == e ? void 0 : e.structure) === d.CZ.PERSONAL && t ? (0, i.jsx)(g, {
                    children: "Plus"
                }) : null
            };
            var m = (0, s.vU)({
                businessPlanName: {
                    id: "badge.businessPlanName",
                    defaultMessage: "Business",
                    description: "label for business tier account"
                }
            })
        },
        77851: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return ep
                }
            });
            var r = n(22830),
                a = n(35250),
                i = n(87758),
                o = n(70079),
                s = n(88798),
                l = n(21739),
                u = n(32542),
                d = n(77010),
                c = n(6948),
                f = n(32877),
                g = n(31621),
                h = n(46020),
                m = n(54118),
                p = n(78931),
                v = n(61888),
                x = n(20476),
                b = n(89368),
                y = n(39324),
                j = n(71209),
                w = n(94968),
                C = n(70671),
                k = n(32004),
                _ = n(62509),
                M = n(50795),
                T = n(82081),
                N = n(97747),
                P = (0, w.vU)({
                    welcomeBack: {
                        id: "existingUserAgeConfirmationModal.welcomeBack",
                        defaultMessage: "Welcome back, Italy!",
                        description: "Title for the age confirmation modal for Italian users"
                    },
                    ageRequirementsButton: {
                        id: "existingUserAgeConfirmationModal.ageRequirementsButton",
                        defaultMessage: "I meet OpenAI's age requirements",
                        description: "Primary button to confirm the user meets the age requirements"
                    },
                    logoutButton: {
                        id: "existingUserAgeConfirmationModal.logoutButton",
                        defaultMessage: "Log out",
                        description: "Secondary button to log out of the platform"
                    },
                    announcementParagraph1: {
                        id: "existingUserAgeConfirmationModal.announcementParagraph1",
                        defaultMessage: "We’re pleased to resume offering ChatGPT in Italy. To continue on ChatGPT, please confirm that you are 18+ or are 13+ and have consent from your parent or guardian to use ChatGPT.",
                        description: "First paragraph of the announcement, explaining the age requirements"
                    },
                    privacyPolicyLink: {
                        id: "existingUserAgeConfirmationModal.privacyPolicyLink",
                        defaultMessage: "Privacy policy",
                        description: "Link to the privacy policy"
                    },
                    helpCenterArticleLink: {
                        id: "existingUserAgeConfirmationModal.helpCenterArticleLink",
                        defaultMessage: "this help center article",
                        description: "Link to the help center article about ChatGPT development"
                    },
                    announcementParagraph2: {
                        id: "existingUserAgeConfirmationModal.announcementParagraph2",
                        defaultMessage: "For information about how we collect and use personal data, please see our {privacyPolicyLink}. For information about how we develop and train ChatGPT, please see {helpCenterArticleLink}.",
                        description: "Second paragraph of the announcement, providing links to more information"
                    }
                }),
                S = "2023-04-25",
                I = "".concat("oai/apps/hasSeenAgeConfirmationModal", "/").concat(S);

            function Z(e) {
                var t = e.onClose,
                    n = (0, C.Z)(),
                    r = (0, o.useCallback)(function() {
                        c.m.setItem(I, !0), t()
                    }, [t]);
                return (0, o.useEffect)(function() {
                    M.o.logEvent(T.a.ageConfirmationModal, {
                        content: S
                    })
                }, []), (0, a.jsx)(b.Z, {
                    isOpen: !0,
                    onClose: v.noop,
                    type: "success",
                    title: n.formatMessage(P.welcomeBack),
                    primaryButton: (0, a.jsx)(N.ZP.Button, {
                        title: n.formatMessage(P.ageRequirementsButton),
                        color: "primary",
                        onClick: r
                    }),
                    secondaryButton: (0, a.jsx)(N.ZP.Button, {
                        title: n.formatMessage(P.logoutButton),
                        color: "light",
                        onClick: function() {
                            M.o.logEvent(T.a.clickLogOut, {
                                eventSource: "mouse"
                            }), (0, _.w7)()
                        },
                        className: "border-gray-800 hover:border-gray-700"
                    }),
                    children: (0, a.jsx)(F, {})
                })
            }
            var F = function() {
                    var e = (0, C.Z)();
                    return (0, a.jsx)("div", {
                        className: "mb-6 mt-4 sm:mt-6",
                        children: (0, a.jsxs)("div", {
                            className: "prose prose-invert text-base text-gray-500",
                            children: [(0, a.jsx)("p", {
                                children: (0, a.jsx)(k.Z, (0, y._)({}, P.announcementParagraph1))
                            }), (0, a.jsx)("p", {
                                children: (0, a.jsx)(k.Z, (0, j._)((0, y._)({}, P.announcementParagraph2), {
                                    values: {
                                        privacyPolicyLink: (0, a.jsx)("a", {
                                            href: "https://openai.com/policies/privacy-policy",
                                            target: "_blank",
                                            className: "text-gray-500 underline",
                                            rel: "noreferrer",
                                            children: e.formatMessage(P.privacyPolicyLink)
                                        }),
                                        helpCenterArticleLink: (0, a.jsx)("a", {
                                            href: "https://help.openai.com/en/articles/7842364-how-chatgpt-and-our-language-models-are-developed",
                                            target: "_blank",
                                            className: "text-gray-500 underline",
                                            rel: "noreferrer",
                                            children: e.formatMessage(P.helpCenterArticleLink)
                                        })
                                    }
                                }))
                            })]
                        })
                    })
                },
                D = n(7614),
                E = n(4337),
                R = n(21389),
                B = n(67273);

            function A() {
                var e = (0, E._)(["flex gap-4 mt-6"]);
                return A = function() {
                    return e
                }, e
            }

            function L() {
                var e = (0, E._)(["prose dark:prose-invert"]);
                return L = function() {
                    return e
                }, e
            }

            function U() {
                var e = (0, E._)(["mb-4"]);
                return U = function() {
                    return e
                }, e
            }

            function O(e) {
                var t = e.pages,
                    n = e.onSubmit,
                    i = (0, r._)((0, o.useState)(0), 2),
                    s = i[0],
                    l = i[1];
                return (0, a.jsx)(H, {
                    children: t.map(function(e, t) {
                        return s === t ? (0, a.jsx)(e, {
                            onChangePage: l,
                            onSubmit: n
                        }) : null
                    })
                })
            }

            function q(e) {
                var t = e.onBack,
                    n = e.onNext,
                    r = e.onSubmit;
                return (0, a.jsxs)(z, {
                    children: [t && (0, a.jsx)(B.z, {
                        as: "button",
                        color: "neutral",
                        onClick: t,
                        children: "Back"
                    }), n && (0, a.jsx)(B.z, {
                        as: "button",
                        onClick: n,
                        color: "neutral",
                        className: "ml-auto",
                        children: "Next"
                    }), r && (0, a.jsx)(B.z, {
                        as: "button",
                        onClick: r,
                        color: "primary",
                        className: "ml-auto",
                        children: "Done"
                    })]
                })
            }
            var z = R.Z.div(A()),
                H = R.Z.div(L()),
                W = R.Z.h4(U()),
                V = "oai/apps/hasSeenOnboarding",
                Q = "chat",
                G = function(e) {
                    var t = (0, o.useCallback)(function() {
                            c.m.setItem("".concat(V, "/").concat(e), new Date().toLocaleDateString("en-CA", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit"
                            }))
                        }, [e]),
                        n = (0, r._)((0, o.useState)(null), 2),
                        a = n[0],
                        i = n[1];
                    (0, o.useEffect)(function() {
                        var t = c.m.getItem("".concat(V, "/").concat(e));
                        i(!!t && t)
                    }, [e]);
                    var s = (0, o.useCallback)(function() {
                        return a ? new Date(!0 === a ? "2022-12-14" : a) : a
                    }, [a]);
                    return (0, o.useMemo)(function() {
                        return {
                            setHasSeenOnboarding: t,
                            getHasSeenOnboardingDate: s
                        }
                    }, [s, t])
                };

            function $(e) {
                var t = e.onClose,
                    n = G(Q).setHasSeenOnboarding,
                    r = (0, o.useCallback)(function() {
                        t(!0), n()
                    }, [t, n]);
                return (0, a.jsx)(O, {
                    pages: [Y, J, K],
                    onSubmit: r
                })
            }
            var Y = function(e) {
                    var t = e.onChangePage;
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)(W, {
                            children: (0, a.jsx)(k.Z, (0, y._)({}, X.page0Subtitle))
                        }), (0, a.jsxs)(D.I, {
                            children: [(0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDD2C",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, X.page0Disclaimer1))
                            }), (0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDEA8",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, X.page0Disclaimer2))
                            })]
                        }), (0, a.jsx)(q, {
                            onNext: function() {
                                return t(1)
                            }
                        })]
                    })
                },
                J = function(e) {
                    var t = e.onChangePage;
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)(W, {
                            children: (0, a.jsx)(k.Z, (0, y._)({}, X.page1Subtitle))
                        }), (0, a.jsxs)(D.I, {
                            children: [(0, a.jsx)(D.Z, {
                                icon: "\uD83E\uDDBE",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, X.page1Disclaimer1))
                            }), (0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDD10",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, X.page1Disclaimer2))
                            })]
                        }), (0, a.jsx)(q, {
                            onBack: function() {
                                return t(0)
                            },
                            onNext: function() {
                                return t(2)
                            }
                        })]
                    })
                },
                K = function(e) {
                    var t = e.onChangePage,
                        n = e.onSubmit,
                        r = (0, o.useRef)(null);
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)(W, {
                            children: (0, a.jsx)(k.Z, (0, y._)({}, X.page2Subtitle))
                        }), (0, a.jsxs)(D.I, {
                            children: [(0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDC4D",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, X.page2Disclaimer1))
                            }), (0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDCAC",
                                children: (0, a.jsx)(k.Z, (0, j._)((0, y._)({}, X.page2Disclaimer2), {
                                    values: {
                                        link: function(e) {
                                            return (0, a.jsx)("a", {
                                                href: "https://discord.gg/openai",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: e
                                            })
                                        }
                                    }
                                }))
                            })]
                        }), (0, a.jsx)(q, {
                            onBack: function() {
                                return t(1)
                            },
                            onSubmit: function() {
                                return null == n ? void 0 : n(r)
                            }
                        })]
                    })
                },
                X = (0, w.vU)({
                    keepInMind: {
                        id: "onboarding.keepInMind",
                        defaultMessage: "Here are a few things to keep in mind before we get started:",
                        description: "Introduction text for the onboarding process"
                    },
                    page0Subtitle: {
                        id: "onboarding.page0Subtitle",
                        defaultMessage: "This is a free research preview.",
                        description: "Subtitle for Page 0"
                    },
                    page0Disclaimer1: {
                        id: "onboarding.page0Disclaimer1",
                        defaultMessage: "Our goal is to get external feedback in order to improve our systems and make them safer.",
                        description: "Disclaimer 1 for Page 0"
                    },
                    page0Disclaimer2: {
                        id: "onboarding.page0Disclaimer2",
                        defaultMessage: "While we have safeguards in place, the system may occasionally generate incorrect or misleading information and produce offensive or biased content. It is not intended to give advice.",
                        description: "Disclaimer 2 for Page 0"
                    },
                    page1Subtitle: {
                        id: "onboarding.page1Subtitle",
                        defaultMessage: "How we collect data",
                        description: "Subtitle for Page 1"
                    },
                    page1Disclaimer1: {
                        id: "onboarding.page1Disclaimer1",
                        defaultMessage: "Conversations may be reviewed by our AI trainers to improve our systems.",
                        description: "Disclaimer 1 for Page 1"
                    },
                    page1Disclaimer2: {
                        id: "onboarding.page1Disclaimer2",
                        defaultMessage: "Please don't share any sensitive information in your conversations.",
                        description: "Disclaimer 2 for Page 1"
                    },
                    page2Subtitle: {
                        id: "onboarding.page2Subtitle",
                        defaultMessage: "We'd love your feedback!",
                        description: "Subtitle for Page 2"
                    },
                    page2Disclaimer1: {
                        id: "onboarding.page2Disclaimer1",
                        defaultMessage: "This system is optimized for dialogue. Let us know if a particular response was good or unhelpful.",
                        description: "Disclaimer 1 for Page 2"
                    },
                    page2Disclaimer2: {
                        id: "onboarding.page2Disclaimer2",
                        defaultMessage: "Share your feedback in our <link>Discord server</link>.",
                        description: "Disclaimer 2 for Page 2, with link to Discord"
                    }
                }),
                ee = n(52696),
                et = "workspace";

            function en(e) {
                var t = e.onClose,
                    n = G(et).setHasSeenOnboarding,
                    r = (0, o.useCallback)(function() {
                        t(!0), n()
                    }, [t, n]);
                return (0, a.jsx)(O, {
                    pages: [er, ea],
                    onSubmit: r
                })
            }
            var er = function(e) {
                    var t = e.onChangePage,
                        n = (0, ee.Ix)();
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)(W, {
                            children: (0, a.jsx)(k.Z, (0, j._)((0, y._)({}, ei.page0Subtitle), {
                                values: {
                                    workspaceName: n
                                }
                            }))
                        }), (0, a.jsxs)(D.I, {
                            children: [(0, a.jsx)(D.Z, {
                                icon: "\uD83C\uDFE2",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, ei.page0Disclaimer1))
                            }), (0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDEA8",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, ei.page0Disclaimer2))
                            })]
                        }), (0, a.jsx)(q, {
                            onNext: function() {
                                return t(1)
                            }
                        })]
                    })
                },
                ea = function(e) {
                    var t = e.onChangePage,
                        n = e.onSubmit,
                        r = (0, o.useRef)(null);
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)(W, {
                            children: (0, a.jsx)(k.Z, (0, y._)({}, ei.page1Subtitle))
                        }), (0, a.jsxs)(D.I, {
                            children: [(0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDED1",
                                children: (0, a.jsx)(k.Z, (0, y._)({}, ei.page1Disclaimer1))
                            }), (0, a.jsx)(D.Z, {
                                icon: "\uD83D\uDD12",
                                children: (0, a.jsx)(k.Z, (0, j._)((0, y._)({}, ei.page1Disclaimer2), {
                                    values: {
                                        link: function(e) {
                                            return (0, a.jsx)("a", {
                                                href: "https://openai.com/policies/api-data-usage-policies",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: e
                                            })
                                        }
                                    }
                                }))
                            })]
                        }), (0, a.jsx)(q, {
                            onBack: function() {
                                return t(0)
                            },
                            onSubmit: function() {
                                return null == n ? void 0 : n(r)
                            }
                        })]
                    })
                },
                ei = (0, w.vU)({
                    page0Subtitle: {
                        id: "WorkspaceOnboarding.page0Subtitle",
                        defaultMessage: "Welcome to the {workspaceName} workspace",
                        description: "Subtitle for the first page of the business onboarding flow"
                    },
                    page0Disclaimer1: {
                        id: "WorkspaceOnboarding.page0Disclaimer1",
                        defaultMessage: "This workspace is private, only select members and roles can use it.",
                        description: "First disclaimer for the first page of the business onboarding flow"
                    },
                    page0Disclaimer2: {
                        id: "WorkspaceOnboarding.page0Disclaimer2",
                        defaultMessage: "While we have safeguards in place, the system may occasionally generate incorrect or misleading information and produce offensive or biased content. It is not intended to give advice.",
                        description: "Second disclaimer for the first page of the business onboarding flow"
                    },
                    page1Subtitle: {
                        id: "WorkspaceOnboarding.page1Subtitle",
                        defaultMessage: "Data management",
                        description: "Subtitle for the second page of the business onboarding flow"
                    },
                    page1Disclaimer1: {
                        id: "WorkspaceOnboarding.page1Disclaimer1",
                        defaultMessage: "Conversations in this workspace are opted out of training and not available to other users.",
                        description: "First disclaimer for the second page of the business onboarding flow"
                    },
                    page1Disclaimer2: {
                        id: "WorkspaceOnboarding.page1Disclaimer2",
                        defaultMessage: "Chats are securely stored for 30 days for <link>Trust and Safety Protocols</link>.",
                        description: "Second disclaimer for the second page of the business onboarding flow"
                    }
                }),
                eo = function(e) {
                    var t = e.onClose;
                    return (0, a.jsx)(b.Z, {
                        isOpen: !0,
                        onClose: v.noop,
                        type: "success",
                        primaryButton: void 0,
                        title: "ChatGPT",
                        children: (0, a.jsx)($, {
                            onClose: t
                        })
                    })
                },
                es = function(e) {
                    var t = e.onClose;
                    return (0, a.jsx)(b.Z, {
                        isOpen: !0,
                        onClose: v.noop,
                        type: "success",
                        primaryButton: void 0,
                        title: (0, a.jsxs)("span", {
                            children: ["ChatGPT ", (0, a.jsx)(x.ZP, {})]
                        }),
                        children: (0, a.jsx)(en, {
                            onClose: t
                        })
                    })
                };

            function el(e) {
                var t, n, i = e.userCountry,
                    s = (0, r._)((0, o.useState)(0), 2),
                    l = s[0],
                    u = s[1],
                    d = G(Q).getHasSeenOnboardingDate,
                    f = G(et).getHasSeenOnboardingDate,
                    g = (0, p.ec)(p.F_.isBusinessWorkspace),
                    h = (t = (0, p.hz)(), n = !!c.m.getItem(I), 0 === t.size ? "loading" : "IT" !== i || n ? "hide" : "show"),
                    m = (0, o.useMemo)(function() {
                        return [{
                            Modal: Z,
                            getModalState: function() {
                                return h
                            }
                        }, {
                            Modal: eo,
                            getModalState: function() {
                                if (g) return "hide";
                                var e = d();
                                return null === e ? "loading" : !1 === e ? "show" : "hide"
                            }
                        }, {
                            Modal: es,
                            getModalState: function() {
                                if (!g) return "hide";
                                var e = f();
                                return null === e ? "loading" : !1 === e ? "show" : "hide"
                            }
                        }]
                    }, [d, f, g, h]);
                (0, o.useEffect)(function() {
                    m[l] && "hide" === m[l].getModalState() && u(m.findIndex(function(e) {
                        return "hide" !== e.getModalState()
                    }))
                }, [l, m]);
                var v = m[l];
                if (!v) return null;
                var x = v.getModalState();
                if ("loading" === x) return null;
                "hide" === x && u(function(e) {
                    return e + 1
                });
                var b = m[l].Modal;
                return (0, a.jsx)(b, {
                    onClose: function() {
                        u(function(e) {
                            return e + 1
                        })
                    }
                })
            }
            var eu = n(98611),
                ed = n(26948),
                ec = function(e) {
                    var t = e.action;
                    return (0, a.jsxs)("div", {
                        className: "flex items-center justify-between overflow-hidden text-gray-600 dark:text-gray-300",
                        children: [(0, a.jsx)("div", {
                            className: "flex flex-shrink items-center overflow-hidden text-sm",
                            children: (0, a.jsx)("div", {
                                className: "truncate",
                                children: t.text
                            })
                        }), (0, a.jsx)("div", {
                            className: "ml-3 flex flex-row gap-2",
                            children: (0, ed.A3)(t.keyboardBinding).map(function(e, n) {
                                return (0, a.jsx)(ef, {
                                    keyName: e
                                }, "".concat(t.key, "-").concat(n))
                            })
                        })]
                    })
                },
                ef = function(e) {
                    var t = e.keyName;
                    return (0, a.jsx)("div", {
                        className: "my-2 flex h-8 min-w-[32px] items-center justify-center rounded-[4px] border border-black/10 capitalize text-gray-600 dark:border-white/10 dark:text-gray-300",
                        children: t.length > 1 ? (0, a.jsx)("span", {
                            className: "text-xs",
                            children: t
                        }) : (0, a.jsx)("span", {
                            className: "text-sm",
                            children: t
                        })
                    })
                },
                eg = (0, w.vU)({
                    keyboardActionsModalTitle: {
                        id: "KeyboardActionsModal.keyboardActionsModalTitle",
                        defaultMessage: "Keyboard shortcuts",
                        description: "Title of the keyboard shortcuts modal"
                    }
                }),
                eh = function() {
                    var e = (0, C.Z)(),
                        t = (0, h.tN)(function(e) {
                            return e.activeModals.has(h.B.KeyboardActions)
                        }),
                        n = function() {
                            h.vm.closeModal(h.B.KeyboardActions)
                        },
                        r = (0, ed.CN)(),
                        i = (0, o.useMemo)(function() {
                            var e = Math.ceil(r.length / 2);
                            return [r.slice(0, e), r.slice(e)]
                        }, [r]);
                    return (0, a.jsx)(b.Z, {
                        isOpen: t,
                        onClose: n,
                        type: "success",
                        size: "custom",
                        className: "md:max-w-[672px] lg:max-w-[796px] xl:max-w-4xl",
                        closeButton: (0, a.jsx)(N.ZP.CloseButton, {
                            onClose: n
                        }),
                        title: e.formatMessage(eg.keyboardActionsModalTitle),
                        children: (0, a.jsx)(a.Fragment, {
                            children: (0, a.jsx)("div", {
                                className: "grid grid-flow-row grid-cols-[repeat(auto-fit,minmax(250px,1fr))] gap-x-9",
                                children: i.map(function(e, t) {
                                    return (0, a.jsx)("div", {
                                        className: "flex flex-col overflow-hidden",
                                        children: e.map(function(e) {
                                            return (0, a.jsx)(ec, {
                                                action: e
                                            }, e.key)
                                        })
                                    }, "col-".concat(t))
                                })
                            })
                        })
                    })
                },
                em = n(15610);

            function ep(e) {
                var t = e.urlThreadId,
                    n = e.clientThreadId,
                    v = e.isUserInCanPayGroup,
                    x = e.serviceStatus,
                    b = e.serviceAnnouncement,
                    y = e.userCountry,
                    j = (0, r._)((0, o.useState)(function() {
                        return void 0 !== t ? t : void 0 !== n ? n : (0, g.OX)()
                    }), 2),
                    w = j[0],
                    C = j[1];
                void 0 !== t && w !== t && C(t), void 0 !== t || (0, g.Zz)(w) || C((0, g.OX)());
                var k = (0, p.$T)(),
                    _ = (0, p.WY)(),
                    M = (0, p.ec)(p.F_.workspaceId),
                    T = (0, l.g)(function(e) {
                        return e.updateFlagValue
                    }),
                    N = (0, p.hz)().has(f.PL);
                (0, o.useEffect)(function() {
                    N && d.Z.gatherData()
                }, [N]), (0, o.useEffect)(function() {
                    void 0 !== v && T("isUserInCanPayGroup", v)
                }, [T, v]), (0, o.useEffect)(function() {
                    (null == x ? void 0 : x.type) && !1 === _ && s.m.warning(x.message, {
                        hasCloseButton: !0,
                        duration: 5
                    })
                }, [_, null == x ? void 0 : x.message, null == x ? void 0 : x.type]);
                var P = (0, g.GR)(w),
                    S = (0, o.useRef)(!1);
                (0, o.useEffect)(function() {
                    if (!k) {
                        var e = _ ? b.paid : b.public;
                        if ((null == e ? void 0 : e.type) && (null == e ? void 0 : e.message) && !S.current) {
                            S.current = !0;
                            var t = e.message,
                                n = {
                                    hasCloseButton: !0,
                                    duration: 15
                                };
                            switch (e.type) {
                                case "danger":
                                    s.m.danger(t, n);
                                    break;
                                case "info":
                                    s.m.info(t, n);
                                    break;
                                case "warning":
                                    s.m.warning(t, n)
                            }
                        }
                    }
                }, [b, k, _]);
                var I = (0, h.tN)(function(e) {
                    return e.activeModals.has(h.B.TempBrowseToast)
                });
                return (0, a.jsx)(u.XA.Provider, {
                    value: P,
                    children: (0, a.jsxs)(u.gB.Provider, {
                        value: !1,
                        children: [(0, a.jsx)(el, {
                            userCountry: y
                        }, M), (0, a.jsx)(eh, {}), (0, a.jsx)(eu.Z, {
                            clientThreadId: w,
                            setClientThreadId: C
                        }), (0, a.jsxs)(i.zt, {
                            children: [(0, a.jsxs)(i.fC, {
                                className: "grid w-[390px] max-w-sm grid-cols-[auto_max-content] items-center gap-x-[15px] rounded-lg bg-white p-[15px] shadow-xs [grid-template-areas:_'title_action'_'description_action'] radix-state-closed:animate-hide radix-state-open:animate-slideIn dark:bg-gray-950",
                                open: I,
                                children: [(0, a.jsxs)(i.Dx, {
                                    className: "text-slate12 mb-[5px] text-[15px] font-medium [grid-area:_title]",
                                    children: ["We've temporarily disabled the Browse with Bing ", (0, em.V)("beta"), " feature"]
                                }), (0, a.jsxs)(i.dk, {
                                    className: "text-slate11 m-0 text-[13px] leading-[1.3] [grid-area:_description]",
                                    children: ["Read the", " ", (0, a.jsx)("a", {
                                        href: "https://help.openai.com/articles/8077698-how-do-i-use-chatgpt-browse-with-bing-to-search-the-web",
                                        target: "_blank",
                                        rel: "noreferrer",
                                        className: "cursor-pointer underline",
                                        children: "Help Center article"
                                    }), "."]
                                }), (0, a.jsx)(i.aU, {
                                    altText: "Dismiss notification",
                                    asChild: !0,
                                    children: (0, a.jsx)(B.z, {
                                        color: "neutral",
                                        size: "small",
                                        onClick: function() {
                                            h.vm.closeModal(h.B.TempBrowseToast), c.m.setItem(m.DN, "true")
                                        },
                                        children: "Dismiss"
                                    })
                                }), (0, a.jsx)(i.x8, {})]
                            }), (0, a.jsx)(i.l_, {
                                className: "z-100 fixed bottom-0 right-0 m-0 flex  max-w-[100vw] list-none flex-col gap-[10px] p-[var(--viewport-padding)] outline-none [--viewport-padding:_25px]"
                            })]
                        })]
                    })
                })
            }
        },
        98611: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return sQ
                }
            });
            var r, a, i, o, s, l, u, d, c, f, g, h, m, p, v, x, b = n(39324),
                y = n(70216),
                j = n(22830),
                w = n(35250),
                C = n(13995),
                k = n(60554),
                _ = n(70079),
                M = n(1454),
                T = n(32004),
                N = n(94968),
                P = n(99486),
                S = n(31621),
                I = n(78103),
                Z = n(10301),
                F = (0, I.ZP)((0, Z.n)(function() {
                    return {
                        aborters: {}
                    }
                })),
                D = F.setState,
                E = {
                    addAborter: function(e, t) {
                        D(function(n) {
                            null != n.aborters[e] && console.warn("Setting aborter for id ".concat(e, " but it already exists")), n.aborters[e] = t
                        })
                    },
                    abortAndRemoveById: function(e) {
                        D(function(t) {
                            var n = t.aborters[e];
                            null != n && (n.abort(), delete t.aborters[e])
                        })
                    },
                    removeAborterById: function(e) {
                        D(function(t) {
                            delete t.aborters[e]
                        })
                    },
                    reset: function() {
                        D(function() {
                            return {
                                aborters: {}
                            }
                        })
                    },
                    abortAllAndReset: function() {
                        D(function(e) {
                            Object.keys(e.aborters).forEach(function(t) {
                                e.aborters[t].abort(), delete e.aborters[t]
                            })
                        })
                    }
                },
                R = n(46020),
                B = n(78931),
                A = n(32542),
                L = n(26948),
                U = n(33669);

            function O(e, t, n) {
                var r = (0, S.XL)(e),
                    a = r.title,
                    i = r.titleSource,
                    o = (0, j._)((0, _.useState)(!1), 2),
                    s = o[0],
                    l = o[1],
                    u = null != a ? a : t,
                    d = (0, _.useRef)(u);
                return (0, _.useEffect)(function() {
                    return n && i === S._L.Generated && u !== d.current && l(!0),
                        function() {
                            d.current = u
                        }
                }, [n, u, i]), {
                    isTypingEffect: s,
                    resolvedTitle: u
                }
            }
            var q = n(51217),
                z = n(19012);

            function H(e) {
                var t = e.text,
                    n = (0, z.Z)(),
                    r = (0, j._)((0, _.useState)(!0), 2),
                    a = r[0],
                    i = r[1],
                    o = (0, j._)((0, _.useState)(0), 2),
                    s = o[0],
                    l = o[1],
                    u = (0, _.useMemo)(function() {
                        return new W().humanTypingDelaysQuertyDistance(t)
                    }, [t]);
                return (0, _.useEffect)(function() {
                    t && a && (i(!0), u.forEach(function(e, t) {
                        setTimeout(function() {
                            n() && (l(t), t === u.length - 1 && i(!1))
                        }, e)
                    }))
                }, [u, n, a, t]), (0, w.jsxs)(w.Fragment, {
                    children: [t.substring(0, s + 1), a && "▋"]
                })
            }
            var W = function() {
                    function e() {
                        (0, q._)(this, e)
                    }
                    var t = e.prototype;
                    return t.qwertyDistance = function(e, t) {
                        var n, r, a = {
                                q: [0, 0],
                                w: [1, 0],
                                e: [2, 0],
                                r: [3, 0],
                                t: [4, 0],
                                y: [5, 0],
                                u: [6, 0],
                                i: [7, 0],
                                o: [8, 0],
                                p: [9, 0],
                                a: [0, 1],
                                s: [1, 1],
                                d: [2, 1],
                                f: [3, 1],
                                g: [4, 1],
                                h: [5, 1],
                                j: [6, 1],
                                k: [7, 1],
                                l: [8, 1],
                                z: [0, 2],
                                x: [1, 2],
                                c: [2, 2],
                                v: [3, 2],
                                b: [4, 2],
                                n: [5, 2],
                                m: [6, 2]
                            },
                            i = (0, j._)(null !== (n = a[e.toLowerCase()]) && void 0 !== n ? n : [0, 0], 2),
                            o = i[0],
                            s = i[1],
                            l = (0, j._)(null !== (r = a[t.toLowerCase()]) && void 0 !== r ? r : [0, 0], 2);
                        return Math.abs(o - l[0]) + Math.abs(s - l[1])
                    }, t.humanTypingDelaysQuertyDistance = function(e) {
                        for (var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100, r = 0, a = [], i = 0; i < e.length; ++i) {
                            var o = void 0;
                            if (i > 0) {
                                var s = this.qwertyDistance(e[i - 1], e[i]);
                                o = 0 === s ? this.getRandomInt(t, Math.floor(n / 2)) : 1 === s ? this.getRandomInt(t, Math.floor(2 * n / 3)) : this.getRandomInt(t, n)
                            } else o = this.getRandomInt(t, n);
                            a.push(o + r), r += o
                        }
                        return a
                    }, t.getRandomInt = function(e, t) {
                        return Math.floor(Math.random() * (t - e + 1)) + e
                    }, e
                }(),
                V = n(71209),
                Q = n(4337),
                G = n(19841),
                $ = n(72201),
                Y = n(26430),
                J = n(84913),
                K = n(44043),
                X = n(82187),
                ee = n(69262),
                et = n(70737),
                en = n(97296),
                er = n(91530),
                ea = n.n(er),
                ei = n(70671),
                eo = n(21389),
                es = n(50795),
                el = n(82081),
                eu = n(32877),
                ed = n(21817),
                ec = n(67273),
                ef = n(97747),
                eg = n(89368),
                eh = n(88327),
                em = n(1821),
                ep = n(44009),
                ev = n(62509),
                ex = n(6948),
                eb = "oai/apps/hasSeenHistoryFilteredDisclosure/".concat("2023-03-21"),
                ey = "conversationHistory";

            function ej() {
                var e, t = (0, B.hz)().has(eu.Ud),
                    n = (0, B.$T)(),
                    r = (0, ev.kP)().session,
                    a = null == r ? void 0 : r.accessToken,
                    i = !t && !!a && !n,
                    o = (0, ep.N)({
                        queryKey: [ey],
                        queryFn: function(e) {
                            var t = e.pageParam;
                            return P.ZP.getConversations(t || 0, 28, null == r ? void 0 : r.accessToken)
                        },
                        getNextPageParam: function(e) {
                            var t = e.offset + e.limit;
                            return t < e.total ? t : void 0
                        },
                        enabled: i
                    }),
                    s = o.data,
                    l = o.fetchNextPage,
                    u = o.hasNextPage,
                    d = o.isInitialLoading,
                    c = o.isFetchingNextPage,
                    f = o.isError,
                    g = (0, _.useMemo)(function() {
                        return null !== (e = null == s ? void 0 : s.pages.flatMap(function(e) {
                            return e.items
                        })) && void 0 !== e ? e : []
                    }, [s]);
                return {
                    data: s,
                    conversations: g,
                    fetchNextPage: l,
                    hasNextPage: u,
                    isLoading: d,
                    isFetchingNextPage: c,
                    isError: i && f
                }
            }

            function ew() {
                var e = (0, C.NL)();
                return (0, _.useCallback)(function() {
                    e.invalidateQueries([ey])
                }, [e])
            }

            function eC() {
                var e = (0, Q._)(["flex flex-col gap-2 pb-2 text-gray-100 text-sm\n", ""]);
                return eC = function() {
                    return e
                }, e
            }

            function ek() {
                var e = (0, Q._)(["flex py-3 px-3 items-center gap-3 relative rounded-md hover:bg-[#2A2B32] cursor-pointer break-all\n", "\n"]);
                return ek = function() {
                    return e
                }, e
            }

            function e_() {
                var e = (0, Q._)(["flex py-3 px-3 items-center gap-3 relative rounded-md hover:bg-[#2A2B32] cursor-pointer hover:pr-14 break-all\n", "\n"]);
                return e_ = function() {
                    return e
                }, e
            }

            function eM() {
                var e = (0, Q._)(["text-sm border-none bg-transparent p-0 m-0 w-full"]);
                return eM = function() {
                    return e
                }, e
            }

            function eT() {
                var e = (0, Q._)(["flex-1 text-ellipsis max-h-5 overflow-hidden break-all relative"]);
                return eT = function() {
                    return e
                }, e
            }

            function eN() {
                var e = (0, Q._)(["h-9 pb-2 pt-3 px-3 text-xs text-gray-500 font-medium text-ellipsis overflow-hidden break-all bg-gray-900"]);
                return eN = function() {
                    return e
                }, e
            }

            function eP() {
                var e = (0, Q._)(["absolute inset-y-0 right-0 w-8 z-10 bg-gradient-to-l\n", ""]);
                return eP = function() {
                    return e
                }, e
            }

            function eS() {
                var e = (0, Q._)(["absolute flex right-1 z-10 text-gray-300\n", ""]);
                return eS = function() {
                    return e
                }, e
            }

            function eI() {
                var e = (0, Q._)(["p-1 hover:text-white"]);
                return eI = function() {
                    return e
                }, e
            }
            var eZ = (0, N.vU)({
                    historyBucketToday: {
                        id: "history.bucket.today",
                        defaultMessage: "Today",
                        description: "Label for today's history bucket"
                    },
                    historyBucketYesterday: {
                        id: "history.bucket.yesterday",
                        defaultMessage: "Yesterday",
                        description: "Label for yesterday's history bucket"
                    },
                    historyBucketLastSeven: {
                        id: "history.bucket.lastSeven",
                        defaultMessage: "Previous 7 Days",
                        description: "Label for the history bucket of the previous 7 days"
                    },
                    historyBucketLastThirty: {
                        id: "history.bucket.lastThirty",
                        defaultMessage: "Previous 30 Days",
                        description: "Label for the history bucket of the previous 30 days"
                    },
                    unableToLoadHistory: {
                        id: "history.unableToLoad",
                        defaultMessage: "Unable to load history",
                        description: "Error message when history fails to load"
                    },
                    retryButton: {
                        id: "history.retryButton",
                        defaultMessage: "Retry",
                        description: "Button to retry loading history"
                    },
                    showMoreButton: {
                        id: "history.showMoreButton",
                        defaultMessage: "Show more",
                        description: "Button to show more history items"
                    },
                    deleteModalTitle: {
                        id: "history.deleteModalTitle",
                        defaultMessage: "Delete chat?",
                        description: "Title of the modal to confirm deleting a conversation"
                    },
                    deleteModalBody: {
                        id: "history.deleteModalBody",
                        defaultMessage: "This will delete {title}.",
                        description: "Body of the modal to confirm deleting a conversation"
                    },
                    deleteModalConfirm: {
                        id: "history.deleteModalConfirm",
                        defaultMessage: "Delete",
                        description: "Button to confirm deleting a conversation"
                    },
                    deleteModalCancel: {
                        id: "history.deleteModalCancel",
                        defaultMessage: "Cancel",
                        description: "Button to cancel deleting a conversation"
                    }
                }),
                eF = {
                    initial: function(e) {
                        return e.isNew ? {
                            opacity: 0,
                            height: 0,
                            overflow: "hidden"
                        } : {}
                    },
                    animate: function() {
                        return {
                            opacity: 1,
                            height: "auto"
                        }
                    },
                    exit: function() {
                        return {
                            opacity: 0,
                            height: 0
                        }
                    }
                };

            function eD(e) {
                var t, n, r = e.activeId,
                    a = e.onNewThread,
                    i = e.setActiveRequests,
                    o = (0, ei.Z)(),
                    s = (0, j._)((0, _.useState)(!1), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, j._)((0, _.useState)(0), 2),
                    c = d[0],
                    f = d[1],
                    g = (0, ed.Z)(),
                    h = ej(),
                    m = h.conversations,
                    p = h.hasNextPage,
                    v = h.fetchNextPage,
                    x = h.isLoading,
                    y = h.isFetchingNextPage,
                    C = h.isError,
                    k = (0, B.hz)().has(eu.DY),
                    M = (0, _.useRef)(null),
                    N = (0, _.useCallback)(function(e) {
                        var t;
                        k && !x && null != e && (null === (t = M.current) || void 0 === t || t.disconnect(), M.current = new IntersectionObserver(function(e) {
                            e[0].isIntersecting && p && v()
                        }), M.current.observe(e))
                    }, [k, x, p, v]);
                (0, _.useEffect)(function() {
                    return function() {
                        var e;
                        null === (e = M.current) || void 0 === e || e.disconnect()
                    }
                }, []);
                var P = ew();
                (0, _.useEffect)(function() {
                    ex.m.removeItem(eb)
                }, []);
                var S = (t = (0, _.useRef)(), n = (0, _.useRef)(), ((0, _.useEffect)(function() {
                    t.current = n.current, n.current = m
                }, [m]), m === n.current) ? t.current : n.current);
                (0, _.useEffect)(function() {
                    g(function() {
                        f(c + 1)
                    }, (0, Y.Z)((0, J.Z)(), Date.now()) + 1e3)
                }, [c, g]);
                var I = 0 === m.length,
                    Z = (0, _.useMemo)(function() {
                        return m.reduce(function(e, t) {
                            var n, r, a = new Date(null !== (r = null !== (n = t.update_time) && void 0 !== n ? n : t.create_time) && void 0 !== r ? r : 0),
                                i = (0, $.Z)(new Date, a);
                            if (0 === i) e.recent.today.items.push(t);
                            else if (i <= 1) e.recent.yesterday.items.push(t);
                            else if (i <= 7) e.recent.lastSeven.items.push(t);
                            else if (i <= 30) e.recent.lastThirty.items.push(t);
                            else if ((0, ee.Z)(a)) {
                                var s = (0, X.Z)(a),
                                    l = (0, K.Z)(a),
                                    u = "".concat(s, "-").concat(l);
                                e.dynamicMonths[u] ? e.dynamicMonths[u].items.push(t) : e.dynamicMonths[u] = {
                                    label: o.formatDate(a, {
                                        month: "long"
                                    }),
                                    items: [t]
                                }
                            } else {
                                var d = (0, X.Z)(a),
                                    c = "".concat(d, "-");
                                e.dynamicYears[c] ? e.dynamicYears[c].items.push(t) : e.dynamicYears[c] = {
                                    label: o.formatDate(a, {
                                        year: "numeric"
                                    }),
                                    items: [t]
                                }
                            }
                            return e
                        }, {
                            recent: {
                                today: {
                                    label: (0, w.jsx)(T.Z, (0, b._)({}, eZ.historyBucketToday)),
                                    items: []
                                },
                                yesterday: {
                                    label: (0, w.jsx)(T.Z, (0, b._)({}, eZ.historyBucketYesterday)),
                                    items: []
                                },
                                lastSeven: {
                                    label: (0, w.jsx)(T.Z, (0, b._)({}, eZ.historyBucketLastSeven)),
                                    items: []
                                },
                                lastThirty: {
                                    label: (0, w.jsx)(T.Z, (0, b._)({}, eZ.historyBucketLastThirty)),
                                    items: []
                                }
                            },
                            dynamicMonths: {},
                            dynamicYears: {}
                        })
                    }, [c, m]);
                return (0, w.jsxs)(eE, {
                    $centered: x || C && I,
                    children: [I && x && (0, w.jsx)(em.Z, {
                        className: "m-auto"
                    }), I && C && (0, w.jsxs)("div", {
                        className: "p-3 text-center italic text-gray-500",
                        children: [(0, w.jsx)(T.Z, (0, b._)({}, eZ.unableToLoadHistory)), !l && (0, w.jsx)("div", {
                            className: "mt-1",
                            children: (0, w.jsx)(ec.z, {
                                as: "button",
                                color: "dark",
                                size: "small",
                                className: "m-auto mt-2",
                                onClick: function() {
                                    u(!0), P()
                                },
                                children: (0, w.jsx)(T.Z, (0, b._)({}, eZ.retryButton))
                            })
                        })]
                    }), !x && (0, w.jsx)("div", {
                        children: (0, w.jsx)(et.M, {
                            initial: !1,
                            children: [Z.recent, Z.dynamicMonths, Z.dynamicYears].flatMap(function(e, t) {
                                return (0, w.jsx)("span", {
                                    children: Object.entries(e).map(function(e) {
                                        var t = (0, j._)(e, 2),
                                            n = t[0],
                                            o = t[1],
                                            s = o.items,
                                            l = o.label;
                                        if ("today" !== n && !s.length) return null;
                                        var u = !!s.find(function(e) {
                                            var t;
                                            return m.length > 0 && e.id === (null === (t = m[0]) || void 0 === t ? void 0 : t.id)
                                        });
                                        return (0, w.jsxs)(en.E.div, {
                                            className: "relative",
                                            layoutId: "bucket-".concat(n),
                                            layout: "position",
                                            initial: {
                                                height: 0,
                                                opacity: 1,
                                                position: "relative"
                                            },
                                            animate: {
                                                height: "auto",
                                                opacity: 1,
                                                transition: {
                                                    duration: .2,
                                                    ease: "easeIn"
                                                }
                                            },
                                            children: [s.length > 0 && (0, w.jsx)(en.E.div, {
                                                className: (0, G.Z)("sticky top-0", u ? "z-[16]" : "z-[14]"),
                                                layoutId: "bucketTitle-".concat(n),
                                                layout: "position",
                                                children: (0, w.jsx)(eq, {
                                                    children: l
                                                })
                                            }), (0, w.jsx)("ol", {
                                                children: s.map(function(e, t) {
                                                    var n = r === e.id,
                                                        o = null == S ? void 0 : S.find(function(t) {
                                                            return t.id === e.id
                                                        });
                                                    return (0, w.jsx)(en.E.li, {
                                                        className: (0, G.Z)("relative", u && 0 === t ? "z-[15]" : ""),
                                                        layoutId: "".concat(e.id),
                                                        layout: "position",
                                                        custom: {
                                                            isNew: !o
                                                        },
                                                        variants: eF,
                                                        initial: "initial",
                                                        animate: "animate",
                                                        exit: "exit",
                                                        children: (0, w.jsx)(eR, {
                                                            id: e.id,
                                                            title: e.title,
                                                            active: n,
                                                            onNewThread: a,
                                                            setActiveRequests: i,
                                                            forwardRef: p && m[m.length - 5 - 1].id === e.id ? N : void 0
                                                        })
                                                    }, "history-item-".concat(e.id))
                                                })
                                            })]
                                        }, n)
                                    })
                                }, "category-".concat(t))
                            })
                        })
                    }), k ? y && (0, w.jsx)("div", {
                        className: "m-4 mb-5 flex justify-center",
                        children: (0, w.jsx)(em.Z, {})
                    }) : (0, w.jsx)(w.Fragment, {
                        children: p && (0, w.jsx)(ec.z, {
                            as: "button",
                            onClick: function() {
                                return v()
                            },
                            color: "dark",
                            className: "m-auto mb-2",
                            size: "small",
                            loading: y,
                            children: (0, w.jsx)(T.Z, (0, b._)({}, eZ.showMoreButton))
                        })
                    })]
                })
            }
            var eE = eo.Z.div(eC(), function(e) {
                return e.$centered && "h-full justify-center items-center"
            });

            function eR(e) {
                var t = e.id,
                    n = e.title,
                    r = e.active,
                    a = e.onNewThread,
                    i = e.forwardRef,
                    o = e.setActiveRequests,
                    s = (0, U.w$)(),
                    l = (0, k.useRouter)(),
                    u = (0, j._)((0, _.useState)(!1), 2),
                    d = u[0],
                    c = u[1],
                    f = (0, _.useRef)(null),
                    g = ew(),
                    h = (0, _.useCallback)(function(e) {
                        var r, a;
                        if (null == e || e.preventDefault(), c(!1), (null === (r = f.current) || void 0 === r ? void 0 : r.value) && (null === (a = f.current) || void 0 === a ? void 0 : a.value) !== n) {
                            var i = f.current.value;
                            P.ZP.patchConversation(t, {
                                title: i
                            }), S.tQ.setTitle(t, i, S._L.User), es.o.logEvent(el.a.renameThread, {
                                threadId: t,
                                content: i
                            }), g()
                        }
                    }, [t, g, n]),
                    m = (0, _.useCallback)(function(e) {
                        "Enter" === e.key && h()
                    }, [h]),
                    p = (0, _.useCallback)(function() {
                        P.ZP.patchConversation(t, {
                            is_visible: !1
                        }).then(function() {
                            g()
                        }), a()
                    }, [t, a, g]),
                    v = (0, _.useCallback)(function(e) {
                        E.abortAllAndReset(), o(new Set), e.preventDefault(), es.o.logEvent(el.a.loadThread, {
                            threadId: t
                        }), l.push("/c/".concat(t), void 0, {
                            shallow: !0
                        })
                    }, [t, l, o]),
                    x = O(t, n, r),
                    b = x.resolvedTitle,
                    y = x.isTypingEffect;
                if (d) return (0, w.jsxs)(eL, {
                    $active: r,
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: M.IC0,
                        className: "flex-shrink-0"
                    }), (0, w.jsx)(eU, {
                        ref: f,
                        type: "text",
                        defaultValue: null != b ? b : "",
                        autoFocus: !0,
                        onKeyDown: m,
                        className: "mr-0",
                        onBlur: h
                    }), (0, w.jsxs)(eH, {
                        $active: !0,
                        children: [(0, w.jsx)(eW, {
                            onClick: h,
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.UgA
                            })
                        }), (0, w.jsx)(eW, {
                            onClick: function(e) {
                                e.preventDefault(), c(!1)
                            },
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.q5L
                            })
                        })]
                    })]
                });
                var C = y && r && s;
                return (0, w.jsxs)(w.Fragment, {
                    children: [r && (0, w.jsx)(eB, {
                        title: n,
                        handleDelete: p
                    }), (0, w.jsxs)(eA, {
                        onClick: r ? ea() : v,
                        $active: r,
                        className: (0, G.Z)("group", C && "animate-flash"),
                        ref: i,
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.IC0
                        }), (0, w.jsxs)(eO, {
                            children: [C ? (0, w.jsx)(H, {
                                text: null != b ? b : ""
                            }) : b, (!y || !r) && (0, w.jsx)(ez, {
                                $active: r
                            })]
                        }), r && (0, w.jsxs)(eH, {
                            $active: r,
                            children: [(0, w.jsx)(eW, {
                                onClick: function(e) {
                                    e.preventDefault(), c(!0)
                                },
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M.Nte
                                })
                            }), (0, w.jsx)(eW, {
                                onClick: function() {
                                    R.vm.openModal(R.B.DeleteChatConfirmation)
                                },
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M.Ybf
                                })
                            })]
                        })]
                    })]
                })
            }
            var eB = function(e) {
                    var t = e.handleDelete,
                        n = e.title,
                        r = (0, ei.Z)(),
                        a = (0, R.tN)(function(e) {
                            return e.activeModals.has(R.B.DeleteChatConfirmation)
                        }),
                        i = function() {
                            R.vm.closeModal(R.B.DeleteChatConfirmation)
                        };
                    return (0, w.jsx)(eg.Z, {
                        isOpen: a,
                        onClose: i,
                        type: "success",
                        title: r.formatMessage(eZ.deleteModalTitle),
                        primaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: r.formatMessage(eZ.deleteModalConfirm),
                            color: "danger",
                            onClick: function() {
                                t(), i()
                            }
                        }),
                        secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: r.formatMessage(eZ.deleteModalCancel),
                            color: "neutral",
                            onClick: i
                        }),
                        children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, eZ.deleteModalBody), {
                            values: {
                                title: (0, w.jsx)("strong", {
                                    children: n
                                })
                            }
                        }))
                    })
                },
                eA = eo.Z.a(ek(), function(e) {
                    return e.$active ? "bg-gray-800 pr-14 hover:bg-gray-800" : "hover:pr-4 bg-gray-900"
                }),
                eL = eo.Z.div(e_(), function(e) {
                    return e.$active ? "pr-14 bg-gray-800 hover:bg-gray-800" : "bg-gray-900"
                }),
                eU = eo.Z.input(eM()),
                eO = eo.Z.div(eT()),
                eq = eo.Z.h3(eN()),
                ez = eo.Z.div(eP(), function(e) {
                    return e.$active ? "from-gray-800" : "from-gray-900 group-hover:from-[#2A2B32]"
                }),
                eH = eo.Z.div(eS(), function(e) {
                    return e.$active ? "visible" : "invisible group-hover:visible"
                }),
                eW = eo.Z.button(eI()),
                eV = n(32148),
                eQ = n(21739),
                eG = n(21722),
                e$ = n(39889),
                eY = n(25260),
                eJ = n(44544),
                eK = n(19579),
                eX = n.n(eK),
                e0 = n(75641),
                e1 = n(70596),
                e2 = n(88809),
                e3 = n(6038),
                e5 = n(32367),
                e4 = n(52696);

            function e8(e) {
                var t = e.workspace,
                    n = (0, ev.kP)().session,
                    r = (0, B.ec)(function(e) {
                        return e.currentWorkspace
                    }),
                    a = (null == r ? void 0 : r.id) === t.id,
                    i = (0, j._)((0, _.useState)(!1), 2),
                    o = i[0],
                    s = i[1],
                    l = (0, e5.Z)().onEnableHistory,
                    u = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return s(!0), t.structure === e0.CZ.WORKSPACE ? (0, eJ.setCookie)(e1.Y, t.id) : B.ec.getState().workspaces.some(function(e) {
                                return e.structure === e0.CZ.WORKSPACE
                            }) ? (0, eJ.setCookie)(e1.Y, e1.b) : (0, eJ.deleteCookie)(e1.Y), B.w_.setCurrentWorkspace(t), l(), (0, e2.I)(), window.location.href = "/", [2]
                        })
                    }), [t, l]),
                    d = (0, e4.Ix)(t),
                    c = (0, e4.qH)(t),
                    f = (0, w.jsx)("div", {
                        className: "flex items-center justify-center",
                        children: (0, w.jsx)(e3.B0, {})
                    });
                if (t.structure === e0.CZ.PERSONAL) {
                    if (!(null == n ? void 0 : n.user)) return null;
                    f = (0, w.jsx)("div", {
                        className: "flex items-center justify-center",
                        children: (0, w.jsx)(eX(), {
                            alt: "Profile",
                            src: n.user.picture,
                            width: 32,
                            height: 32,
                            className: "flex items-center justify-center rounded-sm"
                        })
                    })
                }
                return (0, w.jsxs)(a ? "div" : "button", {
                    onClick: a ? ea() : u,
                    className: (0, G.Z)({
                        "flex w-full items-center gap-2 rounded-lg  p-4 hover:bg-gray-50 focus:bg-gray-50 dark:hover:bg-gray-800 dark:focus:bg-gray-800": !0,
                        "bg-gray-50 dark:bg-gray-800": a
                    }),
                    children: [(0, w.jsxs)("div", {
                        className: "flex w-full gap-4",
                        children: [f, (0, w.jsxs)("div", {
                            className: "flex w-full flex-1 flex-col items-start justify-start",
                            children: [(0, w.jsx)("div", {
                                className: "inline align-top font-medium",
                                children: d
                            }), (0, w.jsx)("div", {
                                className: "text-sm text-gray-500",
                                children: c
                            })]
                        })]
                    }), (0, w.jsxs)("div", {
                        className: "flex h-full items-center p-1",
                        children: [a && !o && (0, w.jsx)(eh.ZP, {
                            icon: eY.Z,
                            size: "medium"
                        }), o && (0, w.jsx)(em.Z, {})]
                    })]
                })
            }

            function e7(e) {
                var t = e.data.map(function(e) {
                    return (0, w.jsx)(e8, {
                        workspace: e
                    }, e.id)
                });
                return (0, w.jsx)("div", {
                    className: "flex w-full flex-col gap-2",
                    children: t
                })
            }

            function e6() {
                var e = (0, R.EV)(R.B.WorkspaceSwitcher),
                    t = (0, e4._O)(),
                    n = (0, ei.Z)(),
                    r = (0, _.useCallback)(function() {
                        R.vm.closeModal(R.B.WorkspaceSwitcher)
                    }, []);
                return 0 === t.length ? null : (0, w.jsx)(eg.Z, {
                    onClose: r,
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: r
                    }),
                    type: "success",
                    isOpen: e,
                    size: "normal",
                    title: n.formatMessage(e9.workspaceSwitcherTitle),
                    children: (0, w.jsx)("div", {
                        className: "flex w-full items-center justify-between",
                        children: (0, w.jsx)(e7, {
                            data: t
                        })
                    })
                })
            }
            var e9 = (0, N.vU)({
                    workspaceSwitcherTitle: {
                        id: "workspaceSwitcher.title",
                        defaultMessage: "Choose Account",
                        description: "title for account switcher modal"
                    }
                }),
                te = n(81949),
                tt = n(74686),
                tn = n(56115),
                tr = n(92720),
                ta = n(55629),
                ti = n(45635);

            function to(e) {
                var t = e.accept,
                    n = e.onFilePicked,
                    r = e.loading,
                    a = e.disabled,
                    i = e.className,
                    o = e.text,
                    s = e.multiple,
                    l = (0, _.useRef)(null),
                    u = (0, _.useCallback)(function() {
                        var e;
                        null === (e = l.current) || void 0 === e || e.click()
                    }, []),
                    d = (0, _.useCallback)(function(e) {
                        var t = e.target.files;
                        t && t.length > 0 && (n(Array.from(t)), e.target.value = "")
                    }, [n]);
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(ec.z, {
                        onClick: u,
                        disabled: a || r,
                        color: "none",
                        className: i,
                        children: (0, w.jsxs)("div", {
                            className: "flex items-center space-x-2",
                            children: [r ? (0, w.jsx)(em.Z, {
                                className: "h-4 w-4"
                            }) : (0, w.jsx)(eh.ZP, {
                                icon: M.OvN,
                                size: "small"
                            }), o && (0, w.jsx)("span", {
                                children: o
                            })]
                        })
                    }), (0, w.jsx)("input", {
                        type: "file",
                        accept: t,
                        ref: l,
                        className: "hidden",
                        onChange: d,
                        multiple: void 0 !== s && s
                    })]
                })
            }
            var ts = n(63031),
                tl = n(88798),
                tu = n(73610),
                td = ["application/pdf", "text/plain", "text/markdown", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/csv"],
                tc = (0, N.vU)({
                    myFiles: {
                        id: "filesModal.myFiles",
                        defaultMessage: "My Files",
                        description: "Title for the files modal"
                    },
                    noFilesFound: {
                        id: "filesModal.noFilesFound",
                        defaultMessage: "No files found.",
                        description: "Message displayed when no files are found"
                    },
                    uploadFile: {
                        id: "filesModal.uploadFile",
                        defaultMessage: "Upload File",
                        description: "Label for the upload file button"
                    },
                    fileDownloadFailed: {
                        id: "filesModal.fileDownloadFailed",
                        defaultMessage: "File download failed. Please try again.",
                        description: "Error message when file download fails"
                    },
                    fileDeleteFailed: {
                        id: "filesModal.fileDeleteFailed",
                        defaultMessage: "File delete failed. Please try again.",
                        description: "Error message when file delete fails"
                    },
                    fileUploadFailed: {
                        id: "filesModal.fileUploadFailed",
                        defaultMessage: "File upload failed. Please try again.",
                        description: "Error message when file upload fails"
                    },
                    fileUploaded: {
                        id: "filesModal.fileUploaded",
                        defaultMessage: "Uploaded file",
                        description: "Success message when file is uploaded"
                    },
                    fileDeleted: {
                        id: "filesModal.fileDeleted",
                        defaultMessage: "File deleted",
                        description: "Success message when file is deleted"
                    },
                    allFilesDeleted: {
                        id: "filesModal.allFilesDeleted",
                        defaultMessage: "All files deleted",
                        description: "Success message when all files are deleted"
                    },
                    allFilesDeleteFailed: {
                        id: "filesModal.allFilesDeletedFailed",
                        defaultMessage: "All files delete failed. Please try again.",
                        description: "Error message when all files delete fails"
                    },
                    confirmDeleteAll: {
                        id: "filesModal.confirmDeleteAll",
                        defaultMessage: "Are you sure you want to delete all files?",
                        description: "Confirmation message for deleting all files"
                    },
                    downloadAll: {
                        id: "filesModal.downloadAll",
                        defaultMessage: "Download All",
                        description: "Label for the download all button"
                    },
                    deleteAll: {
                        id: "filesModal.deleteAll",
                        defaultMessage: "Delete All",
                        description: "Label for the delete all button"
                    },
                    name: {
                        id: "filesModal.name",
                        defaultMessage: "Name",
                        description: "Label for the name column"
                    },
                    date: {
                        id: "filesModal.date",
                        defaultMessage: "Date",
                        description: "Label for the date column"
                    },
                    size: {
                        id: "filesModal.size",
                        defaultMessage: "Size",
                        description: "Label for the size column"
                    },
                    successfullyEmbeddedFileTooltip: {
                        id: "filesModal.successfullyEmbeddedFileTooltip",
                        defaultMessage: "Successfully processed file for searching",
                        description: "Tooltip for the successfully embedded file icon"
                    },
                    failedToEmbedFileTooltip: {
                        id: "filesModal.failedToEmbedFileTooltip",
                        defaultMessage: "Failed to process file for searching,\nplease try deleting and re-uploading",
                        description: "Tooltip for the failed to embed file icon"
                    },
                    embeddingFileTooltip: {
                        id: "filesModal.embeddingFileTooltip",
                        defaultMessage: "Processing file for searching...",
                        description: "Tooltip for the embedding file icon"
                    },
                    deleteHistoryModalCancel: {
                        id: "filesModal.deleteHistoryModalCancel",
                        defaultMessage: "Cancel",
                        description: "Label for the cancel button"
                    },
                    confirmDownloadAll: {
                        id: "filesModal.confirmDownloadAll",
                        defaultMessage: "Are you sure you want to download all files?",
                        description: "Confirmation message for downloading all files"
                    },
                    confirmCancelDownloadAll: {
                        id: "filesModal.confirmCancelDownloadAll",
                        defaultMessage: "Cancel Download All",
                        description: "Label for the cancel download all button in the confirmation modal"
                    },
                    tooManyFilesWithSameName: {
                        id: "filesModal.tooManyFilesWithSameName",
                        defaultMessage: "Too many files with the same name. Please rename your file.",
                        description: "Error message when too many files have the same name"
                    },
                    tooManyFilesUploadedAtOnce: {
                        id: "filesModal.tooManyFilesUploadedAtOnce",
                        defaultMessage: "You can only upload up to {maxFiles} files at a time.",
                        description: "Error message when too many files are uploaded at once"
                    },
                    totalFileSizeExceedsLimit: {
                        id: "filesModal.totalFileSizeExceedsLimit",
                        defaultMessage: "The total size of the files exceeds the limit of {maxSize}.",
                        description: "Error message when the total file size exceeds the limit"
                    },
                    filesModalDescription: {
                        id: "filesModal.filesModalDescription",
                        defaultMessage: "Files can be used with the My Files Browsing model. {totalUploadedSize} / {maxFileSize} of storage used.",
                        description: "Description for the files modal"
                    }
                });
            (r = c || (c = {})).Uploading = "uploading", r.Deleting = "deleting";
            var tf = function(e, t) {
                for (var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3, r = 1, a = e, i = e.lastIndexOf("."), o = i >= 0 ? e.slice(0, i) : e, s = i >= 0 ? e.slice(i) : ""; t.find(function(e) {
                        return e.name === a
                    }) && r <= n;) a = "".concat(o, " (").concat(r, ")").concat(s), r++;
                if (r > n) throw Error();
                return a
            };

            function tg(e) {
                var t = e.label,
                    n = e.children;
                return (0, w.jsx)(ti.u, {
                    side: "top",
                    size: "xsmall",
                    sideOffset: 4,
                    label: t,
                    children: n
                })
            }

            function th(e) {
                var t = e.file,
                    n = e.refetch,
                    r = e.handleFileDelete,
                    a = e.handleFileDeleteFailed,
                    i = e.session,
                    o = e.downloadedFiles,
                    s = e.setDownloadedFiles,
                    l = (0, _.useMemo)(function() {
                        return (0, tn.Z)(new Date(t.ready_time), "MMM d, yyyy")
                    }, [t.ready_time]),
                    u = (0, _.useMemo)(function() {
                        var e;
                        return (e = t.size) < 1048576 ? "".concat((e / 1024).toFixed(0), " KB") : "".concat((e / 1048576).toFixed(1), " MB")
                    }, [t.size]),
                    d = (0, ei.Z)(),
                    f = (0, ts.O6)(),
                    g = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, f(t.id, t.name)];
                                case 1:
                                    return e.sent() && s((0, te._)(o).concat([t.id])), [2]
                            }
                        })
                    }), [t, o, s, f]),
                    h = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    if (!i) return [2];
                                    r(t), e.label = 1;
                                case 1:
                                    return e.trys.push([1, 4, , 5]), [4, P.ZP.deleteFileFromFileService(t.id, i.accessToken)];
                                case 2:
                                    return e.sent(), tl.m.success(d.formatMessage(tc.fileDeleted)), [4, n()];
                                case 3:
                                    return e.sent(), [3, 5];
                                case 4:
                                    return e.sent(), a(t), tl.m.danger(d.formatMessage(tc.fileDeleteFailed)), [3, 5];
                                case 5:
                                    return [2]
                            }
                        })
                    }), [r, a, i, t, n, d]);
                return (0, w.jsxs)(ta.Z.Row, {
                    disabled: t.state === c.Uploading,
                    children: [(0, w.jsx)(ta.Z.Cell, {
                        children: (0, w.jsxs)("div", {
                            className: "inline-flex max-w-full gap-2 align-top",
                            children: [t.retrieval_index_status === e0.Xf.Success ? (0, w.jsx)(tg, {
                                label: d.formatMessage(tc.successfullyEmbeddedFileTooltip),
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M._rq,
                                    size: "xsmall",
                                    className: "mt-1.5 flex-shrink-0 text-green-600"
                                })
                            }) : t.retrieval_index_status === e0.Xf.Failed ? (0, w.jsx)(tg, {
                                label: d.formatMessage(tc.failedToEmbedFileTooltip),
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M.$Rx,
                                    size: "xsmall",
                                    className: "mt-1.5 flex-shrink-0 text-red-500"
                                })
                            }) : (0, w.jsx)(tg, {
                                label: d.formatMessage(tc.embeddingFileTooltip),
                                children: (0, w.jsx)(em.Z, {
                                    className: "mt-1 flex-shrink-0 text-gray-500 dark:text-gray-100"
                                })
                            }), (0, w.jsx)("button", {
                                className: (0, G.Z)(o.includes(t.id) ? "text-[#800080]" : "hover:text-gray-900 dark:hover:text-gray-100", "truncate whitespace-normal break-words text-left focus:outline-none"),
                                onClick: g,
                                children: (0, w.jsx)("span", {
                                    children: t.name
                                })
                            })]
                        })
                    }), (0, w.jsx)(ta.Z.Cell, {
                        className: "align-top",
                        children: t.state !== c.Uploading && l
                    }), (0, w.jsx)(ta.Z.Cell, {
                        className: "align-top",
                        children: t.state !== c.Uploading && u
                    }), (0, w.jsx)(ta.Z.Cell, {
                        textAlign: "right",
                        className: "align-top",
                        children: (0, w.jsx)("div", {
                            className: "flex justify-end space-x-2",
                            children: t.state !== c.Uploading && (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)("button", {
                                    className: "text-gray-500 hover:text-gray-600",
                                    onClick: g,
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M._hL,
                                        size: "small"
                                    })
                                }), (0, w.jsx)("button", {
                                    className: "text-gray-500 hover:text-gray-600",
                                    onClick: h,
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M.Ybf,
                                        size: "small"
                                    })
                                })]
                            })
                        })
                    })]
                })
            }

            function tm() {
                var e, t, n, r, a, i = (0, ei.Z)(),
                    o = (0, tu.W)(),
                    s = o.data,
                    l = o.isLoading,
                    u = o.refetch,
                    d = (0, j._)((0, _.useState)([]), 2),
                    f = d[0],
                    g = d[1],
                    h = (0, _.useRef)([]),
                    m = (0, j._)((0, _.useState)([]), 2),
                    p = m[0],
                    v = m[1],
                    x = (0, ed.Z)(),
                    y = (0, ev.kP)().session,
                    C = (0, _.useMemo)(function() {
                        return null !== (a = null == s ? void 0 : s.files) && void 0 !== a ? a : []
                    }, [s]),
                    k = (0, j._)((0, _.useState)([]), 2),
                    N = k[0],
                    S = k[1],
                    I = (0, j._)((0, _.useState)(!1), 2),
                    Z = I[0],
                    F = I[1],
                    D = (0, j._)((0, _.useState)(!1), 2),
                    E = D[0],
                    B = D[1],
                    A = (0, ts.qS)(),
                    L = (0, _.useCallback)(function() {
                        R.vm.closeFilesModal(), f.length > 0 && u()
                    }, [u, f]),
                    U = (0, tt.D)({
                        mutationFn: function(e) {
                            return P.ZP.uploadFileUsingFileService(e, e0.Ei.MyFiles, y.accessToken)
                        },
                        onMutate: (e = (0, eG._)(function(e) {
                            return (0, e$.__generator)(this, function(t) {
                                return [2, e]
                            })
                        }), function(t) {
                            return e.apply(this, arguments)
                        }),
                        onSuccess: (t = (0, eG._)(function(e) {
                            return (0, e$.__generator)(this, function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, u()];
                                    case 1:
                                        return t.sent(), tl.m.success(i.formatMessage(tc.fileUploaded)), h.current.push(e.file_id), v((0, te._)(h.current)), [2]
                                }
                            })
                        }), function(e) {
                            return t.apply(this, arguments)
                        }),
                        onError: function(e, t) {
                            g(function(e) {
                                return e.filter(function(e) {
                                    return e.name !== t.name
                                })
                            }), tl.m.danger(i.formatMessage(tc.fileUploadFailed))
                        }
                    }),
                    O = (0, _.useCallback)((n = (0, eG._)(function(e) {
                        var t;
                        return (0, e$.__generator)(this, function(n) {
                            switch (n.label) {
                                case 0:
                                    if (!y) return [2];
                                    n.label = 1;
                                case 1:
                                    return n.trys.push([1, 6, , 7]), [4, P.ZP.getFileInfo(e, y.accessToken)];
                                case 2:
                                    if (!((t = n.sent()).retrieval_index_status === e0.Xf.Success || t.retrieval_index_status === e0.Xf.Failed)) return [3, 4];
                                    return h.current = h.current.filter(function(t) {
                                        return t !== e
                                    }), [4, u()];
                                case 3:
                                    return n.sent(), [3, 5];
                                case 4:
                                    x(function() {
                                        return O(e)
                                    }, 500), n.label = 5;
                                case 5:
                                    return [3, 7];
                                case 6:
                                    return n.sent(), h.current = h.current.filter(function(t) {
                                        return t !== e
                                    }), [3, 7];
                                case 7:
                                    return [2]
                            }
                        })
                    }), function(e) {
                        return n.apply(this, arguments)
                    }), [u, y, x]);
                (0, _.useEffect)(function() {
                    h.current.length > 0 && O(h.current[h.current.length - 1])
                }, [p, O]);
                var q = (0, _.useCallback)((0, eG._)(function() {
                        var e;
                        return (0, e$.__generator)(this, function(t) {
                            switch (t.label) {
                                case 0:
                                    if (!y) return [2];
                                    t.label = 1;
                                case 1:
                                    return t.trys.push([1, 3, , 4]), [4, A(e = C.filter(function(e) {
                                        return e.use_case === e0.Ei.MyFiles
                                    }), 30)];
                                case 2:
                                    return t.sent(), S((0, te._)(N).concat((0, te._)(e.map(function(e) {
                                        return e.id
                                    })))), [3, 4];
                                case 3:
                                    return t.sent(), tl.m.danger(i.formatMessage(tc.fileDownloadFailed)), [3, 4];
                                case 4:
                                    return [2]
                            }
                        })
                    }), [y, C, i, N, S, A]),
                    z = (0, _.useCallback)((0, eG._)(function() {
                        var e;
                        return (0, e$.__generator)(this, function(t) {
                            switch (t.label) {
                                case 0:
                                    if (e = C.map(function(e) {
                                            return (0, V._)((0, b._)({}, e), {
                                                state: c.Deleting
                                            })
                                        }), !y) return [2];
                                    g((0, te._)(f).concat((0, te._)(e))), t.label = 1;
                                case 1:
                                    return t.trys.push([1, 4, , 5]), [4, Promise.all(e.filter(function(e) {
                                        return e.use_case === e0.Ei.MyFiles
                                    }).map(function(e) {
                                        return P.ZP.deleteFileFromFileService(e.id, y.accessToken)
                                    }))];
                                case 2:
                                    return t.sent(), tl.m.success(i.formatMessage(tc.allFilesDeleted)), [4, u()];
                                case 3:
                                    return t.sent(), [3, 5];
                                case 4:
                                    return t.sent(), g([]), tl.m.danger(i.formatMessage(tc.allFilesDeleteFailed)), [3, 5];
                                case 5:
                                    return [2]
                            }
                        })
                    }), [C, f, y, i, u]),
                    H = (0, _.useCallback)(function() {
                        F(!0)
                    }, []),
                    W = (0, _.useCallback)(function() {
                        B(!0)
                    }, []),
                    Q = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return F(!1), z(), [2]
                        })
                    }), [z]),
                    G = (0, _.useCallback)(function() {
                        F(!1)
                    }, []),
                    $ = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return B(!1), q(), [2]
                        })
                    }), [q]),
                    Y = (0, _.useCallback)(function() {
                        B(!1)
                    }, []),
                    J = (0, _.useCallback)(function(e, t) {
                        return e.findIndex(function(e) {
                            return e.name === t.name && e.state !== c.Uploading
                        })
                    }, []),
                    K = (0, _.useCallback)(function(e) {
                        var t = (0, V._)((0, b._)({}, e), {
                            state: c.Deleting
                        });
                        g(function(e) {
                            return (0, te._)(e).concat([t])
                        })
                    }, []),
                    X = (0, _.useCallback)(function(e) {
                        g(function(t) {
                            return t.filter(function(t) {
                                return t.name !== e.name
                            })
                        })
                    }, []),
                    ee = (0, _.useMemo)(function() {
                        return (0, te._)(C).concat((0, te._)(f)).filter(function(e, t, n) {
                            if (e.use_case !== e0.Ei.MyFiles) return !1;
                            e.retrieval_index_status === e0.Xf.Success || e.retrieval_index_status === e0.Xf.Failed || h.current.includes(e.id) || (h.current.push(e.id), v((0, te._)(h.current)));
                            var r = J(n, e);
                            return e.state === c.Uploading && -1 !== r ? (g(function(t) {
                                return t.filter(function(t) {
                                    return t.name !== e.name || t.state !== c.Uploading
                                })
                            }), !1) : e.state === c.Deleting && -1 === n.findIndex(function(t) {
                                return t.name === e.name && t.state !== c.Deleting
                            }) ? (g(function(t) {
                                return t.filter(function(t) {
                                    return t.name !== e.name
                                })
                            }), !1) : -1 === n.findIndex(function(t) {
                                return t.name === e.name && t.state === c.Deleting
                            })
                        }).sort(function(e, t) {
                            return new Date(t.ready_time).getTime() - new Date(e.ready_time).getTime()
                        })
                    }, [C, J, f]),
                    et = (0, _.useMemo)(function() {
                        return ee.reduce(function(e, t) {
                            return e + (t.size || 0)
                        }, 0)
                    }, [ee]),
                    en = (0, _.useMemo)(function() {
                        return et / 1073741824
                    }, [et]),
                    er = (0, _.useCallback)((r = (0, eG._)(function(e) {
                        var t, n, r, a, o, s, l, u, d, f;
                        return (0, e$.__generator)(this, function(h) {
                            if (e.length > 10) return tl.m.warning(i.formatMessage(tc.tooManyFilesUploadedAtOnce, {
                                maxFiles: 10
                            })), [2];
                            t = et, n = !0, r = !1, a = void 0;
                            try {
                                for (o = e[Symbol.iterator](); !(n = (s = o.next()).done); n = !0) {
                                    if (l = s.value, (t += l.size) > 2147483648) {
                                        tl.m.warning(i.formatMessage(tc.totalFileSizeExceedsLimit, {
                                            maxSize: "".concat(2, "GB")
                                        }));
                                        break
                                    }
                                    if (u = l.name, C.filter(function(e) {
                                            return e.use_case === e0.Ei.MyFiles
                                        }).find(function(e) {
                                            return e.name === u
                                        })) try {
                                        u = tf(u, C)
                                    } catch (e) {
                                        tl.m.warning(i.formatMessage(tc.tooManyFilesWithSameName));
                                        break
                                    }
                                    d = {
                                        id: "",
                                        name: u,
                                        ready_time: new Date().toISOString(),
                                        use_case: e0.Ei.MyFiles,
                                        size: l.size,
                                        state: c.Uploading
                                    }, g(function(e) {
                                        return (0, te._)(e).concat([d])
                                    }), f = new File([l], u, {
                                        type: l.type
                                    }), U.mutate(f)
                                }
                            } catch (e) {
                                r = !0, a = e
                            } finally {
                                try {
                                    n || null == o.return || o.return()
                                } finally {
                                    if (r) throw a
                                }
                            }
                            return [2]
                        })
                    }), function(e) {
                        return r.apply(this, arguments)
                    }), [C, i, U, et]);
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsxs)(eg.Z, {
                        isOpen: !0,
                        onClose: L,
                        size: "custom",
                        className: "max-w-5xl",
                        type: "success",
                        title: i.formatMessage(tc.myFiles),
                        closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                            onClose: L
                        }),
                        children: [l ? (0, w.jsx)("div", {
                            className: "flex h-64 items-center justify-center",
                            children: (0, w.jsx)(em.Z, {
                                className: "text-gray-500"
                            })
                        }) : ee.length > 0 ? (0, w.jsxs)("div", {
                            className: "flex flex-col",
                            children: [(0, w.jsx)("div", {
                                className: "mb-2 text-xs text-gray-600 dark:text-gray-300",
                                children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, tc.filesModalDescription), {
                                    values: {
                                        totalUploadedSize: (0, w.jsx)("span", {
                                            className: "font-bold",
                                            children: "".concat(Number(en).toPrecision(2), "GB")
                                        }),
                                        maxFileSize: "".concat(2, "GB")
                                    }
                                }))
                            }), (0, w.jsxs)(ta.Z.Root, {
                                className: "max-h-[28rem]",
                                fixed: !0,
                                size: "compact",
                                children: [(0, w.jsxs)(ta.Z.Header, {
                                    children: [(0, w.jsx)(ta.Z.HeaderCell, {
                                        className: "max-w-8/12 w-8/12 dark:bg-gray-900",
                                        children: i.formatMessage(tc.name)
                                    }), (0, w.jsx)(ta.Z.HeaderCell, {
                                        children: i.formatMessage(tc.date)
                                    }), (0, w.jsx)(ta.Z.HeaderCell, {
                                        children: i.formatMessage(tc.size)
                                    }), (0, w.jsx)(ta.Z.HeaderCell, {
                                        textAlign: "right",
                                        children: (0, w.jsxs)(tr.Z.Root, {
                                            children: [(0, w.jsx)(tr.Z.Trigger, {
                                                children: (0, w.jsx)(eh.ZP, {
                                                    icon: M.K9M
                                                })
                                            }), (0, w.jsx)(tr.Z.Portal, {
                                                children: (0, w.jsxs)(tr.Z.Content, {
                                                    children: [(0, w.jsxs)(tr.Z.Item, {
                                                        onClick: W,
                                                        className: "flex gap-2",
                                                        children: [(0, w.jsx)(eh.ZP, {
                                                            icon: M._hL,
                                                            size: "small"
                                                        }), (0, w.jsx)("span", {
                                                            children: i.formatMessage(tc.downloadAll)
                                                        })]
                                                    }), (0, w.jsxs)(tr.Z.Item, {
                                                        onClick: H,
                                                        className: "flex gap-2",
                                                        children: [(0, w.jsx)(eh.ZP, {
                                                            icon: M.Ybf,
                                                            size: "small"
                                                        }), (0, w.jsx)("span", {
                                                            children: i.formatMessage(tc.deleteAll)
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })]
                                }), (0, w.jsx)(ta.Z.Body, {
                                    children: ee.map(function(e, t) {
                                        return (0, w.jsx)(th, {
                                            file: e,
                                            refetch: u,
                                            handleFileDelete: K,
                                            handleFileDeleteFailed: X,
                                            session: y,
                                            downloadedFiles: N,
                                            setDownloadedFiles: S
                                        }, t)
                                    })
                                })]
                            })]
                        }) : (0, w.jsx)(T.Z, (0, b._)({}, tc.noFilesFound)), (0, w.jsx)(to, {
                            accept: td.join(","),
                            onFilePicked: er,
                            loading: U.isLoading,
                            disabled: U.isLoading,
                            className: "mt-4 flex items-center space-x-2 rounded bg-green-600 px-4 py-2 text-white",
                            text: i.formatMessage(tc.uploadFile),
                            multiple: !0
                        })]
                    }), (0, w.jsx)(eg.Z, {
                        isOpen: Z,
                        onClose: function() {
                            return F(!1)
                        },
                        type: "danger",
                        title: i.formatMessage(tc.confirmDeleteAll),
                        primaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: i.formatMessage(tc.deleteAll),
                            color: "danger",
                            onClick: Q
                        }),
                        secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: i.formatMessage(tc.deleteHistoryModalCancel),
                            color: "neutral",
                            onClick: G
                        })
                    }), (0, w.jsx)(eg.Z, {
                        isOpen: E,
                        onClose: function() {
                            return B(!1)
                        },
                        type: "success",
                        title: i.formatMessage(tc.confirmDownloadAll),
                        primaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: i.formatMessage(tc.downloadAll),
                            color: "primary",
                            onClick: $
                        }),
                        secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                            title: i.formatMessage(tc.confirmCancelDownloadAll),
                            color: "neutral",
                            onClick: Y
                        })
                    })]
                })
            }
            var tp = n(65374),
                tv = n(77997),
                tx = n(13002),
                tb = n(54118),
                ty = n(12155);

            function tj() {
                var e, t, n = (0, k.useRouter)(),
                    r = (0, ev.kP)().session,
                    a = (null == r ? void 0 : null === (e = r.user) || void 0 === e ? void 0 : e.idp) === "auth0",
                    i = !!(null == r ? void 0 : null === (t = r.user) || void 0 === t ? void 0 : t.mfa),
                    o = (0, j._)((0, _.useState)(!1), 2),
                    s = o[0],
                    l = o[1],
                    u = (0, _.useCallback)((0, eG._)(function() {
                        var e;
                        return (0, e$.__generator)(this, function(t) {
                            if (e = new URL(n.asPath, window.location.origin).toString(), !a) throw Error("Only username/password users can enable MFA");
                            if (!r) throw Error("No session found, cannot enable MFA");
                            if ("mocked" === r.authProvider) throw Error("Mock users can't enable MFA! Please setup Auth0 following the instructions in the README");
                            return (0, ty.signIn)(r.authProvider, {
                                callbackUrl: e
                            }, (0, b._)({
                                prompt: "login"
                            }, r.authProvider === ev.Ho.OpenAI ? {
                                login_hint: (0, ev.W_)({
                                    oai_enforce_mfa: !0,
                                    idp: "openai"
                                })
                            } : {
                                oai_enforce_mfa: "true"
                            })), [2]
                        })
                    }), [n.asPath, r, a]),
                    d = (0, _.useCallback)((0, eG._)(function() {
                        var e;
                        return (0, e$.__generator)(this, function(t) {
                            switch (t.label) {
                                case 0:
                                    if (!a) throw Error("Only username/password users can disable MFA");
                                    if (!r) throw Error("No session found, cannot enable MFA");
                                    if ("mocked" === r.authProvider) throw Error("Mock users can't enable MFA! Please setup Auth0 following the instructions in the README");
                                    return l(!0), [4, P.ZP.deleteMfa()];
                                case 1:
                                    return t.sent(), [4, (0, ty.signOut)({
                                        redirect: !1,
                                        callbackUrl: "/auth/login?next=".concat(encodeURIComponent(n.asPath))
                                    })];
                                case 2:
                                    return e = t.sent(), l(!1), n.push(e.url), [2]
                            }
                        })
                    }), [a, n, r]);
                return {
                    setupMfa: u,
                    isUsernamePassword: a,
                    isLoggedInWithMfa: i,
                    removeMfa: d,
                    isLoading: s
                }
            }
            var tw = n(10580);

            function tC() {
                var e = (0, Q._)(["absolute right-0 top-1/2 -translate-y-1/2"]);
                return tC = function() {
                    return e
                }, e
            }
            var tk = _.forwardRef(function(e, t) {
                    var n = e.name,
                        r = e.placeholder,
                        a = e.type,
                        i = e.displayName,
                        o = e.onChange,
                        s = e.onBlur,
                        l = e.value,
                        u = e.saveOnBlur,
                        d = e.icon,
                        c = e.onInputIconClick,
                        f = e.className,
                        g = e.autoComplete,
                        h = e.autoFocus,
                        m = e.onPressEnter,
                        p = (0, j._)((0, _.useState)(l), 2),
                        v = p[0],
                        x = p[1],
                        y = (0, _.useCallback)(function(e) {
                            null == s || s(e), u && x(e.target.value)
                        }, [s, u]),
                        C = (0, _.useCallback)(function(e) {
                            null == o || o(e), u && x(e.target.value)
                        }, [o, u]),
                        k = (0, _.useCallback)(function(e) {
                            "Enter" === e.key && m && (e.preventDefault(), m())
                        }, [m]);
                    (0, _.useEffect)(function() {
                        x(l)
                    }, [l]);
                    var M = (0, b._)({}, u ? {} : {
                        value: l
                    }, u ? {
                        value: v
                    } : {});
                    return (0, w.jsxs)("div", {
                        className: (0, G.Z)("rounded-md border border-gray-300 px-3 py-2 shadow-sm focus-within:border-indigo-600 focus-within:ring-1 focus-within:ring-indigo-600 dark:bg-gray-700", f),
                        children: [(0, w.jsx)("label", {
                            htmlFor: n,
                            className: "block text-xs font-medium text-gray-900 dark:text-gray-100",
                            children: i
                        }), (0, w.jsxs)("div", {
                            className: (0, G.Z)(i && "mt-1", "relative"),
                            children: [(0, w.jsx)("input", (0, b._)({
                                ref: t,
                                type: a,
                                name: n,
                                id: n,
                                className: (0, G.Z)("block w-full border-0 p-0 text-gray-900 placeholder-gray-500 outline-none focus:ring-0 dark:bg-gray-700 dark:text-gray-100 sm:text-sm", d && "pr-6"),
                                placeholder: r,
                                onBlur: y,
                                onChange: C,
                                onKeyDown: k,
                                autoComplete: g,
                                autoFocus: h
                            }, M)), d && (0, w.jsx)(t_, {
                                onClick: c,
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: d
                                })
                            })]
                        })]
                    })
                }),
                t_ = eo.Z.button(tC()),
                tM = n(11084),
                tT = n(52787),
                tN = n(28512),
                tP = n(98359),
                tS = n(20525);

            function tI(e) {
                var t = e.children,
                    n = e.sidebarOpen,
                    r = e.onClose;
                return (0, w.jsx)(tP.u.Root, {
                    show: n,
                    as: _.Fragment,
                    children: (0, w.jsxs)(tS.V, {
                        as: "div",
                        className: "relative z-10",
                        onClose: r,
                        children: [(0, w.jsx)("div", {
                            className: "fixed inset-0"
                        }), (0, w.jsx)("div", {
                            className: "fixed inset-0 overflow-hidden",
                            children: (0, w.jsx)("div", {
                                className: "absolute inset-0 overflow-hidden",
                                children: (0, w.jsx)("div", {
                                    className: "pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10",
                                    children: (0, w.jsx)(tP.u.Child, {
                                        as: _.Fragment,
                                        enter: "transform transition ease-in-out duration-100 sm:duration-300",
                                        enterFrom: "translate-x-full",
                                        enterTo: "translate-x-0",
                                        leave: "transform transition ease-in-out duration-300 sm:duration-500",
                                        leaveFrom: "translate-x-0",
                                        leaveTo: "translate-x-full",
                                        children: (0, w.jsx)(tS.V.Panel, {
                                            className: "pointer-events-auto w-screen max-w-md border-l border-gray-100 dark:border-gray-700",
                                            children: (0, w.jsx)("div", {
                                                className: "h-full overflow-y-auto bg-white shadow-xl dark:bg-gray-800",
                                                children: t
                                            })
                                        })
                                    })
                                })
                            })
                        })]
                    })
                })
            }

            function tZ() {
                var e = (0, Q._)(["overflow-y-auto h-full md:w-[250px] lg:w-[300px] xl:w-[350px] 2xl:w-[400px] md:border-l md:border-gray-100 md:dark:border-gray-700 bg-white dark:bg-gray-900"]);
                return tZ = function() {
                    return e
                }, e
            }

            function tF() {
                var e = (0, Q._)(["whitespace-pre-wrap text-sm"]);
                return tF = function() {
                    return e
                }, e
            }

            function tD() {
                var e = (0, Q._)(["px-6 py-4 flex flex-col gap-1 hover:bg-gray-50 dark:hover:bg-gray-500/10 cursor-pointer border-b dark:border-white/10 border-gray-200"]);
                return tD = function() {
                    return e
                }, e
            }

            function tE(e) {
                var t = e.children,
                    n = e.title,
                    r = e.icon,
                    a = e.isOpen,
                    i = e.slideOver,
                    o = e.onClose,
                    s = (0, w.jsxs)(tL, {
                        children: [(0, w.jsxs)("div", {
                            className: "flex items-start justify-between",
                            children: [(0, w.jsxs)("div", {
                                className: "flex items-center gap-2 px-4 py-2 text-lg font-medium text-gray-900 dark:text-white",
                                children: [(0, w.jsx)(eh.ZP, {
                                    icon: r
                                }), n]
                            }), (0, w.jsx)("div", {
                                className: "mr-2 mt-2 flex h-7 items-center",
                                children: (0, w.jsxs)("button", {
                                    type: "button",
                                    className: "rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2",
                                    onClick: o,
                                    children: [(0, w.jsx)("span", {
                                        className: "sr-only",
                                        children: "Close sidebar"
                                    }), (0, w.jsx)(eh.ZP, {
                                        icon: M.q5L,
                                        size: "medium",
                                        "aria-hidden": "true"
                                    })]
                                })
                            })]
                        }), t]
                    });
                return i ? (0, w.jsx)(tI, {
                    sidebarOpen: a,
                    onClose: o,
                    children: s
                }) : a ? s : null
            }

            function tR(e) {
                var t = e.clientThreadId,
                    n = e.isOpen,
                    r = e.slideOver,
                    a = e.onClose,
                    i = S.tQ.getThreadCurrentLeafId(t),
                    o = (0, S.u9)(t, i),
                    s = (0, j._)((0, _.useState)(), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, B.hz)(),
                    c = (0, _.useCallback)(function() {
                        u(void 0)
                    }, []),
                    f = (0, _.useCallback)(function() {
                        var e = S.tQ.getTree(t);
                        (0, tM.S)(e.getTextFromThread(i))
                    }, [i, t]);
                if (!d.has("debug")) return null;
                var g = o.map(function(e, t) {
                    var n = e.author,
                        r = n.role,
                        a = n.name;
                    return (0, w.jsxs)(tO, {
                        role: "button",
                        onClick: function() {
                            return u(t)
                        },
                        children: [(0, w.jsxs)("div", {
                            className: "text-xs font-medium uppercase text-gray-400",
                            children: [r, a && a !== r && " (".concat(a, ")"), " -> ", (0, tT.Ej)(e)]
                        }), (0, w.jsx)("div", {
                            children: (0, tT.RR)(e)
                        })]
                    }, e.id)
                });
                return (0, w.jsxs)(tE, {
                    icon: M.cDN,
                    title: "Debug",
                    isOpen: n,
                    slideOver: r,
                    onClose: a,
                    children: [(0, w.jsxs)("div", {
                        className: "flex items-center justify-around gap-2 px-4 py-1 text-xs font-medium uppercase ",
                        children: [(0, w.jsx)(tA, {
                            clientThreadId: t,
                            messages: o
                        }), (0, w.jsx)("div", {
                            children: (0, w.jsx)(tN.Z, {
                                onCopy: f,
                                buttonText: "Copy text"
                            })
                        })]
                    }), (0, w.jsx)(tU, {
                        children: g
                    }), void 0 !== l && (0, w.jsx)(eg.Z, {
                        isOpen: !0,
                        onClose: c,
                        type: "success",
                        children: (0, w.jsx)("pre", {
                            className: "max-h-[80vh] overflow-auto whitespace-pre-wrap text-xs",
                            children: JSON.stringify(o[l], null, 2)
                        })
                    }, "DebugMessageModal-".concat(l))]
                })
            }

            function tB(e, t) {
                var n = JSON.stringify(t) + "\n",
                    r = new Blob([n], {
                        type: "application/json"
                    }),
                    a = URL.createObjectURL(r),
                    i = document.createElement("a");
                i.href = a, i.download = "messages-".concat(S.tQ.getServerThreadId(e), ".jsonl"), i.click(), URL.revokeObjectURL(a)
            }

            function tA(e) {
                var t = e.clientThreadId,
                    n = e.messages,
                    r = (0, _.useCallback)(function() {
                        tB(t, n)
                    }, [t, n]);
                return (0, w.jsxs)(ec.z, {
                    onClick: r,
                    color: "dark",
                    size: "small",
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: M._hL
                    }), "Download raw conversation"]
                })
            }
            var tL = eo.Z.div(tZ()),
                tU = eo.Z.pre(tF()),
                tO = eo.Z.div(tD()),
                tq = n(8844),
                tz = n(22121),
                tH = n(95954);

            function tW() {
                return (tW = (0, eG._)(function(e) {
                    var t;
                    return (0, e$.__generator)(this, function(n) {
                        switch (n.label) {
                            case 0:
                                return n.trys.push([0, 2, , 3]), [4, function(e) {
                                    return tV.apply(this, arguments)
                                }(e)];
                            case 1:
                                return [2, n.sent()];
                            case 2:
                                return console.error("Error making localhost plugin HTTP call", t = n.sent()), [2, [{
                                    id: (0, tq.Z)(),
                                    author: {
                                        role: tH.uU.Tool,
                                        name: "plugin_service"
                                    },
                                    content: {
                                        content_type: tH.PX.Text,
                                        parts: ["Error making localhost plugin HTTP call: ".concat(t)]
                                    },
                                    recipient: "all"
                                }]];
                            case 3:
                                return [2]
                        }
                    })
                })).apply(this, arguments)
            }

            function tV() {
                return (tV = (0, eG._)(function(e) {
                    var t, n, r, a;

                    function i(e) {
                        return Object.keys(e).map(function(e) {
                            return e.toLowerCase()
                        })
                    }
                    return (0, e$.__generator)(this, function(o) {
                        switch (o.label) {
                            case 0:
                                var s;
                                if (t = {
                                        "content-type": "application/json"
                                    }, s = [i(e.headers), i(t)].flat(), new Set(s).size !== s.length) throw Error("Refusing to make localhost plugin HTTP call with duplicate header keys");
                                return n = e.url, e.qs_params.length > 0 && (n = n + "?" + new URLSearchParams(e.qs_params)), r = void 0, null !== e.body && (r = JSON.stringify(e.body)), [4, fetch(n, {
                                    method: e.method,
                                    headers: (0, b._)({}, t, e.headers),
                                    body: r
                                })];
                            case 1:
                                return [4, o.sent().text()];
                            case 2:
                                if (a = o.sent(), "chat" === e.api_function_type) return [2, [JSON.parse(a)]];
                                if ("kwargs" === e.api_function_type) return [2, [{
                                    id: (0, tq.Z)(),
                                    author: {
                                        role: tH.uU.Tool,
                                        name: "".concat(e.namespace, ".").concat(e.function_name)
                                    },
                                    content: {
                                        content_type: tH.PX.Text,
                                        parts: [a]
                                    },
                                    recipient: "all"
                                }]];
                                throw Error("Not implemented")
                        }
                    })
                })).apply(this, arguments)
            }

            function tQ(e) {
                return !!tG(e.domain)
            }

            function tG(e) {
                return /^localhost:\d+$/.test(e) ? "http://".concat(e) : /^https?:\/\/localhost:\d+$/.test(e) ? e : null
            }

            function t$() {
                return (t$ = (0, eG._)(function(e) {
                    var t, n, r, a, i, o;
                    return (0, e$.__generator)(this, function(s) {
                        switch (s.label) {
                            case 0:
                                return s.trys.push([0, 3, , 4]), [4, fetch(e + "/.well-known/ai-plugin.json")];
                            case 1:
                                return [4, s.sent().json()];
                            case 2:
                                return n = s.sent(), [3, 4];
                            case 3:
                                return s.sent(), tl.m.danger("Failed to fetch localhost manifest. Check to ensure your localhost is running and your localhost server has CORS enabled."), [2];
                            case 4:
                                if (null == (r = null == n ? void 0 : null === (t = n.api) || void 0 === t ? void 0 : t.url)) return tl.m.danger("Localhost manifest is missing OpenAPI spec URL."), [2];
                                if ("pathname" === (a = function(e) {
                                        try {
                                            return new URL(e), "full url"
                                        } catch (t) {
                                            if (e.startsWith("/")) return "pathname";
                                            return "neither"
                                        }
                                    }(r))) r = e + r;
                                else if ("neither" === a) return tl.m.danger("Localhost manifest OpenAPI spec URL is not a valid URL or path."), [2];
                                s.label = 5;
                            case 5:
                                return s.trys.push([5, 8, , 9]), [4, fetch(r)];
                            case 6:
                                return [4, s.sent().text()];
                            case 7:
                                return i = s.sent(), [3, 9];
                            case 8:
                                return s.sent(), tl.m.danger("Failed to fetch localhost OpenAPI spec."), [2];
                            case 9:
                                try {
                                    o = tz.ZP.parse(i)
                                } catch (e) {}
                                try {
                                    o = JSON.parse(i)
                                } catch (e) {}
                                if (null == o) return tl.m.danger("Failed to parse localhost OpenAPI spec as JSON or YAML."), [2];
                                s.label = 10;
                            case 10:
                                return s.trys.push([10, 12, , 13]), [4, P.ZP.createOrUpdateLocalhostPlugin({
                                    localhost: e,
                                    manifest: n,
                                    openapiSpec: o
                                })];
                            case 11:
                                return [2, s.sent()];
                            case 12:
                                return s.sent(), tl.m.danger("Failed to create or update localhost plugin at ".concat(e)), [3, 13];
                            case 13:
                                return [2]
                        }
                    })
                })).apply(this, arguments)
            }
            var tY = n(35101),
                tJ = n(14444);

            function tK(e) {
                var t = e.onSuccess,
                    n = e.onError,
                    r = e.onSettled,
                    a = (0, C.NL)(),
                    i = (0, tt.D)(P.ZP.updatePluginUserSettings.bind(P.ZP), {
                        onSuccess: function(e) {
                            tX(e, a), t0(e, a), t(e)
                        },
                        onError: n,
                        onSettled: r
                    }).mutate;
                return (0, _.useCallback)(function(e) {
                    i({
                        pluginId: e,
                        isInstalled: !0
                    })
                }, [i])
            }

            function tX(e, t) {
                var n = tJ.Z;
                t.setQueryData(n, function(t) {
                    var n = (0, te._)((null == t ? void 0 : t.items) || []),
                        r = n.findIndex(function(t) {
                            return t.id === e.id
                        });
                    return -1 !== r ? n[r] = e : n.push(e), {
                        count: n.length,
                        items: n
                    }
                })
            }

            function t0(e, t) {
                var n = tY.V;
                t.setQueriesData(n, function(t) {
                    if (!t) return t;
                    var n = t.items.findIndex(function(t) {
                        return t.id === e.id
                    });
                    if (-1 === n) return t;
                    var r = (0, te._)(t.items);
                    return r[n] = e, (0, V._)((0, b._)({}, t), {
                        items: r
                    })
                })
            }

            function t1(e, t) {
                return t2.apply(this, arguments)
            }

            function t2() {
                return (t2 = (0, eG._)(function(e, t) {
                    var n, r;
                    return (0, e$.__generator)(this, function(a) {
                        switch (a.label) {
                            case 0:
                                return n = "".concat(window.location.origin, "/aip/").concat(e.id, "/oauth/callback"), [4, P.ZP.pluginOauthRedirect(e.id, n, t)];
                            case 1:
                                return r = a.sent(), window.location.href = r.redirect_uri, [2]
                        }
                    })
                })).apply(this, arguments)
            }

            function t3(e) {
                var t = e.manifest.auth;
                if ("oauth" !== t.type || !e.oauth_client_id) return null;
                var n = new URLSearchParams({
                    response_type: "code",
                    client_id: e.oauth_client_id,
                    redirect_uri: "".concat(window.location.origin, "/aip/").concat(e.id, "/oauth/callback"),
                    scope: t.scope
                });
                return t.client_url.includes("slack.com") && (n.delete("scope"), n.append("user_scope", t.scope)), "".concat(t.client_url, "?").concat(n)
            }

            function t5() {
                var e, t = (0, j._)((0, _.useState)(!1), 2),
                    n = t[0],
                    r = t[1];
                return {
                    fetchManifestAndSpec: (0, _.useCallback)((e = (0, eG._)(function(e) {
                        var t, n, a, i, o, s, l, u, d;
                        return (0, e$.__generator)(this, function(c) {
                            switch (c.label) {
                                case 0:
                                    t = e.domain, n = e.manifestAccessToken, a = e.onSuccess, i = e.onError, o = tG(t), c.label = 1;
                                case 1:
                                    if (c.trys.push([1, 10, 11, 12]), r(!0), !(null != o)) return [3, 3];
                                    return [4, function(e) {
                                        return t$.apply(this, arguments)
                                    }(o)];
                                case 2:
                                    if (void 0 === (s = c.sent())) return [2];
                                    return a({
                                        domain: o,
                                        scrapeManifestResponse: {
                                            plugin: s.plugin,
                                            manifest_validation_info: s.manifest_validation_info
                                        },
                                        apiValidationInfo: s.api_validation_info
                                    }), [3, 9];
                                case 3:
                                    return [4, P.ZP.scrapePluginManifest({
                                        domain: t,
                                        manifestAccessToken: n
                                    })];
                                case 4:
                                    if (!(l = c.sent()).plugin) return [3, 8];
                                    c.label = 5;
                                case 5:
                                    return c.trys.push([5, 7, , 8]), [4, P.ZP.getPluginApi({
                                        id: l.plugin.id
                                    })];
                                case 6:
                                    return u = c.sent().api_validation_info, [3, 8];
                                case 7:
                                    return c.sent(), [3, 8];
                                case 8:
                                    a({
                                        domain: t,
                                        scrapeManifestResponse: l,
                                        apiValidationInfo: u,
                                        manifestAccessToken: n
                                    }), c.label = 9;
                                case 9:
                                    return [3, 12];
                                case 10:
                                    return d = c.sent(), i(null != o ? d : void 0), [3, 12];
                                case 11:
                                    return r(!1), [7];
                                case 12:
                                    return [2]
                            }
                        })
                    }), function(t) {
                        return e.apply(this, arguments)
                    }), []),
                    isLoading: n
                }
            }
            var t4 = n(91809);

            function t8(e) {
                var t = e.plugin,
                    n = t.manifest.name_for_human;
                return (0, w.jsxs)("div", {
                    className: "flex gap-4 rounded bg-gray-50 px-4 py-2 dark:bg-gray-800",
                    children: [(0, w.jsx)(t4.Z, {
                        url: t.manifest.logo_url,
                        name: n,
                        size: 32,
                        className: "flex-shrink-0"
                    }), (0, w.jsxs)("div", {
                        className: "flex flex-col gap-1",
                        children: [(0, w.jsx)("h2", {
                            className: "align-top text-base font-medium",
                            children: n
                        }), (0, w.jsx)("div", {
                            className: "text-sm",
                            children: t.manifest.description_for_human
                        })]
                    })]
                })
            }

            function t7(e) {
                var t = e.manifestValidationInfo,
                    n = (0, y._)(e, ["manifestValidationInfo"]),
                    r = t.manifest_dict,
                    a = t.warnings,
                    i = t.errors;
                return (0, w.jsx)(ne, (0, b._)({
                    name: "manifest",
                    content: r,
                    warnings: a,
                    errors: i
                }, n))
            }

            function t6(e) {
                var t = e.apiValidationInfo,
                    n = (0, y._)(e, ["apiValidationInfo"]),
                    r = t.openapi_spec_dict,
                    a = t.warnings,
                    i = t.errors;
                return (0, w.jsx)(ne, (0, b._)({
                    name: "OpenAPI spec",
                    content: r,
                    warnings: a,
                    errors: i
                }, n))
            }

            function t9(e) {
                var t = e.apiValidationInfo,
                    n = (0, y._)(e, ["apiValidationInfo"]),
                    r = t.api_typescript;
                return r ? (0, w.jsx)(nt, (0, b._)({
                    text: "Prompt for ChatGPT",
                    content: r
                }, n)) : null
            }

            function ne(e) {
                var t = e.name,
                    n = e.content,
                    r = e.warnings,
                    a = e.errors,
                    i = (0, y._)(e, ["name", "content", "warnings", "errors"]),
                    o = r && r.length > 0,
                    s = a && a.length > 0,
                    l = "Validated ".concat(t),
                    u = (0, w.jsx)(eh.ZP, {
                        icon: M.UgA,
                        className: "text-green-500"
                    });
                return s ? (l = "Errors in ".concat(t), u = (0, w.jsx)(eh.ZP, {
                    icon: M.q5L,
                    className: "text-red-500"
                })) : o && (l = "Warnings in ".concat(t), u = (0, w.jsx)(eh.ZP, {
                    icon: M.bcx,
                    className: "text-yellow-500"
                })), (0, w.jsx)(nt, (0, b._)({
                    icon: u,
                    text: l,
                    content: n,
                    warnings: r,
                    errors: a
                }, i))
            }

            function nt(e) {
                var t = e.icon,
                    n = e.text,
                    r = e.content,
                    a = e.warnings,
                    i = e.errors,
                    o = e.expanded,
                    s = e.onChangeExpanded,
                    l = (0, j._)((0, _.useState)(!1), 2),
                    u = l[0],
                    d = l[1],
                    c = null != o ? o : u,
                    f = (0, _.useCallback)(function() {
                        s ? s(!c) : d(function(e) {
                            return !e
                        })
                    }, [c, s]);
                return (0, w.jsxs)("div", {
                    className: "flex flex-col gap-2 text-sm",
                    children: [(0, w.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [t && (0, w.jsx)("div", {
                            children: t
                        }), (0, w.jsx)("div", {
                            children: n
                        }), (0, w.jsx)("div", {
                            role: "button",
                            className: "cursor-pointer text-gray-500 hover:text-gray-700",
                            onClick: f,
                            children: (0, w.jsx)(eh.ZP, {
                                icon: c ? M.rH8 : M.bTu
                            })
                        })]
                    }), c && (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsxs)("div", {
                            className: "flex flex-col gap-2 font-semibold",
                            children: [i && i.map(function(e, t) {
                                return (0, w.jsx)("div", {
                                    className: "text-red-500",
                                    children: e
                                }, t)
                            }), a && a.map(function(e, t) {
                                return (0, w.jsx)("div", {
                                    className: "text-yellow-500",
                                    children: e
                                }, t)
                            })]
                        }), r && (0, w.jsx)("pre", {
                            className: "overflow-auto whitespace-pre-wrap text-xs",
                            children: "string" == typeof r ? r : JSON.stringify(r, null, 2)
                        })]
                    })]
                })
            }
            var nn = [
                    ["www.klarna.com", "server.shop.app"],
                    ["apim.expedia.com", "kayak.com"],
                    ["www.redfin.com", "plugins.zillow.com"],
                    ["instacart.com", "api.tasty.co"]
                ],
                nr = "oai/enabledPluginIds",
                na = (0, I.ZP)(function() {
                    var e = Array.from(new Set(ex.m.getItem(nr)));
                    return {
                        enabledPluginIds: new Set(e.splice(0, 3))
                    }
                });

            function ni() {
                var e = (0, tJ.C)().installedPlugins,
                    t = na().enabledPluginIds;
                return (0, _.useMemo)(function() {
                    return e.filter(function(e) {
                        return t.has(e.id)
                    })
                }, [t, e])
            }

            function no(e) {
                e.length > 3 || na.setState(function() {
                    return ex.m.setItem(nr, e), {
                        enabledPluginIds: new Set(e)
                    }
                })
            }

            function ns(e) {
                na.setState(function(t) {
                    if (t.enabledPluginIds.size >= 3) return t;
                    var n = (0, te._)(t.enabledPluginIds).concat([e]);
                    return ex.m.setItem(nr, n), {
                        enabledPluginIds: new Set(n)
                    }
                })
            }
            var nl = (0, I.ZP)(function() {
                    return {
                        isOpen: !1
                    }
                }),
                nu = {
                    close: function() {
                        nl.setState({
                            isOpen: !1
                        })
                    },
                    setIsOpen: function(e) {
                        nl.setState({
                            isOpen: e
                        })
                    }
                };

            function nd(e) {
                var t = e.slideOver,
                    n = (0, j._)((0, _.useState)(), 2),
                    r = n[0],
                    a = n[1],
                    i = (0, j._)((0, _.useState)(!1), 2),
                    o = i[0],
                    s = i[1],
                    l = (0, j._)((0, _.useState)(!1), 2),
                    u = l[0],
                    d = l[1],
                    c = (0, j._)((0, _.useState)(!1), 2),
                    f = c[0],
                    g = c[1],
                    h = (0, ev.kP)().session,
                    m = (0, B.hz)(),
                    p = (null == h ? void 0 : h.user) != null && (0, ev.yl)(h.user) || m.has(eu.YI),
                    v = (0, C.NL)(),
                    x = nl(function(e) {
                        return e.isOpen
                    }),
                    b = ni(),
                    y = t5().fetchManifestAndSpec,
                    k = (0, _.useMemo)(function() {
                        return p ? b[0] : b.find(tQ)
                    }, [b, p]),
                    T = (0, _.useCallback)((0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return k && (a(void 0), y({
                                domain: k.domain,
                                onSuccess: function(e) {
                                    a({
                                        manifestValidationInfo: e.scrapeManifestResponse.manifest_validation_info,
                                        apiValidationInfo: e.apiValidationInfo
                                    }), null != e.scrapeManifestResponse.plugin && t0(e.scrapeManifestResponse.plugin, v)
                                },
                                onError: function(e) {
                                    tl.m.danger((null == e ? void 0 : e.message) || "Error refreshing plugin.")
                                }
                            })), [2]
                        })
                    }), [k, v, y]);
                return ((0, _.useEffect)(function() {
                    x && T()
                }, [x, T]), m.has(eu.Wk)) ? (0, w.jsx)(tE, {
                    icon: M.V7f,
                    title: "Plugin devtools",
                    isOpen: x,
                    slideOver: t,
                    onClose: nu.close,
                    children: (0, w.jsx)("div", {
                        className: "border-t border-gray-100 p-2 text-sm dark:border-gray-700",
                        children: null != k ? (0, w.jsxs)("div", {
                            className: "flex flex-col gap-2",
                            children: [(0, w.jsx)("div", {
                                children: (0, w.jsx)(ec.z, {
                                    size: "small",
                                    color: "neutral",
                                    onClick: T,
                                    children: "Refresh plugin"
                                })
                            }), r ? (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)(t8, {
                                    plugin: k
                                }), (0, w.jsxs)("div", {
                                    children: ["Plugin id: ", k.id]
                                }), (0, w.jsx)(t7, {
                                    manifestValidationInfo: r.manifestValidationInfo,
                                    expanded: o,
                                    onChangeExpanded: s
                                }), null != r.apiValidationInfo && (0, w.jsxs)(w.Fragment, {
                                    children: [(0, w.jsx)(t6, {
                                        apiValidationInfo: r.apiValidationInfo,
                                        expanded: u,
                                        onChangeExpanded: d
                                    }), (0, w.jsx)(t9, {
                                        apiValidationInfo: r.apiValidationInfo,
                                        expanded: f,
                                        onChangeExpanded: g
                                    })]
                                })]
                            }) : (0, w.jsx)("div", {
                                className: "self-center",
                                children: (0, w.jsx)(em.Z, {})
                            })]
                        }) : (0, w.jsxs)("div", {
                            className: "mt-4 text-center",
                            children: ["Please enable a localhost plugin", " ", p && " (or any plugin if you're a plugin reviewer) ", "to use devtools."]
                        })
                    })
                }) : null
            }
            var nc = n(56817),
                nf = n(47428),
                ng = n(5268),
                nh = ["sharedConversations"],
                nm = (0, N.vU)({
                    name: {
                        id: "sharedConversationModal.name",
                        defaultMessage: "Name",
                        description: "Table column header"
                    },
                    dateShared: {
                        id: "sharedConversationModal.dateShared",
                        defaultMessage: "Date shared",
                        description: "Table column header"
                    },
                    loading: {
                        id: "sharedConversationModal.loading",
                        defaultMessage: "Loading...",
                        description: "Loading message"
                    },
                    somethingWentWrong: {
                        id: "sharedConversationModal.somethingWentWrong",
                        defaultMessage: "Something went wrong...",
                        description: "Error message"
                    },
                    retry: {
                        id: "sharedConversationModal.retry",
                        defaultMessage: "Retry",
                        description: "Retry button text"
                    },
                    noSharedConversations: {
                        id: "sharedConversationModal.noSharedConversations",
                        defaultMessage: "You have no shared links.",
                        description: "No shared links message"
                    },
                    title: {
                        id: "sharedConversationModal.title",
                        defaultMessage: "Shared Links",
                        description: "Shared links modal title"
                    },
                    goToOriginConversation: {
                        id: "sharedConversationModal.goToOriginConversation",
                        defaultMessage: "View source chat",
                        description: "Label for conversation icon"
                    },
                    deleteSharedLink: {
                        id: "sharedConversationModal.deleteSharedLink",
                        defaultMessage: "Delete shared link",
                        description: "Label for delete shared link icon"
                    },
                    deleteSharedLinkFailed: {
                        id: "sharedConversationModal.deleteSharedLinkFailed",
                        defaultMessage: "Deleting shared link failed",
                        description: "Toaster message when deleting share link fails"
                    },
                    deleteAllSharedLinks: {
                        id: "sharedConversationModal.deleteSharedAllConversations",
                        defaultMessage: "Delete all shared links",
                        description: "Menu item for deleting all shared links"
                    },
                    deleteAllSharedLinksConfirm: {
                        id: "sharedConversationModal.deleteSharedAllConversationsConfirm",
                        defaultMessage: "Are you sure you want to delete all your shared links?",
                        description: "Confirmation message for deleting share links"
                    },
                    deleteAllSharedLinksFailed: {
                        id: "sharedConversationModal.deleteSharedAllConversationsFailed",
                        defaultMessage: "Deleting shared links failed",
                        description: "Toaster message when deleting all share links fails"
                    }
                });

            function np() {
                var e = (0, C.NL)(),
                    t = (0, ei.Z)(),
                    n = (0, tt.D)({
                        mutationFn: function() {
                            return P.ZP.deleteAllSharedConversations()
                        },
                        onSettled: function() {
                            e.invalidateQueries(nh)
                        },
                        onError: function() {
                            tl.m.danger(t.formatMessage(nm.deleteAllSharedLinksFailed))
                        }
                    }).mutate;
                return (0, w.jsxs)(nf.fC, {
                    children: [(0, w.jsx)(nf.xz, {
                        asChild: !0,
                        children: (0, w.jsx)("button", {
                            className: "text-gray-500 hover:text-gray-600 radix-state-open:text-gray-600 dark:hover:text-gray-400 dark:radix-state-open:text-gray-400",
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.K9M
                            })
                        })
                    }), (0, w.jsx)(nf.Uv, {
                        children: (0, w.jsx)(nf.VY, {
                            className: "min-w-[8rem] rounded-md bg-white py-1 shadow-lg dark:bg-gray-800",
                            side: "bottom",
                            sideOffset: 4,
                            children: (0, w.jsx)(nf.ck, {
                                onClick: function() {
                                    window.confirm(t.formatMessage(nm.deleteAllSharedLinksConfirm)) && n()
                                },
                                className: "cursor-pointer select-none px-2 py-1 text-red-500 radix-highlighted:bg-gray-50 dark:radix-highlighted:bg-gray-700",
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nm.deleteAllSharedLinks))
                            })
                        })
                    })]
                })
            }

            function nv() {
                return P.ZP.getSharedConversations()
            }

            function nx(e) {
                var t, n = e.sharedConversation,
                    r = (0, ei.Z)(),
                    a = (0, C.NL)(),
                    i = (0, tt.D)({
                        mutationFn: (t = (0, eG._)(function(e) {
                            var t;
                            return (0, e$.__generator)(this, function(n) {
                                return t = e.sharedConversationId, [2, P.ZP.deleteShareLink({
                                    share_id: t
                                })]
                            })
                        }), function(e) {
                            return t.apply(this, arguments)
                        }),
                        onSettled: function() {
                            a.invalidateQueries(nh)
                        },
                        onError: function() {
                            tl.m.danger(r.formatMessage(nm.deleteSharedLinkFailed))
                        }
                    }),
                    o = i.mutate,
                    s = i.isLoading;
                return (0, w.jsxs)(ta.Z.Row, {
                    disabled: s,
                    children: [(0, w.jsx)(ta.Z.Cell, {
                        children: (0, w.jsxs)("a", {
                            href: "/share/".concat(n.id),
                            target: "_blank",
                            rel: "noreferrer",
                            className: "inline-flex items-center gap-2 align-top text-blue-500 dark:text-blue-400",
                            children: [(0, w.jsx)(eh.ZP, {
                                icon: M.XKb,
                                className: "flex-shrink-0"
                            }), n.title]
                        })
                    }), (0, w.jsx)(ta.Z.Cell, {
                        children: null != n.create_time ? (0, w.jsx)(N.Ji, {
                            value: n.create_time,
                            month: "long",
                            year: "numeric",
                            day: "numeric"
                        }) : null
                    }), (0, w.jsx)(ta.Z.Cell, {
                        children: (0, w.jsxs)(ta.Z.Actions, {
                            children: [(0, w.jsx)(ti.u, {
                                label: r.formatMessage(nm.goToOriginConversation),
                                sideOffset: 4,
                                side: "top",
                                children: (0, w.jsx)("a", {
                                    href: "/c/".concat(n.conversation_id),
                                    target: "_blank",
                                    rel: "noreferrer",
                                    "aria-label": r.formatMessage(nm.goToOriginConversation),
                                    className: "cursor-pointer text-gray-500 hover:text-gray-600 dark:hover:text-gray-400",
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M.IC0
                                    })
                                })
                            }), (0, w.jsx)(ti.u, {
                                label: r.formatMessage(nm.deleteSharedLink),
                                sideOffset: 4,
                                side: "top",
                                children: (0, w.jsx)("button", {
                                    onClick: function() {
                                        o({
                                            sharedConversationId: n.id
                                        })
                                    },
                                    "aria-label": r.formatMessage(nm.deleteSharedLink),
                                    className: "text-gray-500 hover:text-gray-600 dark:hover:text-gray-400",
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M.Ybf
                                    })
                                })
                            })]
                        })
                    })]
                })
            }

            function nb(e) {
                var t, n = e.onClose,
                    r = (0, ng.a)({
                        queryKey: nh,
                        queryFn: nv,
                        refetchOnMount: "always"
                    }),
                    a = r.data,
                    i = r.isLoading,
                    o = r.isError,
                    s = r.refetch,
                    l = (0, ei.Z)();
                return t = i ? (0, w.jsx)("div", {
                    className: "pb-8 text-gray-400 dark:text-gray-600",
                    children: (0, w.jsx)(T.Z, (0, b._)({}, nm.loading))
                }) : o ? (0, w.jsxs)("div", {
                    children: [(0, w.jsx)("div", {
                        className: "mb-4 text-red-500",
                        children: (0, w.jsx)(T.Z, (0, b._)({}, nm.somethingWentWrong))
                    }), (0, w.jsx)("div", {
                        children: (0, w.jsx)(ec.z, {
                            color: "neutral",
                            onClick: function() {
                                s()
                            },
                            children: (0, w.jsx)(T.Z, (0, b._)({}, nm.retry))
                        })
                    })]
                }) : 0 === a.total ? (0, w.jsx)("div", {
                    className: "pb-8 text-gray-600 dark:text-gray-400",
                    children: (0, w.jsx)(T.Z, (0, b._)({}, nm.noSharedConversations))
                }) : (0, w.jsxs)(ta.Z.Root, {
                    className: "max-h-[28rem]",
                    size: "compact",
                    children: [(0, w.jsxs)(ta.Z.Header, {
                        children: [(0, w.jsx)(ta.Z.HeaderCell, {
                            children: (0, w.jsx)(T.Z, (0, b._)({}, nm.name))
                        }), (0, w.jsx)(ta.Z.HeaderCell, {
                            children: (0, w.jsx)(T.Z, (0, b._)({}, nm.dateShared))
                        }), (0, w.jsx)(ta.Z.HeaderCell, {
                            textAlign: "right",
                            children: (0, w.jsx)(np, {})
                        })]
                    }), (0, w.jsx)(ta.Z.Body, {
                        children: a.items.map(function(e) {
                            return (0, w.jsx)(nx, {
                                sharedConversation: e
                            }, e.id)
                        })
                    })]
                }), (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: n,
                    size: "custom",
                    className: "max-w-5xl",
                    type: "success",
                    title: l.formatMessage(nm.title),
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: n
                    }),
                    children: t
                })
            }
            var ny = n(50921);

            function nj() {
                var e = (0, Q._)(["block text-sm font-medium mb-1"]);
                return nj = function() {
                    return e
                }, e
            }

            function nw(e) {
                var t, n, r, a = e.onClose,
                    i = e.onToggleHistoryDisabled,
                    o = e.onDeleteHistory,
                    s = (0, ei.Z)(),
                    l = (t = ej().conversations, (0, _.useMemo)(function() {
                        return t.length > 0
                    }, [t])),
                    u = (0, U.w$)(),
                    d = (0, j._)((0, _.useState)(!1), 2),
                    c = d[0],
                    g = d[1],
                    h = (0, j._)((0, _.useState)(!1), 2),
                    m = h[0],
                    p = h[1],
                    v = (0, j._)((0, _.useState)(!1), 2),
                    x = v[0],
                    y = v[1],
                    C = (0, j._)((0, _.useState)(!1), 2),
                    k = C[0],
                    M = C[1],
                    N = (0, j._)((0, _.useState)(f.General), 2),
                    P = N[0],
                    S = N[1],
                    I = (0, _.useContext)(A.QL),
                    Z = I.historyDisabled,
                    F = I.toggleHistoryDisabled,
                    D = nl(function(e) {
                        return e.isOpen
                    }),
                    E = (0, B.hz)(),
                    R = (0, B.ec)(B.F_.isBusinessWorkspace),
                    L = !R && E.has(eu.RJ),
                    O = (0, ev.kP)().session,
                    q = (0, tb.Fl)(),
                    z = q.isBetaFeaturesUiEnabled,
                    H = q.isPluginsAvailable,
                    W = q.isBrowsingAvailable,
                    Q = q.isCodeInterpreterAvailable,
                    $ = (0, _.useCallback)(function() {
                        g(!1)
                    }, []),
                    Y = (0, _.useCallback)(function() {
                        p(!1)
                    }, []),
                    J = (0, _.useCallback)(function() {
                        y(!1)
                    }, []),
                    K = (0, _.useCallback)(function() {
                        g(!0)
                    }, []),
                    X = (0, _.useCallback)(function() {
                        p(!0)
                    }, []),
                    ee = (0, _.useCallback)(function() {
                        y(!0)
                    }, []),
                    et = (0, _.useCallback)(function() {
                        null == i || i(), F()
                    }, [i, F]),
                    en = tj(),
                    er = en.setupMfa,
                    eo = en.isUsernamePassword,
                    es = en.removeMfa;
                return c ? (0, w.jsx)(nN, {
                    onClose: $
                }) : m ? (0, w.jsx)(nT, {
                    onClose: Y,
                    onDeleteHistory: o
                }) : x ? (0, w.jsx)(nZ, {
                    onClose: J
                }) : k ? (0, w.jsx)(nb, {
                    onClose: function() {
                        M(!1)
                    }
                }) : (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: a,
                    size: "custom",
                    className: "md:max-w-[680px]",
                    type: "success",
                    title: s.formatMessage(nD.settings),
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: a
                    }),
                    children: (0, w.jsxs)(tp.fC, {
                        className: "flex flex-col gap-6 md:flex-row",
                        defaultValue: P,
                        orientation: u ? "vertical" : void 0,
                        onValueChange: function(e) {
                            S(e)
                        },
                        children: [(0, w.jsxs)(tp.aV, {
                            className: (0, G.Z)("-ml-[8px] flex min-w-[180px] flex-shrink-0", u ? "flex-col" : "flex-row rounded-lg bg-gray-100 p-1 dark:bg-gray-800/30"),
                            children: [(0, w.jsx)(nP, {
                                value: f.General,
                                icon: tx.oq2,
                                label: (0, w.jsx)(T.Z, (0, b._)({}, nD.generalTab))
                            }), z && (W || H || Q) && (0, w.jsx)(nP, {
                                value: f.BetaFeatures,
                                icon: tx.rTN,
                                label: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaTab))
                            }), (0, w.jsx)(nP, {
                                value: f.DataControls,
                                icon: tx.tQn,
                                label: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataControlsTab))
                            })]
                        }), (0, w.jsxs)(nS, {
                            value: f.General,
                            children: [(0, w.jsx)(nI, {
                                children: (0, w.jsx)(nM, {})
                            }), !R && E.has("tools3_dev") && (0, w.jsx)(nI, {
                                children: (0, w.jsx)(nk, {
                                    label: s.formatMessage(nD.openPluginDevtools),
                                    enabled: D,
                                    onChange: nu.setIsOpen
                                })
                            }), (0, w.jsx)(nI, {
                                children: (0, w.jsx)(n_, {
                                    color: "danger",
                                    disabled: !l,
                                    label: s.formatMessage(nD.clearChatLabel),
                                    buttonLabel: s.formatMessage(nD.clearChatButton),
                                    onClick: X
                                })
                            })]
                        }), (0, w.jsx)(nS, {
                            value: f.BetaFeatures,
                            children: (0, w.jsx)(nC, {})
                        }), (0, w.jsxs)(nS, {
                            value: f.DataControls,
                            children: [R ? (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)(nI, {
                                    children: (0, w.jsx)(nk, {
                                        label: s.formatMessage(nD.chatHistoryLabel),
                                        enabled: !Z,
                                        onChange: et,
                                        description: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, nD.chatHistoryOnlyDescription), {
                                            values: {
                                                link: function(e) {
                                                    return (0, w.jsx)("a", {
                                                        href: "https://help.openai.com/en/articles/7730893 ",
                                                        target: "_blank",
                                                        className: "underline",
                                                        rel: "noreferrer",
                                                        children: e
                                                    })
                                                }
                                            }
                                        }))
                                    })
                                }), (0, w.jsx)(nI, {
                                    children: (0, w.jsx)(nk, {
                                        label: s.formatMessage(nD.chatTrainingLabel),
                                        disabled: !0,
                                        enabled: !1,
                                        onChange: ea(),
                                        description: (0, w.jsx)(T.Z, (0, b._)({}, nD.chatTrainingBusinessDescription)),
                                        toggleTooltip: (0, w.jsx)(T.Z, (0, b._)({}, nD.chatTrainingBusinessTooltip))
                                    })
                                })]
                            }) : (0, w.jsx)(nI, {
                                children: (0, w.jsx)(nk, {
                                    label: s.formatMessage(nD.chatHistoryToggleLabel),
                                    enabled: !Z,
                                    onChange: et,
                                    description: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, nD.chatHistoryDescription), {
                                        values: {
                                            link: function(e) {
                                                return (0, w.jsx)("a", {
                                                    href: "https://help.openai.com/en/articles/7730893 ",
                                                    target: "_blank",
                                                    className: "underline",
                                                    rel: "noreferrer",
                                                    children: e
                                                })
                                            }
                                        }
                                    }))
                                })
                            }), L && (0, w.jsx)(nI, {
                                children: (0, w.jsx)(n_, {
                                    label: s.formatMessage(nD.sharedConversations),
                                    buttonLabel: s.formatMessage(nD.sharedConversationsButton),
                                    onClick: function() {
                                        M(!0)
                                    }
                                })
                            }), !R && (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)(nI, {
                                    children: (0, w.jsx)(n_, {
                                        label: s.formatMessage(nD.exportData),
                                        buttonLabel: s.formatMessage(nD.exportButton),
                                        onClick: K
                                    })
                                }), (0, w.jsx)(nI, {
                                    children: (0, w.jsx)(n_, {
                                        label: s.formatMessage(nD.deleteAccount),
                                        buttonLabel: s.formatMessage(nD.deleteAccountButton),
                                        color: "danger",
                                        onClick: ee
                                    })
                                })]
                            }), E.has(eu.i) && !(null == O ? void 0 : null === (n = O.user) || void 0 === n ? void 0 : n.mfa) && eo && (0, w.jsx)(nI, {
                                children: (0, w.jsx)(n_, {
                                    label: s.formatMessage(nD.enable2fa),
                                    buttonLabel: s.formatMessage(nD.enable),
                                    onClick: er
                                })
                            }), (null == O ? void 0 : null === (r = O.user) || void 0 === r ? void 0 : r.mfa) && eo && (0, w.jsx)(nI, {
                                children: (0, w.jsx)(n_, {
                                    label: s.formatMessage(nD.disable2fa),
                                    buttonLabel: s.formatMessage(nD.disable),
                                    onClick: es,
                                    color: "danger"
                                })
                            })]
                        })]
                    })
                })
            }

            function nC() {
                var e, t = (0, ei.Z)(),
                    n = (0, ev.kP)().session,
                    r = (0, tb.N2)(),
                    a = (0, tb.Fl)(),
                    i = a.isBrowsingAvailable,
                    o = a.isBrowsingEnabled,
                    s = a.isChatPreferencesAvailable,
                    l = a.isChatPreferencesEnabled,
                    u = a.isPluginsAvailable,
                    d = a.isPluginsEnabled,
                    c = a.isCodeInterpreterAvailable,
                    f = a.isCodeInterpreterEnabled,
                    g = (0, tt.D)({
                        mutationFn: function(t) {
                            var r = t.feature,
                                a = t.enabled;
                            return P.ZP.setUserSettingsBetaFeature(null !== (e = null == n ? void 0 : n.accessToken) && void 0 !== e ? e : "", r, a)
                        },
                        onSettled: r,
                        onError: function() {
                            tl.m.danger(t.formatMessage(nD.betaSettingsUpdateFailed))
                        }
                    }),
                    h = g.isLoading,
                    m = g.variables,
                    p = g.mutate,
                    v = h && (null == m ? void 0 : m.feature) === tb.tr.BROWSING,
                    x = h && (null == m ? void 0 : m.feature) === tb.tr.CHAT_PREFERENCES,
                    y = h && (null == m ? void 0 : m.feature) === tb.tr.CODE_INTERPRETER,
                    j = h && (null == m ? void 0 : m.feature) === tb.tr.PLUGINS;
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(nI, {
                        children: (0, w.jsx)("p", {
                            children: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaIntro))
                        })
                    }), i && (0, w.jsx)(nI, {
                        children: (0, w.jsx)(nk, {
                            label: t.formatMessage(nD.betaBrowsingToggleLabel),
                            disabled: v,
                            enabled: v ? null == m ? void 0 : m.enabled : o,
                            onChange: function(e) {
                                p({
                                    feature: tb.tr.BROWSING,
                                    enabled: e
                                })
                            },
                            description: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaBrowsingToggleDescription))
                        })
                    }), s && (0, w.jsx)(nI, {
                        children: (0, w.jsx)(nk, {
                            label: t.formatMessage(nD.betaChatPreferencesToggleLabel),
                            disabled: x,
                            enabled: x ? null == m ? void 0 : m.enabled : l,
                            onChange: function(e) {
                                p({
                                    feature: tb.tr.CHAT_PREFERENCES,
                                    enabled: e
                                })
                            },
                            description: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaChatPreferencesToggleDescription))
                        })
                    }), u && (0, w.jsx)(nI, {
                        children: (0, w.jsx)(nk, {
                            label: t.formatMessage(nD.betaPluginToggleLabel),
                            disabled: j,
                            enabled: j ? null == m ? void 0 : m.enabled : d,
                            onChange: function(e) {
                                p({
                                    feature: tb.tr.PLUGINS,
                                    enabled: e
                                })
                            },
                            description: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaPluginToggleDescription))
                        })
                    }), c && (0, w.jsx)(nI, {
                        children: (0, w.jsx)(nk, {
                            label: t.formatMessage(nD.betaCodeInterpreterToggleLabel),
                            disabled: y,
                            enabled: y ? null == m ? void 0 : m.enabled : f,
                            onChange: function(e) {
                                p({
                                    feature: tb.tr.CODE_INTERPRETER,
                                    enabled: e
                                })
                            },
                            description: (0, w.jsx)(T.Z, (0, b._)({}, nD.betaCodeInterpreterToggleDescription))
                        })
                    })]
                })
            }

            function nk(e) {
                var t = e.label,
                    n = e.disabled,
                    r = e.enabled,
                    a = e.onChange,
                    i = e.description,
                    o = e.toggleTooltip,
                    s = (0, w.jsx)(ny.Z, {
                        disabled: n,
                        enabled: r,
                        onChange: a,
                        label: t,
                        withLockIcon: n
                    });
                return null != o && (s = (0, w.jsx)(ti.u, {
                    label: o,
                    side: "top",
                    sideOffset: 4,
                    children: s
                })), (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, w.jsx)("div", {
                            children: t
                        }), s]
                    }), null != i && (0, w.jsx)("div", {
                        className: "mt-2 text-xs text-gray-500 dark:text-gray-600",
                        children: i
                    })]
                })
            }

            function n_(e) {
                var t = e.color,
                    n = e.disabled,
                    r = e.label,
                    a = e.buttonLabel,
                    i = e.onClick;
                return (0, w.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, w.jsx)("div", {
                        children: r
                    }), (0, w.jsx)(ec.z, {
                        color: void 0 === t ? "neutral" : t,
                        disabled: !!n,
                        onClick: i,
                        children: a
                    })]
                })
            }

            function nM() {
                var e = (0, tv.F)(),
                    t = e.theme,
                    n = e.setTheme;
                return (0, w.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, w.jsx)("div", {
                        children: (0, w.jsx)(T.Z, (0, b._)({}, nD.theme))
                    }), (0, w.jsxs)(tw.Z.Root, {
                        value: t,
                        onValueChange: function(e) {
                            return n(e)
                        },
                        children: [(0, w.jsxs)(tw.Z.Trigger, {
                            children: [(0, w.jsx)(tw.Z.Value, {}), (0, w.jsx)(tw.Z.Icon, {})]
                        }), (0, w.jsx)(tw.Z.Portal, {
                            children: (0, w.jsxs)(tw.Z.Content, {
                                children: [(0, w.jsx)(tw.Z.Item, {
                                    value: "system",
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, nD.system))
                                }), (0, w.jsx)(tw.Z.Item, {
                                    value: "dark",
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dark))
                                }), (0, w.jsx)(tw.Z.Item, {
                                    value: "light",
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, nD.light))
                                })]
                            })
                        })]
                    })]
                })
            }

            function nT(e) {
                var t = e.onClose,
                    n = e.onDeleteHistory,
                    r = (0, ei.Z)();
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: t,
                    type: "success",
                    title: r.formatMessage(nD.deleteHistoryModalTitle),
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: r.formatMessage(nD.deleteHistoryModalConfirm),
                        color: "primary",
                        onClick: function() {
                            n(), t()
                        }
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: r.formatMessage(nD.deleteHistoryModalCancel),
                        color: "neutral",
                        onClick: t
                    })
                })
            }

            function nN(e) {
                var t = e.onClose,
                    n = (0, ei.Z)(),
                    r = (0, ev.kP)().session,
                    a = null == r ? void 0 : r.accessToken,
                    i = (0, _.useCallback)(function() {
                        try {
                            P.ZP.submitDataExport(a).then(function() {
                                tl.m.success(n.formatMessage(nD.dataExportRequested)), t()
                            })
                        } catch (e) {
                            tl.m.warning(n.formatMessage(nD.dataExportFailed), {
                                hasCloseButton: !0
                            })
                        }
                    }, [a, n, t]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: t,
                    type: "success",
                    title: n.formatMessage(nD.dataExportModalTitle),
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: n.formatMessage(nD.dataExportModalConfirm),
                        color: "primary",
                        onClick: i
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: n.formatMessage(nD.dataExportModalCancel),
                        color: "neutral",
                        onClick: t
                    }),
                    children: (0, w.jsxs)("div", {
                        className: "text-sm",
                        children: [(0, w.jsxs)("ul", {
                            className: "my-3 flex list-disc flex-col gap-1 pl-3",
                            children: [(0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataExportModalDescription1))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataExportModalDescription2))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataExportModalDescription3))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataExportModalDescription4))
                            })]
                        }), (0, w.jsx)("div", {
                            children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataExportModalDescription5))
                        })]
                    })
                })
            }

            function nP(e) {
                var t = e.value,
                    n = e.icon,
                    r = e.label,
                    a = (0, U.w$)();
                return (0, w.jsxs)(tp.xz, {
                    className: (0, G.Z)("group flex items-center justify-start gap-2 rounded-md px-2 py-1.5 text-sm radix-state-active:bg-gray-800 radix-state-active:text-white dark:text-gray-500 dark:radix-state-active:text-white", {
                        "flex-1 items-center justify-center": !a
                    }),
                    value: t,
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: n,
                        strokeWidth: 0,
                        className: "h-5 w-5 fill-gray-800 group-radix-state-active:fill-white dark:fill-gray-500"
                    }), (0, w.jsx)("div", {
                        children: r
                    })]
                })
            }

            function nS(e) {
                var t = e.value,
                    n = e.children;
                return (0, w.jsx)(tp.VY, {
                    className: "w-full md:min-h-[300px]",
                    value: t,
                    children: (0, w.jsx)("div", {
                        className: "flex flex-col gap-3 text-sm text-gray-600 dark:text-gray-300",
                        children: n
                    })
                })
            }

            function nI(e) {
                var t = e.children;
                return (0, w.jsx)("div", {
                    className: "border-b pb-3 last-of-type:border-b-0 dark:border-gray-700",
                    children: t
                })
            }

            function nZ(e) {
                var t, n = e.onClose,
                    r = (0, ei.Z)(),
                    a = (0, ev.kP)().session,
                    i = null == a ? void 0 : a.accessToken,
                    o = null == a ? void 0 : null === (t = a.user) || void 0 === t ? void 0 : t.email,
                    s = (0, j._)((0, _.useState)(""), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, j._)((0, _.useState)(""), 2),
                    c = d[0],
                    f = d[1],
                    g = (0, _.useCallback)(function() {
                        var e, t = null == a ? void 0 : null === (e = a.user) || void 0 === e ? void 0 : e.iat;
                        return void 0 === t || Date.now() / 1e3 - t < 600
                    }, [a]),
                    h = (0, _.useCallback)(function() {
                        try {
                            g() ? P.ZP.deactivateAccount(i).then(function() {
                                (0, ev.w7)()
                            }) : tl.m.warning(r.formatMessage(nD.deleteAccountSessionTooOld), {
                                hasCloseButton: !0
                            })
                        } catch (e) {
                            tl.m.warning(r.formatMessage(nD.deleteAccountFailed), {
                                hasCloseButton: !0
                            })
                        }
                    }, [i, r, g]),
                    m = (0, _.useCallback)(function() {
                        (0, ev.w7)()
                    }, []),
                    p = "DELETE" === c && (void 0 === o || l === o),
                    v = (0, j._)((0, _.useState)(function() {
                        return g()
                    }), 1)[0],
                    x = (0, B.e2)();
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: n,
                    type: "success",
                    title: r.formatMessage(nD.deleteAccountTitle),
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: n
                    }),
                    children: (0, w.jsxs)("div", {
                        className: "text-sm",
                        children: [(0, w.jsxs)("ul", {
                            className: "mb-6 mt-4 flex list-disc flex-col gap-1 pl-3",
                            children: [(0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.deleteAccountWarning))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.reuseEmailPhoneWarning))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.dataRemovalWarning))
                            }), (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.apiAccessDeletionWarning))
                            }), (null == x ? void 0 : x.purchase_origin_platform) === nc._4.MOBILE_IOS && (0, w.jsx)("li", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.iapSubscriptionWarning))
                            })]
                        }), v ? (0, w.jsxs)(w.Fragment, {
                            children: [void 0 !== o ? (0, w.jsxs)("div", {
                                className: "mb-4",
                                children: [(0, w.jsx)(nF, {
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, nD.typeEmailLabel))
                                }), (0, w.jsx)(tk, {
                                    value: l,
                                    placeholder: o,
                                    name: "email",
                                    onChange: function(e) {
                                        u(e.target.value)
                                    }
                                })]
                            }) : null, (0, w.jsxs)("div", {
                                className: "mb-4",
                                children: [(0, w.jsx)(nF, {
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, nD.typeDeleteInputLabel))
                                }), (0, w.jsx)(tk, {
                                    value: c,
                                    onChange: function(e) {
                                        f(e.target.value)
                                    },
                                    name: "delete",
                                    className: "mb-4"
                                })]
                            }), (0, w.jsx)(ec.z, {
                                color: p ? "danger" : "disabled",
                                onClick: h,
                                disabled: !p,
                                className: "w-full",
                                children: p ? (0, w.jsxs)(w.Fragment, {
                                    children: [(0, w.jsx)(eh.ZP, {
                                        icon: M.BJv
                                    }), " ", (0, w.jsx)(T.Z, (0, b._)({}, nD.deleteAccountButtonLabel))]
                                }) : (0, w.jsxs)(w.Fragment, {
                                    children: [(0, w.jsx)(eh.ZP, {
                                        icon: M.UIZ
                                    }), " ", (0, w.jsx)(T.Z, (0, b._)({}, nD.lockedButtonLabel))]
                                })
                            })]
                        }) : (0, w.jsxs)(w.Fragment, {
                            children: [(0, w.jsx)("p", {
                                className: "pb-4 text-xs text-gray-500",
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.recentLoginMessage))
                            }), (0, w.jsx)(ec.z, {
                                color: "primary",
                                onClick: m,
                                className: "w-full",
                                children: (0, w.jsx)(T.Z, (0, b._)({}, nD.refreshLoginButtonLabel))
                            })]
                        })]
                    })
                })
            }(a = f || (f = {})).General = "General", a.BetaFeatures = "BetaFeatures", a.DataControls = "DataControls";
            var nF = eo.Z.label(nj()),
                nD = (0, N.vU)({
                    settings: {
                        id: "settingsModal.settings",
                        defaultMessage: "Settings",
                        description: "Title for the settings modal"
                    },
                    theme: {
                        id: "settingsModal.theme",
                        defaultMessage: "Theme",
                        description: "Label for the theme setting"
                    },
                    system: {
                        id: "settingsModal.system",
                        defaultMessage: "System",
                        description: "Option for the system theme"
                    },
                    dark: {
                        id: "settingsModal.dark",
                        defaultMessage: "Dark",
                        description: "Option for the dark theme"
                    },
                    light: {
                        id: "settingsModal.light",
                        defaultMessage: "Light",
                        description: "Option for the light theme"
                    },
                    sharedConversations: {
                        id: "settingsModal.sharedConversations",
                        defaultMessage: "Shared links",
                        description: "Label for the shared chat/link button"
                    },
                    sharedConversationsButton: {
                        id: "settingsModal.sharedConversationsButton",
                        defaultMessage: "Manage",
                        description: "Manage shared links/conversations button"
                    },
                    exportData: {
                        id: "settingsModal.exportData",
                        defaultMessage: "Export data",
                        description: "Label for the export data button"
                    },
                    exportButton: {
                        id: "settingsModal.exportButton",
                        defaultMessage: "Export",
                        description: "Export data button"
                    },
                    deleteAccount: {
                        id: "settingsModal.deleteAccount",
                        defaultMessage: "Delete account",
                        description: "Label for the delete account button"
                    },
                    deleteAccountButton: {
                        id: "settingsModal.deleteButton",
                        defaultMessage: "Delete",
                        description: "Delete account button"
                    },
                    openPluginDevtools: {
                        id: "settingsModal.openPluginDevtools",
                        defaultMessage: "Open plugin devtools",
                        description: "Label for the open plugin devtools setting"
                    },
                    enable2fa: {
                        id: "settingsModal.enable2fa",
                        defaultMessage: "Enable two-factor authentication",
                        description: "Label for the enable 2FA button"
                    },
                    enable: {
                        id: "settingsModal.enable",
                        defaultMessage: "Enable",
                        description: "Enable 2FA button"
                    },
                    disable: {
                        id: "settingsModal.disable",
                        defaultMessage: "Disable",
                        description: "Disable 2FA button"
                    },
                    disable2fa: {
                        id: "settingsModal.disable2fa",
                        defaultMessage: "Disable two factor authentication",
                        description: "Label for the mfa remove button."
                    },
                    chatHistoryDescription: {
                        id: "settingsModal.chatHistoryDescription",
                        defaultMessage: "Save new chats on this browser to your history and allow them to be used to improve our models. Unsaved chats will be deleted from our systems within 30 days. This setting does not sync across browsers or devices. <link>Learn more</link>",
                        description: "Description for the chat history setting"
                    },
                    deleteHistoryModalTitle: {
                        id: "settingsModal.deleteHistoryModalTitle",
                        defaultMessage: "Clear your conversation history - are you sure?",
                        description: "Title for the delete history modal"
                    },
                    deleteHistoryModalConfirm: {
                        id: "settingsModal.deleteHistoryModalConfirm",
                        defaultMessage: "Confirm deletion",
                        description: "Confirm button for the delete history modal"
                    },
                    deleteHistoryModalCancel: {
                        id: "settingsModal.deleteHistoryModalCancel",
                        defaultMessage: "Cancel",
                        description: "Cancel button for the delete history modal"
                    },
                    dataExportRequested: {
                        id: "settingsModal.dataExportRequested",
                        defaultMessage: "Successfully exported data. You should receive an email shortly with your data.",
                        description: "Message shown when a data export request is received"
                    },
                    dataExportFailed: {
                        id: "settingsModal.dataExportFailed",
                        defaultMessage: "We were unable to process your export at this time. Please try again later.",
                        description: "Message shown when a data export request fails"
                    },
                    dataExportModalTitle: {
                        id: "settingsModal.dataExportModalTitle",
                        defaultMessage: "Request data export - are you sure?",
                        description: "Title for the data export modal"
                    },
                    dataExportModalConfirm: {
                        id: "settingsModal.dataExportModalConfirm",
                        defaultMessage: "Confirm export",
                        description: "Confirm button for the data export modal"
                    },
                    dataExportModalCancel: {
                        id: "settingsModal.dataExportModalCancel",
                        defaultMessage: "Cancel",
                        description: "Cancel button for the data export modal"
                    },
                    dataExportModalDescription1: {
                        id: "settingsModal.dataExportModalDescription1",
                        defaultMessage: "Your account details and conversations will be included in the export.",
                        description: "Description for the data export modal"
                    },
                    dataExportModalDescription2: {
                        id: "settingsModal.dataExportModalDescription2",
                        defaultMessage: "The data will be sent to your registered email in a downloadable file.",
                        description: "Description for the data export modal"
                    },
                    dataExportModalDescription3: {
                        id: "settingsModal.dataExportModalDescription3",
                        defaultMessage: "The download link will expire 24 hours after you receive it.",
                        description: "Description for the data export modal"
                    },
                    dataExportModalDescription4: {
                        id: "settingsModal.dataExportModalDescription4",
                        defaultMessage: "Processing may take some time. You'll be notified when it's ready.",
                        description: "Description for the data export modal"
                    },
                    dataExportModalDescription5: {
                        id: "settingsModal.dataExportModalDescription5",
                        defaultMessage: 'To proceed, click "Confirm export" below.',
                        description: "Description for the data export modal"
                    },
                    deleteAccountSessionTooOld: {
                        id: "settingsModal.deleteAccountSessionTooOld",
                        defaultMessage: "Your login session is too old. Please log in again before deleting your account.",
                        description: "Message shown when the user's login session is too old to delete their account."
                    },
                    deleteAccountFailed: {
                        id: "settingsModal.deleteAccountFailed",
                        defaultMessage: "Failed to delete account. Please try again later.",
                        description: "Message shown when there's an error deleting the user's account."
                    },
                    deleteAccountTitle: {
                        id: "settingsModal.deleteAccountTitle",
                        defaultMessage: "Delete account - are you sure?",
                        description: "Title for the delete account confirmation modal."
                    },
                    deleteAccountWarning: {
                        id: "settingsModal.deleteAccountWarning",
                        defaultMessage: "Deleting your account is permanent and cannot be undone.",
                        description: "Warning message about account deletion being permanent."
                    },
                    reuseEmailPhoneWarning: {
                        id: "settingsModal.reuseEmailPhoneWarning",
                        defaultMessage: "For security reasons, you cannot reuse the same email or phone number for a new account.",
                        description: "Warning message about not being able to reuse email or phone number for a new account."
                    },
                    dataRemovalWarning: {
                        id: "settingsModal.dataRemovalWarning",
                        defaultMessage: "All your data, including profile, conversations, and API usage, will be removed.",
                        description: "Warning message about data removal after account deletion."
                    },
                    apiAccessDeletionWarning: {
                        id: "settingsModal.apiAccessDeletionWarning",
                        defaultMessage: "If you've been using ChatGPT with the API, this access will also be deleted.",
                        description: "Warning message about API access being deleted."
                    },
                    iapSubscriptionWarning: {
                        id: "settingsModal.iapSubscriptionWarning",
                        defaultMessage: "You will need to cancel your in-app purchase subscription in the Apple App Store. We cannot cancel your subscription for you.",
                        description: "Warning message about cancelling in-app subscriptions."
                    },
                    typeEmailLabel: {
                        id: "settingsModal.typeEmailLabel",
                        defaultMessage: "Please type your account email.",
                        description: "Label for email input field when deleting an account."
                    },
                    typeDeleteInputLabel: {
                        id: "settingsModal.typeDeleteInputLabel",
                        defaultMessage: 'To proceed, type "DELETE" in the input field below.',
                        description: "Label for DELETE input field when deleting an account."
                    },
                    lockedButtonLabel: {
                        id: "settingsModal.lockedButtonLabel",
                        defaultMessage: "Locked",
                        description: "Label for the locked button when deleting an account."
                    },
                    deleteAccountButtonLabel: {
                        id: "settingsModal.deleteAccountButtonLabel",
                        defaultMessage: "Permanently delete my account",
                        description: "Label for the button to confirm account deletion."
                    },
                    recentLoginMessage: {
                        id: "settingsModal.recentLoginMessage",
                        defaultMessage: "You may only delete your account if you have logged in within the last 10 minutes. Please log in again, then return here to continue.",
                        description: "Message shown when the user needs to log in again to delete their account."
                    },
                    refreshLoginButtonLabel: {
                        id: "settingsModal.refreshLoginButtonLabel",
                        defaultMessage: "Refresh login",
                        description: "Label for the button to refresh login."
                    },
                    chatHistoryToggleLabel: {
                        id: "settingsModal.chatHistoryToggleLabel",
                        defaultMessage: "Chat history & training",
                        description: "Label for the chat history toggle."
                    },
                    chatHistoryLabel: {
                        id: "settingsModal.chatHistoryLabel",
                        defaultMessage: "Chat history",
                        description: "Label for the chat history toggle."
                    },
                    chatHistoryOnlyDescription: {
                        id: "settingsModal.chatHistoryOnlyDescription",
                        defaultMessage: "Save new chats on this browser to your history. Unsaved chats will be deleted from our systems within 30 days. This setting does not sync across browsers or devices. <link>Learn more</link>",
                        description: "Description for the chat history setting"
                    },
                    chatTrainingLabel: {
                        id: "settingsModal.chatTrainingLabel",
                        defaultMessage: "Chat training",
                        description: "Label for the chat training toggle."
                    },
                    chatTrainingBusinessDescription: {
                        id: "settingsModal.chatTrainingBusinessDescription",
                        defaultMessage: "This workspace is private and opted out of training.",
                        description: "Description for the disabled chat training toggle."
                    },
                    chatTrainingBusinessTooltip: {
                        id: "settingsModal.chatTrainingBusinessTooltip",
                        defaultMessage: "ChatGPT for Business automatically disables training.",
                        description: "Tooltip for the disabled chat training toggle."
                    },
                    dataControlsTab: {
                        id: "settingsModal.dataControls",
                        defaultMessage: "Data controls",
                        description: "Label for the data controls tab"
                    },
                    betaIntro: {
                        id: "settingsModal.betaIntro",
                        defaultMessage: "As a Plus user, enjoy early access to experimental new features, which may change during development.",
                        description: "Introduction for the beta features tab"
                    },
                    betaSettingsUpdateFailed: {
                        id: "settingsModal.betaSettingsUpdateFailed",
                        defaultMessage: "Failed to update your beta setting",
                        description: "Message shown when there's an error updating beta settings"
                    },
                    betaPluginToggleLabel: {
                        id: "settingsModal.betaPluginToggleLabel",
                        defaultMessage: "Plugins",
                        description: "Label for the Plugins beta toggle."
                    },
                    betaPluginToggleDescription: {
                        id: "settingsModal.betaPluginToggleDescription",
                        defaultMessage: "Try a version of ChatGPT that knows when and how to use third-party plugins that you enable.",
                        description: "Description for the Plugins beta toggle."
                    },
                    betaBrowsingToggleLabel: {
                        id: "settingsModal.betaBrowsingToggleLabel",
                        defaultMessage: "Browse with Bing",
                        description: "Label for the Browse with Bing beta toggle."
                    },
                    betaBrowsingToggleDescription: {
                        id: "settingsModal.betaBrowsingToggleDescription",
                        defaultMessage: "Try a version of ChatGPT that knows when and how to browse the internet to answer questions about recent topics and events.",
                        description: "Description for the Browsing beta toggle."
                    },
                    betaChatPreferencesToggleLabel: {
                        id: "settingsModal.betaChatPreferencesToggleLabel",
                        defaultMessage: "Custom instructions",
                        description: "Label for the Custom instructions toggle."
                    },
                    betaChatPreferencesToggleDescription: {
                        id: "settingsModal.betaChatPreferencesToggleDescription",
                        defaultMessage: "Try a new feature that lets you share anything you'd like ChatGPT to consider across its responses.",
                        description: "Description for the Custom instructions toggle."
                    },
                    betaCodeInterpreterToggleLabel: {
                        id: "settingsModal.betaCodeInterpreterToggleLabel",
                        defaultMessage: "Code interpreter",
                        description: "Label for the Code interpreter beta toggle."
                    },
                    betaCodeInterpreterToggleDescription: {
                        id: "settingsModal.betaCodeInterpreterToggleDescription",
                        defaultMessage: "Try a version of ChatGPT that knows how to write and execute python code, and can work with file uploads. Try asking for help with data analysis, image conversions, or editing a code file. Note: files will not persist beyond a single session.",
                        description: "Description for the Code interpreter beta toggle."
                    },
                    generalTab: {
                        id: "settingsModal.generalTab",
                        defaultMessage: "General",
                        description: "Label for the general tab"
                    },
                    betaTab: {
                        id: "settingsModal.betaTab",
                        defaultMessage: "Beta features",
                        description: "Label for the Beta Features tab"
                    },
                    clearChatLabel: {
                        id: "settingsModal.clearChatLabel",
                        defaultMessage: "Clear all chats",
                        description: "Label for the clear chat button"
                    },
                    clearChatButton: {
                        id: "settingsModal.clearChatButton",
                        defaultMessage: "Clear",
                        description: "Clear chat button"
                    }
                }),
                nE = n(35588),
                nR = n(13090),
                nB = n(80691),
                nA = n(86273),
                nL = n(15329),
                nU = n(7813),
                nO = n(70788),
                nq = n(6013);

            function nz() {
                var e = (0, Q._)(["bg-green-500 text-white py-0.5 px-1.5 text-[10px] leading-normal font-semibold rounded uppercase"]);
                return nz = function() {
                    return e
                }, e
            }
            var nH = (0, N.vU)({
                    title: {
                        id: "customInstructionsAnnouncement.title",
                        defaultMessage: "Set your Custom instructions",
                        description: "Text displayed in tooltip announcing custom instructions"
                    },
                    new: {
                        id: "customInstructionsAnnouncement.new",
                        defaultMessage: "New",
                        description: "New badge text"
                    }
                }),
                nW = "oai/apps/announcement/customInstructions";

            function nV(e) {
                var t = e.children,
                    n = function() {
                        var e = Date.now();
                        ex.m.setItem(nW, e), o(e)
                    },
                    r = (0, U.w$)(),
                    a = (0, j._)((0, _.useState)(function() {
                        var e = ex.m.getItem(nW);
                        return "number" == typeof e && e
                    }), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, R.tN)(function(e) {
                        return e.isDesktopNavCollapsed
                    }),
                    l = (0, nB.Z)(),
                    u = (0, _.useRef)(null);
                return (0, w.jsxs)(nq.fC, {
                    open: l && !s && r && !1 === i,
                    onOpenChange: function(e) {
                        e || n()
                    },
                    children: [(0, w.jsx)(nq.xz, {
                        asChild: !0,
                        ref: u,
                        children: t
                    }), (0, w.jsx)(nq.h_, {
                        children: (0, w.jsxs)(nq.VY, {
                            side: "right",
                            sideOffset: 16,
                            onOpenAutoFocus: function(e) {
                                e.preventDefault()
                            },
                            onCloseAutoFocus: function(e) {
                                e.preventDefault()
                            },
                            onInteractOutside: function(e) {
                                var t;
                                e.target instanceof Element && (null === (t = u.current) || void 0 === t ? void 0 : t.contains(e.target)) ? n() : e.preventDefault()
                            },
                            className: "relative animate-slideLeftAndFade select-none rounded-xl bg-gray-900 p-4 text-sm text-white shadow-sm dark:bg-gray-50 dark:text-gray-700",
                            children: [(0, w.jsx)("div", {
                                children: (0, w.jsxs)("div", {
                                    className: "mb-0.5 flex items-center gap-2",
                                    children: [(0, w.jsx)(nQ, {
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, nH.new))
                                    }), (0, w.jsx)("div", {
                                        className: "font-medium",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, nH.title))
                                    }), (0, w.jsx)(nq.x8, {
                                        className: "-my-1 -mr-1 ml-1 p-1 opacity-70 transition hover:opacity-100",
                                        children: (0, w.jsx)(eh.ZP, {
                                            icon: M.q5L
                                        })
                                    })]
                                })
                            }), (0, w.jsx)(nq.Eh, {
                                asChild: !0,
                                children: (0, w.jsx)("div", {
                                    className: "relative top-[-6px] h-3 w-3 rotate-45 transform rounded-br-sm bg-gray-900 dark:bg-gray-50"
                                })
                            })]
                        })
                    })]
                })
            }
            var nQ = eo.Z.span(nz());

            function nG(e) {
                var t = e.children;
                return (0, w.jsx)(tP.u, {
                    as: _.Fragment,
                    enter: "transition ease-out duration-200",
                    enterFrom: "opacity-0 translate-y-1",
                    enterTo: "opacity-100 translate-y-0",
                    leave: "transition ease-in duration-150",
                    leaveFrom: "opacity-100 translate-y-0",
                    leaveTo: "opacity-0 translate-y-1",
                    children: t
                })
            }

            function n$() {
                var e = (0, B.WY)();
                (0, B.hz)();
                var t = (0, B.ec)(B.F_.hasMultipleWorkspaces),
                    n = (0, _.useCallback)(function() {
                        es.o.logEvent(el.a.clickSidebarAccountPortalMenuItem), R.vm.openModal(R.B.AccountPortal)
                    }, []),
                    r = (0, nB.Z)();
                return (0, w.jsxs)(w.Fragment, {
                    children: [t && (0, w.jsx)(nL.R, {}), !0 === e && (0, w.jsxs)(nL.ZP, {
                        onClick: n,
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.fzv
                        }), (0, w.jsx)(T.Z, (0, b._)({}, nY.myPlan))]
                    }), r && (0, w.jsxs)(nL.ZP, {
                        onClick: function() {
                            return R.vm.openModal(R.B.UserContext)
                        },
                        children: [(0, w.jsx)(eh.wP, {
                            className: "h-4 w-4"
                        }), (0, w.jsx)(T.Z, (0, b._)({}, nY.chatPreferences))]
                    }), !1]
                })
            }
            var nY = (0, N.vU)({
                    myPlan: {
                        id: "popoverNavigation.myPlan",
                        defaultMessage: "My plan",
                        description: "My plan menu item"
                    },
                    chatPreferences: {
                        id: "popoverNavigation.chatPreferences",
                        defaultMessage: "Custom instructions",
                        description: "Custom instructions menu item"
                    },
                    myFiles: {
                        id: "popoverNavigation.myFiles",
                        defaultMessage: "My files",
                        description: "Files menu item"
                    }
                }),
                nJ = n(57101),
                nK = n(9181),
                nX = n.n(nK);

            function n0() {
                var e = (0, B.ec)(B.F_.hasMultipleWorkspaces);
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsxs)(n1, {
                        href: "/admin",
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: nJ.Z
                        }), (0, w.jsx)(T.Z, (0, b._)({}, n2.myWorkspaceSettings))]
                    }), e && (0, w.jsx)(nL.R, {})]
                })
            }

            function n1(e) {
                var t = e.href,
                    n = e.children;
                return (0, w.jsx)(nU.v.Item, {
                    children: function(e) {
                        var r = e.active;
                        return (0, w.jsx)(nX(), {
                            href: t,
                            children: (0, w.jsx)(nL.ZB, {
                                $as: "span",
                                className: (0, G.Z)(r ? "bg-gray-700" : "cursor-pointer hover:bg-gray-700"),
                                children: n
                            })
                        })
                    }
                })
            }
            var n2 = (0, N.vU)({
                myWorkspaceSettings: {
                    id: "workspacePopoverNavigation.myWorkspaceSettings",
                    defaultMessage: "Workspace settings",
                    description: "Workspace settings menu item"
                }
            });

            function n3(e) {
                var t = e.onClickSettings;
                return (0, w.jsxs)(nU.v, {
                    as: "div",
                    className: "group relative",
                    children: [(0, w.jsx)(n6, {}), (0, w.jsx)(nG, {
                        children: (0, w.jsx)(nU.v.Items, {
                            className: "absolute bottom-full left-0 z-20 mb-2 w-full overflow-hidden rounded-md bg-gray-950 pb-1.5 pt-1 outline-none",
                            children: (0, w.jsx)(n7, {
                                onClickSettings: t
                            })
                        })
                    })]
                })
            }

            function n5() {
                var e = (0, ev.kP)().session,
                    t = null == e ? void 0 : e.user,
                    n = (0, e4.Ix)();
                return t ? (0, w.jsx)(w.Fragment, {
                    children: (0, w.jsx)(nL.ZP, {
                        onClick: function() {
                            R.vm.openModal(R.B.WorkspaceSwitcher)
                        },
                        children: (0, w.jsxs)("div", {
                            className: "flex w-full flex-col gap-2",
                            children: [(0, w.jsx)(e3.zf, {
                                className: "h-10 w-10",
                                iconSize: "medium"
                            }), (0, w.jsxs)("div", {
                                className: "flex w-full items-center justify-between gap-2",
                                children: [(0, w.jsxs)("div", {
                                    className: "flex flex-col items-start gap-1",
                                    children: [(0, w.jsx)("div", {
                                        className: "text-base text-white",
                                        children: n
                                    }), (0, w.jsx)("div", {
                                        className: "text-sm text-gray-500",
                                        children: null == t ? void 0 : t.email
                                    })]
                                }), (0, w.jsx)("div", {
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: nO.Z,
                                        size: "small"
                                    })
                                })]
                            })]
                        })
                    })
                }) : null
            }
            var n4 = "oai/apps/hasSeenUserSurvey6_23";

            function n8() {
                var e = (0, ei.Z)(),
                    t = (0, U.w$)(),
                    n = (0, j._)((0, _.useState)(!1), 2),
                    r = n[0],
                    a = n[1],
                    i = ex.m.getItem(n4);
                return r || i ? null : (0, w.jsx)("div", {
                    className: "mx-1 mb-1 rounded-sm bg-[#0077FF]",
                    children: (0, w.jsxs)("div", {
                        className: "flex flex-col items-center justify-stretch gap-3 p-3 text-sm text-white",
                        children: [(0, w.jsxs)("div", {
                            className: "flex w-full items-start",
                            children: [(0, w.jsxs)("div", {
                                className: "flex-grow",
                                children: [(0, w.jsx)("div", {
                                    className: "font-bold",
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, re.surveyTitle))
                                }), (0, w.jsx)("div", {
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, re.surveyDescription))
                                })]
                            }), (0, w.jsx)("button", {
                                className: "text-white/25 hover:text-white/40",
                                onClick: function() {
                                    a(!0), ex.m.setItem(n4, !0)
                                },
                                "aria-label": e.formatMessage(re.surveyDismiss),
                                children: (0, w.jsx)(eh.QF, {
                                    width: t ? "20px" : "24px",
                                    height: t ? "20px" : "24px"
                                })
                            })]
                        }), (0, w.jsxs)("a", {
                            href: "https://openai.qualtrics.com/jfe/form/SV_7QmSGWHymCCmIxE",
                            target: "_blank",
                            className: "flex w-full flex-row items-center justify-center gap-2 rounded-[4px] bg-white/25 p-2 hover:bg-white/40",
                            rel: "noreferrer",
                            onClick: function() {
                                ex.m.setItem(n4, !0), a(!0)
                            },
                            children: [(0, w.jsx)(eh.ZP, {
                                size: "small",
                                icon: M.AlO
                            }), (0, w.jsx)(T.Z, (0, b._)({}, re.takeSurveyButton))]
                        })]
                    })
                })
            }

            function n7(e) {
                var t = e.onClickSettings,
                    n = (0, B.WY)(),
                    r = (0, B.ec)(B.F_.isBusinessWorkspace),
                    a = (0, B.hz)(),
                    i = a.has(eu.G_),
                    o = (0, B.ec)(B.F_.hasMultipleWorkspaces),
                    s = (0, U.w$)(),
                    l = a.has(eu.rk);
                return (0, w.jsxs)("nav", {
                    children: [i && (0, w.jsx)(n8, {}), o && (0, w.jsx)(n5, {}), r ? (0, w.jsx)(n0, {}) : (0, w.jsx)(n$, {}), (!l || !s) && (0, w.jsxs)(nL.ZP, {
                        as: "a",
                        href: "https://help.openai.com/en/collections/3742473-chatgpt",
                        target: "_blank",
                        onClick: function() {
                            es.o.logEvent(el.a.clickFaqLink)
                        },
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.AlO
                        }), (0, w.jsx)(T.Z, (0, b._)({}, re.helpAndFaq))]
                    }), (0, w.jsxs)(nL.ZP, {
                        onClick: t,
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.nbt
                        }), n ? (0, w.jsx)(T.Z, (0, b._)({}, re.settingsPlus)) : (0, w.jsx)(T.Z, (0, b._)({}, re.settings))]
                    }), (0, w.jsx)(nL.R, {}), (0, w.jsxs)(nL.ZP, {
                        onClick: function() {
                            es.o.logEvent(el.a.clickLogOut, {
                                eventSource: "mouse"
                            }), (0, ev.w7)()
                        },
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.xqh
                        }), (0, w.jsx)(T.Z, (0, b._)({}, re.logOut))]
                    })]
                })
            }

            function n6() {
                var e = (0, ev.kP)().session;
                return (null == e ? void 0 : e.user) ? (0, w.jsx)(n9, {}) : null
            }

            function n9() {
                var e = (0, e4.Ix)();
                return (0, w.jsx)(nV, {
                    children: (0, w.jsxs)(nU.v.Button, {
                        className: "flex w-full items-center gap-2.5 rounded-md px-3 py-3 text-sm transition-colors duration-200 hover:bg-gray-800 group-ui-open:bg-gray-800",
                        children: [(0, w.jsx)("div", {
                            className: "flex-shrink-0",
                            children: (0, w.jsx)(e3.zf, {
                                iconSize: "redesign"
                            })
                        }), (0, w.jsx)("div", {
                            className: "grow overflow-hidden text-ellipsis whitespace-nowrap text-left text-white",
                            children: e
                        }), (0, w.jsx)(eh.ZP, {
                            icon: M.K9M,
                            size: "small",
                            className: "flex-shrink-0 text-gray-500"
                        })]
                    })
                })
            }
            var re = (0, N.vU)({
                helpAndFaq: {
                    id: "navigation.helpAndFaq",
                    defaultMessage: "Help & FAQ",
                    description: "Help & FAQ menu item"
                },
                settings: {
                    id: "navigation.settings",
                    defaultMessage: "Settings",
                    description: "Settings menu item"
                },
                settingsPlus: {
                    id: "navigation.settingsPlus",
                    defaultMessage: "Settings & Beta",
                    description: "Settings menu item for Plus users"
                },
                logOut: {
                    id: "navigation.logOut",
                    defaultMessage: "Log out",
                    description: "Log out menu item"
                },
                takeSurveyButton: {
                    id: "navigation.survey.takeSurveyButton",
                    defaultMessage: "Take survey",
                    description: "Survey offer call to action"
                },
                surveyDismiss: {
                    id: "navigation.surveyDismiss",
                    defaultMessage: "Dismiss survey",
                    description: "Survey offer dismiss button"
                },
                surveyDescription: {
                    id: "navigation.surveyDescription",
                    defaultMessage: "Shape the future of ChatGPT.",
                    description: "Survey offer description"
                },
                surveyTitle: {
                    id: "navigation.surveyTitle",
                    defaultMessage: "We’d love to hear from you!",
                    description: "Survey offer title"
                }
            });

            function rt() {
                var e = (0, Q._)(["flex-col flex-1 transition-opacity duration-500\n  ", "\n  ", ""]);
                return rt = function() {
                    return e
                }, e
            }

            function rn(e) {
                var t = e.onDeleteHistory,
                    n = e.onNewThread,
                    r = e.children,
                    a = (0, ei.Z)(),
                    i = (0, B.hz)(),
                    o = i.has(eu.Ue),
                    s = (0, B.WY)(),
                    l = (0, B.$T)(),
                    u = (0, nB.Z)(),
                    d = (0, B.ec)(B.F_.isBusinessWorkspace),
                    c = (0, eQ.g)(function(e) {
                        return e.flags.isUserInCanPayGroup
                    }),
                    f = (0, nE.t)(function(e) {
                        return {
                            setShowAccountPaymentModal: e.setShowAccountPaymentModal
                        }
                    }).setShowAccountPaymentModal,
                    g = (0, _.useCallback)(function() {
                        f(!0, function() {
                            es.o.logEvent(el.a.clickSidebarAccountPaymentMenuItem)
                        })
                    }, [f]),
                    h = (0, _.useRef)(null),
                    m = (0, j._)((0, _.useState)(!1), 2),
                    p = m[0],
                    v = m[1],
                    x = (0, _.useContext)(A.QL),
                    y = x.historyDisabled,
                    C = x.toggleHistoryDisabled,
                    k = x.getModifiedSettings,
                    N = x.unsetModifiedSettings,
                    P = k(),
                    S = (0, R.tN)(function(e) {
                        return e.activeModals.has(R.B.Settings)
                    }),
                    I = (0, _.useCallback)(function() {
                        R.vm.openModal(R.B.Settings)
                    }, []),
                    Z = (0, _.useCallback)(function() {
                        R.vm.closeModal(R.B.Settings), N()
                    }, [N]);
                (0, _.useEffect)(function() {
                    P && R.vm.openModal(R.B.Settings)
                }, []);
                var F = (0, _.useCallback)(function() {
                        n(), C()
                    }, [n, C]),
                    D = (0, w.jsxs)("div", {
                        className: (0, G.Z)("absolute left-0 top-14 z-20 overflow-hidden transition-all duration-500", y ? "visible max-h-72" : "invisible max-h-0"),
                        children: [(0, w.jsxs)("div", {
                            className: "bg-gray-900 px-4 py-3",
                            children: [(0, w.jsx)("div", {
                                className: "p-1 text-sm text-gray-100",
                                children: (0, w.jsx)(T.Z, (0, b._)({}, ra.chatHistoryOff))
                            }), (0, w.jsx)("div", {
                                className: "p-1 text-xs text-gray-500",
                                children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, d ? ra.chatHistoryOffDescriptionBusiness : ra.chatHistoryOffDescription), {
                                    values: {
                                        learnMore: (0, w.jsx)("a", {
                                            href: "https://help.openai.com/en/articles/7730893",
                                            target: "_blank",
                                            className: "underline",
                                            rel: "noreferrer",
                                            children: (0, w.jsx)(T.Z, (0, b._)({}, ra.learnMore))
                                        }),
                                        b: function(e) {
                                            return (0, w.jsx)("strong", {
                                                children: e
                                            })
                                        }
                                    }
                                }))
                            }), (0, w.jsxs)(ec.z, {
                                className: "mt-4 w-full",
                                onClick: F,
                                color: "primary",
                                size: "medium",
                                children: [(0, w.jsx)(eh.ZP, {
                                    icon: M.$IY
                                }), (0, w.jsx)(T.Z, (0, b._)({}, ra.enableChatHistory))]
                            })]
                        }), (0, w.jsx)("div", {
                            className: "h-24 bg-gradient-to-t from-gray-900/0 to-gray-900"
                        })]
                    });
                (0, _.useEffect)(function() {
                    var e;
                    h.current && v((e = h.current).scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth)
                }, [r]);
                var E = !(0, B.WY)() && !i.has("disable_upgrade_ui"),
                    L = (0, B.KQ)(),
                    U = (0, R.tN)(function(e) {
                        return e.isFilesModalOpen
                    });
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsxs)("div", {
                        className: "scrollbar-trigger relative h-full w-full flex-1 items-start border-white/20",
                        children: [(0, w.jsx)(eV.f, {
                            asChild: !0,
                            children: (0, w.jsx)("h2", {
                                children: (0, w.jsx)(T.Z, (0, b._)({}, ra.chatHistoryLabel))
                            })
                        }), (0, w.jsxs)("nav", {
                            className: "flex h-full w-full flex-col p-2",
                            "aria-label": a.formatMessage(ra.chatHistoryLabel),
                            children: [(0, w.jsxs)("div", {
                                className: "mb-1 flex flex-row gap-2",
                                children: [(0, w.jsxs)(nR.MP, {
                                    onClick: n,
                                    children: [(0, w.jsx)(eh.ZP, {
                                        icon: y ? M.Bw1 : M.OvN
                                    }), (0, w.jsx)(T.Z, (0, b._)({}, y ? ra.clearChat : ra.newChat))]
                                }), o && (0, w.jsx)(nR.H, {})]
                            }), D, (0, w.jsx)(rr, {
                                ref: h,
                                $offsetScrollbar: p,
                                $disableScroll: y,
                                children: r
                            }), (0, w.jsxs)("div", {
                                className: "border-t border-white/20 pt-2 empty:hidden",
                                children: [!l && !1 === s && c && !d && (0, w.jsx)(nL.Vq, {
                                    onClick: g,
                                    className: "rounded-md",
                                    children: (0, w.jsxs)("span", {
                                        className: "flex w-full flex-row justify-between",
                                        children: [(0, w.jsxs)("span", {
                                            className: "gold-new-button flex items-center gap-3",
                                            children: [(0, w.jsx)(eh.ZP, {
                                                icon: M.fzv
                                            }), L ? (0, w.jsx)(T.Z, (0, b._)({}, ra.renewPlus)) : (0, w.jsx)(T.Z, (0, b._)({}, ra.upgradeToPlus))]
                                        }), E && !L && (0, w.jsx)("span", {
                                            className: "rounded-md bg-yellow-200 px-1.5 py-0.5 text-xs font-medium uppercase text-gray-800",
                                            children: (0, w.jsx)(T.Z, (0, b._)({}, ra.newLabel))
                                        })]
                                    })
                                }), (0, w.jsx)(n3, {
                                    onClickSettings: I
                                })]
                            })]
                        })]
                    }), S && (0, w.jsx)(nw, {
                        onClose: Z,
                        onToggleHistoryDisabled: n,
                        onDeleteHistory: t
                    }), i.has("files_list_ui") && U && (0, w.jsx)(tm, {}), u && (0, w.jsx)(nA.wm, {}), (0, w.jsx)(e6, {})]
                })
            }
            var rr = eo.Z.div(rt(), function(e) {
                    return e.$disableScroll ? "overflow-y-hidden opacity-20 pointer-events-none" : "overflow-y-auto"
                }, function(e) {
                    return e.$offsetScrollbar && "-mr-2"
                }),
                ra = (0, N.vU)({
                    upgradeToPlus: {
                        id: "NavigationContent.upgradeToPlus",
                        defaultMessage: "Upgrade to Plus",
                        description: "Upgrade to Plus menu item"
                    },
                    renewPlus: {
                        id: "NavigationContent.renewPlus",
                        defaultMessage: "Renew Plus",
                        description: "Renew Plus menu item"
                    },
                    chatHistoryLabel: {
                        id: "NavigationContent.chatHistoryLabel",
                        defaultMessage: "Chat history",
                        description: "Chat history label heading"
                    },
                    chatHistoryOff: {
                        id: "NavigationContent.chatHistoryOff",
                        defaultMessage: "Chat History is off for this browser.",
                        description: "Text indicating that chat history is turned off"
                    },
                    chatHistoryOffDescription: {
                        id: "NavigationContent.chatHistoryOffDescription",
                        defaultMessage: "When history is turned off, new chats on this browser won't appear in your history on any of your devices, be used to train our models, or stored for longer than 30 days. <b>This setting does not sync across browsers or devices.</b> {learnMore}",
                        description: "Description for chat history being off"
                    },
                    chatHistoryOffDescriptionBusiness: {
                        id: "NavigationContent.chatHistoryOffDescriptionBusiness",
                        defaultMessage: "When history is turned off, new chats on this browser won't appear in your history on any of your devices, or stored for longer than 30 days. <b>This setting does not sync across browsers or devices.</b> {learnMore}",
                        description: "Description for chat history being off"
                    },
                    learnMore: {
                        id: "NavigationContent.learnMore",
                        defaultMessage: "Learn more",
                        description: "Learn more link text"
                    },
                    enableChatHistory: {
                        id: "NavigationContent.enableChatHistory",
                        defaultMessage: "Enable chat history",
                        description: "Enable chat history button label"
                    },
                    newLabel: {
                        id: "NavigationContent.newLabel",
                        defaultMessage: "NEW",
                        description: "Label for new features or items"
                    },
                    clearChat: {
                        id: "NavigationContent.clearChat",
                        defaultMessage: "Clear chat",
                        description: "Clear chat button label"
                    },
                    newChat: {
                        id: "NavigationContent.newChat",
                        defaultMessage: "New chat",
                        description: "New chat button label"
                    }
                }),
                ri = n(82277),
                ro = n(6128),
                rs = n(73413),
                rl = n.n(rs),
                ru = n(11253),
                rd = n.n(ru),
                rc = n(77010),
                rf = n(16600),
                rg = n(2827),
                rh = n(77370);

            function rm(e) {
                var t = e.id,
                    n = e.label,
                    r = e.disabled;
                return (0, w.jsxs)("div", {
                    className: "form-check",
                    children: [(0, w.jsx)("input", {
                        className: "form-check-input float-left mr-2 mt-1 h-4 w-4 cursor-pointer appearance-none rounded-sm border border-gray-300 bg-white bg-contain bg-center bg-no-repeat align-top transition duration-200 checked:border-blue-600 checked:bg-blue-600 focus:outline-none",
                        type: "checkbox",
                        disabled: r,
                        value: "",
                        id: t
                    }), (0, w.jsx)("label", {
                        className: "form-check-label text-gray-800 dark:text-gray-100",
                        htmlFor: t,
                        children: n
                    })]
                })
            }
            var rp = n(54655);

            function rv() {
                var e = (0, Q._)(["p-2 rounded-md hover:bg-gray-200 hover:text-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200 flex items-center gap-2"]);
                return rv = function() {
                    return e
                }, e
            }

            function rx() {
                var e = (0, Q._)(["flex justify-between items-center p-4 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm"]);
                return rx = function() {
                    return e
                }, e
            }

            function rb(e) {
                var t = e.clientThreadId,
                    n = e.messageForRating,
                    r = e.variantIds,
                    a = e.conversationTurnMountTime,
                    i = function(e) {
                        var i, l, u = S.tQ.getTree(t),
                            d = r[0] || "",
                            c = (null == u ? void 0 : u.getConversationTurns(d)) || [],
                            f = c[c.length - 1],
                            g = (null == f ? void 0 : f.messages) || [],
                            h = g[g.length - 1],
                            m = (null == h ? void 0 : null === (i = h.message) || void 0 === i ? void 0 : i.id) || "",
                            p = r[1] || "",
                            v = (null == u ? void 0 : u.getConversationTurns(p)) || [],
                            x = v[v.length - 1],
                            y = (null == x ? void 0 : x.messages) || [],
                            j = y[y.length - 1],
                            w = (null == j ? void 0 : null === (l = j.message) || void 0 === l ? void 0 : l.id) || "";
                        P.ZP.submitMessageComparisonFeedback({
                            feedback_version: "inline_regen_feedback:a:1.0",
                            original_message_id: m,
                            new_message_id: w,
                            rating: "none",
                            conversation_id: S.tQ.getServerThreadId(t),
                            text: "",
                            tags: [],
                            completion_comparison_rating: e,
                            new_completion_placement: "not-applicable",
                            feedback_start_time: a,
                            compare_step_start_time: a,
                            new_completion_load_start_time: o,
                            new_completion_load_end_time: s,
                            frontend_submission_time: Date.now(),
                            timezone_offset_min: new Date().getTimezoneOffset()
                        }), S.tQ.updateTree(t, function(t) {
                            t.updateNode(n.nodeId, {
                                metadata: {
                                    $set: (0, V._)((0, b._)({}, t.getMetadata(n.nodeId)), {
                                        inlineComparisonRating: e
                                    })
                                }
                            })
                        }), S.tQ.updateTree(t, function(e) {
                            e.updateNode(h.nodeId, {
                                metadata: {
                                    $set: (0, V._)((0, b._)({}, e.getMetadata(h.nodeId)), {
                                        inlineComparisonRating: "baseline"
                                    })
                                }
                            })
                        })
                    },
                    o = (0, j._)((0, _.useState)(function() {
                        return null != n.message.create_time ? 1e3 * n.message.create_time : Date.now()
                    }), 1)[0],
                    s = (0, j._)((0, _.useState)(function() {
                        return Date.now()
                    }), 1)[0];
                return (0, w.jsxs)(rj, {
                    children: [(0, w.jsx)("div", {
                        className: (0, G.Z)("mr-4"),
                        children: "Was this response better or worse?"
                    }), (0, w.jsxs)(ry, {
                        onClick: function() {
                            return i("new")
                        },
                        title: "This response was better than the previous response",
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.fmn,
                            className: (0, G.Z)("mr-1")
                        }), "Better"]
                    }), (0, w.jsxs)(ry, {
                        onClick: function() {
                            return i("original")
                        },
                        title: "This response was worse than the previous response",
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.oLd,
                            className: (0, G.Z)("mr-1")
                        }), "Worse"]
                    }), (0, w.jsxs)(ry, {
                        onClick: function() {
                            return i("same")
                        },
                        title: "This response was the same in quality",
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: rp.Ny3,
                            className: (0, G.Z)("mr-1 rounded-full border border-gray-400 dark:border-gray-300")
                        }), "Same"]
                    }), (0, w.jsx)(ry, {
                        onClick: function() {
                            S.tQ.updateTree(t, function(e) {
                                e.updateNode(n.nodeId, {
                                    metadata: {
                                        $set: (0, V._)((0, b._)({}, e.getMetadata(n.nodeId)), {
                                            inlineComparisonRating: "skip"
                                        })
                                    }
                                })
                            })
                        },
                        title: "Skip this comparison",
                        children: (0, w.jsx)(eh.ZP, {
                            icon: M.q5L,
                            size: "medium"
                        })
                    })]
                })
            }
            var ry = eo.Z.button(rv()),
                rj = eo.Z.div(rx()),
                rw = n(47635),
                rC = n(16920),
                rk = n(52738);

            function r_() {
                var e = (0, Q._)(["flex flex-col items-start"]);
                return r_ = function() {
                    return e
                }, e
            }

            function rM() {
                var e = (0, Q._)(["flex items-center text-xs bg-green-100 rounded p-3 text-gray-900 ", ""]);
                return rM = function() {
                    return e
                }, e
            }

            function rT() {
                var e = (0, Q._)(["max-w-full overflow-x-auto mt-3 flex flex-col gap-2 rounded bg-gray-100 p-3 text-sm text-gray-800"]);
                return rT = function() {
                    return e
                }, e
            }
            var rN = _.memo(function(e) {
                    var t = e.children,
                        n = e.isComplete,
                        r = e.expanderClosedLabel,
                        a = e.expanderOpenLabel,
                        i = e.resultsPreview,
                        o = e.results,
                        s = e.initialExpanded,
                        l = e.onExpand,
                        u = (0, j._)((0, _.useState)(void 0 !== s && s), 2),
                        d = u[0],
                        c = u[1],
                        f = (0, _.useCallback)(function() {
                            c(function(e) {
                                return !e
                            }), null == l || l()
                        }, [l]);
                    return (0, w.jsxs)(rP, {
                        children: [(0, w.jsxs)(rS, {
                            $complete: n,
                            children: [(0, w.jsx)("div", {
                                children: t
                            }), !n && (0, w.jsx)(em.Z, {
                                className: (0, G.Z)("shrink-0", null != o ? "ml-1" : "ml-12")
                            }), null != o && (0, w.jsxs)("div", {
                                className: "ml-12 flex items-center gap-2",
                                role: "button",
                                onClick: f,
                                children: [null != a && null != r && (0, w.jsx)("div", {
                                    className: "text-xs text-gray-600",
                                    children: d ? a : r
                                }), !d && i, (0, w.jsx)(eh.ZP, {
                                    icon: d ? M.rH8 : M.bTu
                                })]
                            })]
                        }), d && o]
                    })
                }),
                rP = eo.Z.div(r_()),
                rS = eo.Z.div(rM(), function(e) {
                    return e.$complete && "bg-gray-100"
                }),
                rI = eo.Z.div(rT()),
                rZ = (0, N.vU)({
                    startingBrowsing: {
                        id: "browsingMessage.startingBrowsing",
                        defaultMessage: "Browsing the web...",
                        description: "Status message when browsing is starting"
                    },
                    startingFileSearch: {
                        id: "browsingMessage.startingFileSearch",
                        defaultMessage: "Searching files...",
                        description: "Status message when searching files is starting"
                    },
                    finishedBrowsing: {
                        id: "browsingMessage.finishedBrowsing",
                        defaultMessage: "Finished browsing",
                        description: "Status message when browsing is finished"
                    },
                    finishedFileSearch: {
                        id: "browsingMessage.finishedFileSearch",
                        defaultMessage: "Finished searching files",
                        description: "Status message when searching files is finished"
                    },
                    thinking: {
                        id: "browsingMessage.thinking",
                        defaultMessage: "Thinking...",
                        description: "Status message when the next browsing command is being generated"
                    },
                    searchInProgressWeb: {
                        id: "browsingMessage.command.search.inProgress.web",
                        defaultMessage: "Searching Bing: <bold>“<link>{searchQuery}</link>”</bold>",
                        description: "Browsing command to search Bing is in progress"
                    },
                    searchInProgressFiles: {
                        id: "browsingMessage.command.search.inProgress.files",
                        defaultMessage: "Searching files: <bold>“{searchQuery}”</bold>",
                        description: "Browsing command to search files is in progress"
                    },
                    searchFinishedWeb: {
                        id: "browsingMessage.command.search.finished.web",
                        defaultMessage: "Searched Bing: <bold>“<link>{searchQuery}</link>”</bold>",
                        description: "Browsing command to search Bing finished"
                    },
                    searchFinishedFiles: {
                        id: "browsingMessage.command.search.finished.files",
                        defaultMessage: "Searched files: <bold>“{searchQuery}”</bold>",
                        description: "Browsing command to search files finished"
                    },
                    searchError: {
                        id: "browsingMessage.command.search.error",
                        defaultMessage: "Search failed",
                        description: "Browsing command to search the web failed"
                    },
                    clickInProgress: {
                        id: "browsingMessage.command.click.inProgress",
                        defaultMessage: "Clicking on a link...",
                        description: "Browsing command to click on a link is in progress"
                    },
                    openFileInProgress: {
                        id: "browsingMessage.command.openFile.inProgress",
                        defaultMessage: "Opening a file...",
                        description: "Browsing command to click into a file is in progress"
                    },
                    clickFinished: {
                        id: "browsingMessage.command.click.finished",
                        defaultMessage: "Clicked on a link",
                        description: "Browsing command to click on a link finished"
                    },
                    openFileFinished: {
                        id: "browsingMessage.command.openFile.finished",
                        defaultMessage: "Opened a file",
                        description: "Browsing command to click into a file finished"
                    },
                    clickFinishedWithLink: {
                        id: "browsingMessage.command.click.finishedWithLink",
                        defaultMessage: "Clicked on:",
                        description: "Browsing command to click on a link finished. The link that was clicked will be displayed after the :"
                    },
                    openFileFinishedWithLink: {
                        id: "browsingMessage.command.openFile.finishedWithLink",
                        defaultMessage: "Opened:",
                        description: "Browsing command to click into a file finished. The file that was opened will be displayed after the :"
                    },
                    clickError: {
                        id: "browsingMessage.command.click.error",
                        defaultMessage: "Click failed",
                        description: "Browsing command to click on a link failed"
                    },
                    openFileError: {
                        id: "browsingMessage.command.openFile.error",
                        defaultMessage: "Opening file failed",
                        description: "Browsing command to click on a link failed"
                    },
                    quote: {
                        id: "browsingMessage.command.quote",
                        defaultMessage: "Reading content",
                        description: "Browsing command to read a specific quote from a page"
                    },
                    quoteError: {
                        id: "browsingMessage.command.quote.error",
                        defaultMessage: "Reading content failed",
                        description: "Browsing command to read a specific quote from a page failed"
                    },
                    back: {
                        id: "browsingMessage.command.back",
                        defaultMessage: "Going back to last page",
                        description: "Browsing command to go back to the last page"
                    },
                    backError: {
                        id: "browsingMessage.command.back.error",
                        defaultMessage: "Going back failed",
                        description: "Browsing command to go back to the last page failed"
                    },
                    scroll: {
                        id: "browsingMessage.command.scroll",
                        defaultMessage: "Scrolling down",
                        description: "Browsing command to scroll down on a page"
                    },
                    scrollError: {
                        id: "browsingMessage.command.scroll.error",
                        defaultMessage: "Scroll failed",
                        description: "Browsing command to scroll down on a page failed"
                    }
                }),
                rF = _.memo(function(e) {
                    var t, n = e.messages,
                        r = e.isComplete,
                        a = e.isRetrieval,
                        i = (0, B.hz)(),
                        o = n.map(function(e) {
                            return e.message
                        }),
                        s = o.map(function(e, t) {
                            if (e.author.role !== tH.uU.Tool || t > 0 && rH(e) && rH(o[t - 1])) return null;
                            if ("browser_one_box" === e.author.name) return {
                                type: "search",
                                didError: "system_error" === e.content.content_type,
                                message: e
                            };
                            var n = e.metadata;
                            if (!n) return null;
                            var r = n.command,
                                a = n.status;
                            return r ? {
                                type: r,
                                status: a,
                                didError: "system_error" === e.content.content_type,
                                message: e
                            } : null
                        }).filter(Boolean),
                        l = s.map(function(e, t) {
                            return (0, w.jsx)(rD, {
                                command: e,
                                isRetrieval: a
                            }, t)
                        });
                    r ? (l.push((0, w.jsx)(rq, {
                        isRetrieval: a
                    }, "finished")), t = (0, w.jsx)(rq, {
                        isRetrieval: a,
                        compact: !0
                    })) : 0 === l.length ? (l.push((0, w.jsx)(rO, {
                        isRetrieval: a
                    }, "waiting")), t = (0, w.jsx)(rO, {
                        isRetrieval: a,
                        compact: !0
                    })) : "finished" === s[s.length - 1].status && l.push((0, w.jsx)(rz, {
                        icon: M.Wqx,
                        children: (0, w.jsx)(T.Z, (0, b._)({}, rZ.thinking))
                    }, "thinking")), t || (t = (0, w.jsx)(rD, {
                        command: s[s.length - 1],
                        isRetrieval: a,
                        compact: !0
                    }));
                    var u = i.has(eu.UG) && !r ? function(e) {
                        var t, n = e.reverse().find(function(e) {
                            return e.author.role === tH.uU.Assistant
                        });
                        if (!n) return null;
                        for (var r = (0, tT.RR)(n), a = /^#\s*(.*)/gm, i = []; null !== (t = a.exec(r));) i.push(t[1]);
                        return i.length > 0 ? i.join("\n") : null
                    }(o) : null;
                    return (0, w.jsxs)(rN, {
                        isComplete: r,
                        results: (0, w.jsx)(rI, {
                            className: "text-xs",
                            children: l
                        }),
                        children: [null != u && (0, w.jsx)("div", {
                            className: "mb-2 whitespace-pre-wrap font-medium",
                            children: u
                        }), t]
                    })
                });

            function rD(e) {
                var t = e.command,
                    n = e.isRetrieval,
                    r = e.compact;
                if (t.didError) return (0, w.jsx)(rU, {
                    commandType: t.type
                });
                switch (t.type) {
                    case "search":
                        var a, i, o, s, l = "browser_one_box" === t.message.author.name ? null === (a = t.message.metadata) || void 0 === a ? void 0 : null === (i = a._cite_metadata) || void 0 === i ? void 0 : i.original_query : null === (o = t.message.metadata) || void 0 === o ? void 0 : null === (s = o.args) || void 0 === s ? void 0 : s[0];
                        if (null == l) return null;
                        return (0, w.jsx)(rE, {
                            searchQuery: l,
                            isComplete: "finished" === t.status,
                            isRetrieval: n,
                            compact: r
                        });
                    case "click":
                    case "open_url":
                        var u, d, c = null === (u = t.message.metadata) || void 0 === u ? void 0 : null === (d = u._cite_metadata) || void 0 === d ? void 0 : d.metadata_list[0];
                        return (0, w.jsx)(rR, {
                            isRetrieval: n,
                            citationMetadata: c,
                            compact: r
                        });
                    case "quote":
                    case "quote_full":
                        return (0, w.jsx)(rB, {
                            compact: r
                        });
                    case "back":
                        return (0, w.jsx)(rA, {
                            compact: r
                        });
                    case "scroll":
                        return (0, w.jsx)(rL, {
                            compact: r
                        });
                    default:
                        return null
                }
            }

            function rE(e) {
                var t = e.searchQuery,
                    n = e.isComplete,
                    r = e.isRetrieval,
                    a = e.compact,
                    i = function(e) {
                        var n = P.ZP.getBingLink({
                            query: t
                        });
                        return (0, w.jsx)("a", {
                            href: n,
                            target: "_blank",
                            rel: "noreferrer",
                            className: "text-green-600",
                            children: e
                        })
                    },
                    o = r ? rZ.searchInProgressFiles : rZ.searchInProgressWeb,
                    s = r ? rZ.searchFinishedFiles : rZ.searchFinishedWeb;
                return (0, w.jsx)(rz, {
                    icon: M.jRj,
                    compact: a,
                    children: n ? (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, s), {
                        values: {
                            bold: function(e) {
                                return (0, w.jsx)("span", {
                                    className: "font-medium",
                                    children: e
                                })
                            },
                            link: i,
                            searchQuery: t
                        }
                    })) : (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, o), {
                        values: {
                            bold: function(e) {
                                return (0, w.jsx)("span", {
                                    className: "font-medium",
                                    children: e
                                })
                            },
                            link: i,
                            searchQuery: t
                        }
                    }))
                })
            }

            function rR(e) {
                var t = e.isRetrieval,
                    n = e.citationMetadata,
                    r = e.compact,
                    a = t ? rZ.openFileInProgress : rZ.clickInProgress,
                    i = t ? rZ.openFileFinished : rZ.clickFinished,
                    o = t ? rZ.openFileFinishedWithLink : rZ.clickFinishedWithLink;
                return (0, w.jsx)(rz, {
                    icon: t ? M.NOg : M.PS6,
                    compact: r,
                    children: n ? !0 === r ? (0, w.jsx)(T.Z, (0, b._)({}, i)) : (0, w.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, w.jsx)(T.Z, (0, b._)({}, o)), (0, w.jsx)("div", {
                            className: "rounded border border-black/10 bg-white px-2 py-1",
                            children: (0, w.jsx)(rk.Op, {
                                citationMetadata: n,
                                onClick: function() {
                                    if (void 0 === n.type || "webpage" === n.type) {
                                        var e;
                                        rC.m.logEvent("chatgpt_browsing_click_link", n.url, {
                                            domain: null !== (e = rw.get(new URL(n.url).hostname)) && void 0 !== e ? e : ""
                                        })
                                    }
                                }
                            })
                        })]
                    }) : (0, w.jsx)(T.Z, (0, b._)({}, a))
                })
            }

            function rB(e) {
                var t = e.compact;
                return (0, w.jsx)(rz, {
                    icon: M.SnF,
                    compact: t,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, rZ.quote))
                })
            }

            function rA(e) {
                var t = e.compact;
                return (0, w.jsx)(rz, {
                    icon: M.cww,
                    compact: t,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, rZ.back))
                })
            }

            function rL(e) {
                var t = e.compact;
                return (0, w.jsx)(rz, {
                    icon: M.nlg,
                    compact: t,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, rZ.scroll))
                })
            }

            function rU(e) {
                var t, n = e.commandType,
                    r = e.compact;
                switch (n) {
                    case "search":
                        t = rZ.searchError;
                        break;
                    case "click":
                    case "open_url":
                        t = rZ.clickError;
                        break;
                    case "quote":
                    case "quote_full":
                        t = rZ.quoteError;
                        break;
                    case "back":
                        t = rZ.backError;
                        break;
                    case "scroll":
                        t = rZ.scrollError;
                        break;
                    default:
                        return null
                }
                return (0, w.jsx)(rz, {
                    icon: M.bcx,
                    compact: r,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, t))
                })
            }

            function rO(e) {
                var t = e.isRetrieval,
                    n = e.compact,
                    r = t ? rZ.startingFileSearch : rZ.startingBrowsing;
                return (0, w.jsx)(rz, {
                    icon: M.jRj,
                    compact: n,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, r))
                })
            }

            function rq(e) {
                var t = e.isRetrieval,
                    n = e.compact,
                    r = t ? rZ.finishedFileSearch : rZ.finishedBrowsing;
                return (0, w.jsx)(rz, {
                    icon: M._rq,
                    compact: n,
                    children: (0, w.jsx)(T.Z, (0, b._)({}, r))
                })
            }

            function rz(e) {
                var t = e.children,
                    n = e.icon,
                    r = e.compact;
                return (0, w.jsxs)("div", {
                    className: (0, G.Z)("flex items-center gap-2", !0 !== r && "min-h-[24px]"),
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: n,
                        className: "shrink-0"
                    }), (0, w.jsx)("div", {
                        children: t
                    })]
                })
            }

            function rH(e) {
                var t, n;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : t.command) === "quote" || (null === (n = e.metadata) || void 0 === n ? void 0 : n.command) === "quote_full"
            }
            var rW = _.memo(function(e) {
                var t, n = e.message,
                    r = e.isCollapsed,
                    a = null === (t = n.message.metadata) || void 0 === t ? void 0 : t.aggregate_result;
                if (!a) return console.error("Corrupt code execution result message"), null;
                var i = a.messages.filter(rJ),
                    o = r && i.length > 0,
                    s = r && null != a.final_expression_output,
                    l = r && null != a.in_kernel_exception,
                    u = !r && a.messages.filter(r$).length > 0;
                return (0, w.jsxs)(w.Fragment, {
                    children: [o && (0, w.jsx)(rV, {
                        label: "STDOUT/STDERR",
                        output: i.map(function(e, t) {
                            return (0, w.jsx)("span", {
                                className: "stderr" === e.stream_name ? "text-red-500" : "",
                                children: e.text
                            }, "".concat(t))
                        })
                    }), s && (0, w.jsx)(rV, {
                        label: "RESULT",
                        output: a.final_expression_output
                    }), l && (0, w.jsx)("div", {
                        className: "overflow-auto rounded border-t border-gray-500 bg-black text-white",
                        children: (0, w.jsx)("div", {
                            className: "border-l-4 border-red-500 p-2 text-xs",
                            children: (0, w.jsx)("div", {
                                className: "scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-700 flex max-h-64 flex-col-reverse",
                                children: (0, w.jsx)("pre", {
                                    className: "shrink-0",
                                    children: a.in_kernel_exception.traceback.join("")
                                })
                            })
                        })
                    }), u && a.messages.filter(r$).map(function(e, t) {
                        return (0, w.jsx)("div", {
                            className: "empty:hidden",
                            children: (0, w.jsx)(rY, {
                                jupyterMessage: e
                            })
                        }, t)
                    })]
                })
            });

            function rV(e) {
                var t = e.label,
                    n = e.output;
                return (0, w.jsxs)("div", {
                    className: "rounded-md bg-black p-4 text-xs",
                    children: [(0, w.jsx)("div", {
                        className: "mb-1 text-gray-400",
                        children: t
                    }), (0, w.jsx)("div", {
                        className: "scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-700 prose flex max-h-64 flex-col-reverse overflow-auto text-white",
                        children: (0, w.jsx)("pre", {
                            className: "shrink-0",
                            children: n
                        })
                    })]
                })
            }
            var rQ = Math.log(151) / Math.log(1.5);

            function rG(e) {
                var t = e.fileId,
                    n = (0, j._)((0, _.useState)(""), 2),
                    r = n[0],
                    a = n[1];
                return (0, ng.a)({
                    queryKey: ["getFileDownloadLink", t],
                    queryFn: function() {
                        return P.ZP.getFileDownloadLink(t).then(function(e) {
                            return (null == e ? void 0 : e.status) === "success" && a(e.download_url), e
                        })
                    },
                    refetchInterval: function(e, t) {
                        var n = t.state.dataUpdateCount;
                        return (null == e ? void 0 : e.status) !== "success" && !(n > rQ) && "error" !== t.state.status && 100 * Math.pow(1.5, n)
                    }
                }), (0, w.jsxs)(w.Fragment, {
                    children: [" ", r && (0, w.jsx)("img", {
                        src: r
                    }), " "]
                })
            }

            function r$(e) {
                return "image" === e.message_type || "image_url" in e && (0, ts.$H)(e.image_url + "")
            }

            function rY(e) {
                var t = e.jupyterMessage;
                if ((0, _.useContext)(A.gB)) return (0, w.jsxs)("div", {
                    className: "flex h-52 w-full max-w-xs flex-col items-center justify-center gap-2 rounded-md border-black/5 bg-gray-100 p-7 text-center text-gray-500 dark:border-white/10",
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: M.LFN,
                        size: "medium"
                    }), (0, w.jsx)(T.Z, (0, b._)({}, rK.imageNotSupported))]
                });
                if (null != t.image_payload) return (0, w.jsx)("img", {
                    src: "data:image/png;base64,".concat(t.image_payload)
                });
                if (null != t.image_url) {
                    var n = (0, ts.Iy)(t.image_url);
                    return (0, w.jsx)(rG, {
                        fileId: n
                    })
                }
                return null
            }

            function rJ(e) {
                return "stream" === e.message_type
            }
            var rK = (0, N.vU)({
                    imageNotSupported: {
                        id: "CodeExecutionOutputMessage.imageNotSupported",
                        defaultMessage: "Image output is not supported in a shared chat",
                        description: "Message shown when an image is output in a shared thread"
                    }
                }),
                rX = n(67576),
                r0 = {},
                r1 = {};

            function r2(e) {
                var t = e.message,
                    n = e.outputMessage,
                    r = e.clientThreadId,
                    a = e.isComplete,
                    i = (0, tv.F)().theme;
                (0, _.useEffect)(function() {
                    r0[t.message.id] || (es.o.logEvent(el.a.renderTool2Message, {
                        id: t.message.id,
                        finishedExecuting: a
                    }), r0[t.message.id] = !0)
                }, [t, a]);
                var o = (0, _.useCallback)(function() {
                        r1[t.message.id] || (es.o.logEvent(el.a.expandTool2Message, {
                            id: t.message.id,
                            finishedExecuting: a
                        }), r1[t.message.id] = !0)
                    }, [t, a]),
                    s = (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsx)("div", {
                            className: "mt-3 self-stretch",
                            children: (0, w.jsx)(rX.Z, {
                                clientThreadId: r,
                                messageId: t.message.id,
                                className: (0, G.Z)("markdown prose w-full break-words dark:prose-invert", "dark" === i ? "dark" : "light"),
                                children: function(e) {
                                    var t = function(e, t) {
                                        return "```".concat(t, "\n").concat(e, "\n```")
                                    };
                                    if ("code" === e.message.content.content_type) return t(e.message.content.text, "python");
                                    if ("python" === e.message.recipient) {
                                        if ("text" !== e.message.content.content_type) throw Error("Unexpected content type for code message");
                                        var n = e.message.content.parts;
                                        if (1 !== n.length || "string" != typeof n[0]) throw Error("Unexpected parts for code message");
                                        return t(n[0], "python")
                                    }
                                    throw Error("Unexpected code message format")
                                }(t)
                            })
                        }), n && (0, w.jsx)("div", {
                            className: "self-stretch",
                            children: (0, w.jsx)(rW, {
                                message: n,
                                isCollapsed: !0
                            })
                        })]
                    });
                return (0, w.jsx)(rN, {
                    expanderClosedLabel: "Show work",
                    expanderOpenLabel: "Hide work",
                    isComplete: a,
                    results: s,
                    onExpand: o,
                    children: a ? "Finished working" : "Working..."
                })
            }
            var r3 = n(31541);

            function r5(e) {
                var t = e.messages,
                    n = e.clientThreadId,
                    r = e.isCompletionInProgress,
                    a = e.isCompletion,
                    i = e.onRequestMoreCompletions,
                    o = (0, _.useMemo)(function() {
                        return [t.reduce(function(e, t) {
                            return null == t.err ? e + (0, tT.RR)(t.message) : e
                        }, "")]
                    }, [t]);
                return (0, w.jsx)(r3.Cf, {
                    clientThreadId: n,
                    parts: o,
                    format: !0,
                    isCompletion: a,
                    isCompletionInProgress: r,
                    id: "",
                    onRequestMoreCompletions: i
                })
            }
            var r4 = n(20485);

            function r8(e) {
                return (0, tT.qi)(e) && !(0, tT.oH)(e)
            }(i = g || (g = {})).Planning = "planning", i.Running = "running", i.Done = "done", i.Stopped = "stopped";
            var r7 = _.memo(function(e) {
                var t, n = e.messages,
                    r = (0, j._)(n, 2),
                    a = r[0],
                    i = r[1],
                    o = function(e, t) {
                        if (r8(e.message)) return {
                            status: g.Stopped,
                            numTotalSubAgents: 0,
                            numCompletedSubAgents: 0
                        };
                        var n, r, a = null === (n = null == t ? void 0 : t.message.metadata) || void 0 === n ? void 0 : null === (r = n.parallel_browse) || void 0 === r ? void 0 : r.frontend_info.sub_agent_infos;
                        if (null == a) return {
                            status: g.Planning,
                            numTotalSubAgents: 0,
                            numCompletedSubAgents: 0
                        };
                        var i = r9(a),
                            o = i.length,
                            s = i.filter(ae).length;
                        return {
                            status: s === o ? g.Done : g.Running,
                            numTotalSubAgents: o,
                            numCompletedSubAgents: s
                        }
                    }(a, i);
                switch (o.status) {
                    case g.Planning:
                        t = at.planning;
                        break;
                    case g.Running:
                        t = at.running;
                        break;
                    case g.Done:
                        t = at.done;
                        break;
                    case g.Stopped:
                        t = at.stopped
                }
                return (0, w.jsx)(rN, {
                    isComplete: o.status === g.Done || o.status === g.Stopped,
                    results: null != i ? (0, w.jsx)(rI, {
                        children: (0, w.jsx)(r6, {
                            toolMessage: i
                        })
                    }) : void 0,
                    children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, t), {
                        values: {
                            numCompleted: o.numCompletedSubAgents,
                            numTotal: o.numTotalSubAgents
                        }
                    }))
                })
            });

            function r6(e) {
                var t, n, r = null === (t = e.toolMessage.message.metadata) || void 0 === t ? void 0 : null === (n = t.parallel_browse) || void 0 === n ? void 0 : n.frontend_info.sub_agent_infos;
                if (null == r) return null;
                var a = r9(r).map(function(e, t) {
                    return (0, w.jsxs)("div", {
                        children: [(0, w.jsx)("div", {
                            className: "font-bold",
                            children: (0, w.jsx)(T.Z, (0, b._)({}, function(e) {
                                switch (e) {
                                    case tH.RF.Running:
                                        return at.subAgentRunning;
                                    case tH.RF.Done:
                                        return at.subAgentDone;
                                    case tH.RF.Timeout:
                                    case tH.RF.Error:
                                        return at.subAgentFailed;
                                    case tH.RF.Starting:
                                    default:
                                        return at.subAgentStarting
                                }
                            }(e.status)))
                        }), (0, w.jsx)("div", {
                            children: e.task_instruction
                        })]
                    }, t)
                });
                return (0, w.jsx)("div", {
                    className: "flex flex-col gap-4",
                    children: a
                })
            }

            function r9(e) {
                return Object.values(Object.values(e).reduce(function(e, t) {
                    var n = t.task_index;
                    return null == e[n] && (e[n] = []), e[n].push(t), e
                }, {})).map(function(e) {
                    return (0, V._)((0, b._)({}, e[0]), {
                        status: function(e) {
                            var t = e.map(function(e) {
                                    return e.status
                                }),
                                n = [tH.RF.Starting, tH.RF.Running, tH.RF.Done, tH.RF.Error, tH.RF.Timeout],
                                r = !0,
                                a = !1,
                                i = void 0;
                            try {
                                for (var o, s = n[Symbol.iterator](); !(r = (o = s.next()).done); r = !0) {
                                    var l = function() {
                                        var e = o.value;
                                        if (t.some(function(t) {
                                                return t === e
                                            })) return {
                                            v: e
                                        }
                                    }();
                                    if ("object" === (0, r4._)(l)) return l.v
                                }
                            } catch (e) {
                                a = !0, i = e
                            } finally {
                                try {
                                    r || null == s.return || s.return()
                                } finally {
                                    if (a) throw i
                                }
                            }
                            return tH.RF.Starting
                        }(e)
                    })
                }).sort(function(e, t) {
                    return e.task_index - t.task_index
                })
            }

            function ae(e) {
                return e.status === tH.RF.Done || e.status === tH.RF.Timeout || e.status === tH.RF.Error
            }
            var at = (0, N.vU)({
                    planning: {
                        id: "parallelBrowsingMessage.planning",
                        defaultMessage: "Creating a browsing plan...",
                        description: "Status message when browsing is being planned"
                    },
                    running: {
                        id: "parallelBrowsingMessage.running",
                        defaultMessage: "Executing browsing plan ({numCompleted}/{numTotal})",
                        description: "Status message when browsing is in progress"
                    },
                    done: {
                        id: "parallelBrowsingMessage.done",
                        defaultMessage: "Finished browsing",
                        description: "Status message when browsing is finished"
                    },
                    stopped: {
                        id: "parallelBrowsingMessage.stopped",
                        defaultMessage: "Stopped browsing",
                        description: "Status message when browsing was stopped"
                    },
                    subAgentStarting: {
                        id: "parallelBrowsingMessage.subAgent.starting",
                        defaultMessage: "Waiting to start",
                        description: "Status when a browsing task is waiting to start"
                    },
                    subAgentRunning: {
                        id: "parallelBrowsingMessage.subAgent.running",
                        defaultMessage: "In progress",
                        description: "Status when a browsing task is in progress"
                    },
                    subAgentDone: {
                        id: "parallelBrowsingMessage.subAgent.done",
                        defaultMessage: "Completed",
                        description: "Status when a browsing task is complete"
                    },
                    subAgentFailed: {
                        id: "parallelBrowsingMessage.subAgent.failed",
                        defaultMessage: "Could not complete",
                        description: "Status when a browsing task failed to complete"
                    }
                }),
                an = n(66570),
                ar = n(40803);

            function aa() {
                var e = (0, Q._)(["grid gap-4\n", ""]);
                return aa = function() {
                    return e
                }, e
            }
            var ai = (0, N.vU)({
                generatedImage: {
                    id: "pluginDisplayParams.generatedImage",
                    defaultMessage: "Generated by plugin",
                    description: "Description text for an image that was generated by a plugin"
                }
            });

            function ao(e) {
                var t, n, r, a = e.plugin,
                    i = e.pluginMessage,
                    o = e.toolMessage;
                if ("plugin-bd1fbb6d-40f9-4159-8da9-7a8975c5793b" !== a.id) return null;
                var s = !1,
                    l = h.SQUARE;
                if ("text" === i.content.content_type) try {
                    var u = function(e) {
                            var t = !0,
                                n = !1,
                                r = void 0;
                            try {
                                for (var a, i = ["", "}", '"}', "]}", '"]}'][Symbol.iterator](); !(t = (a = i.next()).done); t = !0) {
                                    var o = a.value,
                                        s = e.trimEnd().endsWith(",") ? e.trimEnd().slice(0, -1) : e;
                                    try {
                                        return {
                                            result: JSON.parse(s + o),
                                            isComplete: "" === o
                                        }
                                    } catch (e) {}
                                }
                            } catch (e) {
                                n = !0, r = e
                            } finally {
                                try {
                                    t || null == i.return || i.return()
                                } finally {
                                    if (n) throw r
                                }
                            }
                            return {
                                result: JSON.parse(e),
                                isComplete: !1
                            }
                        }(i.content.parts[0]),
                        d = u.result,
                        c = u.isComplete;
                    t = d, s = c, (null == t ? void 0 : t.image_shape) != null && (l = t.image_shape)
                } catch (e) {}
                var f = !1;
                if (null != o) {
                    if ("text" === o.content.content_type) {
                        try {
                            n = JSON.parse(o.content.parts[0])
                        } catch (e) {}
                        if ((null == n ? void 0 : n.images) != null) return (0, w.jsx)(al, {
                            imageUrls: n.images,
                            gridItemShape: l
                        })
                    }
                    f = !0
                }
                return (null == t ? void 0 : t.prompts) != null ? (0, w.jsx)(as, {
                    numItems: null !== (r = null == t ? void 0 : t.n) && void 0 !== r ? r : Math.max(t.prompts.length, 1),
                    prompts: t.prompts,
                    gridItemShape: l,
                    isPromptListComplete: null != s && s,
                    showErrorState: f || r8(i)
                }) : null
            }

            function as(e) {
                for (var t = e.numItems, n = e.prompts, r = e.gridItemShape, a = e.isPromptListComplete, i = e.showErrorState, o = [], s = 0; s < t; s++) {
                    var l = n[s],
                        u = s < n.length - 1 || a || i;
                    o.push((0, w.jsx)(au, {
                        className: (0, G.Z)("text-sm", i && "text-gray-500"),
                        shape: r,
                        bgColor: i ? "medium" : null == l ? "dark" : "light",
                        children: (0, w.jsx)(ar.default, {
                            className: "hide-scrollbar h-full",
                            followButtonClassName: "hidden",
                            children: (0, w.jsxs)("div", {
                                className: "flex min-h-full flex-col justify-between gap-3 px-4 pb-5",
                                children: [null != l && (0, w.jsx)("div", {
                                    className: (0, G.Z)("pt-4", !u && "result-streaming"),
                                    children: (0, w.jsx)("span", {
                                        children: l
                                    })
                                }), u && !i && (0, w.jsx)(em.Z, {
                                    className: "h-4 w-4 self-center"
                                }), i && (0, w.jsx)(eh.ZP, {
                                    icon: M.bcx,
                                    className: "self-center text-gray-400"
                                })]
                            })
                        })
                    }, s))
                }
                return (0, w.jsx)(ac, {
                    $numItems: t,
                    children: o
                })
            }

            function al(e) {
                var t = e.imageUrls,
                    n = e.gridItemShape,
                    r = t.map(function(e, t) {
                        return (0, w.jsx)(ad, {
                            imageUrl: e,
                            shape: n
                        }, t)
                    });
                return (0, w.jsx)(ac, {
                    $numItems: r.length,
                    children: r
                })
            }

            function au(e) {
                var t = e.children,
                    n = e.shape,
                    r = e.className,
                    a = e.bgColor,
                    i = void 0 === a ? "light" : a;
                return (0, w.jsxs)("div", {
                    className: (0, G.Z)("relative overflow-hidden rounded", r, n === h.WIDE && "aspect-[7/4]", n === h.SQUARE && "aspect-square max-w-[400px]", n === h.TALL && "aspect-[4/7] max-w-xs"),
                    children: [(0, w.jsx)("div", {
                        className: (0, G.Z)("pointer-events-none absolute inset-0 blur-xl", "light" === i && "bg-black/[.04]", "medium" === i && "bg-black/[.08]", "dark" === i && "bg-black/[.12]")
                    }), t]
                })
            }

            function ad(e) {
                var t = e.imageUrl,
                    n = e.shape,
                    r = (0, ei.Z)();
                return (0, w.jsx)(au, {
                    shape: n,
                    children: (0, w.jsx)("a", {
                        href: t,
                        target: "_blank",
                        rel: "noreferrer",
                        children: (0, w.jsx)("img", {
                            src: t,
                            alt: r.formatMessage(ai.generatedImage)
                        })
                    })
                })
            }(o = h || (h = {})).WIDE = "wide", o.SQUARE = "square", o.TALL = "tall";
            var ac = eo.Z.div(aa(), function(e) {
                return 1 === e.$numItems ? "grid-cols-1" : "grid-cols-2"
            });

            function af() {
                var e = (0, Q._)(["flex h-[18px] w-[18px] items-center justify-center rounded-[5px] bg-red-200 text-red-800"]);
                return af = function() {
                    return e
                }, e
            }

            function ag() {
                var e = (0, Q._)(["flex items-center gap-1 rounded-[5px] bg-red-200 py-0.5 px-1.5 text-xs font-medium uppercase text-red-800"]);
                return ag = function() {
                    return e
                }, e
            }
            var ah = eo.Z.div(af());

            function am() {
                return (0, w.jsx)(ah, {
                    children: (0, w.jsx)(eh.ZP, {
                        icon: M.OH,
                        className: "h-3 w-3",
                        strokeWidth: 2.5
                    })
                })
            }

            function ap() {
                return (0, w.jsx)(ah, {
                    children: (0, w.jsx)(eh.ZP, {
                        icon: M.V7f,
                        className: "h-3 w-3"
                    })
                })
            }
            var av = eo.Z.div(ag());

            function ax() {
                return (0, w.jsxs)(av, {
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: M.OH,
                        className: "h-3 w-3",
                        strokeWidth: 2.5
                    }), (0, w.jsx)("div", {
                        children: "Unverified"
                    })]
                })
            }

            function ab() {
                return (0, w.jsxs)(av, {
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: M.V7f,
                        className: "h-3 w-3"
                    }), (0, w.jsx)("div", {
                        children: "Localhost"
                    })]
                })
            }
            var ay = n(28531),
                aj = _.memo(function(e) {
                    var t, n = e.messages,
                        r = (0, j._)(n, 2),
                        a = r[0],
                        i = r[1],
                        o = (0, ay.v)(),
                        s = (0, tT.fj)(a.message.recipient),
                        l = o.find(function(e) {
                            return e.namespace === (null == s ? void 0 : s.pluginNamespace)
                        }),
                        u = null == l ? void 0 : l.manifest.name_for_human,
                        d = r8(a.message),
                        c = null != u ? (0, w.jsx)("b", {
                            children: u
                        }) : "unknown plugin",
                        f = null != i ? (0, w.jsxs)("div", {
                            children: ["Used ", c]
                        }) : d ? (0, w.jsxs)("div", {
                            children: ["Tried to use ", c]
                        }) : (0, w.jsxs)("div", {
                            children: ["Using ", c, "..."]
                        });
                    return l && (tQ(l) ? t = (0, w.jsx)(ab, {}) : "approved" !== l.status && (t = (0, w.jsx)(ax, {}))), (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsx)(rN, {
                            isComplete: null != i || d,
                            results: (0, w.jsx)(aw, {
                                pluginName: null != u ? u : "unknown plugin",
                                pluginMessage: a,
                                toolMessage: i
                            }),
                            children: (0, w.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [f, t]
                            })
                        }), null != l && (0, w.jsx)(ao, {
                            plugin: l,
                            pluginMessage: a.message,
                            toolMessage: null == i ? void 0 : i.message
                        })]
                    })
                });

            function aw(e) {
                var t = e.pluginName,
                    n = e.pluginMessage,
                    r = e.toolMessage,
                    a = (0, tT.RR)(n.message),
                    i = r ? (0, tT.RR)(r.message) : null;
                try {
                    a = JSON.stringify(JSON.parse(a), null, 2), null != i && (i = JSON.stringify(JSON.parse(i), null, 2))
                } catch (e) {}
                var o = (null == r ? void 0 : r.message.author.name) === "plugin_service";
                return (0, w.jsxs)("div", {
                    className: "my-3 flex max-w-full flex-col gap-3",
                    children: [(0, w.jsx)(aC, {
                        title: "Request to ".concat(t),
                        infoTooltip: n.message.recipient,
                        children: a
                    }), null != i && (0, w.jsx)(aC, {
                        title: o ? "Error" : "Response from ".concat(t),
                        infoTooltip: n.message.recipient,
                        children: (0, w.jsx)("span", {
                            className: (0, G.Z)(o && "text-red-500"),
                            children: i
                        })
                    })]
                })
            }

            function aC(e) {
                var t = e.title,
                    n = e.infoTooltip,
                    r = e.children;
                return (0, w.jsx)(an.$, {
                    title: (0, w.jsx)("span", {
                        className: "uppercase",
                        children: t
                    }),
                    headerDecoration: void 0 !== n ? (0, w.jsx)(ti.u, {
                        label: n,
                        children: (0, w.jsx)(eh.ZP, {
                            icon: M.H33,
                            className: "text-white/50"
                        })
                    }) : void 0,
                    shouldWrapCode: !0,
                    className: "w-full text-xs text-white/80",
                    children: r
                })
            }
            var ak = n(63857),
                a_ = n(42569);

            function aM() {
                var e = (0, Q._)([""]);
                return aM = function() {
                    return e
                }, e
            }

            function aT() {
                var e = (0, Q._)(["flex flex-grow flex-col gap-3"]);
                return aT = function() {
                    return e
                }, e
            }

            function aN() {
                var e = (0, Q._)(["flex p-4 gap-4 ", "\n  ", ""]);
                return aN = function() {
                    return e
                }, e
            }

            function aP() {
                var e = (0, Q._)(["flex-shrink-0 flex flex-col relative items-end"]);
                return aP = function() {
                    return e
                }, e
            }

            function aS() {
                var e = (0, Q._)(["p-1 ", ""]);
                return aS = function() {
                    return e
                }, e
            }

            function aI() {
                var e = (0, Q._)(["text-gray-400 flex self-end lg:self-center justify-center mt-2 gap-2 md:gap-3 lg:gap-1 lg:absolute lg:top-0 lg:translate-x-full lg:right-0 lg:mt-0 lg:pl-2\n", ""]);
                return aI = function() {
                    return e
                }, e
            }

            function aZ() {
                var e = (0, Q._)(["text-center border-b p-3 text-gray-500 dark:border-black/20 dark:text-gray-400 text-xs"]);
                return aZ = function() {
                    return e
                }, e
            }
            var aF = ["#7989FF"];
            (s = m || (m = {}))[s.Text = 0] = "Text", s[s.MultiText = 1] = "MultiText", s[s.Browsing = 2] = "Browsing", s[s.Code = 3] = "Code", s[s.CodeExecutionOutput = 4] = "CodeExecutionOutput", s[s.Plugin = 5] = "Plugin", s[s.RetrievalBrowsing = 6] = "RetrievalBrowsing", s[s.ParallelBrowsing = 7] = "ParallelBrowsing";
            var aD = "#19c37d",
                aE = "openai",
                aR = "#1a7f64",
                aB = _.memo(function(e) {
                    var t, n, r, a = e.turnIndex,
                        i = e.conversationLeafId,
                        o = e.isFinalTurn,
                        s = e.clientThreadId,
                        l = e.onChangeItemInView,
                        u = e.onChangeRating,
                        d = e.onRequestMoreCompletions,
                        c = e.onDeleteNode,
                        f = e.onRequestCompletion,
                        g = e.onUpdateNode,
                        h = e.activeRequests,
                        p = e.showInlineEmbeddedDisplay,
                        v = void 0 !== p && p,
                        x = e.currentModelId,
                        b = e.initiallyHighlightedMessageId,
                        y = e.avatarColor,
                        C = (0, _.useContext)(A.gB),
                        k = (0, B.ec)(B.F_.isBusinessWorkspace),
                        T = (0, S.GD)(s, a, i),
                        N = T.role,
                        P = T.messages,
                        I = T.variantIds,
                        Z = (0, U.x_)(),
                        F = (0, j._)((0, _.useState)(!1), 2),
                        D = F[0],
                        E = F[1],
                        L = (0, _.useMemo)(function() {
                            return I.findIndex(function(e) {
                                return e === P[0].nodeId
                            })
                        }, [I, P]),
                        O = N !== tH.uU.User,
                        q = (0, _.useContext)(A.QL).historyDisabled,
                        z = (0, B.hz)().has(eu.FZ),
                        H = (0, tb.Fl)(),
                        W = H.isBrowsingAvailable,
                        V = H.isPluginsAvailable,
                        Q = H.isCodeInterpreterAvailable,
                        $ = (0, R.tN)(function(e) {
                            return e.isDesktopNavCollapsed
                        }),
                        Y = P.some(function(e) {
                            return e.message.content.content_type === tH.PX.MultimodalText
                        }),
                        J = W || V || Q,
                        K = (0, _.useRef)(null);
                    (0, _.useEffect)(function() {
                        var e;
                        null != b && T.messages.map(function(e) {
                            return e.message.id
                        }).includes(b) && (null === (e = K.current) || void 0 === e || e.scrollIntoView({
                            behavior: "auto"
                        }))
                    }, [b]);
                    var X = P[P.length - 1],
                        ee = X.rating,
                        et = (0, ay.v)(),
                        en = (0, _.useMemo)(function() {
                            return O && (null == P ? void 0 : P[0]) != null && (0, tT.Rc)(P[0].message) || x
                        }, [O, P, x]),
                        er = (0, _.useCallback)(function() {
                            if (1 === P.length) {
                                var e = N === tH.uU.User ? el.a.editPrompt : el.a.editCompletion;
                                es.o.logEvent(e, {
                                    id: P[0].message.id,
                                    threadId: S.tQ.getServerThreadId(s)
                                }), E(!0)
                            }
                        }, [P, N, s]),
                        ea = (0, _.useCallback)(function() {
                            E(!1)
                        }, []),
                        ei = (0, _.useCallback)(function() {
                            S.tQ.copyMessageToClipboard(s, a)
                        }, [s, a]),
                        eo = (0, _.useCallback)(function(e) {
                            u(X.nodeId, X.message.id, e)
                        }, [X, u]),
                        ed = (0, j._)((0, _.useState)(function() {
                            return Date.now()
                        }), 1)[0],
                        ec = (0, _.useMemo)(function() {
                            return rh.Cv.getRequestIdFromConversationTurn(T)
                        }, [T]),
                        ef = (0, _.useMemo)(function() {
                            return h.has(ec)
                        }, [h, ec]),
                        eg = (0, _.useMemo)(function() {
                            var e = !0,
                                t = !1,
                                n = void 0;
                            try {
                                for (var r, a = P[Symbol.iterator](); !(e = (r = a.next()).done); e = !0) {
                                    var i = r.value;
                                    if (i.errType) return i.errType
                                }
                            } catch (e) {
                                t = !0, n = e
                            } finally {
                                try {
                                    e || null == a.return || a.return()
                                } finally {
                                    if (t) throw n
                                }
                            }
                            return !1
                        }, [P]),
                        em = (0, _.useMemo)(function() {
                            if (O) {
                                var e, t, n = S.tQ.getTree(s),
                                    r = null === (e = n.getParentPromptNode(P[0].nodeId)) || void 0 === e ? void 0 : e.parentId,
                                    a = r && (null === (t = n.getNode(r).message.metadata) || void 0 === t ? void 0 : t.model_slug);
                                if (en && a && en !== a) return a_.n2.has(a) ? "The previous model used in this conversation has been deprecated. We've switched you to the latest default model." : "The previous model used in this conversation is unavailable. We've switched you to the latest default model."
                            }
                            return null
                        }, [en, O, P, s]),
                        ep = (0, _.useMemo)(function() {
                            if (!J) return {
                                avatarIcon: aE,
                                avatarColor: aD
                            };
                            if (ef && P.length > 0) {
                                var e = P[P.length - 1],
                                    t = (0, tT.rH)(e.message);
                                switch (t) {
                                    case tT.Cs.Text:
                                        if ((0, tT.RR)(e.message).length > 0 || P.length > 1) return {
                                            avatarIcon: "text",
                                            avatarColor: aR
                                        };
                                        break;
                                    case tT.Cs.Browsing:
                                    case tT.Cs.BrowseTool:
                                        return {
                                            avatarIcon: "browsing",
                                            avatarColor: aR
                                        };
                                    case tT.Cs.Code:
                                    case tT.Cs.CodeExecutionOutput:
                                        return {
                                            avatarIcon: "code",
                                            avatarColor: aR
                                        };
                                    case tT.Cs.Plugin:
                                    case tT.Cs.PluginTool:
                                        var n = (0, tT.fj)(t === tT.Cs.Plugin ? e.message.recipient : e.message.author.name),
                                            r = et.find(function(e) {
                                                return e.namespace === (null == n ? void 0 : n.pluginNamespace)
                                            });
                                        if (r) return {
                                            avatarPlugin: r
                                        };
                                        return {
                                            avatarIcon: "plugin",
                                            avatarColor: aR
                                        }
                                }
                            }
                            return {
                                avatarIcon: aE,
                                avatarColor: aD
                            }
                        }, [J, ef, P, et]),
                        ev = ep.avatarIcon,
                        ex = ep.avatarColor,
                        eb = ep.avatarPlugin,
                        ey = (0, _.useCallback)(function(e, t, n, r) {
                            S.tQ.updateTree(s, function(a) {
                                var i = a.getParentId(e);
                                a.addNode(t, n, i, tH.Jq.Prompt, void 0, r)
                            })
                        }, [s]),
                        ej = (0, _.useMemo)(function() {
                            var e = [];
                            return P.forEach(function(t, n) {
                                var r = (0, tT.rH)(t.message),
                                    a = null == P ? void 0 : P[n - 1],
                                    i = null != a && ((0, tT.lD)(a.message) || (0, tT.qs)(t.message)),
                                    o = r === tT.Cs.Text && (0, tT.RR)(t.message);
                                if (r === tT.Cs.Browsing || r === tT.Cs.BrowseTool) {
                                    var s = e[e.length - 1];
                                    (null == s ? void 0 : s.type) === m.Browsing ? s.messages.push(t) : e.push({
                                        type: m.Browsing,
                                        messages: [t]
                                    })
                                } else if (r === tT.Cs.RetrievalBrowsing || r === tT.Cs.RetrievalBrowsingTool) {
                                    var l = e[e.length - 1];
                                    (null == l ? void 0 : l.type) === m.RetrievalBrowsing ? l.messages.push(t) : e.push({
                                        type: m.RetrievalBrowsing,
                                        messages: [t]
                                    })
                                } else if (r === tT.Cs.ParallelBrowsing || r === tT.Cs.ParallelBrowsingTool) {
                                    var u = e[e.length - 1];
                                    (null == u ? void 0 : u.type) === m.ParallelBrowsing ? u.messages.push(t) : e.push({
                                        type: m.ParallelBrowsing,
                                        messages: [t]
                                    })
                                } else if (r === tT.Cs.Plugin || r === tT.Cs.PluginTool) {
                                    var d = e[e.length - 1];
                                    r === tT.Cs.PluginTool && (null == d ? void 0 : d.type) === m.Plugin ? d.messages.push(t) : e.push({
                                        type: m.Plugin,
                                        messages: [t]
                                    })
                                } else if (r === tT.Cs.Code) e.push({
                                    type: m.Code,
                                    message: t
                                });
                                else if (r === tT.Cs.CodeExecutionOutput) e.push({
                                    type: m.CodeExecutionOutput,
                                    message: t
                                });
                                else if (i && null != o) {
                                    var c = e.pop();
                                    (null == c ? void 0 : c.type) === m.MultiText ? (c.messages.push(t), e.push(c)) : (null == c ? void 0 : c.type) === m.Text && e.push({
                                        type: m.MultiText,
                                        messages: [c.message, t]
                                    })
                                } else e.push({
                                    type: m.Text,
                                    message: t
                                })
                            }), e.map(function(t, n) {
                                var r, a = n === e.length - 1;
                                switch (t.type) {
                                    case m.Text:
                                        return (0, w.jsx)(r3.ZP, {
                                            className: "min-h-[20px]",
                                            message: t.message,
                                            isEditing: D,
                                            format: O,
                                            isCompletionInProgress: a && ef,
                                            onCreateEditNode: ey,
                                            clientThreadId: s,
                                            onUpdateNode: g,
                                            onDeleteNode: c,
                                            onChangeItemInView: l,
                                            onRequestCompletion: f,
                                            onExitEdit: ea,
                                            disabled: 0 !== h.size,
                                            isCompletion: O,
                                            onRequestMoreCompletions: d,
                                            isResponseToPluginMessage: (null === (r = e[n - 1]) || void 0 === r ? void 0 : r.type) === m.Plugin
                                        }, t.message.nodeId);
                                    case m.MultiText:
                                        return (0, w.jsx)(r5, {
                                            clientThreadId: s,
                                            messages: t.messages,
                                            isCompletionInProgress: a && ef,
                                            isCompletion: O,
                                            onRequestMoreCompletions: d
                                        }, n);
                                    case m.Browsing:
                                    case m.RetrievalBrowsing:
                                        var i = t.messages[t.messages.length - 1];
                                        return (0, w.jsx)(rF, {
                                            messages: t.messages,
                                            isComplete: !o || !a || 0 === h.size || r8(i.message),
                                            isRetrieval: t.type === m.RetrievalBrowsing
                                        }, t.messages[0].nodeId);
                                    case m.ParallelBrowsing:
                                        return (0, w.jsx)(r7, {
                                            messages: t.messages
                                        }, t.messages[0].nodeId);
                                    case m.Code:
                                        var u, p, v = e[n + 1],
                                            x = v && v.type === m.CodeExecutionOutput ? v.message : void 0;
                                        return (0, w.jsx)(r2, {
                                            clientThreadId: s,
                                            message: t.message,
                                            outputMessage: x,
                                            isComplete: !o || !a || 0 === h.size || (null == (p = null === (u = null == x ? void 0 : x.message.metadata) || void 0 === u ? void 0 : u.aggregate_result) ? void 0 : p.status) !== void 0 && (null == p ? void 0 : p.status) !== "running" || r8(t.message.message)
                                        }, t.message.nodeId);
                                    case m.CodeExecutionOutput:
                                        return (0, w.jsx)(rW, {
                                            message: t.message,
                                            isCollapsed: !1
                                        }, t.message.nodeId);
                                    case m.Plugin:
                                        return (0, w.jsx)(aj, {
                                            messages: t.messages
                                        }, t.messages[0].nodeId);
                                    default:
                                        return null
                                }
                            })
                        }, [P, D, O, ef, ey, s, g, c, l, f, ea, h.size, d, o]),
                        ew = (0, S.r7)(s),
                        eC = !k && !C && !ew && !q && Z && O && !ef && !v && !D && 1 === L && o && !X.inlineComparisonRating && !ee && 2 === I.length && Date.now() - (null !== (r = X.message.create_time) && void 0 !== r ? r : 0) * 1e3 < 6e5,
                        ek = O && !v && !C && !ew,
                        e_ = !C && !v && !D,
                        eM = !O && !v && !C && !Y && 1 === P.length && !D,
                        eT = function(e) {
                            l(I[e]), es.o.logEvent(el.a.changeNode, {
                                intent: "toggle_between"
                            })
                        };
                    if (T.role === tH.uU.Unknown || T.role === tH.uU.System) return null;
                    var eN = eM ? (0, w.jsx)(aq, {
                            $isMessageRedesign: z,
                            onClick: er,
                            className: (0, G.Z)(!z && Z && "md:invisible md:group-hover:visible"),
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.vPQ
                            })
                        }) : null,
                        eP = O && !v ? (0, w.jsx)(tN.Z, {
                            onCopy: ei,
                            className: (0, G.Z)("rounded-md p-1", z ? "text-gray-500 hover:text-gray-700 dark:hover:text-gray-400" : "hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200 disabled:dark:hover:text-gray-400")
                        }) : null,
                        eS = ek && !k ? (0, w.jsxs)("div", {
                            className: "flex gap-1",
                            children: ["thumbsDown" !== ee && !q && (0, w.jsx)(aq, {
                                $isMessageRedesign: z,
                                onClick: function() {
                                    return eo("thumbsUp")
                                },
                                disabled: "thumbsUp" === ee,
                                className: (0, G.Z)("thumbsUp" === ee && (z ? "bg-gray-100 dark:bg-gray-700" : "!dark:text-gray-200 bg-gray-100 text-gray-700 dark:bg-gray-700")),
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M.fmn
                                })
                            }, "thumbsUp:".concat(X.nodeId)), "thumbsUp" !== ee && !q && (0, w.jsx)(aq, {
                                $isMessageRedesign: z,
                                onClick: function() {
                                    return eo("thumbsDown")
                                },
                                disabled: "thumbsDown" === ee,
                                className: (0, G.Z)("thumbsDown" === ee && (z ? "bg-gray-100 dark:bg-gray-700" : "!dark:text-gray-200 bg-gray-100 text-gray-700 dark:bg-gray-700")),
                                children: (0, w.jsx)(eh.ZP, {
                                    icon: M.oLd
                                })
                            }, "thumbsDown:".concat(X.nodeId))]
                        }) : null,
                        eI = eC ? (0, w.jsx)(rb, {
                            clientThreadId: s,
                            messageForRating: X,
                            variantIds: I,
                            conversationTurnMountTime: ed
                        }) : null,
                        eZ = e_ && I.length > 1,
                        eF = function() {
                            return (0, w.jsxs)("div", {
                                className: "flex gap-1",
                                children: [eS, eN, eP]
                            })
                        },
                        eD = null === (n = P[0].message.metadata) || void 0 === n ? void 0 : n.shared_conversation_id,
                        eE = null != eD;
                    return (0, w.jsxs)(aA, {
                        className: (0, G.Z)("group", "w-full text-gray-800 dark:text-gray-100", z ? (0, G.Z)("sm:rounded-2xl", O ? "my-2 hover:bg-gray-50/50 dark:hover:bg-gray-700/50" : "bg-gray-50 hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600") : (0, G.Z)(!v && "border-b border-black/10 dark:border-gray-900/50", O ? "bg-gray-50 dark:bg-[#444654]" : "dark:bg-gray-800")),
                        ref: K,
                        children: [em && (0, w.jsx)(aH, {
                            children: em
                        }), (0, w.jsxs)(aU, {
                            $isStaticSharedThread: C,
                            $isDesktopNavCollapsed: $,
                            $isMessageRedesign: z,
                            className: (0, G.Z)(v ? "ml-5" : "m-auto"),
                            children: [(0, w.jsxs)(aO, {
                                children: [(0, w.jsx)("div", {
                                    className: z ? "" : "w-[30px]",
                                    children: O ? eb ? (0, w.jsx)(e3.Ph, {
                                        plugin: eb,
                                        notice: eg || void 0
                                    }) : (0, w.jsx)(e3.k$, {
                                        background: null != y ? y : ex,
                                        iconName: ev,
                                        notice: eg || void 0
                                    }) : eE || v ? (0, w.jsx)(e3.k$, {
                                        background: aF[(null !== (t = null == eD ? void 0 : eD.charCodeAt(0)) && void 0 !== t ? t : 0) % aF.length],
                                        iconName: "user"
                                    }) : (0, w.jsx)(e3.zf, {
                                        notice: eg || void 0
                                    })
                                }), !z && e_ && Z && (0, w.jsx)(ak.Z, {
                                    currentPage: L,
                                    onChangeIndex: eT,
                                    length: I.length,
                                    className: (0, G.Z)("invisible absolute left-0 top-2 -ml-4 -translate-x-full group-hover:visible", I.length > 1 ? "visible" : "!invisible")
                                })]
                            }), (0, w.jsxs)("div", {
                                className: (0, G.Z)("relative", z ? "min-w-0 grow" : "flex w-[calc(100%-50px)] flex-col gap-1 md:gap-3 lg:w-[calc(100%-115px)]"),
                                children: [z && (0, w.jsx)("div", {
                                    className: "mb-1 select-none text-xs font-medium tracking-wide text-gray-400",
                                    children: O ? "ChatGPT" : eE ? "User" : "You"
                                }), (0, w.jsx)(aL, {
                                    children: ej
                                }), z ? (!Z || eZ || null != eI) && !v && (0, w.jsxs)("div", {
                                    className: "mt-2 flex flex-col gap-4",
                                    children: [(0, w.jsxs)("div", {
                                        className: "flex gap-2 text-gray-400",
                                        children: [eZ && (0, w.jsx)(ak.Z, {
                                            currentPage: L,
                                            onChangeIndex: eT,
                                            length: I.length,
                                            className: "rounded-xl border border-gray-100 bg-white p-1 dark:border-gray-600 dark:bg-gray-700"
                                        }), !Z && eF()]
                                    }), eI]
                                }) : (0, w.jsxs)(w.Fragment, {
                                    children: [eM && Z && (0, w.jsx)(az, {
                                        $hidden: 0 !== h.size,
                                        children: eN
                                    }), (ek || e_) && (0, w.jsxs)("div", {
                                        className: "flex justify-between lg:block",
                                        children: [!Z && e_ && (0, w.jsx)(ak.Z, {
                                            currentPage: L,
                                            onChangeIndex: eT,
                                            length: I.length,
                                            className: (0, G.Z)("self-center pt-2", I.length > 1 ? "visible" : "!invisible")
                                        }), eM && !Z && (0, w.jsx)(az, {
                                            $hidden: ef,
                                            children: eN
                                        }), ek && (0, w.jsxs)(az, {
                                            $hidden: ef,
                                            children: [eP, eS]
                                        }), eC && eI]
                                    })]
                                })]
                            }), z && Z && !D && !v && (!C || O) && (0, w.jsx)("div", {
                                className: "absolute -top-4 right-4 hidden rounded bg-white p-1 shadow-[0_0.5px_2px_rgba(0,0,0,0.15)] group-hover:block dark:bg-gray-900",
                                children: eF()
                            })]
                        })]
                    })
                }),
                aA = eo.Z.div(aM()),
                aL = eo.Z.div(aT()),
                aU = eo.Z.div(aN(), function(e) {
                    return e.$isMessageRedesign ? "relative" : e.$isDesktopNavCollapsed ? "text-base md:gap-6 md:max-w-3xl md:py-6 lg:px-0" : "text-base md:gap-6 md:max-w-2xl lg:max-w-[38rem] xl:max-w-3xl md:py-6 lg:px-0"
                }, function(e) {
                    return e.$isStaticSharedThread ? "pl-0 pr-4" : ""
                }),
                aO = eo.Z.div(aP()),
                aq = eo.Z.button(aS(), function(e) {
                    return e.$isMessageRedesign ? "text-gray-500 enabled:hover:text-gray-700 enabled:dark:hover:text-gray-400 rounded-sm" : "rounded-md hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200 disabled:dark:hover:text-gray-400"
                }),
                az = eo.Z.div(aI(), function(e) {
                    return e.$hidden ? "invisible" : "visible"
                }),
                aH = eo.Z.div(aZ());

            function aW() {
                var e = (0, Q._)(["mb-2 mt-auto ml-auto mr-auto"]);
                return aW = function() {
                    return e
                }, e
            }

            function aV() {
                var e = (0, Q._)(["relative rounded-md border border-black/10 bg-gray-50 dark:border-gray-900/50 dark:bg-[#444654] flex flex-col overflow-hidden"]);
                return aV = function() {
                    return e
                }, e
            }

            function aQ() {
                var e = (0, Q._)(["mb-5 border dark:bg-gray-800 overflow-hidden"]);
                return aQ = function() {
                    return e
                }, e
            }

            function aG() {
                var e = (0, Q._)([""]);
                return aG = function() {
                    return e
                }, e
            }
            var a$ = (0, N.vU)({
                submitFeedback: {
                    id: "feedbackModal.submitFeedback",
                    defaultMessage: "Submit feedback",
                    description: "Button text for submitting the feedback"
                },
                submitReport: {
                    id: "feedbackModal.submitReport",
                    defaultMessage: "Submit report",
                    description: "Button text for submitting a content-moderation report"
                },
                submitRejectModeration: {
                    id: "feedbackModal.moderationReject",
                    defaultMessage: "Block Content",
                    description: "Button text for rejecting the share link and blocking it from being viewed"
                },
                submitAcceptModeration: {
                    id: "feedbackModal.moderationAccept",
                    defaultMessage: "Allow Content",
                    description: "Button text for accepting the share link and allowing it to be viewed"
                },
                thumbsUpPlaceholder: {
                    id: "feedbackModal.thumbsUpPlaceholder",
                    defaultMessage: "What do you like about the response?",
                    description: "Placeholder for textarea input when user chooses thumbs up"
                },
                thumbsDownPlaceholder: {
                    id: "feedbackModal.thumbsDownPlaceholder",
                    defaultMessage: "What was the issue with the response? How could it be improved?",
                    description: "Placeholder for textarea input when user chooses thumbs down"
                },
                reportContentExplanationPlaceholder: {
                    id: "feedbackModal.reportContentExplanationPlaceholder",
                    defaultMessage: "What is wrong with the response? What about this response is harmful? Please be as specific as possible, and add any details that are not present in the checkboxes below.",
                    description: "Placeholder for textarea input when user chooses to report a shared chat"
                },
                harmfulUnsafe: {
                    id: "feedbackModal.harmfulUnsafe",
                    defaultMessage: "This is harmful / unsafe",
                    description: "Label for harmful/unsafe checkbox"
                },
                harmfulOffensive: {
                    id: "feedbackModal.harmfulOffensive",
                    defaultMessage: "This content is harmful or offensive",
                    description: "Label for harmful/offensive checkbox"
                },
                copyrightContent: {
                    id: "feedbackModal.copyrightContent",
                    defaultMessage: "This content violates copyright law",
                    description: "Label for Copyrighted Content checkbox"
                },
                reportOtherContent: {
                    id: "feedbackModal.reportOtherContent",
                    defaultMessage: "I don't like this for some other reason (please describe)",
                    description: "Label for Report Other Content checkbox"
                },
                notTrue: {
                    id: "feedbackModal.notTrue",
                    defaultMessage: "This isn't true",
                    description: "Label for not true checkbox"
                },
                notHelpful: {
                    id: "feedbackModal.notHelpful",
                    defaultMessage: "This isn't helpful",
                    description: "Label for not helpful checkbox"
                },
                dontLikeThis: {
                    id: "feedbackModal.dontLikeThis",
                    defaultMessage: "I don't like this",
                    description: "Label for I Don't Like This checkbox"
                },
                sexualAbuse: {
                    id: "feedbackModal.sexualAbuse",
                    defaultMessage: "This content contains sexual abuse",
                    description: "Label for Sexual Abuse checkbox"
                },
                provideAdditionalFeedback: {
                    id: "feedbackModal.provideAdditionalFeedback",
                    defaultMessage: "Provide additional feedback",
                    description: "Title for the critique feedback modal"
                },
                provideReportModalTitle: {
                    id: "feedbackModal.provideReportModalTitle",
                    defaultMessage: "Report This Content",
                    description: "Title for the 'report' feedback modal"
                },
                pickBestAnswer: {
                    id: "feedbackModal.pickBestAnswer",
                    defaultMessage: "Pick the best answer to improve the model",
                    description: "Title for the compare feedback modal"
                },
                newAnswer: {
                    id: "feedbackModal.newAnswer",
                    defaultMessage: "New Answer",
                    description: "Title for the new answer during comparison"
                },
                originalAnswer: {
                    id: "feedbackModal.originalAnswer",
                    defaultMessage: "Original Answer",
                    description: "Title for the original answer during comparison"
                },
                newAnswerBetter: {
                    id: "feedbackModal.newAnswerBetter",
                    defaultMessage: "New answer is better",
                    description: "Button text for choosing new answer during comparison"
                },
                originalAnswerBetter: {
                    id: "feedbackModal.originalAnswerBetter",
                    defaultMessage: "Original answer is better",
                    description: "Button text for choosing original answer during comparison"
                },
                neitherAnswerBetter: {
                    id: "feedbackModal.neitherAnswerBetter",
                    defaultMessage: "Neither answer is better",
                    description: "Button text for choosing neither answer during comparison"
                },
                skipStep: {
                    id: "feedbackModal.skipStep",
                    defaultMessage: "Skip this step",
                    description: "Button text for skipping comparison step"
                },
                continueWithChosenAnswer: {
                    id: "feedbackModal.continueWithChosenAnswer",
                    defaultMessage: "The conversation will continue with the answer you choose.",
                    description: "Information text for user during comparison"
                }
            });

            function aY(e) {
                var t, n, r, a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return (null == e ? void 0 : null === (t = e.messages) || void 0 === t ? void 0 : t.length) === 1 && !(null == e ? void 0 : null === (n = e.messages) || void 0 === n ? void 0 : n.some(function(e) {
                    return "error" in e
                })) && (!a || !((null == e ? void 0 : null === (r = e.messages) || void 0 === r ? void 0 : r.length) === 1 && (0, tT.RR)(null == e ? void 0 : e.messages[0].message).length < 20))
            }

            function aJ(e) {
                var t, n, r = e.ratingModalNodeId,
                    a = e.ratingModalOpen,
                    i = e.onCloseRatingModal,
                    o = e.handleSubmitFeedback,
                    s = e.onHandleChangeFeedbackComparisonRating,
                    l = e.feedbackTextareaRef,
                    u = e.clientThreadId,
                    d = e.activeRequests,
                    c = e.currentModelId,
                    f = e.onChangeItemInView,
                    g = e.onRequestMoreCompletions,
                    h = e.onDeleteNode,
                    m = e.onRequestCompletion,
                    p = e.onUpdateNode,
                    v = (0, ei.Z)(),
                    x = S.tQ.getTree(u),
                    y = (0, S.XK)(u);
                (0, _.useEffect)(function() {
                    "report" === a && ev.pg.forceEnableSession()
                }, [a]);
                var C = (0, _.useRef)(.5 > Math.random() ? "left" : "right"),
                    k = null == x ? void 0 : x.getConversationTurns(r || "root"),
                    N = k.length - 1,
                    I = k[k.length - 1],
                    Z = (0, B.hz)().has(eu.FZ),
                    F = (0, j._)((0, _.useState)("critique"), 2),
                    D = F[0],
                    E = F[1],
                    R = (0, U.w$)(),
                    A = aY(I, !0) && R,
                    L = (0, _.useMemo)(function() {
                        return {
                            id: r || "root",
                            threadId: S.tQ.getServerThreadId(u),
                            rating: a,
                            model: c
                        }
                    }, [r, u, a, c]),
                    O = null == k ? void 0 : k[(null == k ? void 0 : k.length) - 1].variantIds,
                    q = null == O ? void 0 : O[(null == O ? void 0 : O.length) - 1],
                    z = (n = (t = null == x ? void 0 : x.getConversationTurns(q))[t.length - 1]).messages[n.messages.length - 1].nodeId,
                    H = null == x ? void 0 : x.getConversationTurns(z),
                    W = (0, _.useMemo)(function() {
                        var e = null == H ? void 0 : H[(null == H ? void 0 : H.length) - 1];
                        return "thumbsDown" === a && A && aY(e) && aY(I)
                    }, [a, A, H, I]),
                    Q = (0, _.useRef)(Date.now()),
                    $ = (0, _.useRef)(-1),
                    Y = (0, _.useRef)(Date.now()),
                    J = (0, _.useRef)(Date.now());
                (0, _.useEffect)(function() {
                    "compare" === D ? ($.current = Date.now(), es.o.logEvent(el.a.displayedComparisonUIV0, L)) : "critique" === D && "thumbsDown" === a && es.o.logEvent(el.a.displayedThumbsDownFeedbackForm, L)
                }, [D]);
                var K = k.length - 2,
                    X = H.length - 1,
                    ee = H[H.length - 1],
                    et = (0, _.useMemo)(function() {
                        return ee && rh.Cv.getRequestIdFromConversationTurn(ee)
                    }, [ee]),
                    en = (0, _.useMemo)(function() {
                        return d.has(et)
                    }, [d, et]);
                (0, _.useMemo)(function() {
                    en || (J.current = Date.now())
                }, [en]);
                var er = I.messages,
                    eo = er[er.length - 1],
                    ed = eo.message.id,
                    ec = eo.nodeId,
                    eh = x.getLeafFromNode(ec),
                    em = ee.messages,
                    ep = em[em.length - 1],
                    ex = ep.message.id,
                    eb = ep.nodeId,
                    ey = x.getLeafFromNode(eb),
                    ej = "critique" === D ? "report" === a ? v.formatMessage(a$.provideReportModalTitle) : v.formatMessage(a$.provideAdditionalFeedback) : v.formatMessage(a$.pickBestAnswer),
                    ew = (0, _.useRef)([]),
                    eC = (0, _.useRef)(""),
                    ek = (0, _.useCallback)(function() {
                        var e, t = null === (e = l.current) || void 0 === e ? void 0 : e.elements;
                        ew.current = (0, te._)(t || []).filter(function(e) {
                            return e.checked
                        }).map(function(e) {
                            return e.id
                        }).map(function(e) {
                            return e.replace("feedback-", "")
                        }), eC.current = (null == t ? void 0 : t["feedback-other"].value) || ""
                    }, [l]),
                    e_ = (0, _.useCallback)(function() {
                        ek(), o(eC.current, ew.current), "thumbsDown" === a && es.o.logEvent(el.a.submitThumbsDownFeedbackForm, L), W ? E("compare") : i()
                    }, [ek, o, a, W, L, i]),
                    eM = (0, _.useCallback)(function(e, t) {
                        var n = S.tQ.getServerThreadId(u);
                        if (null != n) {
                            var r = S.tQ.getThreadCurrentLeafId(u);
                            P.ZP.submitSharedConversationReportFeedback({
                                message_id: r,
                                shared_conversation_id: n,
                                text: e,
                                tags: t
                            }).then(function() {
                                tl.m.success("Moderation logged successfully")
                            }).catch(function() {
                                tl.m.danger("Moderation NOT logged successfully! Please try again")
                            }), i()
                        }
                    }, [u, i]),
                    eT = (0, _.useCallback)(function() {
                        ek(), ew.current.push("moderation-reject"), eM(eC.current, ew.current)
                    }, [eM, ek]),
                    eN = (0, _.useCallback)(function() {
                        ek(), ew.current.push("moderation-accept"), eM(eC.current, ew.current)
                    }, [eM, ek]),
                    eP = "moderate" === a ? (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsx)(ef.ZP.Button, {
                            title: v.formatMessage(a$.submitRejectModeration),
                            color: "danger",
                            onClick: eT
                        }), (0, w.jsx)(ef.ZP.Button, {
                            title: v.formatMessage(a$.submitAcceptModeration),
                            color: "primary",
                            onClick: eN
                        })]
                    }) : "critique" === D ? (0, w.jsx)(ef.ZP.Button, {
                        title: v.formatMessage("report" === a ? a$.submitReport : a$.submitFeedback),
                        onClick: e_
                    }) : null,
                    eS = "left" === C.current,
                    eI = eS ? "new" : "original",
                    eZ = eS ? "original" : "new",
                    eF = eS ? v.formatMessage(a$.newAnswer) : v.formatMessage(a$.originalAnswer),
                    eD = eS ? v.formatMessage(a$.originalAnswer) : v.formatMessage(a$.newAnswer),
                    eE = eS ? v.formatMessage(a$.newAnswerBetter) : v.formatMessage(a$.originalAnswerBetter),
                    eR = eS ? v.formatMessage(a$.originalAnswerBetter) : v.formatMessage(a$.newAnswerBetter),
                    eB = a && "report" !== a && "moderate" !== a,
                    eA = (0, _.useCallback)(function(e) {
                        var t = "left" === e ? eI : "right" === e ? eZ : "same";
                        if (es.o.logEvent(el.a.submittedComparisonUIV0, Object.assign({}, L, {
                                choice: t
                            })), eB) {
                            var n = S.tQ.getTree(u),
                                r = n.getMetadata(ec);
                            n.updateNode(ec, {
                                metadata: {
                                    $set: (0, V._)((0, b._)({}, r), {
                                        inlineComparisonRating: "baseline"
                                    })
                                }
                            });
                            var o = n.getMetadata(eb);
                            n.updateNode(eb, {
                                metadata: {
                                    $set: (0, V._)((0, b._)({}, o), {
                                        inlineComparisonRating: t
                                    })
                                }
                            }), s(ed, ex, a, t, C.current, Q.current, $.current, Y.current, J.current, eC.current, ew.current)
                        }
                        S.tQ.setThreadCurrentLeafId(u, e === C.current ? ey.id : eh.id), i()
                    }, [eI, eZ, L, eB, u, ey.id, eh.id, i, ec, eb, s, ed, ex, a]),
                    eL = !en && null != J.current && W,
                    eU = (0, _.useCallback)(function() {
                        i(), "critique" === D ? es.o.logEvent(el.a.skippedThumbsDownFeedbackForm, Object.assign({}, L)) : "compare" === D && es.o.logEvent(el.a.skippedComparisonUIV0, Object.assign({}, L))
                    }, [i, L, D]),
                    eO = (0, j._)((0, _.useState)([]), 2),
                    eq = eO[0],
                    ez = eO[1];
                return (0, _.useEffect)(function() {
                    "moderate" === a && P.ZP.fetchShareModerationCategories().then(function(e) {
                        var t = e.moderation_categories;
                        ez(Object.keys(t).map(function(e) {
                            return [e, t[e]]
                        }))
                    })
                }, []), (0, w.jsxs)(eg.Z, {
                    isOpen: !0,
                    onClose: eU,
                    size: "custom",
                    className: "md:max-w-[672px] lg:max-w-[896px] xl:max-w-6xl",
                    type: "critique" === D ? "thumbsUp" === a ? "success" : "danger" : "success",
                    icon: "critique" === D ? "thumbsUp" === a ? M.fmn : M.oLd : void 0,
                    title: ej,
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: eU
                    }),
                    children: ["critique" === D && (0, w.jsxs)("form", {
                        ref: l,
                        children: [(0, w.jsx)(rg.ZP, {
                            id: "feedback-other",
                            placeholder: "thumbsUp" === a ? v.formatMessage(a$.thumbsUpPlaceholder) : "report" === a ? v.formatMessage(a$.reportContentExplanationPlaceholder) : v.formatMessage(a$.thumbsDownPlaceholder),
                            rows: 3,
                            className: "mb-1 mt-4 w-full rounded-md dark:bg-gray-800 dark:focus:border-white dark:focus:ring-white"
                        }), "thumbsDown" === a && (0, w.jsxs)("div", {
                            className: "mb-4",
                            children: [(0, w.jsx)(rm, {
                                id: "feedback-harmful",
                                label: v.formatMessage(a$.harmfulUnsafe)
                            }), (0, w.jsx)(rm, {
                                id: "feedback-false",
                                label: v.formatMessage(a$.notTrue)
                            }), (0, w.jsx)(rm, {
                                id: "feedback-not-helpful",
                                label: v.formatMessage(a$.notHelpful)
                            })]
                        }), null != a && !eB && (0, w.jsx)(w.Fragment, {
                            children: (0, w.jsxs)("div", {
                                className: "mb-4",
                                children: ["report" === a && (0, w.jsxs)(w.Fragment, {
                                    children: [(0, w.jsx)(rm, {
                                        id: "feedback-dont-like-this",
                                        label: v.formatMessage(a$.dontLikeThis)
                                    }), (0, w.jsx)(rm, {
                                        id: "feedback-false",
                                        label: v.formatMessage(a$.notTrue)
                                    }), (0, w.jsx)(rm, {
                                        id: "feedback-not-helpful",
                                        label: v.formatMessage(a$.notHelpful)
                                    }), (0, w.jsx)(rm, {
                                        id: "feedback-harmful-offensive",
                                        label: v.formatMessage(a$.harmfulOffensive)
                                    }), (0, w.jsx)(rm, {
                                        id: "feedback-sexual-abuse",
                                        label: v.formatMessage(a$.sexualAbuse)
                                    })]
                                }), "moderate" === a && (0, w.jsxs)(w.Fragment, {
                                    children: [eq.map(function(e) {
                                        var t = (0, j._)(e, 2),
                                            n = t[0],
                                            r = t[1];
                                        return (0, w.jsx)(rm, {
                                            id: "feedback-" + n,
                                            label: r
                                        }, n)
                                    }), (0, w.jsx)(rm, {
                                        id: "feedback-copyright",
                                        label: v.formatMessage(a$.copyrightContent)
                                    })]
                                }), (0, w.jsx)(rm, {
                                    id: "feedback-content-other",
                                    label: v.formatMessage(a$.reportOtherContent)
                                })]
                            })
                        })]
                    }), "compare" === D && H && void 0 !== y && (0, w.jsxs)("div", {
                        className: (0, G.Z)("w-full"),
                        children: [(0, w.jsx)("p", {
                            className: (0, G.Z)("mb-7 mt-3"),
                            children: (0, w.jsx)(T.Z, (0, b._)({}, a$.continueWithChosenAnswer))
                        }), (0, w.jsx)(a0, {
                            className: Z ? "rounded-2xl" : "rounded-md",
                            children: (0, w.jsx)(a1, {
                                children: (0, w.jsx)(aB, {
                                    currentModelId: c,
                                    turnIndex: K,
                                    isFinalTurn: !1,
                                    clientThreadId: u,
                                    onChangeItemInView: f,
                                    onChangeRating: ea(),
                                    onRequestMoreCompletions: g,
                                    onDeleteNode: h,
                                    onRequestCompletion: m,
                                    onUpdateNode: p,
                                    activeRequests: d,
                                    showInlineEmbeddedDisplay: !0
                                })
                            })
                        }), (0, w.jsxs)("div", {
                            className: (0, G.Z)(),
                            children: [(0, w.jsxs)("div", {
                                className: (0, G.Z)("mb-2 grid w-full grid-cols-2 gap-5"),
                                children: [(0, w.jsx)("div", {
                                    children: (0, w.jsx)("p", {
                                        className: (0, G.Z)("font-semibold"),
                                        children: eF
                                    })
                                }), (0, w.jsx)("div", {
                                    children: (0, w.jsx)("p", {
                                        className: (0, G.Z)("font-semibold"),
                                        children: eD
                                    })
                                })]
                            }), (0, w.jsxs)("div", {
                                className: (0, G.Z)("mb-5 grid w-full grid-cols-2 gap-5"),
                                children: [(0, w.jsxs)(aX, {
                                    children: [(0, w.jsx)(a1, {
                                        children: (0, w.jsx)(aB, {
                                            currentModelId: c,
                                            turnIndex: eS ? X : N,
                                            conversationLeafId: eS ? eb : ec,
                                            isFinalTurn: !0,
                                            clientThreadId: u,
                                            onChangeItemInView: f,
                                            onChangeRating: ea(),
                                            onDeleteNode: h,
                                            onRequestMoreCompletions: g,
                                            onRequestCompletion: m,
                                            onUpdateNode: p,
                                            activeRequests: d,
                                            showInlineEmbeddedDisplay: !0
                                        })
                                    }), (0, w.jsx)(aK, {
                                        children: (0, w.jsx)(ef.ZP.Button, {
                                            disabled: !eL,
                                            title: eE,
                                            onClick: function() {
                                                return eA("left")
                                            },
                                            color: "dark"
                                        })
                                    })]
                                }), (0, w.jsxs)(aX, {
                                    children: [(0, w.jsx)(a1, {
                                        children: (0, w.jsx)(aB, {
                                            currentModelId: c,
                                            turnIndex: eS ? N : X,
                                            conversationLeafId: eS ? ec : eb,
                                            isFinalTurn: !0,
                                            clientThreadId: u,
                                            onChangeItemInView: f,
                                            onChangeRating: ea(),
                                            onDeleteNode: h,
                                            onRequestMoreCompletions: g,
                                            onRequestCompletion: m,
                                            onUpdateNode: p,
                                            activeRequests: d,
                                            showInlineEmbeddedDisplay: !0
                                        })
                                    }), (0, w.jsx)(aK, {
                                        children: (0, w.jsx)(ef.ZP.Button, {
                                            disabled: !eL,
                                            title: eR,
                                            onClick: function() {
                                                return eA("right")
                                            },
                                            color: "dark"
                                        })
                                    })]
                                })]
                            }), (0, w.jsx)("div", {
                                className: (0, G.Z)("grid w-full"),
                                children: (0, w.jsxs)("div", {
                                    className: (0, G.Z)("mb-2 text-right"),
                                    children: [(0, w.jsx)(ef.ZP.Button, {
                                        disabled: !eL,
                                        title: v.formatMessage(a$.neitherAnswerBetter),
                                        color: "primary",
                                        onClick: function() {
                                            return eA("same")
                                        },
                                        className: (0, G.Z)("mr-2")
                                    }), (0, w.jsx)(ef.ZP.Button, {
                                        title: v.formatMessage(a$.skipStep),
                                        onClick: function() {
                                            return i()
                                        }
                                    })]
                                })
                            })]
                        })]
                    }), (0, w.jsx)(ef.ZP.Actions, {
                        primaryButton: eP
                    })]
                }, "RatingModal-".concat(r))
            }
            var aK = eo.Z.div(aW()),
                aX = eo.Z.div(aV()),
                a0 = eo.Z.div(aQ()),
                a1 = eo.Z.div(aG()),
                a2 = n(50744);

            function a3() {
                var e, t, n, r, a, i, o = (t = (e = tj()).isLoggedInWithMfa, n = e.isUsernamePassword, r = e.setupMfa, i = (a = ni()).filter(function(e) {
                        return !("none" === e.manifest.auth.type || "service_http" === e.manifest.auth.type)
                    }), (t || !n) && (i = []), {
                        disablePluginsThatWeCantUse: function() {
                            no(a.filter(function(e) {
                                return "none" === e.manifest.auth.type || "service_http" === e.manifest.auth.type
                            }).map(function(e) {
                                return e.id
                            }))
                        },
                        pluginsWeCantUse: i,
                        setupMfa: r
                    }),
                    s = o.disablePluginsThatWeCantUse,
                    l = o.pluginsWeCantUse,
                    u = o.setupMfa,
                    d = (0, _.useCallback)(function() {
                        s()
                    }, [s]);
                return 0 === l.length ? null : (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: d,
                    title: "Some of your plugins require two-factor authentication.",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        onClick: u,
                        title: "Setup two-factor authentication",
                        color: "primary"
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        onClick: s,
                        title: "Turn off the plugins"
                    }),
                    type: "danger",
                    children: (0, w.jsx)("div", {
                        className: "flex flex-col gap-2 py-4",
                        children: l.map(function(e) {
                            return (0, w.jsx)("div", {
                                className: "w-full",
                                children: (0, w.jsx)(t8, {
                                    plugin: e
                                })
                            }, e.id)
                        })
                    })
                })
            }
            var a5 = n(96175),
                a4 = n(19350),
                a8 = n(51061);

            function a7(e) {
                var t = e.isOpen,
                    n = e.onClose,
                    r = (0, j._)((0, _.useState)(!1), 2),
                    a = r[0],
                    i = r[1],
                    o = (0, k.useRouter)(),
                    s = (0, _.useCallback)(function() {
                        es.o.logEvent(el.a.closeAccountPaymentModal), n()
                    }, [n]),
                    l = (0, _.useCallback)((0, eG._)(function() {
                        var e;
                        return (0, e$.__generator)(this, function(t) {
                            switch (t.label) {
                                case 0:
                                    i(!0), es.o.logEvent(el.a.clickAccountCustomerPortal), t.label = 1;
                                case 1:
                                    return t.trys.push([1, 3, 4, 5]), [4, P.ZP.fetchCustomerPortalUrl()];
                                case 2:
                                    return e = t.sent(), o.push(e.url), [3, 5];
                                case 3:
                                    return t.sent(), tl.m.warning("The account management page encountered an error. Please try again. If the problem continues, please visit help.openai.com.", {
                                        hasCloseButton: !0
                                    }), [3, 5];
                                case 4:
                                    return i(!1), [7];
                                case 5:
                                    return [2]
                            }
                        })
                    }), [o, i]),
                    u = (0, _.useCallback)(function() {
                        es.o.logEvent(el.a.clickAccountPaymentGetHelp)
                    }, []),
                    d = (0, _.useCallback)(function() {
                        es.o.logEvent(el.a.clickAccountManageIos)
                    }, []),
                    c = (0, B.e2)(),
                    f = (0, B.YD)();
                return (0, w.jsxs)(a5.x, {
                    isOpen: t,
                    onClose: n,
                    children: [(0, w.jsxs)("div", {
                        className: "flex w-full flex-row items-center justify-between border-b px-4 py-3 dark:border-gray-700",
                        children: [(0, w.jsx)("span", {
                            className: "text-base font-semibold sm:text-base",
                            children: "Your plan"
                        }), (0, w.jsx)("button", {
                            className: "text-gray-700 opacity-50 transition hover:opacity-75 dark:text-white",
                            onClick: s,
                            children: (0, w.jsx)(M.q5L, {
                                className: "h-6 w-6"
                            })
                        })]
                    }), (0, w.jsx)("div", {
                        className: "grid",
                        children: (0, w.jsx)("div", {
                            className: "relative order-1 col-span-1 sm:order-2",
                            children: (0, w.jsx)(a4.Oi, {
                                rowElements: [(0, w.jsx)(a4.Cu, {
                                    text: a8.S.plus.name,
                                    children: (0, w.jsx)("span", {
                                        className: "font-semibold text-gray-500",
                                        children: a8.S.plus.costInDollars
                                    })
                                }, "row-plus-plan-name"), (0, w.jsx)(a4.hi, {
                                    disabled: !0,
                                    variant: "primary-disabled",
                                    text: a8.S.plus.callToAction.active
                                }, "row-plus-plan-button"), (0, w.jsx)(a4.G, {
                                    text: a8.S.plus.demandAccess
                                }, "row-plus-plan-demand"), (0, w.jsx)(a4.G, {
                                    text: a8.S.plus.responseSpeed
                                }, "row-plus-plan-speed"), (0, w.jsx)(a4.G, {
                                    className: "sm:pb-1",
                                    text: a8.S.plus.modelFeatures
                                }, "row-plus-plan-feathers"), (null == c ? void 0 : c.purchase_origin_platform) === nc._4.MOBILE_IOS && (0, w.jsx)(nX(), {
                                    href: nc.m1,
                                    target: "_blank",
                                    passHref: !0,
                                    children: (0, w.jsx)(a4.nR, {
                                        className: "sm:pb-1",
                                        isLoading: !1,
                                        text: a8.S.manageSubscriptionIos.callToAction,
                                        onClick: d
                                    })
                                }, "row-plus-plan-manage-ios"), (!c || c.purchase_origin_platform === nc._4.WEBAPP || c.purchase_origin_platform === nc._4.GRANTED) && f && (0, w.jsx)(a4.nR, {
                                    className: "sm:pb-1",
                                    isLoading: a,
                                    text: a8.S.manageSubscriptionWeb.callToAction,
                                    onClick: l
                                }, "row-plus-plan-manage"), (0, w.jsx)(nX(), {
                                    href: nc.ti,
                                    target: "_blank",
                                    passHref: !0,
                                    children: (0, w.jsx)(a4.nR, {
                                        className: "sm:pb-1",
                                        isLoading: !1,
                                        isTextOnly: !0,
                                        text: a8.S.getHelp.callToAction,
                                        onClick: u
                                    }, "row-plus-plan-help")
                                }, "row-plus-plan-help-link")]
                            })
                        })
                    })]
                })
            }
            var a6 = n(93683),
                a9 = n(43019),
                ie = n(26003),
                it = n(43477),
                ir = (0, _.createContext)(),
                ia = function(e) {
                    return (0, I.oR)((0, _.useContext)(ir), e)
                },
                ii = n(68993);

            function io(e) {
                return e.some(function(e) {
                    return e.messages.some(function(e) {
                        var t, n, r, a;
                        return (null == (r = null === (t = e.message.metadata) || void 0 === t ? void 0 : t.aggregate_result) ? void 0 : null === (n = r.messages) || void 0 === n ? void 0 : n.some(r$)) || ("parts" in (a = e.message.content) ? a.parts.join("") : "").includes("sandbox:")
                    })
                })
            }
            var is = function(e) {
                    var t = e.children,
                        n = e.color,
                        r = void 0 === n ? "yellow" : n,
                        a = e.icon;
                    return (0, w.jsxs)("div", {
                        className: (0, G.Z)("mb-4 flex items-start justify-start gap-2.5 rounded-md p-4 last:mb-0", {
                            "bg-yellow-300 text-[#756B5C]": "yellow" === r,
                            "bg-gray-50 text-gray-800 dark:bg-[#444654] dark:text-gray-100": "gray" === r
                        }),
                        children: [null != a && (0, w.jsx)(eh.ZP, {
                            icon: a,
                            size: "small",
                            className: "mt-1 flex-shrink-0"
                        }), t]
                    })
                },
                il = n(20476),
                iu = n(75318);

            function id() {
                var e = (0, Q._)(["text-gray-800 w-full mx-auto md:max-w-2xl lg:max-w-3xl md:h-full md:flex md:flex-col px-6 dark:text-gray-100"]);
                return id = function() {
                    return e
                }, e
            }

            function ic() {
                var e = (0, Q._)(["text-4xl font-semibold text-center mt-6 sm:mt-[20vh] ml-auto mr-auto mb-10 sm:mb-16 flex gap-2 items-center justify-center"]);
                return ic = function() {
                    return e
                }, e
            }

            function ig() {
                var e = (0, Q._)(["md:flex items-start text-center gap-3.5"]);
                return ig = function() {
                    return e
                }, e
            }

            function ih() {
                var e = (0, Q._)(["flex flex-col mb-8 md:mb-auto gap-3.5 flex-1"]);
                return ih = function() {
                    return e
                }, e
            }

            function im() {
                var e = (0, Q._)(["flex gap-3 items-center m-auto text-lg font-normal md:flex-col md:gap-2"]);
                return im = function() {
                    return e
                }, e
            }

            function ip() {
                var e = (0, Q._)(["flex flex-col gap-3.5 w-full sm:max-w-md m-auto"]);
                return ip = function() {
                    return e
                }, e
            }

            function iv() {
                var e = (0, Q._)(["w-full bg-gray-50 dark:bg-white/5 p-3 rounded-md"]);
                return iv = function() {
                    return e
                }, e
            }

            function ix() {
                var e = (0, Q._)(["w-full bg-gray-50 dark:bg-white/5 p-3 rounded-md after:content-['\"'] before:content-['\"']"]);
                return ix = function() {
                    return e
                }, e
            }

            function ib() {
                var e = (0, Q._)(["w-full bg-gray-50 dark:bg-white/5 p-3 rounded-md hover:bg-gray-200 dark:hover:bg-gray-900"]);
                return ib = function() {
                    return e
                }, e
            }
            eo.Z.div(id()), eo.Z.h1(ic());
            var iy = eo.Z.div(ig()),
                ij = eo.Z.div(ih()),
                iw = eo.Z.h2(im()),
                iC = eo.Z.ul(ip()),
                ik = eo.Z.li(iv());
            eo.Z.li(ix());
            var i_ = eo.Z.button(ib());

            function iM() {
                var e = (0, Q._)(["text-4xl font-semibold text-center mt-6 sm:mt-[6vh] ml-auto mr-auto mb-4 sm:mb-16 flex gap-2 items-center justify-center"]);
                return iM = function() {
                    return e
                }, e
            }

            function iT() {
                var e = (0, Q._)(["text-gray-800 w-full mx-auto md:max-w-2xl lg:max-w-3xl md:flex md:flex-col px-6 dark:text-gray-100"]);
                return iT = function() {
                    return e
                }, e
            }

            function iN(e) {
                var t = e.text,
                    n = e.onChangeCurrentPrompt,
                    r = (0, _.useCallback)(function() {
                        n(t)
                    }, [t, n]);
                return (0, w.jsxs)(i_, {
                    onClick: r,
                    children: ['"', t, '" →']
                })
            }

            function iP(e) {
                var t = function(e) {
                        var t;
                        null == n || null === (t = n.current) || void 0 === t || t.setInputValue(e)
                    },
                    n = e.promptTextareaRef;
                return (0, w.jsxs)(iI, {
                    children: [(0, w.jsxs)(iS, {
                        children: ["ChatGPT", (0, w.jsx)(il.ZP, {})]
                    }), (0, w.jsxs)(iy, {
                        children: [(0, w.jsxs)(ij, {
                            children: [(0, w.jsxs)(iw, {
                                children: [(0, w.jsx)(eh.ZP, {
                                    icon: M.kXG,
                                    size: "medium"
                                }), "Examples"]
                            }), (0, w.jsxs)(iC, {
                                children: [(0, w.jsx)(iN, {
                                    text: "Explain quantum computing in simple terms",
                                    onChangeCurrentPrompt: t
                                }), (0, w.jsx)(iN, {
                                    text: "Got any creative ideas for a 10 year old’s birthday?",
                                    onChangeCurrentPrompt: t
                                }), (0, w.jsx)(iN, {
                                    text: "How do I make an HTTP request in Javascript?",
                                    onChangeCurrentPrompt: t
                                })]
                            })]
                        }), (0, w.jsxs)(ij, {
                            children: [(0, w.jsxs)(iw, {
                                children: [(0, w.jsx)(eh.ZP, {
                                    icon: iu.Z,
                                    size: "medium"
                                }), "Capabilities"]
                            }), (0, w.jsxs)(iC, {
                                children: [(0, w.jsx)(ik, {
                                    children: "Remembers what user said earlier in the conversation"
                                }), (0, w.jsx)(ik, {
                                    children: "Allows user to provide follow-up corrections"
                                }), (0, w.jsx)(ik, {
                                    children: "Trained to decline inappropriate requests"
                                })]
                            })]
                        }), (0, w.jsxs)(ij, {
                            children: [(0, w.jsxs)(iw, {
                                children: [(0, w.jsx)(eh.ZP, {
                                    icon: M.BJv,
                                    size: "medium"
                                }), "Limitations"]
                            }), (0, w.jsxs)(iC, {
                                children: [(0, w.jsx)(ik, {
                                    children: "May occasionally generate incorrect information"
                                }), (0, w.jsx)(ik, {
                                    children: "May occasionally produce harmful instructions or biased content"
                                }), (0, w.jsx)(ik, {
                                    children: "Limited knowledge of world and events after 2021"
                                })]
                            })]
                        })]
                    })]
                })
            }
            var iS = eo.Z.h1(iM()),
                iI = eo.Z.div(iT()),
                iZ = n(40058),
                iF = n(26563),
                iD = n(57526),
                iE = n(99581);

            function iR() {
                var e = (0, Q._)(["rounded-lg bg-white ring-1 ring-black/10 dark:bg-gray-800 dark:ring-white/20 shadow-[0_1px_7px_0_rgba(0,0,0,0.03)]"]);
                return iR = function() {
                    return e
                }, e
            }

            function iB() {
                var e = (0, Q._)(["absolute z-[17] mt-2 flex max-h-60 w-full flex-col overflow-hidden text-base focus:outline-none dark:last:border-0 sm:text-sm md:w-[100%]"]);
                return iB = function() {
                    return e
                }, e
            }

            function iA() {
                var e = (0, Q._)(["absolute z-[17] -ml-[1px] flex flex-col gap-2 p-3 sm:p-4"]);
                return iA = function() {
                    return e
                }, e
            }

            function iL() {
                var e = (0, Q._)(["flex items-center gap-2 truncate"]);
                return iL = function() {
                    return e
                }, e
            }

            function iU() {
                var e = (0, Q._)(["h-6 w-6 shrink-0"]);
                return iU = function() {
                    return e
                }, e
            }

            function iO() {
                var e = (0, Q._)(["absolute inset-y-0 right-0 flex items-center pr-5 text-gray-800 dark:text-gray-100"]);
                return iO = function() {
                    return e
                }, e
            }

            function iq() {
                var e = (0, Q._)(["absolute inset-y-0 right-0 flex items-center pr-3 text-gray-800 dark:text-gray-100"]);
                return iq = function() {
                    return e
                }, e
            }
            var iz = ["confidential", "alpha", "plus"];

            function iH(e) {
                var t = e.selectedOptions,
                    n = e.selectedLabel,
                    r = e.onChange,
                    a = e.onAction,
                    i = e.onOpen,
                    o = e.onClose,
                    s = e.dropdownRef,
                    l = (0, y._)(e, ["selectedOptions", "selectedLabel", "onChange", "onAction", "onOpen", "onClose", "dropdownRef"]),
                    u = (0, _.useCallback)(function(e) {
                        if (e.some(function(e) {
                                return "string" == typeof e
                            })) {
                            var t = e.find(function(e) {
                                return "string" == typeof e
                            });
                            null == a || a(t)
                        } else r(e)
                    }, [r, a]);
                return (0, w.jsx)(iF.R, {
                    value: t.map(function(e) {
                        return e.value
                    }),
                    multiple: !0,
                    onChange: u,
                    children: function(e) {
                        var r = e.open;
                        return (0, w.jsx)(iW, (0, b._)({
                            ref: s,
                            selectedLabel: n || "".concat(t.length, " selected"),
                            open: r,
                            onOpen: i,
                            onClose: o,
                            multiple: !0
                        }, l))
                    }
                })
            }
            var iW = (0, _.forwardRef)(function(e, t) {
                var n = e.name,
                    r = e.selectedLabel,
                    a = e.open,
                    i = e.options,
                    o = e.actions,
                    s = e.multiple,
                    l = e.isLoading,
                    u = e.loadingState,
                    d = e.header,
                    c = e.onOpen,
                    f = e.onClose,
                    g = e.theme,
                    h = (0, _.useRef)(null),
                    m = (0, _.useRef)(null),
                    p = (0, U.oc)();
                (0, _.useImperativeHandle)(t, function() {
                    return {
                        open: function() {
                            if (!a) {
                                var e;
                                null === (e = h.current) || void 0 === e || e.click()
                            }
                        },
                        close: function() {
                            if (a) {
                                var e;
                                null === (e = h.current) || void 0 === e || e.click()
                            }
                        }
                    }
                }, [a]);
                var v = l ? u || (0, w.jsx)("div", {
                    className: "flex h-[42px] items-center justify-center",
                    children: (0, w.jsx)(em.Z, {})
                }) : (0, w.jsxs)(w.Fragment, {
                    children: [d, (0, w.jsxs)(iF.R.Options, {
                        className: "overflow-auto",
                        children: [i.map(function(e, t) {
                            return (0, w.jsx)(iV, {
                                value: e.value,
                                disabled: e.disabled,
                                theme: g,
                                children: function(t) {
                                    var n = t.selected,
                                        r = t.active;
                                    return (0, w.jsxs)(w.Fragment, {
                                        children: [(0, w.jsxs)(i3, {
                                            children: [e.imageUrl && (0, w.jsx)(i5, {
                                                children: (0, w.jsx)(t4.Z, {
                                                    url: e.imageUrl,
                                                    name: e.title,
                                                    size: "100%"
                                                })
                                            }), (0, w.jsxs)("span", {
                                                className: (0, G.Z)(n && !s && "font-semibold", "flex h-6 items-center gap-1 text-gray-800 dark:text-gray-100"),
                                                children: [e.title, e.tags.map(function(e) {
                                                    return iJ(e)
                                                }), e.customTags]
                                            })]
                                        }), s && !e.disabled ? (0, w.jsx)(iG, {
                                            theme: g,
                                            selected: n
                                        }) : n && (0, w.jsx)(iQ, {
                                            theme: g,
                                            icon: "mini" === g ? eh.HQ : M.UgA
                                        }), e.disabled && (0, w.jsx)(iQ, {
                                            theme: g,
                                            icon: iD.Z,
                                            className: "text-red-700 dark:text-red-500"
                                        }), r && p && (0, iE.createPortal)((0, w.jsx)(iY, {
                                            option: e,
                                            dropdownRef: m
                                        }), document.body)]
                                    })
                                }
                            }, t)
                        }), null == o ? void 0 : o.map(function(e, t) {
                            return (0, w.jsx)(iV, {
                                value: e.id,
                                theme: g,
                                children: function() {
                                    return (0, w.jsxs)(w.Fragment, {
                                        children: [(0, w.jsx)("div", {
                                            className: "text-gray-800 dark:text-gray-100",
                                            children: e.label
                                        }), (0, w.jsx)(iQ, {
                                            theme: g,
                                            icon: e.icon
                                        })]
                                    })
                                }
                            }, t)
                        })]
                    })]
                });
                return (0, w.jsxs)("div", {
                    className: "relative w-full md:w-1/2 lg:w-1/3 xl:w-1/4",
                    children: [(0, w.jsxs)(iF.R.Button, {
                        ref: h,
                        onClick: a ? f : c,
                        className: (0, G.Z)("relative flex cursor-pointer flex-col bg-white py-2 pr-10 text-left dark:bg-gray-800 sm:text-sm", "mini" === g ? "mx-auto w-auto rounded-lg border border-transparent pl-4 pr-7 hover:border-black/10 dark:hover:border-white/10" : "w-full rounded-md border border-black/10 pl-3 focus:border-green-600 focus:outline-none focus:ring-1 focus:ring-green-600 dark:border-white/20"),
                        children: ["mini" !== g && (0, w.jsx)(iF.R.Label, {
                            className: "block text-xs text-gray-700 dark:text-gray-500",
                            children: n
                        }), (0, w.jsx)("span", {
                            className: "inline-flex w-full truncate",
                            children: (0, w.jsx)("span", {
                                className: "flex h-6 items-center gap-1 truncate",
                                children: r
                            })
                        }), (0, w.jsx)("span", {
                            className: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2",
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.bTu,
                                className: " text-gray-400",
                                "aria-hidden": "true"
                            })
                        })]
                    }), (0, w.jsx)(tP.u, {
                        show: a,
                        as: _.Fragment,
                        leave: "transition ease-in duration-100",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0",
                        children: (0, w.jsx)(iX, {
                            ref: m,
                            children: v
                        })
                    })]
                })
            });

            function iV(e) {
                var t = e.value,
                    n = e.disabled,
                    r = e.children,
                    a = e.theme;
                return (0, w.jsx)(iF.R.Option, {
                    className: function(e) {
                        var t = e.active;
                        return (0, G.Z)("mini" === a ? i1 : i2, t && !n ? "bg-gray-100 dark:bg-gray-700" : "text-gray-900", n && "cursor-auto bg-gray-50 text-gray-400 dark:bg-gray-700 dark:text-gray-100")
                    },
                    value: t,
                    children: r
                })
            }

            function iQ(e) {
                var t = e.icon,
                    n = e.className,
                    r = e.theme;
                return (0, w.jsx)("mini" === r ? i4 : i8, {
                    children: (0, w.jsx)(eh.ZP, {
                        icon: t,
                        className: (0, G.Z)("h-5 w-5", n),
                        "aria-hidden": "true"
                    })
                })
            }

            function iG(e) {
                var t = e.selected,
                    n = e.disabled;
                return "mini" === e.theme ? (0, w.jsxs)(i4, {
                    children: [(0, w.jsx)(eh.ZP, {
                        icon: t ? eh.HQ : eh.i9,
                        className: "h-5 w-5 text-blue-600",
                        strokeWidth: t ? 2.5 : 2
                    }), !t && (0, w.jsx)(eh.ZP, {
                        icon: eh.nQ,
                        className: (0, G.Z)("absolute h-5 w-5 text-blue-600 opacity-0 transition-opacity", !n && "group-hover:opacity-100")
                    })]
                }) : (0, w.jsx)(i8, {
                    children: (0, w.jsx)("div", {
                        className: (0, G.Z)("flex h-6 w-6 items-center justify-center rounded-full border transition-colors", t ? "border-transparent bg-green-600 text-white" : "border-black/5 dark:border-white/20"),
                        "aria-hidden": "true",
                        children: (0, w.jsx)(eh.ZP, {
                            icon: M.UgA,
                            className: (0, G.Z)("h-3 w-3 transition-opacity", t && "opacity-100", !t && "opacity-0", !t && !n && "group-hover:opacity-50"),
                            strokeWidth: t ? 2.5 : 2
                        })
                    })
                })
            }

            function i$(e) {
                var t = e.showCheckbox,
                    n = e.theme;
                return (0, w.jsxs)("div", {
                    className: (0, G.Z)("mini" === n ? i1 : i2, "cursor-auto"),
                    children: [(0, w.jsxs)(i3, {
                        children: [(0, w.jsx)(i5, {
                            children: (0, w.jsx)("div", {
                                className: "h-full w-full rounded-sm bg-gray-200"
                            })
                        }), (0, w.jsx)("div", {
                            className: "h-[12px] w-[88px] rounded-sm bg-gray-100"
                        })]
                    }), t && (0, w.jsx)(iG, {
                        theme: n,
                        selected: !1,
                        disabled: !0
                    })]
                })
            }

            function iY(e) {
                var t = e.option,
                    n = e.dropdownRef,
                    r = (0, j._)((0, _.useState)(), 2),
                    a = r[0],
                    i = r[1];
                return ((0, _.useEffect)(function() {
                    var e = function() {
                        if (n.current) {
                            var e = n.current.getBoundingClientRect();
                            i({
                                top: e.top,
                                left: e.left - 260,
                                minHeight: e.height
                            })
                        }
                    };
                    return e(), window.addEventListener("resize", e),
                        function() {
                            return window.removeEventListener("resize", e)
                        }
                }, [n]), a) ? (0, w.jsxs)(i0, {
                    style: {
                        width: 260,
                        minHeight: a.minHeight,
                        top: a.top,
                        left: a.left
                    },
                    children: [t.disabled && (0, w.jsx)(eh.ZP, {
                        icon: iD.Z,
                        size: "medium",
                        className: "text-red-700 dark:text-red-500"
                    }), t.imageUrl && (0, w.jsx)(t4.Z, {
                        url: t.imageUrl,
                        name: t.title,
                        size: 70
                    }), (0, w.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [t.title, " ", t.tags.map(function(e) {
                            return iJ(e)
                        }), " ", t.customTags]
                    }), (0, w.jsx)("div", {
                        className: "whitespace-pre-line text-xs",
                        children: t.description
                    })]
                }) : null
            }
            var iJ = function(e) {
                    return iz.includes(e) && (0, w.jsx)("span", {
                        className: (0, G.Z)("py-0.25 rounded px-1 text-[10px] font-semibold uppercase", "confidential" === e && "bg-red-200 text-red-800", "alpha" === e && "bg-blue-200 text-blue-500", "plus" === e && "bg-yellow-200 text-yellow-900"),
                        children: e
                    }, e)
                },
                iK = eo.Z.div(iR()),
                iX = (0, eo.Z)(iK)(iB()),
                i0 = (0, eo.Z)(iK)(iA()),
                i1 = "group relative flex h-[50px] cursor-pointer select-none items-center overflow-hidden border-b border-black/10 pl-5 pr-12 last:border-0 dark:border-white/20",
                i2 = "group relative flex h-[42px] cursor-pointer select-none items-center overflow-hidden border-b border-black/10 pl-3 pr-9 last:border-0 dark:border-white/20",
                i3 = eo.Z.span(iL()),
                i5 = eo.Z.span(iU()),
                i4 = eo.Z.span(iO()),
                i8 = eo.Z.span(iq()),
                i7 = n(7614);

            function i6() {
                var e = (0, Q._)(["mt-4 flex flex-col gap-4"]);
                return i6 = function() {
                    return e
                }, e
            }

            function i9() {
                var e = (0, Q._)(["text-sm text-red-500"]);
                return i9 = function() {
                    return e
                }, e
            }
            var oe = eo.Z.div(i6()),
                ot = eo.Z.div(i9());

            function on(e) {
                var t = e.onClickInstall,
                    n = e.onInstallLocalhost,
                    r = e.onClose,
                    a = (0, j._)((0, _.useState)(), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)(), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, j._)((0, _.useState)(!1), 2),
                    c = d[0],
                    f = d[1],
                    g = (0, _.useCallback)(function(e) {
                        o(e)
                    }, []),
                    h = (0, _.useCallback)(function() {
                        f(!0)
                    }, []);
                return c && (null == i ? void 0 : i.scrapeManifestResponse.plugin) ? (0, w.jsx)(os, {
                    plugin: null == i ? void 0 : i.scrapeManifestResponse.plugin,
                    onClickInstall: t,
                    onClose: r
                }) : l && (null == i ? void 0 : i.scrapeManifestResponse.plugin) ? (0, w.jsx)(oo, {
                    plugin: i.scrapeManifestResponse.plugin,
                    manifestAccessToken: i.manifestAccessToken,
                    verificationTokens: l,
                    onReadyToInstall: h,
                    onClose: r
                }) : i ? (0, w.jsx)(oi, {
                    loadManifestResult: i,
                    onRefetch: g,
                    onSubmitAuthInfo: u,
                    onReadyToInstall: h,
                    onInstallLocalhost: n,
                    onClose: r
                }) : (0, w.jsx)(or, {
                    onFetch: g,
                    onClose: r
                })
            }

            function or(e) {
                var t = e.onFetch,
                    n = e.onClose,
                    r = (0, ev.kP)().session,
                    a = (0, j._)((0, _.useState)(!1), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)("bearer"), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, j._)((0, _.useState)(), 2),
                    c = d[0],
                    f = d[1],
                    g = (0, _.useRef)(null),
                    h = (0, _.useRef)(null),
                    m = t5(),
                    p = m.fetchManifestAndSpec,
                    v = m.isLoading;
                (0, _.useEffect)(function() {
                    var e;
                    null === (e = g.current) || void 0 === e || e.focus()
                }, []);
                var x = (0, _.useCallback)(function() {
                        o(function(e) {
                            return !e
                        })
                    }, []),
                    b = (0, _.useCallback)(function(e) {
                        u(e.target.value)
                    }, []),
                    y = (0, _.useCallback)((0, eG._)(function() {
                        var e, n, r;
                        return (0, e$.__generator)(this, function(a) {
                            return (r = null === (e = g.current) || void 0 === e ? void 0 : e.value) ? (p({
                                domain: r,
                                manifestAccessToken: i ? {
                                    authorization_type: l,
                                    token: (null === (n = h.current) || void 0 === n ? void 0 : n.value) || ""
                                } : void 0,
                                onSuccess: t,
                                onError: function(e) {
                                    return f((null == e ? void 0 : e.message) || "Couldn't find manifest.")
                                }
                            }), [2]) : (f("Please provide a domain."), [2])
                        })
                    }), [p, t, l, i]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: n,
                    type: "success",
                    title: "Enter your website domain",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Find manifest file",
                        color: "primary",
                        onClick: y,
                        loading: v
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: n
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [(0, w.jsx)("a", {
                            href: "https://platform.openai.com/docs/plugins/getting-started",
                            target: "_blank",
                            rel: "noreferrer",
                            className: "text-green-600",
                            children: "Visit our documentation to learn how to build a plugin."
                        }), (0, w.jsxs)(i7.Z, {
                            icon: "\uD83D\uDEA8",
                            children: ["If your plugin has been approved to be in the ChatGPT plugin store, and you have made changes to your ", "plugin's", " manifest, your plugin will be removed from the store, and you will need to", " ", (0, w.jsx)("a", {
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-green-600",
                                href: "https://platform.openai.com/docs/plugins/review/submit-a-plugin-for-review",
                                children: "resubmit it for review"
                            }), "."]
                        }), (0, w.jsx)(tk, {
                            ref: g,
                            name: "url",
                            displayName: "Domain",
                            placeholder: "ex: openai.com or localhost:3000",
                            onPressEnter: y,
                            autoFocus: !0
                        }), (null == r ? void 0 : r.user) != null && (0, ev.yl)(r.user) && (0, w.jsxs)(w.Fragment, {
                            children: [(0, w.jsxs)("div", {
                                role: "button",
                                className: "flex cursor-pointer items-center gap-1 text-sm text-black/60 hover:text-black/70",
                                onClick: x,
                                children: [(0, w.jsx)("div", {
                                    children: "My file requires authentication"
                                }), (0, w.jsx)(eh.ZP, {
                                    icon: i ? M.rH8 : M.bTu
                                })]
                            }), i && (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsxs)("div", {
                                    className: "flex flex-col gap-2 text-sm",
                                    children: [(0, w.jsx)("div", {
                                        children: "Authentication type"
                                    }), (0, w.jsxs)("div", {
                                        className: "flex gap-6",
                                        children: [(0, w.jsx)(oa, {
                                            label: "Bearer",
                                            value: "bearer",
                                            checked: "bearer" === l,
                                            onChange: b
                                        }), (0, w.jsx)(oa, {
                                            label: "Basic",
                                            value: "basic",
                                            checked: "basic" === l,
                                            onChange: b
                                        })]
                                    })]
                                }), (0, w.jsxs)("div", {
                                    className: "flex flex-col gap-2 text-sm",
                                    children: [(0, w.jsx)("div", {
                                        children: "Access token"
                                    }), (0, w.jsx)(tk, {
                                        ref: h,
                                        name: "manifestToken",
                                        onPressEnter: y
                                    })]
                                })]
                            })]
                        }), c && (0, w.jsx)(ot, {
                            children: c
                        })]
                    })
                })
            }

            function oa(e) {
                var t = e.label,
                    n = e.value,
                    r = e.checked,
                    a = e.onChange;
                return (0, w.jsxs)("label", {
                    className: "flex items-center gap-2",
                    children: [(0, w.jsx)("input", {
                        name: "manifestAuthType",
                        type: "radio",
                        value: n,
                        checked: r,
                        onChange: a,
                        className: "text-green-600 focus:ring-green-600"
                    }), t]
                })
            }

            function oi(e) {
                var t = e.loadManifestResult,
                    n = e.onRefetch,
                    r = e.onSubmitAuthInfo,
                    a = e.onReadyToInstall,
                    i = e.onInstallLocalhost,
                    o = e.onClose,
                    s = t.domain,
                    l = t.manifestAccessToken,
                    u = t.scrapeManifestResponse,
                    d = t.apiValidationInfo,
                    c = u.plugin,
                    f = u.manifest_validation_info,
                    g = (0, j._)((0, _.useState)(), 2),
                    h = g[0],
                    m = g[1],
                    p = (0, j._)((0, _.useState)(!1), 2),
                    v = p[0],
                    x = p[1],
                    b = (0, _.useRef)(null),
                    y = (0, _.useRef)(null),
                    k = (0, _.useRef)(null),
                    M = t5(),
                    T = M.fetchManifestAndSpec,
                    N = M.isLoading,
                    S = (0, C.NL)(),
                    I = c && tQ(c),
                    Z = (null == c ? void 0 : c.manifest.auth.type) === "service_http",
                    F = (null == c ? void 0 : c.manifest.auth.type) === "oauth",
                    D = f.errors && f.errors.length > 0 || (null == d ? void 0 : d.errors) && (null == d ? void 0 : d.errors.length) > 0,
                    E = (0, _.useCallback)((0, eG._)(function() {
                        var e, t, u, d, f;
                        return (0, e$.__generator)(this, function(g) {
                            switch (g.label) {
                                case 0:
                                    if (!D) return [3, 1];
                                    return T({
                                        domain: s,
                                        manifestAccessToken: l,
                                        onSuccess: n,
                                        onError: function(e) {
                                            return m((null == e ? void 0 : e.message) || "Couldn't find manifest.")
                                        }
                                    }), [3, 15];
                                case 1:
                                    if (!I) return [3, 2];
                                    return tX(c, S), i(c), [3, 15];
                                case 2:
                                    if (!Z) return [3, 8];
                                    if (!(null === (e = b.current) || void 0 === e ? void 0 : e.value)) return m("Please provide your service access token."), [2];
                                    g.label = 3;
                                case 3:
                                    return g.trys.push([3, 5, 6, 7]), x(!0), [4, P.ZP.setPluginServiceHttpToken({
                                        id: c.id,
                                        serviceAccessToken: b.current.value
                                    })];
                                case 4:
                                    return r(g.sent().verification_tokens), [3, 7];
                                case 5:
                                    return g.sent(), m("Error setting access token."), [3, 7];
                                case 6:
                                    return x(!1), [7];
                                case 7:
                                    return [3, 15];
                                case 8:
                                    if (!F) return [3, 14];
                                    if (d = null === (t = y.current) || void 0 === t ? void 0 : t.value, f = null === (u = k.current) || void 0 === u ? void 0 : u.value, !d || !f) return m("Please provide your OAuth credentials."), [2];
                                    g.label = 9;
                                case 9:
                                    return g.trys.push([9, 11, 12, 13]), [4, P.ZP.setPluginOAuthClientCredentials({
                                        id: c.id,
                                        clientId: y.current.value,
                                        clientSecret: k.current.value
                                    })];
                                case 10:
                                    return r(g.sent().verification_tokens), [3, 13];
                                case 11:
                                    return g.sent(), m("Error setting OAuth credentials."), [3, 13];
                                case 12:
                                    return x(!1), [7];
                                case 13:
                                    return [3, 15];
                                case 14:
                                    c ? a(c) : o(), g.label = 15;
                                case 15:
                                    return [2]
                            }
                        })
                    }), [Z, F, c, s, l, D, I, S, T, n, r, a, i, o]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: o,
                    type: "success",
                    title: "Found plugin",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: D ? "Refetch manifest" : I ? "Install localhost plugin" : "Next",
                        color: "primary",
                        onClick: E,
                        loading: v || N
                    }),
                    secondaryButton: (D || Z || F) && (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: o
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [(0, w.jsx)(t7, {
                            manifestValidationInfo: f
                        }), d && (0, w.jsx)(t6, {
                            apiValidationInfo: d
                        }), c && (0, w.jsx)(t8, {
                            plugin: c
                        }), Z && !D && (0, w.jsxs)("div", {
                            children: [(0, w.jsx)("div", {
                                className: "text-sm",
                                children: "Enter your service access token:"
                            }), (0, w.jsx)("div", {
                                className: "mt-2",
                                children: (0, w.jsx)(tk, {
                                    ref: b,
                                    name: "serviceToken",
                                    placeholder: "Service access token",
                                    autoComplete: "off",
                                    onPressEnter: E,
                                    autoFocus: !0
                                })
                            })]
                        }), F && !D && (0, w.jsxs)("div", {
                            children: [(0, w.jsx)("div", {
                                className: "text-sm",
                                children: "Enter your OAuth credentials:"
                            }), (0, w.jsx)("div", {
                                className: "mt-2",
                                children: (0, w.jsx)(tk, {
                                    ref: y,
                                    name: "clientId",
                                    placeholder: "Client ID",
                                    autoComplete: "off",
                                    onPressEnter: E,
                                    autoFocus: !0
                                })
                            }), (0, w.jsx)("div", {
                                className: "mt-2",
                                children: (0, w.jsx)(tk, {
                                    ref: k,
                                    type: "password",
                                    name: "clientSecret",
                                    placeholder: "Client secret",
                                    autoComplete: "off",
                                    onPressEnter: E
                                })
                            })]
                        }), h && (0, w.jsx)(ot, {
                            children: h
                        })]
                    })
                })
            }

            function oo(e) {
                var t = e.plugin,
                    n = e.manifestAccessToken,
                    r = e.verificationTokens,
                    a = e.onReadyToInstall,
                    i = e.onClose,
                    o = (0, j._)((0, _.useState)(), 2),
                    s = o[0],
                    l = o[1],
                    u = (0, j._)((0, _.useState)(!1), 2),
                    d = u[0],
                    c = u[1],
                    f = (0, _.useCallback)((0, eG._)(function() {
                        var e, i;
                        return (0, e$.__generator)(this, function(o) {
                            switch (o.label) {
                                case 0:
                                    return o.trys.push([0, 2, 3, 4]), c(!0), [4, P.ZP.scrapePluginManifest({
                                        domain: t.domain,
                                        manifestAccessToken: n
                                    })];
                                case 1:
                                    if (e = o.sent().plugin) {
                                        for (var s in i = "service_http" === e.manifest.auth.type || "oauth" === e.manifest.auth.type ? e.manifest.auth.verification_tokens : {}, r)
                                            if (r[s] !== i[s]) return l('Please add the "'.concat(s, '" token to your manifest file.')), [2];
                                        a(e)
                                    } else l("Error creating plugin.");
                                    return [3, 4];
                                case 2:
                                    return o.sent(), l("Error creating plugin."), [3, 4];
                                case 3:
                                    return c(!1), [7];
                                case 4:
                                    return [2]
                            }
                        })
                    }), [t, n, r, a]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: i,
                    type: "success",
                    title: "Add verification token",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Verify tokens",
                        color: "primary",
                        onClick: f,
                        loading: d
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "I'll add the tokens later",
                        color: "neutral",
                        onClick: i
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [(0, w.jsx)(t8, {
                            plugin: t
                        }), (0, w.jsx)("div", {
                            className: "text-sm",
                            children: "Add the following verification tokens to your manifest file:"
                        }), (0, w.jsx)("pre", {
                            className: "text-sm",
                            children: JSON.stringify(r, null)
                        }), s && (0, w.jsx)(ot, {
                            children: s
                        })]
                    })
                })
            }

            function os(e) {
                var t = e.plugin,
                    n = e.onClickInstall,
                    r = e.onClose,
                    a = (0, _.useCallback)(function() {
                        n(t)
                    }, [t, n]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: r,
                    type: "success",
                    title: "Ready to install",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Install for me",
                        color: "primary",
                        onClick: a
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Install later",
                        color: "neutral",
                        onClick: r
                    }),
                    children: (0, w.jsx)(oe, {
                        children: (0, w.jsxs)("div", {
                            className: "text-sm",
                            children: ["Your unverified plugin can now be installed by", " ", (0, w.jsx)("a", {
                                href: "https://platform.openai.com/docs/plugins/production/can-i-invite-people-to-try-my-plugin",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-green-600",
                                children: "up to 15 developers"
                            }), ". Once ", "you're", " ready to make your plugin available to everyone, you can", " ", (0, w.jsx)("a", {
                                href: "https://platform.openai.com/docs/plugins/review/submit-a-plugin-for-review",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-green-600",
                                children: "submit your plugin for review"
                            }), "."]
                        })
                    })
                })
            }

            function ol(e) {
                var t = e.onConfirm,
                    n = e.onClose;
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: n,
                    type: "success",
                    title: "Unverified plugin",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Continue",
                        color: "primary",
                        onClick: t
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: n
                    }),
                    children: (0, w.jsx)(oe, {
                        children: (0, w.jsx)(i7.I, {
                            children: (0, w.jsx)(i7.Z, {
                                icon: "\uD83D\uDEA8",
                                children: "OpenAI hasn't vetted this plugin. This plugin may pose risks to your information. Be sure you trust this plugin before proceeding."
                            })
                        })
                    })
                })
            }

            function ou(e) {
                var t = e.plugin,
                    n = e.onInstall,
                    r = e.onClose,
                    a = (0, j._)((0, _.useState)(!1), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)(t), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, _.useCallback)(function() {
                        o(!0)
                    }, []);
                return l ? i ? (0, w.jsx)(oc, {
                    plugin: l,
                    onInstall: n,
                    onClose: r
                }) : (0, w.jsx)(ol, {
                    onConfirm: d,
                    onClose: r
                }) : (0, w.jsx)(od, {
                    onLoad: u,
                    onClose: r
                })
            }

            function od(e) {
                var t = e.onLoad,
                    n = e.onClose,
                    r = (0, _.useRef)(null),
                    a = (0, j._)((0, _.useState)(!1), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)(), 2),
                    l = s[0],
                    u = s[1];
                (0, _.useEffect)(function() {
                    setTimeout(function() {
                        var e;
                        null === (e = r.current) || void 0 === e || e.focus()
                    }, 50)
                }, []);
                var d = (0, _.useCallback)((0, eG._)(function() {
                    var e, n, a;
                    return (0, e$.__generator)(this, function(i) {
                        switch (i.label) {
                            case 0:
                                if (!(n = null === (e = r.current) || void 0 === e ? void 0 : e.value)) return u("Please provide a URL."), [2];
                                if (tG(n)) return u('To add a localhost plugin, please go to "Develop your own plugin."'), [2];
                                i.label = 1;
                            case 1:
                                return i.trys.push([1, 3, 4, 5]), o(!0), [4, P.ZP.getPluginByDomain({
                                    domain: n
                                })];
                            case 2:
                                return (a = i.sent()) ? t(a) : u("That plugin doesn't exist."), [3, 5];
                            case 3:
                                return i.sent(), u("Couldn't find plugin."), [3, 5];
                            case 4:
                                return o(!1), [7];
                            case 5:
                                return [2]
                        }
                    })
                }), [t, o, u]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: n,
                    type: "success",
                    title: "Install an unverified plugin",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Find plugin",
                        color: "primary",
                        onClick: d,
                        loading: i
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: n
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [(0, w.jsx)("div", {
                            children: "Please provide the website domain of the unverified plugin you'd like to install."
                        }), (0, w.jsx)(tk, {
                            ref: r,
                            name: "url",
                            placeholder: "openai.com",
                            onPressEnter: d
                        }), l && (0, w.jsx)(ot, {
                            children: l
                        })]
                    })
                })
            }

            function oc(e) {
                var t = e.plugin,
                    n = e.onInstall,
                    r = e.onClose,
                    a = (0, j._)((0, _.useState)(), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)(!1), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, _.useRef)(null),
                    c = tK({
                        onSuccess: function(e) {
                            n(e), r()
                        },
                        onError: function(e) {
                            o("Couldn't install plugin.")
                        }
                    }),
                    f = (0, B.hz)(),
                    g = t.manifest.name_for_human,
                    h = "user_http" === t.manifest.auth.type,
                    m = "oauth" === t.manifest.auth.type,
                    p = (0, _.useCallback)((0, eG._)(function() {
                        var e, n;
                        return (0, e$.__generator)(this, function(r) {
                            switch (r.label) {
                                case 0:
                                    if (!m) return [3, 1];
                                    if (f.has("new_plugin_oauth_endpoint")) return t1(t), [2];
                                    return (e = t3(t)) ? window.location.href = e : o("Missing plugin configuration for ".concat(g, ".")), [3, 8];
                                case 1:
                                    if (!h) return [3, 7];
                                    if (!(null === (n = d.current) || void 0 === n ? void 0 : n.value)) return o("Please provide your credentials."), [2];
                                    r.label = 2;
                                case 2:
                                    return r.trys.push([2, 4, 5, 6]), u(!0), [4, P.ZP.setPluginUserHttpToken({
                                        id: t.id,
                                        userAccessToken: d.current.value
                                    })];
                                case 3:
                                    return r.sent(), c(t.id), [3, 6];
                                case 4:
                                    return r.sent(), o("Couldn't install plugin."), [3, 6];
                                case 5:
                                    return u(!1), [7];
                                case 6:
                                    return [3, 8];
                                case 7:
                                    try {
                                        u(!0), c(t.id)
                                    } catch (e) {
                                        o("Couldn't install plugin.")
                                    } finally {
                                        u(!1)
                                    }
                                    r.label = 8;
                                case 8:
                                    return [2]
                            }
                        })
                    }), [f, t, g, m, h, c]);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: r,
                    type: "success",
                    title: "Unverified plugin",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: m ? "Log in with ".concat(g) : "Install plugin",
                        color: "primary",
                        onClick: p,
                        loading: l
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: r
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [(0, w.jsx)(t8, {
                            plugin: t
                        }), h && (0, w.jsxs)("div", {
                            children: [(0, w.jsx)("div", {
                                className: "text-sm",
                                children: t.manifest.auth.instructions || "Enter your HTTP access token below:"
                            }), (0, w.jsx)("div", {
                                className: "mt-2",
                                children: (0, w.jsx)(tk, {
                                    ref: d,
                                    type: "password",
                                    name: "token",
                                    placeholder: "Enter your credentials",
                                    autoComplete: "off",
                                    onPressEnter: p
                                })
                            })]
                        }), m && (0, w.jsxs)("div", {
                            children: ["You will be redirected to", " ", (0, w.jsx)("span", {
                                className: "font-medium",
                                children: g
                            }), " to log in."]
                        }), i && (0, w.jsx)(ot, {
                            children: i
                        })]
                    })
                })
            }
            var of = n(96237), og = n(89678), oh = n.n(og);
            (l = p || (p = {}))[l.All = 0] = "All", l[l.Installed = 1] = "Installed", (u = v || (v = {})).New = "newly_added", u.Popular = "most_popular";
            var om = [{
                id: v.Popular,
                title: "Popular"
            }, {
                id: v.New,
                title: "New"
            }, {
                id: p.All,
                title: "All"
            }, {
                id: p.Installed,
                title: "Installed"
            }];

            function op(e) {
                var t = e.page,
                    n = e.numPages,
                    r = e.goToPage,
                    a = t > 0,
                    i = t < n - 1,
                    o = (0, _.useCallback)(function() {
                        r(Math.max(t - 1, 0))
                    }, [t, r]),
                    s = (0, _.useCallback)(function() {
                        r(Math.min(t + 1, n - 1))
                    }, [t, n, r]),
                    l = [],
                    u = !0,
                    d = !1,
                    c = void 0;
                try {
                    for (var f, g = (function(e, t) {
                            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10,
                                r = Math.max(0, t - n + 1);
                            if (0 === r) return ov(0, t);
                            var a = ov(0, e),
                                i = ov(e + 1, t);
                            if (r < i.length - 1) i.splice(Math.floor((i.length - r) / 2), r, -1);
                            else if (r < a.length - 1) a.splice(Math.floor((a.length - r) / 2), r, -1);
                            else {
                                var o = Math.min(i.length - 3, r),
                                    s = r - o + 1;
                                i.splice(Math.floor((i.length - o) / 2), o, -1), a.splice(Math.floor((a.length - s) / 2), s, -2)
                            }
                            return (0, te._)(a).concat([e], (0, te._)(i))
                        })(t, n)[Symbol.iterator](); !(u = (f = g.next()).done); u = !0) ! function() {
                        var e = f.value;
                        e < 0 ? l.push((0, w.jsx)("div", {
                            role: "button",
                            className: "flex h-5 w-5 items-center justify-center",
                            children: "…"
                        }, "ellipsis-".concat(e))) : l.push((0, w.jsx)(oI, {
                            role: "button",
                            className: (0, G.Z)("flex h-5 w-5 items-center justify-center", e === t && "text-blue-600 hover:text-blue-600 dark:text-blue-600 dark:hover:text-blue-600"),
                            onClick: function() {
                                return r(e)
                            },
                            children: e + 1
                        }, e))
                    }()
                } catch (e) {
                    d = !0, c = e
                } finally {
                    try {
                        u || null == g.return || g.return()
                    } finally {
                        if (d) throw c
                    }
                }
                return (0, w.jsxs)("div", {
                    className: "flex flex-wrap gap-2 text-sm text-black/60 dark:text-white/70",
                    children: [(0, w.jsxs)(oI, {
                        role: "button",
                        className: (0, G.Z)("flex items-center", !a && "opacity-50"),
                        onClick: o,
                        $disabled: !a,
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.YFh
                        }), "Prev"]
                    }), l, (0, w.jsxs)(oI, {
                        role: "button",
                        className: (0, G.Z)("flex items-center", !i && "opacity-50"),
                        onClick: s,
                        $disabled: !i,
                        children: ["Next", (0, w.jsx)(eh.ZP, {
                            icon: M.Tfp
                        })]
                    })]
                })
            }

            function ov(e, t) {
                return Array.from({
                    length: t - e
                }, function(t, n) {
                    return n + e
                })
            }

            function ox(e) {
                var t = e.onClose,
                    n = tj().setupMfa;
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: t,
                    type: "success",
                    title: "Enable two-factor authentication",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Enable two-factor authentication",
                        color: "primary",
                        onClick: n
                    }),
                    secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: t
                    }),
                    children: (0, w.jsx)(oe, {
                        children: (0, w.jsx)(i7.I, {
                            children: (0, w.jsx)(i7.Z, {
                                icon: "\uD83D\uDEA8",
                                children: "This plugin requires you to have two-factor authentication enabled for additional security. Please set up two-factor authentication and try again."
                            })
                        })
                    })
                })
            }

            function ob() {
                var e = (0, Q._)(["text-sm text-black/70 dark:text-white/70 whitespace-nowrap ", ""]);
                return ob = function() {
                    return e
                }, e
            }

            function oy() {
                var e = (0, Q._)(["hidden h-4 border-l border-black/30 dark:border-white/30 sm:block"]);
                return oy = function() {
                    return e
                }, e
            }
            var oj = (x = {}, (0, of ._)(x, U._G.Mobile, 8), (0, of ._)(x, U._G.Small, 4), (0, of ._)(x, U._G.Medium, 4), (0, of ._)(x, U._G.Large, 6), (0, of ._)(x, U._G.XLarge, 8), x),
                ow = (0, N.vU)({
                    searchPlaceholder: {
                        id: "PluginStoreModal.searchPlaceholder",
                        defaultMessage: "Search plugins",
                        description: "Placeholder text for the plugin store search bar"
                    },
                    noSearchResultsTitle: {
                        id: "PluginStoreModal.noSearchResults",
                        defaultMessage: 'No plugins found for "{query}"',
                        description: "Message shown when no plugins are found for a search query"
                    },
                    noSearchResultsHint: {
                        id: "PluginStoreModal.noSearchResultsHint",
                        defaultMessage: "Try a different query or category",
                        description: "Hint shown when no plugins are found for a search query"
                    },
                    installUnverifiedPlugin: {
                        id: "PluginStoreModal.installUnverifiedPlugin",
                        defaultMessage: "Install an unverified plugin",
                        description: "Link to dialog to install an unverified plugin"
                    },
                    developPlugin: {
                        id: "PluginStoreModal.developPlugin",
                        defaultMessage: "Develop your own plugin",
                        description: "Link to dialog to develop your own plugin"
                    },
                    aboutPlugins: {
                        id: "PluginStoreModal.aboutPlugins",
                        defaultMessage: "About plugins",
                        description: "Link to learn more about plugins"
                    }
                }),
                oC = v.Popular;

            function ok(e) {
                var t, n, r, a = e.onInstallWithAuthRequired,
                    i = e.onClickInstallDeveloper,
                    o = e.onClickDevelop,
                    s = e.onClickAbout,
                    l = e.onClose,
                    u = (0, ei.Z)(),
                    d = (0, B.hz)(),
                    c = (0, j._)((0, _.useState)(oC), 2),
                    f = c[0],
                    g = c[1],
                    h = (0, j._)((0, _.useState)(""), 2),
                    m = h[0],
                    v = h[1],
                    x = (0, j._)((0, _.useState)(""), 2),
                    y = x[0],
                    C = x[1],
                    k = (n = (t = (0, tJ.C)()).isLoading, r = t.installedPlugins, {
                        availableFilters: (0, _.useMemo)(function() {
                            return om.filter(function(e) {
                                return e.id !== p.Installed || r.length > 0
                            })
                        }, [r]),
                        isLoading: n
                    }).availableFilters;
                (0, _.useEffect)(function() {
                    k.some(function(e) {
                        return e.id === f
                    }) || g(oC)
                }, [f, k]);
                var N = (0, _.useCallback)(oh()(function(e) {
                    C(e)
                }, 300), []);
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: l,
                    size: "custom",
                    className: "w-full max-w-7xl bg-gray-50 md:min-w-[672px] lg:min-w-[896px] xl:min-w-[1024px]",
                    type: "success",
                    title: "Plugin store",
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: l
                    }),
                    children: (0, w.jsxs)(oe, {
                        children: [k.length > 1 && (0, w.jsxs)("div", {
                            className: "flex flex-wrap gap-3",
                            children: [k.map(function(e) {
                                return (0, w.jsx)(oM, {
                                    selected: f === e.id,
                                    onClick: function() {
                                        g(e.id)
                                    },
                                    children: e.title
                                }, e.id)
                            }), (0, w.jsxs)("div", {
                                className: "relative",
                                children: [(0, w.jsx)("div", {
                                    className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3",
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M.jRj,
                                        className: "h-5 w-5 text-gray-500 dark:text-gray-400"
                                    })
                                }), (0, w.jsx)(tk, {
                                    className: "pl-10",
                                    autoFocus: !0,
                                    type: "search",
                                    placeholder: u.formatMessage(ow.searchPlaceholder),
                                    value: m,
                                    onChange: function(e) {
                                        v(e.target.value), g(p.All), N(e.target.value)
                                    },
                                    name: "search"
                                })]
                            })]
                        }), (0, w.jsx)(o_, {
                            filter: f,
                            query: y,
                            onInstallWithAuthRequired: a,
                            children: (0, w.jsxs)("div", {
                                className: "flex flex-col items-center gap-2 sm:flex-row",
                                children: [d.has("tools3_dev") && (0, w.jsxs)(w.Fragment, {
                                    children: [(0, w.jsx)(oI, {
                                        onClick: i,
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, ow.installUnverifiedPlugin))
                                    }), (0, w.jsx)(oZ, {}), (0, w.jsx)(oI, {
                                        onClick: o,
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, ow.developPlugin))
                                    }), (0, w.jsx)(oZ, {})]
                                }), (0, w.jsx)(oI, {
                                    onClick: s,
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, ow.aboutPlugins))
                                })]
                            })
                        })]
                    })
                })
            }

            function o_(e) {
                var t = e.filter,
                    n = e.query,
                    r = e.onInstallWithAuthRequired,
                    a = e.children,
                    i = oj[(0, U.dQ)()],
                    o = (0, j._)((0, _.useState)(0), 2),
                    s = o[0],
                    l = o[1],
                    u = function(e) {
                        var t = e.filter,
                            n = e.query,
                            r = e.page,
                            a = e.pageSize,
                            i = (0, tY.Z)({
                                category: function(e) {
                                    if (e !== p.All && e !== p.Installed) return e
                                }(t),
                                search: n,
                                offset: a * r,
                                limit: a
                            }),
                            o = i.data,
                            s = i.isLoading,
                            l = (0, tJ.C)(),
                            u = l.installedPlugins,
                            d = l.isLoading,
                            c = (0, _.useMemo)(function() {
                                return "" !== n ? u.map(function(e) {
                                    return {
                                        plugin: e,
                                        score: function(e, t) {
                                            var n = t.toLowerCase(),
                                                r = n.trim().split(/\s+/),
                                                a = e.manifest.description_for_human.toLowerCase(),
                                                i = e.manifest.name_for_human.toLowerCase(),
                                                o = 0;
                                            if (i === n || e.domain.toLowerCase() === n) return 1e3;
                                            if (i.startsWith(n)) return 500;
                                            if (i.includes(n)) return 100;
                                            var s = !0,
                                                l = !1,
                                                u = void 0;
                                            try {
                                                for (var d, c = r[Symbol.iterator](); !(s = (d = c.next()).done); s = !0) {
                                                    var f = d.value;
                                                    if (i.startsWith(f)) o += 50;
                                                    else if (i.includes(f)) o += 10;
                                                    else {
                                                        if (!a.includes(f)) return 0;
                                                        o += 1
                                                    }
                                                }
                                            } catch (e) {
                                                l = !0, u = e
                                            } finally {
                                                try {
                                                    s || null == c.return || c.return()
                                                } finally {
                                                    if (l) throw u
                                                }
                                            }
                                            return o
                                        }(e, n)
                                    }
                                }).filter(function(e) {
                                    return e.score > 0
                                }).sort(function(e, t) {
                                    return t.score - e.score
                                }).map(function(e) {
                                    return e.plugin
                                }) : u.sort(function(e, t) {
                                    return e.manifest.name_for_human.localeCompare(t.manifest.name_for_human)
                                })
                            }, [u, n]);
                        if (t === p.Installed) {
                            var f, g, h, m, v, x, b = (g = (f = {
                                page: r,
                                items: c,
                                pageSize: a
                            }).page, h = f.items, m = f.pageSize, v = Math.ceil(h.length / m), x = g * m, {
                                pagesTotal: v,
                                pageItems: h.slice(x, x + m)
                            });
                            return {
                                isLoading: d,
                                items: b.pageItems,
                                pagesTotal: b.pagesTotal
                            }
                        }
                        var y = null != o ? o : {
                                count: void 0,
                                items: void 0
                            },
                            j = y.count;
                        return {
                            isLoading: s,
                            items: y.items,
                            pagesTotal: void 0 !== j ? Math.ceil(j / a) : void 0
                        }
                    }({
                        pageSize: i,
                        filter: t,
                        query: n,
                        page: s
                    }),
                    d = u.isLoading,
                    c = u.items,
                    f = u.pagesTotal;
                (0, _.useEffect)(function() {
                    l(0)
                }, [t, n]);
                var g = (0, j._)((0, _.useState)(!1), 2),
                    h = g[0],
                    m = g[1];
                return h ? (0, w.jsx)(ox, {
                    onClose: function() {
                        m(!1)
                    }
                }) : (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(oT, {
                        plugins: null != c ? c : [],
                        numSkeletons: i,
                        query: n,
                        isLoading: d,
                        onInstallWithAuthRequired: r,
                        onRequestMfa: function() {
                            return m(!0)
                        }
                    }), (0, w.jsxs)("div", {
                        className: "flex flex-col flex-wrap items-center justify-center gap-6 sm:flex-row md:justify-between",
                        children: [(0, w.jsx)("div", {
                            className: "flex flex-1 justify-start max-lg:justify-center",
                            children: void 0 !== f && f > 1 && (0, w.jsx)(op, {
                                page: s,
                                numPages: f,
                                goToPage: l
                            })
                        }), a]
                    })]
                })
            }

            function oM(e) {
                var t = e.selected,
                    n = e.onClick,
                    r = e.children;
                return (0, w.jsx)(ec.z, {
                    color: t ? "light" : "neutral",
                    className: (0, G.Z)("focus:ring-0", t && "hover:bg-gray-200", !t && "text-black/50"),
                    onClick: n,
                    children: r
                })
            }

            function oT(e) {
                var t = e.plugins,
                    n = e.numSkeletons,
                    r = e.isLoading,
                    a = e.onInstallWithAuthRequired,
                    i = e.onRequestMfa,
                    o = e.query;
                if (0 === t.length && !r && o) return (0, w.jsxs)("div", {
                    className: "flex h-[404px] flex-col items-center justify-center gap-4",
                    children: [(0, w.jsx)("div", {
                        className: "text-lg font-medium",
                        children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, ow.noSearchResultsTitle), {
                            values: {
                                query: o
                            }
                        }))
                    }), (0, w.jsx)("div", {
                        className: "text-sm text-black/50",
                        children: (0, w.jsx)(T.Z, (0, b._)({}, ow.noSearchResultsHint))
                    })]
                });
                var s = r ? Array(n).fill(0).map(function(e, t) {
                    return (0, w.jsx)(oP, {}, t)
                }) : t.map(function(e) {
                    return (0, w.jsx)(oN, {
                        plugin: e,
                        onInstallWithAuthRequired: a,
                        onRequestMfa: i
                    }, e.id)
                });
                return (0, w.jsx)("div", {
                    className: "grid grid-cols-1 gap-3 sm:grid-cols-2 sm:grid-rows-2 lg:grid-cols-3 xl:grid-cols-4",
                    children: s
                })
            }

            function oN(e) {
                var t, n, r, a, i, o, s, l, u = e.plugin,
                    d = e.onInstallWithAuthRequired,
                    c = e.onRequestMfa,
                    f = (0, j._)((0, _.useState)(!1), 2),
                    g = f[0],
                    h = f[1],
                    m = (0, j._)((0, _.useState)(!1), 2),
                    p = m[0],
                    v = m[1],
                    x = tK({
                        onSuccess: function(e) {
                            ns(e.id)
                        },
                        onError: function(e) {
                            console.error(e), tl.m.danger("Error installing ".concat(u.manifest.name_for_human, "."))
                        },
                        onSettled: function() {
                            h(!1)
                        }
                    }),
                    b = (n = (t = {
                        onSuccess: function() {},
                        onError: function(e) {
                            console.error(e), tl.m.danger("Error uninstalling ".concat(u.manifest.name_for_human, "."))
                        },
                        onSettled: function() {
                            v(!1)
                        }
                    }).onSuccess, r = t.onError, a = t.onSettled, i = (0, C.NL)(), o = (0, tt.D)(P.ZP.updatePluginUserSettings.bind(P.ZP), {
                        onSuccess: function(e) {
                            (function(e, t) {
                                var n = tJ.Z;
                                t.setQueryData(n, function(t) {
                                    var n = (0, te._)((null == t ? void 0 : t.items) || []),
                                        r = n.findIndex(function(t) {
                                            return t.id === e.id
                                        });
                                    return -1 !== r && n.splice(r, 1), {
                                        count: n.length,
                                        items: n
                                    }
                                })
                            })(e, i), t0(e, i), n(e)
                        },
                        onError: r,
                        onSettled: a
                    }).mutate, (0, _.useCallback)(function(e) {
                        o({
                            pluginId: e,
                            isInstalled: !1
                        })
                    }, [o])),
                    y = (0, ev.kP)().session,
                    k = (0, B.hz)(),
                    T = tj().isUsernamePassword,
                    N = (0, _.useCallback)(function() {
                        var e, t = u.manifest.auth.type;
                        if (!("none" === t || "service_http" === t) && !(null == y ? void 0 : null === (e = y.user) || void 0 === e ? void 0 : e.mfa) && k.has(eu.i) && T) {
                            c();
                            return
                        }
                        if ("oauth" === t) {
                            if (k.has("new_plugin_oauth_endpoint")) {
                                t1(u);
                                return
                            }
                            var n = t3(u);
                            n ? window.location.href = n : tl.m.danger("Missing plugin configuration for ".concat(u.manifest.name_for_human, "."))
                        } else "user_http" === t ? d(u) : (h(!0), x(u.id))
                    }, [u, x, d, c, T, y, k]),
                    S = (0, _.useCallback)(function() {
                        v(!0), b(u.id)
                    }, [u, b]);
                return l = g || p ? (0, w.jsxs)(ec.z, {
                    color: "light",
                    className: "bg-green-100 hover:bg-green-100",
                    children: [g ? "Installing" : "Uninstalling", (0, w.jsx)(em.Z, {})]
                }) : (null === (s = u.user_settings) || void 0 === s ? void 0 : s.is_installed) ? (0, w.jsxs)(ec.z, {
                    color: "light",
                    className: "hover:bg-gray-200",
                    onClick: S,
                    children: ["Uninstall", (0, w.jsx)(eh.ZP, {
                        icon: M.$Rx
                    })]
                }) : (0, w.jsxs)(ec.z, {
                    onClick: N,
                    children: ["Install", (0, w.jsx)(eh.ZP, {
                        icon: M.wzc
                    })]
                }), (0, w.jsx)(oS, {
                    logo: (0, w.jsx)(t4.Z, {
                        url: u.manifest.logo_url,
                        name: u.manifest.name_for_human,
                        size: "100%",
                        large: !0
                    }),
                    tag: tQ(u) ? (0, w.jsx)(ap, {}) : "approved" !== u.status ? (0, w.jsx)(am, {}) : void 0,
                    title: (0, w.jsx)("div", {
                        className: "max-w-full truncate text-lg leading-6",
                        children: u.manifest.name_for_human
                    }),
                    button: l,
                    description: u.manifest.description_for_human
                })
            }

            function oP() {
                return (0, w.jsx)(oS, {
                    logo: (0, w.jsx)("div", {
                        className: "h-full w-full rounded-[5px] bg-gray-300"
                    }),
                    title: (0, w.jsx)("div", {
                        className: "h-[19px] w-[103px] rounded-[5px] bg-gray-100"
                    }),
                    button: (0, w.jsx)("div", {
                        className: "h-[36px] w-[103px] rounded-[5px] bg-gray-200"
                    }),
                    description: (0, w.jsxs)("div", {
                        className: "flex flex-col gap-1.5",
                        children: [(0, w.jsx)("div", {
                            className: "h-[14px] w-[209px] rounded-[5px] bg-gray-100"
                        }), (0, w.jsx)("div", {
                            className: "h-[14px] w-[218px] rounded-[5px] bg-gray-100"
                        }), (0, w.jsx)("div", {
                            className: "h-[14px] w-[184px] rounded-[5px] bg-gray-100"
                        })]
                    })
                })
            }

            function oS(e) {
                var t = e.logo,
                    n = e.tag,
                    r = e.title,
                    a = e.button,
                    i = e.description;
                return (0, w.jsxs)("div", {
                    className: "flex flex-col gap-4 rounded border border-black/10 bg-white p-6 dark:border-white/20 dark:bg-gray-900",
                    children: [(0, w.jsxs)("div", {
                        className: "flex gap-4",
                        children: [(0, w.jsx)("div", {
                            className: "h-[70px] w-[70px] shrink-0",
                            children: t
                        }), (0, w.jsxs)("div", {
                            className: "flex min-w-0 flex-col items-start justify-between",
                            children: [n ? (0, w.jsxs)("div", {
                                className: "flex items-center gap-1.5",
                                children: [n, r]
                            }) : r, a]
                        })]
                    }), (0, w.jsx)("div", {
                        className: "h-[60px] text-sm text-black/70 line-clamp-3 dark:text-white/70",
                        children: i
                    })]
                })
            }
            var oI = eo.Z.button(ob(), function(e) {
                    return e.$disabled ? "opacity-50 cursor-default" : "hover:text-black/50 dark:hover:text-white/50"
                }),
                oZ = eo.Z.div(oy());

            function oF(e) {
                var t = e.allowClose,
                    n = e.onConfirm,
                    r = e.onClose;
                return (0, w.jsx)(eg.Z, {
                    isOpen: !0,
                    onClose: r,
                    type: "success",
                    title: "About plugins",
                    primaryButton: (0, w.jsx)(ef.ZP.Button, {
                        title: "OK",
                        color: "primary",
                        onClick: n
                    }),
                    secondaryButton: t && (0, w.jsx)(ef.ZP.Button, {
                        title: "Cancel",
                        color: "neutral",
                        onClick: r
                    }),
                    children: (0, w.jsx)(oe, {
                        children: (0, w.jsxs)(i7.I, {
                            children: [(0, w.jsx)(i7.Z, {
                                icon: "\uD83D\uDEA8",
                                children: "Plugins are powered by third party applications that are not controlled by OpenAI. Be sure you trust a plugin before installation."
                            }), (0, w.jsx)(i7.Z, {
                                icon: "\uD83C\uDF10",
                                children: "Plugins connect ChatGPT to external apps. If you enable a plugin, ChatGPT may send your conversation, Custom Instructions, and the country or state you're in to the plugin."
                            }), (0, w.jsx)(i7.Z, {
                                icon: "\uD83E\uDDE0",
                                children: "ChatGPT automatically chooses when to use plugins during a conversation, depending on the plugins you've enabled."
                            })]
                        })
                    })
                })
            }
            var oD = "oai/apps/hasSeenPluginsDisclaimer";

            function oE(e) {
                var t = e.onInstall,
                    n = e.onClose,
                    r = (0, j._)((0, _.useState)(!!ex.m.getItem(oD)), 2),
                    a = r[0],
                    i = r[1],
                    o = (0, j._)((0, _.useState)(!1), 2),
                    s = o[0],
                    l = o[1],
                    u = (0, j._)((0, _.useState)(!1), 2),
                    d = u[0],
                    c = u[1],
                    f = (0, j._)((0, _.useState)(), 2),
                    g = f[0],
                    h = f[1],
                    m = (0, j._)((0, _.useState)(!1), 2),
                    p = m[0],
                    v = m[1],
                    x = (0, _.useCallback)(function() {
                        i(!0), l(!1), ex.m.setItem(oD, !0)
                    }, []),
                    b = (0, _.useCallback)(function(e) {
                        h(e), c(!0)
                    }, []),
                    y = (0, _.useCallback)(function() {
                        c(!0)
                    }, []),
                    C = (0, _.useCallback)(function() {
                        v(!0)
                    }, []),
                    k = (0, _.useCallback)(function() {
                        l(!0)
                    }, []),
                    M = (0, _.useCallback)(function(e) {
                        ns(e.id), n(), t(e)
                    }, [t, n]),
                    T = (0, _.useCallback)(function() {
                        h(void 0), c(!1), n()
                    }, [n]),
                    N = (0, _.useCallback)(function() {
                        v(!1), n()
                    }, [n]);
                return !a || s ? (0, w.jsx)(oF, {
                    allowClose: !a,
                    onConfirm: x,
                    onClose: n
                }) : d ? (0, w.jsx)(ou, {
                    plugin: g,
                    onInstall: M,
                    onClose: T
                }) : p ? (0, w.jsx)(on, {
                    onClickInstall: b,
                    onInstallLocalhost: M,
                    onClose: N
                }) : (0, w.jsx)(ok, {
                    onInstallWithAuthRequired: b,
                    onClickInstallDeveloper: y,
                    onClickDevelop: C,
                    onClickAbout: k,
                    onClose: n
                })
            }

            function oR() {
                var e = (0, Q._)(["flex h-8 flex-shrink-0 items-center justify-center border-b border-black/10 bg-gray-50 text-xs text-gray-800 dark:border-white/20 dark:bg-[#272832] dark:text-white"]);
                return oR = function() {
                    return e
                }, e
            }

            function oB(e) {
                var t, n = e.theme,
                    r = void 0 === n ? "default" : n,
                    a = (0, j._)((0, _.useState)(!1), 2),
                    i = a[0],
                    o = a[1],
                    s = (0, j._)((0, _.useState)(!1), 2),
                    l = s[0],
                    u = s[1],
                    d = (0, k.useRouter)(),
                    c = (0, tJ.C)(),
                    f = c.installedPlugins,
                    g = c.isLoading,
                    h = ni(),
                    m = (0, _.useRef)(null);
                (0, _.useEffect)(function() {
                    if (!g) {
                        var e = d.query,
                            t = e.loginAip,
                            n = e.loginSuccess,
                            r = (0, y._)(e, ["loginAip", "loginSuccess"]);
                        if (t) {
                            var a, i, o = f.find(function(e) {
                                return e.id === t
                            });
                            o && "true" === n ? (ns(d.query.loginAip), null === (a = m.current) || void 0 === a || a.open()) : tl.m.warning("Couldn't log in with ".concat(null !== (i = null == o ? void 0 : o.manifest.name_for_human) && void 0 !== i ? i : "plugin", ".")), d.replace({
                                pathname: d.pathname,
                                query: r
                            })
                        }
                    }
                }, [d, f, g]);
                var p = (0, _.useCallback)(function() {
                        var e;
                        null === (e = m.current) || void 0 === e || e.open()
                    }, []),
                    v = (0, _.useCallback)(function() {
                        o(!1)
                    }, []),
                    x = (0, j._)((0, _.useState)(h), 2),
                    b = x[0],
                    C = x[1],
                    T = (0, _.useCallback)(function(e) {
                        if (e.length > 3) u(!0), setTimeout(function() {
                            u(!1)
                        }, 600);
                        else {
                            var t = e.filter(function(e) {
                                    return !h.find(function(t) {
                                        return t.id === e.id
                                    })
                                }),
                                n = !0,
                                r = !1,
                                a = void 0;
                            try {
                                for (var i, o = nn[Symbol.iterator](); !(n = (i = o.next()).done); n = !0) {
                                    var s = function() {
                                        var e = i.value,
                                            n = h.find(function(t) {
                                                return e.includes(t.domain)
                                            });
                                        if (n) {
                                            var r = e.find(function(e) {
                                                    return e !== n.domain
                                                }),
                                                a = t.find(function(e) {
                                                    return e.domain === r
                                                });
                                            if (a) return tl.m.warning("You can't enable ".concat(a.manifest.name_for_human, " while ").concat(n.manifest.name_for_human, " is enabled.")), {
                                                v: void 0
                                            }
                                        }
                                    }();
                                    if ("object" === (0, r4._)(s)) return s.v
                                }
                            } catch (e) {
                                r = !0, a = e
                            } finally {
                                try {
                                    n || null == o.return || o.return()
                                } finally {
                                    if (r) throw a
                                }
                            }
                            no(e.map(function(e) {
                                return e.id
                            }))
                        }
                    }, [h]),
                    N = (0, _.useCallback)(function(e) {
                        var t;
                        null === (t = m.current) || void 0 === t || t.close(), "store" === e && o(!0)
                    }, []),
                    P = (0, _.useCallback)(function() {
                        C(h), rC.m.logEvent("chatgpt_plugin_chooser_opened", null, {
                            num_enabled_plugins: "".concat(h.length)
                        })
                    }, [h]),
                    S = (0, _.useCallback)(function() {
                        var e = b.filter(function(e) {
                                return !h.find(function(t) {
                                    return t.id === e.id
                                })
                            }),
                            t = h.filter(function(e) {
                                return !b.find(function(t) {
                                    return t.id === e.id
                                })
                            }),
                            n = !0,
                            r = !1,
                            a = void 0;
                        try {
                            for (var i, o = t[Symbol.iterator](); !(n = (i = o.next()).done); n = !0) {
                                var s = i.value;
                                rC.m.logEvent("chatgpt_plugin_enabled", null, {
                                    plugin_id: s.id
                                })
                            }
                        } catch (e) {
                            r = !0, a = e
                        } finally {
                            try {
                                n || null == o.return || o.return()
                            } finally {
                                if (r) throw a
                            }
                        }
                        var l = !0,
                            u = !1,
                            d = void 0;
                        try {
                            for (var c, f = e[Symbol.iterator](); !(l = (c = f.next()).done); l = !0) {
                                var g = c.value;
                                rC.m.logEvent("chatgpt_plugin_disabled", null, {
                                    plugin_id: g.id
                                })
                            }
                        } catch (e) {
                            u = !0, d = e
                        } finally {
                            try {
                                l || null == f.return || f.return()
                            } finally {
                                if (u) throw d
                            }
                        }
                    }, [h, b]),
                    I = f.map(function(e) {
                        return {
                            value: e,
                            title: e.manifest.name_for_human,
                            description: e.manifest.description_for_human,
                            tags: [],
                            customTags: tQ(e) ? (0, w.jsx)(ap, {}) : "approved" !== e.status ? (0, w.jsx)(am, {}) : void 0,
                            imageUrl: e.manifest.logo_url
                        }
                    }),
                    Z = I.filter(function(e) {
                        return h.find(function(t) {
                            return t.id === e.value.id
                        })
                    }),
                    F = "".concat(0 === h.length ? "No" : h.length, " plugins enabled");
                if (h.length > 0 && h.length < 6) {
                    var D = h.map(function(e, t) {
                        return (0, w.jsx)(t4.Z, {
                            url: e.manifest.logo_url,
                            name: e.manifest.name_for_human,
                            size: 24
                        }, t)
                    });
                    F = (0, w.jsx)("div", {
                        className: "flex gap-2",
                        children: D
                    })
                }
                var E = [{
                    id: "store",
                    label: "Plugin store",
                    icon: M.Rgz
                }];
                f.length > 3 && (t = (0, w.jsxs)(oA, {
                    className: (0, G.Z)("transition-colors duration-300", l && "bg-red-200 text-red-800 dark:bg-red-200 dark:text-red-800"),
                    children: [h.length, "/", 3, " Enabled"]
                }));
                var R = (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(oA, {
                        children: "Loading..."
                    }), (0, w.jsx)(i$, {
                        showCheckbox: !0,
                        theme: r
                    }), (0, w.jsx)(i$, {
                        showCheckbox: !0,
                        theme: r
                    }), (0, w.jsx)(i$, {
                        showCheckbox: !0,
                        theme: r
                    }), (0, w.jsx)(i$, {
                        showCheckbox: !0,
                        theme: r
                    }), (0, w.jsx)(i$, {
                        showCheckbox: !0,
                        theme: r
                    })]
                });
                return (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(iH, {
                        name: "Plugins",
                        selectedOptions: Z,
                        selectedLabel: F,
                        options: I,
                        actions: E,
                        onChange: T,
                        onAction: N,
                        onOpen: P,
                        onClose: S,
                        dropdownRef: m,
                        isLoading: g,
                        loadingState: R,
                        header: t,
                        theme: "mini" === r ? "mini" : "default"
                    }), i && (0, w.jsx)(oE, {
                        onInstall: p,
                        onClose: v
                    })]
                })
            }
            var oA = eo.Z.div(oR());

            function oL(e) {
                var t, n = e.currentModelId,
                    r = e.shouldShowPlusUpsell,
                    a = (0, a_.fm)(),
                    i = (0, a_.Q_)(),
                    o = (0, a_.B9)(),
                    s = void 0 !== n ? o.get(n) : void 0,
                    l = (0, tb.Fl)().isPluginsAvailable;
                return s && i ? (0, w.jsxs)("div", {
                    className: "relative flex flex-col items-stretch justify-center gap-2 sm:items-center",
                    children: [(0, w.jsx)(iZ.Z, {
                        shouldShowPlusUpsell: r,
                        currentModel: s,
                        onModelChange: a
                    }), l && (null == s ? void 0 : null === (t = s.enabledTools) || void 0 === t ? void 0 : t.includes("tools3")) && (0, w.jsx)(oB, {
                        theme: "mini"
                    })]
                }) : null
            }

            function oU() {
                var e = (0, Q._)(["px-2 relative w-full flex flex-col py-2 md:py-6 sticky top-0"]);
                return oU = function() {
                    return e
                }, e
            }

            function oO() {
                var e = (0, Q._)(["text-4xl font-semibold text-center text-gray-200 dark:text-gray-600 ml-auto mr-auto mb-10 sm:mb-16 flex gap-2 items-center justify-center flex-grow"]);
                return oO = function() {
                    return e
                }, e
            }
            var oq = function(e) {
                    var t = e.shouldShowThreadSettings,
                        n = e.shouldShowPlusUpsell,
                        r = e.currentModelId,
                        a = e.title,
                        i = e.promptTextareaRef,
                        o = e.shouldShowPlaceholder;
                    return (0, B.hz)().has(eu.Zz) ? (0, w.jsx)(oz, {
                        promptTextareaRef: i,
                        shouldShowPlaceholder: o,
                        shouldShowPlusUpsell: n,
                        shouldShowThreadSettings: t,
                        currentModelId: r,
                        title: a
                    }) : (0, w.jsxs)(w.Fragment, {
                        children: [t && (0, w.jsx)(oH, {
                            children: (0, w.jsx)(oL, {
                                shouldShowPlusUpsell: n,
                                currentModelId: r
                            })
                        }), t && !o && (0, w.jsx)("div", {
                            className: "align-center flex h-full w-full flex-col justify-center self-center px-2 pb-2 md:pb-[8vh]",
                            children: (0, w.jsxs)(oW, {
                                children: [a, (0, w.jsx)(il.ZP, {})]
                            })
                        }), o && (0, w.jsx)(iP, {
                            promptTextareaRef: i
                        })]
                    })
                },
                oz = function(e) {
                    var t = e.shouldShowThreadSettings,
                        n = e.shouldShowPlusUpsell,
                        r = e.currentModelId;
                    return e.shouldShowPlaceholder ? (0, w.jsxs)("div", {
                        className: "flex h-full flex-col items-center justify-between pb-64",
                        children: [t && (0, w.jsx)(oH, {
                            children: (0, w.jsx)(oL, {
                                shouldShowPlusUpsell: n,
                                currentModelId: r
                            })
                        }), (0, w.jsx)("div", {
                            className: "flex flex-grow flex-col items-center justify-center",
                            children: (0, w.jsx)("h1", {
                                children: (0, w.jsx)("div", {
                                    className: "flex cursor-default items-center text-[20px] font-bold leading-none lg:text-[22px]",
                                    children: (0, w.jsxs)("div", {
                                        className: "title animate-slideUpAndFadeLong text-4xl",
                                        children: ["ChatGPT", " ", (0, w.jsx)("span", {
                                            className: "animate-slideLeftAndFadeLong font-circle",
                                            children: "●"
                                        })]
                                    })
                                })
                            })
                        })]
                    }) : null
                },
                oH = eo.Z.div(oU()),
                oW = eo.Z.h1(oO()),
                oV = n(33554),
                oQ = n(59837),
                oG = n(77421),
                o$ = n(62853),
                oY = function(e) {
                    var t = e.children,
                        n = e.contentClassName,
                        r = e.content,
                        a = e.side,
                        i = e.sideOffset,
                        o = (0, j._)((0, _.useState)(void 0), 2),
                        s = o[0],
                        l = o[1],
                        u = function() {
                            l(!0)
                        },
                        d = function() {
                            l(void 0)
                        };
                    return (0, w.jsxs)(nq.fC, {
                        open: s,
                        onOpenChange: function(e) {
                            l(!0 === e || void 0)
                        },
                        children: [(0, w.jsx)(nq.xz, {
                            asChild: !0,
                            onMouseEnter: u,
                            onMouseLeave: d,
                            children: t
                        }), (0, w.jsx)(nq.h_, {
                            children: (0, w.jsx)(nq.VY, {
                                onMouseEnter: u,
                                onMouseLeave: d,
                                side: a,
                                sideOffset: i,
                                collisionPadding: 16,
                                className: n,
                                onOpenAutoFocus: function(e) {
                                    e.preventDefault()
                                },
                                onCloseAutoFocus: function(e) {
                                    e.preventDefault()
                                },
                                children: r
                            })
                        })]
                    })
                },
                oJ = n(42271);

            function oK() {
                var e = (0, Q._)(["translateY(", ")"]);
                return oK = function() {
                    return e
                }, e
            }
            var oX = [0, 60],
                o0 = function(e) {
                    var t, n, r, a = e.currentModelConfig,
                        i = e.clientThreadId,
                        o = e.icon,
                        s = (0, ei.Z)(),
                        l = (0, _.useContext)(A.gB),
                        u = (0, R.tN)(R.bM.isThreadHeaderVisible),
                        d = S.tQ.getServerThreadId(i),
                        c = (0, R.tN)(function(e) {
                            return "debug" === e.activeSidebar
                        }),
                        f = (0, B.hz)(),
                        g = f.has("debug") && !c,
                        h = (0, B.ec)(B.F_.isBusinessWorkspace),
                        m = (0, S.cj)(i),
                        p = f.has(eu.RJ) && !l && d && !m && !h,
                        v = [];
                    g && v.push((0, w.jsx)(ti.u, {
                        side: "left",
                        label: s.formatMessage(o2.openDebug),
                        children: (0, w.jsx)(oJ.O, {
                            onClick: function() {
                                return R.vm.toggleActiveSidebar("debug")
                            },
                            "aria-label": s.formatMessage(o2.openDebug),
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.cDN
                            })
                        })
                    })), p && v.push((0, w.jsx)(ti.u, {
                        side: "left",
                        label: s.formatMessage(o2.shareChat),
                        children: (0, w.jsx)(oJ.O, {
                            onClick: function() {
                                return R.vm.openSharingModal(d)
                            },
                            "aria-label": s.formatMessage(o2.shareChat),
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.A8q
                            })
                        })
                    }));
                    var x = (0, oV.c)(0),
                        b = (0, _.useRef)(null),
                        y = (0, _.useRef)(null),
                        C = (0, j._)((0, ar.useAtTop)(), 1)[0],
                        T = (0, _.useCallback)(function(e) {
                            var t = e.scrollTop;
                            if (null == b.current || b.current === t) {
                                b.current = t;
                                return
                            }
                            if (y.current = b.current, b.current = t, y.current > b.current) {
                                R.vm.showThreadHeader();
                                var n = Math.max(oX[0], x.get() - Math.abs(y.current - b.current));
                                n !== x.get() && x.set(n)
                            } else {
                                var r = Math.min(oX[1], x.get() + Math.abs(y.current - b.current));
                                r !== x.get() && x.set(r)
                            }
                        }, [x]),
                        N = (0, oQ.H)(x, oX, ["0%", "-100%"]),
                        P = (0, j._)((0, _.useState)(N.get()), 2),
                        I = (P[0], P[1]);
                    (0, oG.W)(N, "change", function(e) {
                        I(e)
                    });
                    var Z = (0, o$.Y)(oK(), N);
                    (0, _.useEffect)(function() {
                        R.vm.showThreadHeader()
                    }, []), (0, ar.useObserveScrollPosition)(l ? void 0 : T);
                    var F = (0, S.Qi)(i),
                        D = null != F,
                        E = D && null == F.aboutModelMessage && null == F.aboutUserMessage && null !== F.shareId,
                        L = f.has(eu.b5),
                        U = (0, S.Ro)(i);
                    void 0 === U && (U = a);
                    var O = U.tags.filter(function(e) {
                            return iz.includes(e)
                        }).map(function(e) {
                            return iJ(e)
                        }),
                        q = (0, ay.v)();
                    if (q.length > 0) {
                        var z = q.map(function(e, t) {
                            return (0, w.jsx)(t4.Z, {
                                url: e.manifest.logo_url,
                                name: e.manifest.name_for_human,
                                size: 16
                            }, t)
                        });
                        r = (0, w.jsxs)(w.Fragment, {
                            children: [(0, w.jsx)("div", {
                                children: "Enabled plugins:"
                            }), z]
                        })
                    }
                    var H = (0, k.useRouter)(),
                        W = l && (null === (t = H.query) || void 0 === t ? void 0 : null === (n = t.shareParams) || void 0 === n ? void 0 : n[1]) === "moderate",
                        V = (0, R.tN)(function(e) {
                            return e.activeModals.has(R.B.DownloadMessages)
                        }),
                        Q = S.tQ.getThreadCurrentLeafId(i),
                        G = (0, S.u9)(i, Q),
                        $ = (0, _.useCallback)(function() {
                            L && tB(i, G)
                        }, [i, L, G]);
                    return (0, w.jsxs)(w.Fragment, {
                        children: [L && (0, w.jsx)(eg.Z, {
                            type: "success",
                            isOpen: V,
                            onClose: function() {
                                R.vm.closeModal(R.B.DownloadMessages)
                            },
                            closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                                onClose: function() {
                                    R.vm.closeModal(R.B.DownloadMessages)
                                }
                            }),
                            primaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: $,
                                children: "Download"
                            }),
                            title: "Download chat debug info",
                            secondaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: function() {
                                    R.vm.closeModal(R.B.DownloadMessages)
                                },
                                children: "Cancel"
                            })
                        }), (0, w.jsx)(en.E.header, {
                            animate: u ? void 0 : {
                                top: u ? 0 : "-90px",
                                transition: {
                                    duration: .2,
                                    ease: "easeIn"
                                }
                            },
                            style: {
                                boxShadow: !C && u ? "0px 4px 24px 0px #0000000D" : void 0,
                                transform: u ? Z : void 0
                            },
                            className: "sticky top-0 z-[9] w-full",
                            children: (0, w.jsxs)("div", {
                                className: "relative z-20 flex min-h-[60px] flex-wrap items-center justify-between gap-3 border-b border-black/10 bg-white p-2 text-gray-500 dark:border-gray-900/50 dark:bg-gray-800 dark:text-gray-300",
                                onClick: function(e) {
                                    L && !l && 3 === e.detail && R.vm.openModal(R.B.DownloadMessages)
                                },
                                children: [(0, w.jsx)("div", {
                                    className: "hidden flex-shrink flex-row sm:flex",
                                    children: v.map(function(e, t) {
                                        return (0, w.jsx)(oJ.h, {}, t)
                                    })
                                }), (0, w.jsxs)("div", {
                                    className: "flex flex-1 flex-grow items-center gap-1 p-1 text-gray-600 dark:text-gray-200 sm:justify-center sm:p-0",
                                    children: [l && (0, w.jsxs)("div", {
                                        className: "flex items-center justify-center gap-1",
                                        children: [(0, w.jsx)("span", {
                                            children: "Shared Chat"
                                        }), (0, w.jsx)("span", {
                                            className: "px-1",
                                            children: "•"
                                        })]
                                    }), !l && void 0 !== o && (0, w.jsx)(eh.ZP, {
                                        icon: o
                                    }), (0, w.jsx)("span", {
                                        children: a.title
                                    }), O, r ? (0, w.jsxs)("div", {
                                        className: "flex items-center justify-center gap-1",
                                        children: [(0, w.jsx)("span", {
                                            className: "px-1",
                                            children: "•"
                                        }), r]
                                    }) : null, W && (0, w.jsxs)("div", {
                                        className: "flex items-center justify-center gap-1",
                                        children: [(0, w.jsx)("span", {
                                            className: "px-1",
                                            children: "•"
                                        }), (0, w.jsx)("strong", {
                                            children: "MODERATION VIEW"
                                        })]
                                    }), !l && D && !E && (0, w.jsx)("div", {
                                        className: "",
                                        children: (0, w.jsx)(o1, {
                                            clientThreadId: i
                                        })
                                    })]
                                }), (0, w.jsx)("div", {
                                    className: "flex flex-shrink flex-row",
                                    children: v.map(function(e, t) {
                                        return (0, w.jsx)("span", {
                                            children: e
                                        }, t)
                                    })
                                })]
                            })
                        })]
                    })
                },
                o1 = function(e) {
                    var t = e.clientThreadId,
                        n = (0, S.Qi)(t),
                        r = (0, _.useMemo)(function() {
                            if (null == n) return null;
                            var e = n.aboutUserMessage,
                                t = n.aboutModelMessage,
                                r = n.fallback;
                            return null != e && null != t ? (0, w.jsxs)("div", {
                                className: "flex flex-col gap-7",
                                children: [null !== e && "" !== e && (0, w.jsxs)("div", {
                                    className: "flex flex-col gap-3",
                                    children: [(0, w.jsx)("div", {
                                        className: "font-medium text-gray-600 dark:text-gray-200",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, nA.sY.aboutYouHelpText))
                                    }), (0, w.jsx)("div", {
                                        className: "flex flex-row gap-1 text-gray-500",
                                        children: e
                                    })]
                                }), null !== t && "" !== t && (0, w.jsxs)("div", {
                                    className: "flex flex-col gap-3",
                                    children: [(0, w.jsx)("div", {
                                        className: "font-medium text-gray-600 dark:text-gray-200",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, nA.sY.modelHelpText))
                                    }), (0, w.jsx)("div", {
                                        className: "flex flex-row gap-1 text-gray-500",
                                        children: t
                                    })]
                                })]
                            }) : null != r ? r : null
                        }, [n]);
                    return null === n ? null : (0, w.jsx)(w.Fragment, {
                        children: (0, w.jsx)(oY, {
                            contentClassName: "relative max-h-[450px] min-w-[300px] max-w-[350px] animate-slideDownAndFade select-none overflow-y-auto whitespace-pre-line rounded-xl border-gray-100 bg-white p-4 text-sm text-gray-600 shadow-xs dark:bg-gray-900 dark:text-white sm:max-w-lg md:max-w-xl",
                            side: "bottom",
                            sideOffset: 8,
                            content: (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)("div", {
                                    className: "mb-5 mt-1 border-b border-black/10 pb-5 dark:border-white/10",
                                    children: (0, w.jsx)("div", {
                                        className: "flex flex-row items-center gap-2 text-gray-500",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, o2.chatPreferencesNote))
                                    })
                                }), r]
                            }),
                            children: (0, w.jsxs)("div", {
                                className: "cursor-pointer pt-0.5",
                                children: [(0, w.jsx)(eh.HV, {
                                    className: "h-4 w-4 flex-shrink-0 sm:mb-0.5 sm:h-5 sm:w-5"
                                }), (0, w.jsx)(eV.T, {
                                    children: (0, w.jsx)(T.Z, (0, b._)({}, o2.chatPreferencesInfoLabel))
                                })]
                            })
                        })
                    })
                },
                o2 = (0, N.vU)({
                    chatPreferencesInfoLabel: {
                        id: "ThreadSettings.chatPreferencesInfoLabel",
                        defaultMessage: "Custom instructions details",
                        description: "Label for the Custom instructions info icon"
                    },
                    chatPreferencesNote: {
                        id: "ThreadSettings.chatPreferencesNote",
                        defaultMessage: "Custom instructions are on and can only be changed at the beginning of the chat.",
                        description: "Label in the popover for Custom Instructions"
                    },
                    openDebug: {
                        id: "ThreadSettings.openDebug",
                        defaultMessage: "Open debug sidebar",
                        description: "Open debug sidebar button tooltip"
                    },
                    shareChat: {
                        id: "ThreadSettings.shareChat",
                        defaultMessage: "Share chat",
                        description: "Open share modal button tooltip"
                    }
                }),
                o3 = n(16592);

            function o5() {
                var e = (0, Q._)(["\n  flex flex-col text-sm dark:bg-gray-800\n  ", "\n"]);
                return o5 = function() {
                    return e
                }, e
            }

            function o4() {
                var e = (0, Q._)(["h-32 md:h-48 flex-shrink-0"]);
                return o4 = function() {
                    return e
                }, e
            }

            function o8() {
                var e = (0, Q._)(["cursor-pointer absolute right-6 bottom-[124px] md:bottom-[180px] lg:bottom-[120px] z-10 rounded-full border border-gray-200 bg-gray-50 text-gray-600 dark:border-white/10 dark:bg-white/10 dark:text-gray-200"]);
                return o8 = function() {
                    return e
                }, e
            }
            var o7 = (0, N.vU)({
                codeInterpreterSupportDisclaimer: {
                    id: "sharedConversation.codeInterpreterSupportDisclaimer",
                    defaultMessage: "This chat contains files or images produced by Code Interpreter which are not yet visible in Shared Chats.",
                    description: "Disclaimer about our lack of support for Code Interpreter inline images and file downloads with shared links"
                },
                userContextCustomProfileDisclaimer: {
                    id: "sharedConversation.userContextCustomProfileDisclaimer",
                    defaultMessage: "This conversation may reflect the link creator’s Custom Instructions, which aren’t shared and can meaningfully change how the model responds.",
                    description: "Disclaimer about our lack of support for custom profiles with shared links"
                },
                userContextCustomProfileAndCodeInterpreterSupportDisclaimer: {
                    id: "sharedConversation.userContextCustomProfileAndCodeInterpreterSupportDisclaimer",
                    defaultMessage: "This conversation may reflect the link creator’s Custom Instructions, which aren’t shared and can meaningfully change how the model responds. The chat contains files or images produced by Code Interpreter which are not yet visible in Shared Chats.",
                    description: "Disclaimer about our lack of support for Code Interpreter inline images and file downloads with shared links and not sharing custom profile data"
                }
            });

            function o6(e) {
                var t = e.clientThreadId,
                    n = (0, S.qA)(t),
                    r = (0, S.je)(t),
                    a = (0, S.qN)(function(e) {
                        return S.iN.getThreadCreateTime(t, e)
                    }),
                    i = (0, S.JI)(t),
                    o = (0, _.useMemo)(function() {
                        return io(i)
                    }, [i]),
                    s = (0, S.aS)(t);
                return (0, w.jsxs)("div", {
                    className: "mb-1 border-b border-gray-100 pt-3 sm:mb-2 sm:pb-6 sm:pt-8",
                    children: [(0, w.jsx)("h1", {
                        className: "max-w-md text-3xl font-semibold leading-tight text-gray-700 dark:text-gray-100 sm:text-4xl",
                        children: n
                    }), (null != r || null != a) && (0, w.jsxs)("div", {
                        className: "pt-3 text-base text-gray-400 sm:pt-4",
                        children: [null != r && (0, w.jsx)("span", {
                            children: r
                        }), null != r && null != a && (0, w.jsx)("span", {
                            className: "px-2",
                            children: "•"
                        }), null != a && (0, w.jsx)(N.Ji, {
                            value: a,
                            month: "long",
                            year: "numeric",
                            day: "numeric"
                        })]
                    }), (0, w.jsx)(o9, {
                        shouldShowCodeInterpreterDisclaimer: o,
                        shouldShowUserContextCustomProfileDisclaimer: s
                    })]
                })
            }
            var o9 = function(e) {
                var t = e.shouldShowCodeInterpreterDisclaimer,
                    n = e.shouldShowUserContextCustomProfileDisclaimer;
                return t && n ? (0, w.jsx)("div", {
                    className: "mt-4",
                    children: (0, w.jsx)(is, {
                        icon: M.H33,
                        children: (0, w.jsx)(T.Z, (0, b._)({}, o7.userContextCustomProfileAndCodeInterpreterSupportDisclaimer))
                    })
                }) : (0, w.jsxs)(w.Fragment, {
                    children: [t && (0, w.jsx)("div", {
                        className: "mt-4",
                        children: (0, w.jsx)(is, {
                            icon: M.H33,
                            color: "gray",
                            children: (0, w.jsx)(T.Z, (0, b._)({}, o7.codeInterpreterSupportDisclaimer))
                        })
                    }), n && (0, w.jsx)("div", {
                        className: "mt-4",
                        children: (0, w.jsx)(is, {
                            icon: M.H33,
                            color: "gray",
                            children: (0, w.jsx)(T.Z, (0, b._)({}, o7.userContextCustomProfileDisclaimer))
                        })
                    })]
                })
            };

            function se(e) {
                var t, n = e.onChangeItemInView,
                    r = e.onRequestMoreCompletions,
                    a = e.onUpdateNode,
                    i = e.onChangeRating,
                    o = e.onDeleteNode,
                    s = e.onRequestCompletion,
                    l = e.clientThreadId,
                    u = e.conversationLeafId,
                    d = e.isNewThread,
                    c = e.activeRequests,
                    f = e.currentThreadModel,
                    g = e.inlineEmbeddedDisplay,
                    h = e.initiallyHighlightedMessageId,
                    m = e.promptTextareaRef,
                    p = (0, _.useContext)(A.gB),
                    v = (0, ar.useScrollToBottom)(),
                    x = (0, j._)((0, ar.useSticky)(), 1)[0],
                    b = (0, B.hz)(),
                    y = (0, tb.Fl)().isBetaFeaturesUiEnabled,
                    C = (0, S.Kt)(l),
                    k = (0, B.$T)(),
                    T = (0, a_.iu)(),
                    N = (0, a_.ZL)(),
                    P = (0, a_.Xy)(f, l),
                    I = (0, R.tN)(function(e) {
                        return e.isDesktopNavCollapsed
                    }),
                    Z = b.has("model_switcher") && T.size > 1,
                    F = b.has("model_switcher_upsell"),
                    D = d && !k && !N && (b.has(eu.Zz) || !Z),
                    E = (0, j._)((0, _.useState)(!1), 2),
                    L = E[0],
                    U = E[1],
                    O = (0, o3.Ri)(P.id),
                    q = (0, S.U0)(l, u);
                (0, _.useEffect)(function() {
                    if (C) {
                        var e = setTimeout(function() {
                            U(!0)
                        }, 1e3);
                        return function() {
                            clearTimeout(e)
                        }
                    }
                    U(!1)
                }, [C]);
                var z = d && !k,
                    H = b.has(eu.FZ),
                    W = !y && P.tags.includes(a_.S.GPT_4) ? "black" : null !== (t = null == O ? void 0 : O.backgroundColor) && void 0 !== t ? t : void 0,
                    V = (0, te._)(Array(q).keys()).map(function(e) {
                        return (0, w.jsx)(aB, {
                            isFinalTurn: e === q - 1,
                            turnIndex: e,
                            clientThreadId: l,
                            conversationLeafId: u,
                            onChangeItemInView: n,
                            onChangeRating: i,
                            onRequestMoreCompletions: r,
                            onDeleteNode: o,
                            onRequestCompletion: s,
                            onUpdateNode: a,
                            activeRequests: c,
                            currentModelId: P.id,
                            showInlineEmbeddedDisplay: g,
                            initiallyHighlightedMessageId: h,
                            avatarColor: W
                        }, e)
                    });
                return (0, w.jsx)(w.Fragment, {
                    children: (0, w.jsxs)(st, {
                        $shouldShowThreadSettings: z,
                        children: [(0, w.jsx)(oq, {
                            title: "ChatGPT",
                            shouldShowThreadSettings: z,
                            shouldShowPlusUpsell: F,
                            currentModelId: P.id,
                            promptTextareaRef: m,
                            shouldShowPlaceholder: D
                        }), L && (0, w.jsx)(em.Z, {
                            className: "mt-4 self-center"
                        }), !d && (p || !k) && !g && (0, w.jsx)(o0, {
                            icon: y ? null == O ? void 0 : O.icon : void 0,
                            currentModelConfig: P,
                            clientThreadId: l
                        }), H ? V.length > 0 && (0, w.jsx)("div", {
                            className: (0, G.Z)("flex flex-col items-center", I ? "sm:px-14" : "sm:px-4"),
                            children: (0, w.jsxs)("div", {
                                className: "w-full max-w-[44rem] pt-4",
                                children: [p && !g && (0, w.jsx)(o6, {
                                    clientThreadId: l
                                }), V]
                            })
                        }) : (0, w.jsxs)(w.Fragment, {
                            children: [p && !g && (0, w.jsx)("div", {
                                className: "mx-auto w-full p-4 md:max-w-2xl lg:max-w-xl lg:px-0 xl:max-w-3xl",
                                children: (0, w.jsx)(o6, {
                                    clientThreadId: l
                                })
                            }), V]
                        }), !g && !D && (0, w.jsx)(sn, {}), !x && !g && (0, w.jsx)(sr, {
                            onClick: v,
                            children: (0, w.jsx)(eh.ZP, {
                                icon: M.tv1,
                                className: "m-1"
                            })
                        })]
                    })
                })
            }
            var st = eo.Z.div(o5(), function(e) {
                    return e.$shouldShowThreadSettings && "h-full"
                }),
                sn = eo.Z.div(o4()),
                sr = eo.Z.button(o8());

            function sa() {
                var e = (0, Q._)(["relative h-full w-full transition-width flex flex-col overflow-hidden items-stretch"]);
                return sa = function() {
                    return e
                }, e
            }

            function si() {
                var e = (0, Q._)(["grow flex-1 overflow-hidden"]);
                return si = function() {
                    return e
                }, e
            }

            function so() {
                var e = (0, Q._)(["w-full mb-4 shadow-[0_2px_12px_0px_rgba(0,0,0,0.08)] dark:bg-gray-800/90 rounded-lg border border-gray-100 dark:border-gray-700 overflow-hidden bg-gray-50"]);
                return so = function() {
                    return e
                }, e
            }

            function ss() {
                var e = (0, Q._)(["flex p-4 bg-white dark:bg-gray-800/90 border-t border-gray-100 dark:border-gray-700 rounded-b-lg w-full h-full\n", "\n"]);
                return ss = function() {
                    return e
                }, e
            }

            function sl() {
                var e = (0, Q._)(["flex w-full items-center justify-left gap-2 min-h-[1.5rem]"]);
                return sl = function() {
                    return e
                }, e
            }

            function su() {
                var e = (0, Q._)(["border-none focus:ring-gray-200 dark:focus:ring-gray-600 bg-transparent py-0.5 -my-0.5 pl-1 -ml-1 w-full"]);
                return su = function() {
                    return e
                }, e
            }

            function sd() {
                var e = (0, Q._)(["flex-none h-full mt-auto mb-auto"]);
                return sd = function() {
                    return e
                }, e
            }
            var sc = (0, N.vU)({
                sharingModalTitle: {
                    id: "thread.sharingModal.title",
                    defaultMessage: "Share Link to Chat",
                    description: "Title of sharing feature in the title of the sharing modal"
                },
                sharingModalDescription: {
                    id: "sharingModal.description",
                    defaultMessage: "Messages you send after creating your link won't be shared. Anyone with the URL will be able to view the shared chat.",
                    description: "Description of sharing feature in the first paragraph of the sharing modal"
                },
                existingShareDescription: {
                    id: "sharingModal.exisitingDescription",
                    defaultMessage: "You have shared this chat <existingLink>before</existingLink>. If you want to update the shared chat content, <deleteLink>delete this link</deleteLink> and create a new shared link.",
                    description: "Description in sharing modal when viewing an existing link"
                },
                sharingModalMoreInfo: {
                    id: "thread.sharingModal.moreInfo",
                    defaultMessage: "More Info",
                    description: "Link to a helpdesk article with more information about the sharing modal"
                },
                moderationBlocked: {
                    id: "sharingModal.moderationBlocked",
                    defaultMessage: "This shared link has been disabled by moderation.",
                    description: "Error message in sharing modal when shared link has been moderated."
                },
                confirmCloseWithChanges: {
                    id: "thread.sharingModal.confirmCloseWithChanges",
                    defaultMessage: "You have unsaved changes. Do you want to continue?",
                    description: "Confirmation message when closing share modal with changes"
                },
                confirmDeleteLink: {
                    id: "sharingModal.confirmDeleteLink",
                    defaultMessage: "Are you sure you want to delete the share link?",
                    description: "Confirmation message when deleting share link"
                },
                codeInterpreterSupportDisclaimer: {
                    id: "sharingModal.codeInterpreterSupportDisclaimer",
                    defaultMessage: "Recipients won’t be able to view Code Interpreter images or download files.",
                    description: "Disclaimer about our lack of support for Code Interpreter inline images and file downloads with shared links"
                },
                userContextCustomProfileDisclaimer: {
                    id: "sharingModal.userContextCustomProfileDisclaimer",
                    defaultMessage: "Your Custom Instructions won’t be shared with viewers.",
                    description: "Disclaimer about our policy to not copy over custom profile data which could have PII"
                },
                userContextCustomProfileAndCodeInterpreterSupportDisclaimer: {
                    id: "sharingModal.userContextCustomProfileAndCodeInterpreterSupportDisclaimer",
                    defaultMessage: "Recipients won’t be able to view images, download files, or custom profiles.",
                    description: "Disclaimer about our lack of support for Code Interpreter inline images and file downloads with shared links and not sharing custom profile data"
                }
            });

            function sf(e) {
                var t = e.serverThreadId,
                    n = e.activeRequests,
                    r = (0, S.oq)(t),
                    a = (0, j._)((0, _.useState)(function() {
                        return (0, it.Z)(function(e, t) {
                            return {
                                title: void 0,
                                highlightedMessageId: void 0,
                                initiallyHighlightedMessageId: void 0,
                                currentNodeId: void 0,
                                shareLinkId: void 0,
                                shareLinkUrl: void 0,
                                isPublic: !1,
                                isDeleted: !1,
                                isAnonymous: !0,
                                linkAlreadyExisted: !1,
                                linkError: void 0,
                                moderationState: void 0
                            }
                        })
                    }), 1)[0],
                    i = 0 === n.size && "root" !== r,
                    o = (0, _.useRef)(!1);
                return (0, _.useEffect)(function() {
                    if (i && !o.current) {
                        o.current = !0;
                        var e = S.tQ.getThreadCurrentLeafId(t),
                            n = S.tQ.getTree(t).getMessageId(e);
                        P.ZP.createShareLink({
                            current_node_id: n,
                            conversation_id: t,
                            is_anonymous: !0
                        }).then(function(e) {
                            a.setState({
                                shareLinkId: e.share_id,
                                shareLinkUrl: e.share_url,
                                isPublic: e.is_public,
                                isDeleted: !e.is_visible,
                                title: e.title,
                                highlightedMessageId: e.highlighted_message_id,
                                initiallyHighlightedMessageId: e.highlighted_message_id,
                                currentNodeId: e.current_node_id,
                                linkAlreadyExisted: e.already_exists,
                                isAnonymous: e.is_anonymous,
                                moderationState: e.moderation_state
                            })
                        }).catch(function(e) {
                            e instanceof ii.Q0 && "string" == typeof e.message ? a.setState({
                                linkError: e.message
                            }) : (tl.m.danger("Failed to copy link to clipboard - could not create link"), R.vm.closeSharingModal())
                        })
                    }
                }, [i]), (0, w.jsx)(ir.Provider, {
                    value: a,
                    children: (0, w.jsx)(sh, (0, b._)({}, e))
                })
            }

            function sg(e) {
                return !0 === e.has_been_auto_blocked || !0 === e.has_been_auto_moderated || !0 === e.has_been_blocked
            }

            function sh(e) {
                var t, n, r, a, i, o = e.serverThreadId,
                    s = e.activeRequests,
                    l = e.currentThreadModel,
                    u = function() {
                        (!X || window.confirm(d.formatMessage(sc.confirmCloseWithChanges))) && R.vm.closeSharingModal()
                    },
                    d = (0, ei.Z)(),
                    c = (0, _.useRef)(null),
                    f = (0, j._)((0, _.useState)(!1), 2),
                    g = f[0],
                    h = f[1],
                    m = (0, j._)((0, _.useState)(!1), 2),
                    p = m[0],
                    v = m[1],
                    x = (0, j._)((0, _.useState)(!1), 2),
                    y = x[0],
                    C = x[1],
                    k = (0, _.useContext)(ir),
                    I = ia(function(e) {
                        return e.title
                    }),
                    Z = ia(function(e) {
                        return e.shareLinkId
                    }),
                    F = ia(function(e) {
                        return e.shareLinkUrl
                    }),
                    D = ia(function(e) {
                        return e.isAnonymous
                    }),
                    E = ia(function(e) {
                        return e.initiallyHighlightedMessageId
                    }),
                    B = ia(function(e) {
                        return e.currentNodeId
                    }),
                    L = ia(function(e) {
                        return e.isPublic
                    }),
                    U = ia(function(e) {
                        return e.linkAlreadyExisted
                    }) && L,
                    O = ia(function(e) {
                        return e.linkError
                    }),
                    q = ia(function(e) {
                        return e.moderationState
                    }),
                    z = null != q && sg(q),
                    H = (0, _.useRef)(),
                    W = (0, _.useRef)();
                (0, _.useEffect)(function() {
                    U && (H.current = I, W.current = D)
                }, [U]);
                var Q = (0, ev.kP)().session,
                    $ = (0, S.JI)(o, B),
                    Y = (0, _.useMemo)(function() {
                        return io($)
                    }, [$]),
                    J = (0, S.aS)(o),
                    K = (t = (0, eG._)(function(e, t) {
                        var n, r, a, i, o, s, l;
                        return (0, e$.__generator)(this, function(u) {
                            switch (u.label) {
                                case 0:
                                    v(!0), r = (n = k.getState()).highlightedMessageId, a = n.title, i = n.isDeleted, o = n.isAnonymous;
                                    try {
                                        (0, tM.S)(t)
                                    } catch (e) {
                                        return console.warn("Could not copy link to clipboard: " + e), tl.m.warning("Failed to copy link to clipboard"), v(!1), [2]
                                    }
                                    u.label = 1;
                                case 1:
                                    return u.trys.push([1, 3, 4, 5]), [4, P.ZP.updateShareLink({
                                        share_id: e,
                                        highlighted_message_id: r,
                                        title: null != a ? a : void 0,
                                        is_public: !i,
                                        is_visible: !i,
                                        is_anonymous: o
                                    })];
                                case 2:
                                    if (sg(s = u.sent().moderation_state)) return k.setState({
                                        moderationState: s
                                    }), [2];
                                    return k.setState({
                                        isPublic: !0,
                                        moderationState: s
                                    }), C(!0), setTimeout(function() {
                                        R.vm.closeSharingModal(), tl.m.success("Copied shared conversation URL to clipboard!")
                                    }, 500), [3, 5];
                                case 3:
                                    return (l = u.sent()) instanceof ii.Q0 && "string" == typeof l.message && k.setState({
                                        linkError: l.message
                                    }), [3, 5];
                                case 4:
                                    return v(!1), [7];
                                case 5:
                                    return [2]
                            }
                        })
                    }), function(e, n) {
                        return t.apply(this, arguments)
                    }),
                    X = U && (I !== H.current || D !== W.current),
                    ee = (0, w.jsxs)(ef.ZP.Button, {
                        onClick: function() {
                            return K(Z, F)
                        },
                        color: "primary",
                        disabled: p || y || null == Z || null == F || null != O || z,
                        children: [y ? (0, w.jsx)(eh.ZP, {
                            icon: M.LSm
                        }) : p ? (0, w.jsx)(em.Z, {}) : (0, w.jsx)(eh.ZP, {
                            icon: M.XKb
                        }), y ? "Copied!" : p ? "Copying..." : X ? "Update and Copy Link" : "Copy Link"]
                    }),
                    et = (0, _.useCallback)(function(e) {
                        var t;
                        null == e || e.preventDefault(), k.setState({
                            title: null === (t = c.current) || void 0 === t ? void 0 : t.value
                        }), h(!1)
                    }, [k]),
                    en = (0, _.useCallback)(function(e) {
                        "Enter" === e.key && et()
                    }, [et]),
                    er = (n = (0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, P.ZP.deleteShareLink({
                                        share_id: k.getState().shareLinkId
                                    }).catch(function(e) {
                                        tl.m.danger("Failed to delete shared link")
                                    }).then(function() {
                                        R.vm.closeSharingModal()
                                    })];
                                case 1:
                                    return e.sent(), [2]
                            }
                        })
                    }), function() {
                        return n.apply(this, arguments)
                    }),
                    eo = (r = (0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return k.setState({
                                isAnonymous: !0
                            }), S.qN.setState(function(e) {
                                e.threads[o].initialThreadData.authorName = void 0
                            }), [2]
                        })
                    }), function() {
                        return r.apply(this, arguments)
                    }),
                    es = (a = (0, eG._)(function() {
                        return (0, e$.__generator)(this, function(e) {
                            return k.setState({
                                isAnonymous: !1
                            }), S.qN.setState(function(e) {
                                var t;
                                e.threads[o].initialThreadData.authorName = null == Q ? void 0 : null === (t = Q.user) || void 0 === t ? void 0 : t.name
                            }), [2]
                        })
                    }), function() {
                        return a.apply(this, arguments)
                    }),
                    el = (0, w.jsxs)(sb, {
                        $active: g,
                        children: [(0, w.jsxs)("div", {
                            className: "flex-1 pr-1",
                            children: [void 0 !== I ? g ? (0, w.jsx)(sj, {
                                ref: c,
                                type: "text",
                                defaultValue: null != I ? I : "",
                                autoFocus: !0,
                                onKeyDown: en,
                                onBlur: et
                            }) : (0, w.jsxs)(sy, {
                                onDoubleClick: function() {
                                    return h(!0)
                                },
                                children: [I, g || null == I || U ? null : (0, w.jsx)("button", {
                                    onClick: function() {
                                        return h(!0)
                                    },
                                    className: "text-gray-500",
                                    children: (0, w.jsx)(eh.ZP, {
                                        icon: M.Nte,
                                        size: "small"
                                    })
                                })]
                            }) : (0, w.jsx)("div", {
                                className: "h-6"
                            }), (0, w.jsxs)("div", {
                                className: "mt-1 text-gray-500",
                                children: [!D && (0, w.jsxs)("span", {
                                    children: [null == Q ? void 0 : null === (i = Q.user) || void 0 === i ? void 0 : i.name, " \xb7 "]
                                }), (0, w.jsx)(N.Ji, {
                                    value: new Date,
                                    month: "long",
                                    day: "numeric",
                                    year: "numeric"
                                })]
                            })]
                        }), (0, w.jsx)(sw, {
                            children: (0, w.jsxs)(nq.fC, {
                                children: [(0, w.jsx)(nq.xz, {
                                    asChild: !0,
                                    children: (0, w.jsx)(ec.z, {
                                        color: "neutral",
                                        className: "mb-auto mt-auto",
                                        children: (0, w.jsx)(tx.JEI, {})
                                    })
                                }), (0, w.jsx)(nq.h_, {
                                    children: (0, w.jsxs)(nq.VY, {
                                        className: "PopoverContent rounded-sm bg-white p-2 pb-0.5 shadow-xl dark:bg-gray-800/90",
                                        side: "top",
                                        align: "end",
                                        children: [D && (0, w.jsx)(ec.z, {
                                            color: "neutral",
                                            className: "mb-2 flex w-full border-0",
                                            onClick: es,
                                            children: (0, w.jsxs)("div", {
                                                className: "flex w-full items-start",
                                                children: [(0, w.jsx)(eh.ZP, {
                                                    icon: M.fzv,
                                                    className: "float-left mb-auto mr-4 mt-auto"
                                                }), " ", (0, w.jsx)("div", {
                                                    children: "Share your name"
                                                })]
                                            })
                                        }), !D && (0, w.jsx)(ec.z, {
                                            color: "neutral",
                                            className: "mb-2 flex w-full border-0",
                                            onClick: eo,
                                            children: (0, w.jsxs)("div", {
                                                className: "flex w-full items-start",
                                                children: [(0, w.jsx)(eh.ZP, {
                                                    icon: M.fzv,
                                                    className: "float-left mb-auto mr-4 mt-auto"
                                                }), " ", (0, w.jsx)("div", {
                                                    children: "Share anonymously"
                                                })]
                                            })
                                        }), U && (0, w.jsx)(ec.z, {
                                            color: "neutral",
                                            className: "mb-2 flex w-full border-0",
                                            onClick: er,
                                            children: (0, w.jsxs)("div", {
                                                className: "flex w-full items-start",
                                                children: [(0, w.jsx)(eh.ZP, {
                                                    icon: M.Ybf,
                                                    className: "float-left mb-auto mr-4 mt-auto"
                                                }), " ", (0, w.jsx)("div", {
                                                    children: "Delete Link"
                                                })]
                                            })
                                        })]
                                    })
                                })]
                            })
                        })]
                    }),
                    eu = O;
                return null == eu && ((null == q ? void 0 : q.has_been_auto_blocked) || (null == q ? void 0 : q.has_been_auto_moderated) || (null == q ? void 0 : q.has_been_blocked)) && (eu = (0, w.jsx)(T.Z, (0, b._)({}, sc.moderationBlocked))), (0, w.jsxs)(eg.Z, {
                    isOpen: !0,
                    onClose: function() {
                        u()
                    },
                    size: "custom",
                    className: "max-w-[550px]",
                    type: "success",
                    title: d.formatMessage(sc.sharingModalTitle),
                    closeButton: (0, w.jsx)(ef.ZP.CloseButton, {
                        onClose: function() {
                            u()
                        }
                    }),
                    children: [null != eu && (0, w.jsx)("div", {
                        className: "mb-4 rounded-md bg-red-500 p-4 text-white",
                        children: eu
                    }), (0, w.jsx)("div", {
                        className: (0, G.Z)("w-full"),
                        children: (0, w.jsx)("p", {
                            className: (0, G.Z)("mb-6 text-gray-500"),
                            children: U ? (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, sc.existingShareDescription), {
                                values: {
                                    existingLink: function(e) {
                                        return (0, w.jsx)("a", {
                                            href: F,
                                            target: "_blank",
                                            rel: "noreferrer",
                                            className: "underline",
                                            children: e
                                        })
                                    },
                                    deleteLink: function(e) {
                                        return (0, w.jsx)("a", {
                                            href: "#",
                                            onClick: function(e) {
                                                e.preventDefault(), window.confirm(d.formatMessage(sc.confirmDeleteLink)) && er()
                                            },
                                            className: "underline",
                                            children: e
                                        })
                                    }
                                }
                            })) : (0, w.jsx)(T.Z, (0, b._)({}, sc.sharingModalDescription))
                        })
                    }), (0, w.jsx)(sm, {
                        shouldShowCodeInterpreterDisclaimer: Y,
                        shouldShowUserContextCustomProfileDisclaimer: J
                    }), (0, w.jsx)(sx, {
                        children: (0, w.jsx)("div", {
                            className: "flex h-full max-w-full flex-1 flex-col",
                            children: (0, w.jsx)(sp, {
                                children: (0, w.jsxs)(sv, {
                                    children: [(0, w.jsx)(ie.f, {
                                        ratio: 1.9,
                                        className: "overflow-auto bg-white dark:bg-gray-800",
                                        children: null != B ? (0, w.jsx)(A.gB.Provider, {
                                            value: !0,
                                            children: (0, w.jsx)(se, {
                                                onChangeItemInView: ea(),
                                                onRequestMoreCompletions: ea(),
                                                onUpdateNode: ea(),
                                                onChangeRating: ea(),
                                                onDeleteNode: ea(),
                                                onRequestCompletion: ea(),
                                                clientThreadId: o,
                                                conversationLeafId: B,
                                                activeRequests: s,
                                                currentThreadModel: l,
                                                inlineEmbeddedDisplay: !0,
                                                isNewThread: !1,
                                                initiallyHighlightedMessageId: E
                                            })
                                        }) : (0, w.jsx)("div", {
                                            className: "flex h-full items-center justify-center",
                                            children: (0, w.jsx)(em.Z, {
                                                className: "text-gray-400 dark:text-gray-500"
                                            })
                                        })
                                    }), el]
                                })
                            })
                        })
                    }), (0, w.jsx)(ef.ZP.Actions, {
                        isSpacedBetween: !0,
                        primaryButton: ee,
                        secondaryButton: (0, w.jsx)("div", {
                            children: (0, w.jsxs)("a", {
                                href: "https://help.openai.com/en/articles/7925741-chatgpt-shared-links-faq",
                                className: "flex items-center gap-2 text-gray-500 hover:text-gray-600 dark:hover:text-gray-400",
                                target: "_blank",
                                rel: "noreferrer",
                                children: [d.formatMessage(sc.sharingModalMoreInfo), (0, w.jsx)(eh.ZP, {
                                    icon: M.AlO
                                })]
                            })
                        })
                    })]
                })
            }
            var sm = function(e) {
                    var t = e.shouldShowCodeInterpreterDisclaimer,
                        n = e.shouldShowUserContextCustomProfileDisclaimer;
                    return t && n ? (0, w.jsx)(is, {
                        icon: M.H33,
                        children: (0, w.jsx)(T.Z, (0, b._)({}, sc.userContextCustomProfileAndCodeInterpreterSupportDisclaimer))
                    }) : (0, w.jsxs)(w.Fragment, {
                        children: [t && (0, w.jsx)(is, {
                            icon: M.H33,
                            children: (0, w.jsx)(T.Z, (0, b._)({}, sc.codeInterpreterSupportDisclaimer))
                        }), n && (0, w.jsxs)("p", {
                            className: "mb-6 flex flex-row gap-2.5 text-gray-500",
                            children: [(0, w.jsx)(eh.ZP, {
                                icon: M.H33,
                                size: "small",
                                className: "mt-1 flex-shrink-0"
                            }), (0, w.jsx)(T.Z, (0, b._)({}, sc.userContextCustomProfileDisclaimer))]
                        })]
                    })
                },
                sp = eo.Z.main(sa()),
                sv = eo.Z.div(si()),
                sx = eo.Z.div(so()),
                sb = eo.Z.div(ss(), function(e) {
                    return e.$active, ""
                }),
                sy = eo.Z.div(sl()),
                sj = eo.Z.input(su()),
                sw = eo.Z.div(sd());

            function sC() {
                return (sC = (0, eG._)(function(e, t) {
                    var n, r;
                    return (0, e$.__generator)(this, function(a) {
                        switch (a.label) {
                            case 0:
                                if ((null === (n = t.metadata) || void 0 === n ? void 0 : n.client_actions) === void 0 || 0 === t.metadata.client_actions.length || 0 == (r = t.metadata.client_actions.filter(function(e) {
                                        return "browser_tool" === e.type
                                    })).length) return [2, []];
                                return [4, Promise.all(r.map(function(n) {
                                    return function(e, t, n) {
                                        return s_.apply(this, arguments)
                                    }(e, n.action, t)
                                }))];
                            case 1:
                                return [2, a.sent().flat()]
                        }
                    })
                })).apply(this, arguments)
            }
            var sk = function() {
                function e(t) {
                    (0, q._)(this, e), this.conversationId = t
                }
                var t = e.prototype;
                return t.createRequest = function(e) {
                    var t = this;
                    return new Promise(function(n, r) {
                        var a = new BroadcastChannel(Math.random().toString()),
                            i = setTimeout(function() {
                                r("Timeout"), a.close()
                            }, 6e4);
                        a.onmessage = function(e) {
                            n(e.data), clearTimeout(i), a.close()
                        };
                        var o = (0, V._)((0, b._)({
                            action: "browse",
                            id: t.conversationId
                        }, e), {
                            channel: a.name
                        });
                        window.postMessage(o, "*")
                    })
                }, t.browse = function(e) {
                    return this.createRequest({
                        url: e,
                        type: "browse"
                    })
                }, t.back = function() {
                    return this.createRequest({
                        type: "back"
                    })
                }, t.click = function(e) {
                    return this.createRequest({
                        target: e,
                        type: "click"
                    })
                }, t.scroll = function(e) {
                    return this.createRequest({
                        amount: e,
                        type: "scroll"
                    })
                }, t.quote = function(e, t) {
                    return this.createRequest({
                        quote_start: e,
                        quote_end: t,
                        type: "quote"
                    })
                }, e
            }();

            function s_() {
                return (s_ = (0, eG._)(function(e, t, n) {
                    var r, a;
                    return (0, e$.__generator)(this, function(n) {
                        var i, o;
                        switch (n.label) {
                            case 0:
                                r = new sk(e), n.label = 1;
                            case 1:
                                switch (n.trys.push([1, 14, , 15]), t.command) {
                                    case "back":
                                        return [3, 2];
                                    case "quote":
                                        return [3, 4];
                                    case "scroll":
                                        return [3, 6];
                                    case "open_url":
                                        return [3, 8];
                                    case "click":
                                        return [3, 10]
                                }
                                return [3, 12];
                            case 2:
                                return [4, r.back()];
                            case 3:
                            case 7:
                            case 9:
                            case 11:
                                return [2, [(! function(e) {
                                    for (var t in e.urls) e.text.includes("".concat(t)) || delete e.urls[t]
                                }(i = n.sent()), {
                                    id: (0, tq.Z)(),
                                    author: {
                                        role: tH.uU.Tool,
                                        name: "browser"
                                    },
                                    content: {
                                        content_type: tH.PX.TetherBrowsingDisplay,
                                        result: i.text,
                                        summary: i.title
                                    },
                                    metadata: {
                                        _cite_metadata: {
                                            citation_format: {
                                                name: "tether_og"
                                            },
                                            metadata_list: [{
                                                type: "webpage",
                                                title: i.title,
                                                url: i.url,
                                                text: i.text
                                            }]
                                        }
                                    },
                                    recipient: "all"
                                })]];
                            case 4:
                                return [4, r.quote(t.quote_start, t.quote_end)];
                            case 5:
                                return [2, [(o = n.sent(), {
                                    id: (0, tq.Z)(),
                                    author: {
                                        role: tH.uU.Tool,
                                        name: "browser"
                                    },
                                    content: {
                                        content_type: tH.PX.Text,
                                        parts: ["".concat(JSON.stringify(o))]
                                    },
                                    recipient: "all"
                                })]];
                            case 6:
                                return [4, r.scroll(t.amount)];
                            case 8:
                                return [4, r.browse(t.url)];
                            case 10:
                                return [4, r.click(t.target)];
                            case 12:
                                throw Error("Unsupported browser action type " + t);
                            case 13:
                                return [3, 15];
                            case 14:
                                return console.error(a = n.sent()), [2, [{
                                    id: (0, tq.Z)(),
                                    author: {
                                        role: tH.uU.Tool,
                                        name: "browser"
                                    },
                                    content: {
                                        content_type: tH.PX.Text,
                                        parts: ["Error making browse call: ".concat(a)]
                                    },
                                    recipient: "all"
                                }]];
                            case 15:
                                return [2]
                        }
                    })
                })).apply(this, arguments)
            }
            var sM = n(23111),
                sT = n(98076);

            function sN(e, t, n, r, a, i, o) {
                return sP.apply(this, arguments)
            }

            function sP() {
                return (sP = (0, eG._)(function(e, t, n, r, a, i, o) {
                    var s, l, u;
                    return (0, e$.__generator)(this, function(d) {
                        switch (d.label) {
                            case 0:
                                if (l = null === (s = a.get(n)) || void 0 === s ? void 0 : s.tags.includes(a_.S.GPT_4), r && l && rc.Z.gatherData(), S.tQ.updateTree(e, function(e) {
                                        var n = !0,
                                            r = !1,
                                            a = void 0;
                                        try {
                                            for (var i, s = o[Symbol.iterator](); !(n = (i = s.next()).done); n = !0) {
                                                var l = i.value;
                                                e.addNode(l.id, l, t, tH.Jq.Completion, {
                                                    completionSampleFinishTime: Date.now()
                                                }), t = l.id
                                            }
                                        } catch (e) {
                                            r = !0, a = e
                                        } finally {
                                            try {
                                                n || null == s.return || s.return()
                                            } finally {
                                                if (r) throw a
                                            }
                                        }
                                    }), S.tQ.setThreadCurrentLeafId(e, t), !(r && l)) return [3, 2];
                                return [4, rc.Z.getEnforcementToken()];
                            case 1:
                                u = d.sent(), d.label = 2;
                            case 2:
                                return i({
                                    model: n,
                                    completionType: tH.Os.Next,
                                    parentNodeId: t,
                                    metadata: {},
                                    arkoseToken: null != u ? u : null
                                }), [2]
                        }
                    })
                })).apply(this, arguments)
            }
            var sS = n(65642),
                sI = [/\bnigger\w*/i, /\bfaggot\w*/i, /\bkike\w*/i, /\bdykes?\b/i, /\bwetbacks?\b/i, /\bchinks?\b/i, /\bgooks?\b/i, /\bpakis?\b/i, /\binjuns?\b/i, /\btrannys?\b/i, /\btrannies\b/i, /\bspicks?\b/i, /\bshemales?\b/i],
                sZ = n(58268);

            function sF(e) {
                return sD.apply(this, arguments)
            }

            function sD() {
                return (sD = (0, eG._)(function(e) {
                    var t, n;
                    return (0, e$.__generator)(this, function(r) {
                        switch (r.label) {
                            case 0:
                                return (t = (0, j._)(e.queryKey, 2))[0], n = t[1], [4, P.ZP.getThreadInterpreterState(n).then(function(e) {
                                    return 0 === e.time_remaining_ms && e.kernel_started && tl.m.warning("This code interpreter (beta) chat has timed out. You may continue the conversation, but previous files, links, and code blocks below may not work as expected.", {
                                        hasCloseButton: !0,
                                        duration: 0
                                    }), e
                                })];
                            case 1:
                                return [2, r.sent()]
                        }
                    })
                })).apply(this, arguments)
            }
            var sE = n(55344),
                sR = n.n(sE)()(function() {
                    return Promise.resolve().then(n.bind(n, 40803))
                }, {
                    loadableGenerated: {
                        webpack: function() {
                            return [40803]
                        }
                    },
                    ssr: !1
                });

            function sB(e) {
                var t = e.children;
                return (0, w.jsx)(sR, {
                    className: "h-full dark:bg-gray-800",
                    followButtonClassName: "scroll-convo",
                    initialScrollBehavior: "auto",
                    children: t
                })
            }

            function sA() {
                var e = (0, Q._)(["grow flex-1 overflow-hidden"]);
                return sA = function() {
                    return e
                }, e
            }

            function sL() {
                var e = (0, Q._)(["absolute bottom-0 left-0 w-full border-t md:border-t-0 dark:border-white/20 md:border-transparent md:dark:border-transparent md:bg-vert-light-gradient bg-white dark:bg-gray-800 md:!bg-transparent dark:md:bg-vert-dark-gradient pt-2 md:pl-2 md:w-[calc(100%-.5rem)]"]);
                return sL = function() {
                    return e
                }, e
            }
            var sU = (0, N.vU)({
                contentPolicyViolation: {
                    id: "thread.modal.restrictedTerms.title",
                    defaultMessage: "This prompt may violate our content policy.",
                    description: "Title for the restricted terms modal"
                },
                acknowledge: {
                    id: "thread.modal.common.acknowledge",
                    defaultMessage: "Acknowledge",
                    description: "Acknowledge button text"
                },
                doNotShareSensitive: {
                    id: "thread.modal.onboarding.title",
                    defaultMessage: "Do not share sensitive materials with this application",
                    description: "Title for the onboarding warning modal"
                },
                freeResearchPreview: {
                    id: "thread.chatgptFreeResearchPreview-july20-23",
                    defaultMessage: "Free Research Preview. ChatGPT may produce inaccurate information about people, places, or facts. <link>ChatGPT July 20 Version</link>",
                    description: "Free Research Preview disclaimer"
                },
                mayProduceInaccurateInformation: {
                    id: "thread.chatgptMayProduceInaccurateInformation-july20-23",
                    defaultMessage: "ChatGPT may produce inaccurate information about people, places, or facts. <link>ChatGPT July 20 Version</link>",
                    description: "ChatGPT disclaimer for producing inaccurate information"
                },
                somethingWentWrong: {
                    id: "thread.modal.unrecoverableError.title",
                    defaultMessage: "Something went wrong",
                    description: "Title for the UnrecoverableErrorModal"
                },
                tryAgainLater: {
                    id: "thread.modal.unrecoverableError.description",
                    defaultMessage: "We're sorry, but something went wrong. Please try again later.",
                    description: "Description for the UnrecoverableErrorModal"
                },
                resetThread: {
                    id: "thread.modal.unrecoverableError.resetThread",
                    defaultMessage: "Reset thread",
                    description: "Reset thread button text"
                },
                reportModalThankYouTitle: {
                    id: "thread.modal.reportModalThankYou.title",
                    defaultMessage: "Thank you for your report!",
                    description: "Title for the post-report thank-you modal"
                },
                reportModalThankYouDescription: {
                    id: "thread.modal.reportModalThankYou.description",
                    defaultMessage: "Thank you for your report.",
                    description: "Description for the post-report thank-you modal"
                },
                reportModalThankYouDismiss: {
                    id: "thread.modal.reportModalThankYou.dismissButton",
                    defaultMessage: "Close",
                    description: "Close button for the post-report thank-you modal"
                },
                sharedConversationContinueConversation: {
                    id: "thread.sharedConversation.continue",
                    defaultMessage: "Continue this conversation",
                    description: "Button for shared links to allow user to continue conversation in their own history"
                },
                sharedConversationReportConversation: {
                    id: "thread.sharedConversation.report",
                    defaultMessage: "Report conversation",
                    description: "Button for shared links to report chat for legal, safety, or other reasons"
                },
                sharedConversationModerateConversation: {
                    id: "thread.sharedConversation.moderate",
                    defaultMessage: "Moderate conversation",
                    description: "Button for shared links to moderate a chat for legal, safety, or other reasons"
                },
                reportSharedConversation: {
                    id: "thread.reportSharedConversation",
                    defaultMessage: "Report content",
                    description: "Report shared chat footer link text"
                },
                termsOfUse: {
                    id: "thread.termsOfUse",
                    defaultMessage: "Terms of use",
                    description: "Terms of use footer link text"
                },
                privacyPolicy: {
                    id: "thread.privacyPolicy",
                    defaultMessage: "Privacy policy",
                    description: "Privacy policy footer link text"
                },
                helpAndFaq: {
                    id: "thread.helpAndFaq",
                    defaultMessage: "Help & FAQ",
                    description: "Help & FAQ menu item"
                },
                keyboardShortcutsMenu: {
                    id: "thread.keyboardShortcutsMenu",
                    defaultMessage: "Keyboard shortcuts",
                    description: "Keyboard shortcuts menu item"
                }
            });

            function sO(e) {
                var t = e.onClickReportSharedConversation;
                return (0, w.jsxs)("div", {
                    className: "flex justify-center gap-3 text-gray-500",
                    children: [(0, w.jsx)("button", {
                        onClick: function() {
                            t()
                        },
                        children: (0, w.jsx)(T.Z, (0, b._)({}, sU.reportSharedConversation))
                    }), (0, w.jsx)("span", {
                        children: "|"
                    }), (0, w.jsx)("a", {
                        href: "https://openai.com/policies/terms-of-use",
                        target: "_blank",
                        rel: "noreferrer",
                        children: (0, w.jsx)(T.Z, (0, b._)({}, sU.termsOfUse))
                    }), (0, w.jsx)("span", {
                        children: "|"
                    }), (0, w.jsx)("a", {
                        href: "https://openai.com/policies/privacy-policy",
                        target: "_blank",
                        rel: "noreferrer",
                        children: (0, w.jsx)(T.Z, (0, b._)({}, sU.privacyPolicy))
                    })]
                })
            }
            var sq = function(e) {
                    var t, n, r, a, i, o, s, l, u, d, c, f, g, h, m, p, v, x, C, N, I, Z, D, L, O, q, z, H, W, Q, $, Y, J, K, X, ee, et, en = e.initialThreadData,
                        er = e.clientThreadId,
                        eo = e.activeRequests,
                        ed = e.setActiveRequests,
                        eh = e.handleResetThread,
                        em = e.initiallyHighlightedMessageId,
                        ep = e.continueConversationUrl,
                        eb = (0, _.useContext)(A.gB),
                        ey = (0, ei.Z)(),
                        ej = (0, B.hz)(),
                        eC = (0, tb.Fl)().isPluginsAvailable,
                        ek = (0, U.w$)(),
                        e_ = (0, _.useContext)(A.QL).historyDisabled,
                        eM = (0, k.useRouter)(),
                        eT = eb && (null === ($ = eM.query) || void 0 === $ ? void 0 : null === (Y = $.shareParams) || void 0 === Y ? void 0 : Y[1]) === "moderate",
                        eN = (0, S.U0)(er),
                        eP = (0, S.Kt)(er),
                        eS = (0, S.oq)(er),
                        eI = (0, S.je)(er),
                        eZ = (0, S.Hk)(er),
                        eF = (0, _.useContext)(A.gt).serviceStatus,
                        eD = eo.has(eZ),
                        eE = "root" !== eS && !eD && !(null == eF ? void 0 : eF.oof),
                        eR = (0, j._)((0, _.useState)(!1), 2),
                        eB = eR[0],
                        eA = eR[1],
                        eL = (0, j._)((0, _.useState)(!1), 2),
                        eU = eL[0],
                        eO = eL[1],
                        eq = (0, j._)((0, _.useState)(), 2),
                        ez = eq[0],
                        eH = eq[1],
                        eW = (0, j._)((0, _.useState)(!1), 2),
                        eV = eW[0],
                        eY = eW[1],
                        eJ = (0, j._)((0, _.useState)(), 2),
                        eK = eJ[0],
                        eX = eJ[1],
                        e0 = (0, j._)((0, _.useState)(), 2),
                        e1 = e0[0],
                        e2 = e0[1],
                        e3 = (0, j._)((0, _.useState)(), 2),
                        e5 = e3[0],
                        e4 = e3[1],
                        e8 = (0, _.useRef)(null),
                        e7 = (0, B.WY)(),
                        e6 = (0, eQ.g)(function(e) {
                            return e.flags.isUserInCanPayGroup
                        }),
                        e9 = ej.has(eu.FZ),
                        te = (0, j._)((0, _.useState)(!1), 2),
                        tt = te[0],
                        tn = te[1],
                        tr = (o = (i = {
                            exempt: !1,
                            onRestrictedTermFound: (0, _.useCallback)(function(e) {
                                tn(!0), es.o.logEvent(el.a.promptUsedRestrictedWords, {
                                    threadId: S.tQ.getServerThreadId(er),
                                    content: e
                                })
                            }, [er])
                        }).exempt, s = i.onRestrictedTermFound, u = (l = (0, j._)((0, _.useState)(!1), 2))[0], d = l[1], {
                            hasRestrictedTerms: u,
                            checkRestrictedTerms: (0, _.useCallback)(function(e) {
                                var t;
                                return (sI.some(function(n) {
                                    var r = n.exec(e);
                                    return r && (t = r[0]), r
                                }), !o && t) ? (d(!0), null == s || s(t), !0) : (d(!1), !1)
                            }, [o, s])
                        }),
                        ta = tr.hasRestrictedTerms,
                        ti = tr.checkRestrictedTerms,
                        to = (0, j._)((0, _.useState)(!0), 2),
                        ts = to[0],
                        tl = to[1],
                        tu = (0, j._)((0, _.useState)(!1), 2),
                        td = tu[0],
                        tc = tu[1],
                        tf = (0, a_.iu)(),
                        tg = ni(),
                        th = (0, a_.Gg)(tf, !0),
                        tm = null !== (et = (0, a_.Bv)(en.lastModelUsed, er)) && void 0 !== et ? et : th,
                        tp = (0, a_.B9)(),
                        tv = void 0 !== tm ? tp.get(tm) : void 0,
                        tx = ew(),
                        ty = (0, _.useCallback)(function() {
                            tx(), es.o.logEvent(el.a.newThread)
                        }, [tx]),
                        tj = S.tQ.getTitle(er),
                        tw = (0, _.useCallback)(function(e, t) {
                            var n = null != t ? t : "";
                            e_ || "" === n || P.ZP.generateTitle(n, e, tm).then(function(e) {
                                var r = e.title;
                                S.tQ.setTitle(n, r, S._L.Generated), tx(), es.o.logEvent(el.a.renameThread, {
                                    threadId: t,
                                    content: r,
                                    model: tm
                                })
                            }).catch(function(e) {
                                console.error(e)
                            })
                        }, [e_, tm, tx]),
                        tC = (0, sZ.x0)();
                    (0, _.useEffect)(function() {
                        (0, sZ.sb)()
                    }, []);
                    var tk = eN >= 2,
                        t_ = (0, B.hz)().has(eu.Zz) ? [{
                            title: "Brainstorm names",
                            body: "for my cafe-by-day, bar-by-night business",
                            prompt: 'Come up with 5 sophisticated names for my coffee-shop-by-day, bar-by-night business like "The Page Turner".'
                        }, {
                            title: "Explain superconductors",
                            body: "like I'm five years old",
                            prompt: "Explain superconductors like I'm five years old."
                        }, {
                            title: "Write a thank-you note",
                            body: "to my interviewer",
                            prompt: "Write a friendly thank-you note to my interviewer, reiterating my excitement for the job opportunity."
                        }, {
                            title: "Plan a trip",
                            body: "to experience Seoul like a local",
                            prompt: "I'm planning a 4-day trip to Seoul. Can you suggest an itinerary that doesn't involve popular tourist attractions?"
                        }] : [],
                        tM = (null == tC ? void 0 : tC.messageId) === (null === (J = S.tQ.getTree(er).getLastValidNode(eS)) || void 0 === J ? void 0 : null === (K = J.message) || void 0 === K ? void 0 : K.id) ? null == tC ? void 0 : tC.suggestions : tk ? void 0 : t_,
                        tN = (0, _.useCallback)(function(e, t, n) {
                            var r = (0, B.N$)().has(eu.uj);
                            e_ || !r || void 0 === n || (0, tT.lD)(n) || (0, tT.JD)(n) || (0, sZ.yu)(e, t, tm)
                        }, [e_, tm]),
                        tP = (0, S.Uy)(er),
                        tS = (c = eC && (null == tv ? void 0 : null === (X = tv.enabledTools) || void 0 === X ? void 0 : X.includes("tools3")) ? tg.map(function(e) {
                            return e.id
                        }) : void 0, g = (f = (0, B.hz)()).has(eu.PL), h = (0, _.useId)(), m = (0, sT.Y8)(function(e) {
                            return null == e ? void 0 : e.setCapTimeout
                        }), p = (0, sT.Y8)(function(e) {
                            return null == e ? void 0 : e.clearCapTimeout
                        }), v = (0, _.useContext)(A.QL).historyDisabled, x = (0, a_.B9)(), C = (0, _.useRef)(0), N = (0, _.useRef)({}), I = (0, _.useRef)(void 0), (0, _.useEffect)(function() {
                            return function() {
                                var e;
                                return null === (e = I.current) || void 0 === e ? void 0 : e.call(I)
                            }
                        }, []), Z = (0, _.useCallback)(function(e, t, n, r) {
                            var a, i, o, s, l, u = r.eventSource,
                                d = function() {
                                    rC.m.logEvent("chatgpt_focus_after_blur_during_completion", null, {
                                        completion_duration_ms: "".concat(o - F),
                                        blur_time_ms: "".concat(s - F),
                                        refocus_time_ms: "".concat(l - F)
                                    })
                                },
                                c = function() {
                                    if (void 0 === s) {
                                        s = Date.now();
                                        var e = function() {
                                                window.removeEventListener("focus", t), I.current = void 0
                                            },
                                            t = function() {
                                                l = Date.now(), void 0 !== o && d(), e()
                                            };
                                        window.addEventListener("focus", t), I.current = e
                                    }
                                },
                                h = function() {
                                    window.removeEventListener("blur", c), setTimeout(function() {
                                        E.removeAborterById(n), ed(function(e) {
                                            var t = new Set(e);
                                            return t.delete(n), t
                                        }), delete N.current[n], S.tQ.releaseThread(er)
                                    }, 0)
                                },
                                v = S.tQ.getTree(er),
                                y = n,
                                j = v.getParentId(y),
                                w = t === tH.Os.Continue,
                                C = !0,
                                k = !1,
                                _ = v.getMessage(y),
                                M = new Set,
                                T = v.getIsBlockedFromNode(j),
                                P = !1,
                                Z = !1,
                                F = Date.now();
                            window.addEventListener("blur", c);
                            var D = oh()(function() {
                                T || P || S.tQ.updateTree(er, function(e) {
                                    e.updateNodeMessage(y, _)
                                })
                            }, 50, {
                                leading: !0,
                                maxWait: 50
                            });
                            return a = (0, eG._)(function(r) {
                                    var a, c, j, I, R, B, A, U, O, q, z, H, W, Q, G, $, Y, J, K, X, ee, et, en, ea, ei, eo, eu;
                                    return (0, e$.__generator)(this, function(ed) {
                                        switch (ed.label) {
                                            case 0:
                                                if ("error" === r.type) return console.error(a = r.error), c = (null == a ? void 0 : a.message) || "Something went wrong", S.tQ.updateTree(er, function(e) {
                                                    e.updateNode(y, {
                                                        message: {
                                                            $set: _
                                                        },
                                                        metadata: {
                                                            $set: {
                                                                err: c,
                                                                errType: "danger",
                                                                errCode: (0, sM.T)(a) && a.code || "",
                                                                completionSampleFinishTime: Date.now()
                                                            }
                                                        }
                                                    })
                                                }), h(), (0, sM.T)(a) && (null == a ? void 0 : a.code) === sT.uU && (null == a ? void 0 : a.clearsIn) && (m(new Date(Date.now() + 1e3 * a.clearsIn).toISOString()), setTimeout(function() {
                                                    p()
                                                }, 1e3 * a.clearsIn)), [2];
                                                if ("moderation" === r.type && (j = r.isCompletion, I = r.messageId, R = r.conversationId, B = r.flagged, A = r.blocked, (B || A) && (Z = !0, A && (P = !0, j || (T = !0)), S.tQ.updateTree(er, function(e) {
                                                        var t = e.messageIdToNodeId(I);
                                                        e.updateNode(t, {
                                                            message: {
                                                                content: {
                                                                    parts: {
                                                                        $set: [""]
                                                                    }
                                                                }
                                                            },
                                                            metadata: {
                                                                $set: (0, V._)((0, b._)({}, A ? rf.sK : rf.Mf), {
                                                                    completionSampleFinishTime: Date.now()
                                                                })
                                                            }
                                                        })
                                                    }), es.o.logEvent(j ? A ? el.a.completionBlockedByModeration : el.a.completionFlaggedByModeration : A ? el.a.promptBlockedByModeration : el.a.promptFlaggedByModeration, {
                                                        threadId: R,
                                                        id: I
                                                    }))), "message" === r.type) {
                                                    if (U = r.message, O = r.conversationId, C && v.isFirstCompletion) {
                                                        if ((null == U ? void 0 : U.author.role) === tH.uU.System) return v.appendSystemMessageToRoot(U), [2];
                                                        if ((null == U ? void 0 : U.author.role) === tH.uU.User) return [2]
                                                    }
                                                    C ? (z = (null === (q = S.qN.getState().threads[er]) || void 0 === q ? void 0 : q.continuingFromSharedConversationId) != null, S.tQ.removeContinuingFromSharedConversationId(er), C = !1, k = v.isFirstCompletion || z, (null == U ? void 0 : U.id) && M.add(n), void 0 !== O && (i = O, (0, S.Zz)(er) && S.tQ.setServerIdForNewThread(er, O)), S.tQ.updateTree(er, function(e) {
                                                        e.updateNodeMessage(y, U)
                                                    }), k && ty(O), H = {
                                                        id: n,
                                                        threadId: O,
                                                        completionType: t,
                                                        eventSource: u,
                                                        model: e
                                                    }, t === tH.Os.Next && (Y = null == ($ = S.qN.getState().threads[O]) ? void 0 : null === (W = $.conversationTurns) || void 0 === W ? void 0 : W.length, (K = null === (G = (J = null == $ ? void 0 : null === (Q = $.conversationTurns) || void 0 === Q ? void 0 : Q.filter(function(e) {
                                                        return e.role == tH.uU.User
                                                    }))[J.length - 1]) || void 0 === G ? void 0 : G.messages[0].message).content.content_type == tH.PX.Text && (X = K.content.parts.join("").length, et = null !== (ee = J.length) && void 0 !== ee ? ee : 0, H.countConversationTurns = Y, H.countUserSubmittedMessages = et, H.countLastUserPromptTextMessageLength = X)), es.o.logEvent(el.a.generateCompletion, H), E.addAborter(n, N.current[n])) : w || U.id === v.getMessageId(y) || (M.add(U.id), D.flush(), S.tQ.updateTree(er, function(e) {
                                                        e.addNode(U.id, U, y, tH.Jq.Completion)
                                                    }), y = U.id, S.tQ.setThreadCurrentLeafId(er, y)), _ = U
                                                }
                                                if (D(), "done" !== r.type) return [3, 4];
                                                if (T || P || (D.flush(), Z || (ea = v.getMessageId(y), k && tw(ea, i), tN(i, ea, _))), S.tQ.updateTree(er, function(e) {
                                                        e.updateNode(y, {
                                                            metadata: {
                                                                $set: (0, V._)((0, b._)({}, v.getMetadata(y)), {
                                                                    completionSampleFinishTime: Date.now()
                                                                })
                                                            }
                                                        })
                                                    }), h(), !((null == _ ? void 0 : null === (en = _.metadata) || void 0 === en ? void 0 : en.client_actions) !== void 0)) return [3, 2];
                                                return [4, function(e, t) {
                                                    return sC.apply(this, arguments)
                                                }(er, _)];
                                            case 1:
                                                (ei = ed.sent()).length > 0 && sN(er, y, e, g, x, L, ei), ed.label = 2;
                                            case 2:
                                                if (void 0 !== s && (o = Date.now(), rC.m.logEvent("chatgpt_blur_during_completion", null, {
                                                        completion_duration_ms: "".concat(o - F),
                                                        blur_time_ms: "".concat(s - F)
                                                    }), void 0 !== l && d()), !f.has("tools3_dev") || !(eo = function(e) {
                                                        var t, n, r, a, i = null !== (a = null === (t = e.metadata) || void 0 === t ? void 0 : null === (n = t.invoked_plugin) || void 0 === n ? void 0 : n.http_api_call_data) && void 0 !== a ? a : null === (r = e.metadata) || void 0 === r ? void 0 : r.http_api_call_data;
                                                        if (void 0 !== i) {
                                                            if (e.author.role !== tH.uU.Assistant) {
                                                                console.error("Refusing to make localhost plugin HTTP call from non-assistant message", e);
                                                                return
                                                            }
                                                            if ("object" != typeof i || "string" != typeof i.namespace || 0 === i.namespace.length || "string" != typeof i.function_name || 0 === i.function_name.length || "string" != typeof i.parent_message_id || 0 === i.parent_message_id.length || "string" != typeof i.url || 0 === i.url.length || "string" != typeof i.method || !["get", "post", "put", "delete", "patch"].includes(i.method) || !Array.isArray(i.qs_params) || i.qs_params.some(function(e) {
                                                                    return !Array.isArray(e) || 2 !== e.length || "string" != typeof e[0] || "string" != typeof e[1]
                                                                }) || "object" != typeof i.headers || Object.keys(i.headers).some(function(e) {
                                                                    return "string" != typeof e
                                                                }) || Object.values(i.headers).some(function(e) {
                                                                    return "string" != typeof e
                                                                }) || !(null === i.body || "object" == typeof i.body && Object.keys(i.body).every(function(e) {
                                                                    return "string" == typeof e
                                                                })) || "string" != typeof i.api_function_type || !["kwargs", "chat"].includes(i.api_function_type)) {
                                                                console.error("Refusing to make localhost plugin HTTP call with invalid metadata", e);
                                                                return
                                                            }
                                                            if (!/^https?:\/\/localhost:/.test(i.url)) {
                                                                console.error("Refusing to make localhost plugin HTTP call with non-localhost URL", e);
                                                                return
                                                            }
                                                            return i
                                                        }
                                                    }(_))) return [3, 4];
                                                return eu = [er, y, e, g, x, L], [4, function(e) {
                                                    return tW.apply(this, arguments)
                                                }(eo)];
                                            case 3:
                                                sN.apply(void 0, eu.concat([ed.sent()])), ed.label = 4;
                                            case 4:
                                                return [2]
                                        }
                                    })
                                }),
                                function(e) {
                                    return a.apply(this, arguments)
                                }
                        }, [ty, tw, ed, er]), L = (0, _.useCallback)((D = (0, eG._)(function(e) {
                            var t, n, r, a, i, o, s, l, u, d, f, g, m, p, x, b, y;
                            return (0, e$.__generator)(this, function(j) {
                                switch (j.label) {
                                    case 0:
                                        return t = e.model, n = e.completionType, r = e.parentNodeId, a = e.metadata, o = void 0 === (i = e.focusOnNewCompletion) || i, s = e.completionMetadata, l = e.arkoseToken, u = S.tQ.getTree(er), S.tQ.retainThread(er), d = "".concat(rh.Vh).concat(h, "-").concat(C.current++), ed(function(e) {
                                            var t = new Set(e);
                                            return t.add(d), t
                                        }), S.tQ.updateTree(er, function(e) {
                                            e.addNode(d, "", r, tH.Jq.Completion)
                                        }), o && S.tQ.setThreadCurrentLeafId(er, d), g = [], m = u.getNode(r), n === tH.Os.Next || n === tH.Os.Variant ? (f = (null === (p = (x = u.getNode(m.parentId)).message) || void 0 === p ? void 0 : p.id) || x.id, g.push(m.message)) : f = m.message.id, void 0 === (b = S.tQ.getServerThreadId(er)) && (0, S.Zz)(er) && S.tQ.updateInitialThreadDataForNewThread(er, t, c), [4, P.ZP.publicApiCompletionStream({
                                            model: t,
                                            completionType: n,
                                            threadId: b,
                                            continueFromSharedConversationId: tP,
                                            historyDisabled: v,
                                            parentMessageId: f,
                                            messages: g,
                                            arkoseToken: null != l ? l : null,
                                            enabledPluginIds: c,
                                            completionMetadata: s
                                        }, Z(t, n, d, a))];
                                    case 1:
                                        return y = j.sent(), N.current[d] = y, [2]
                                }
                            })
                        }), function(e) {
                            return D.apply(this, arguments)
                        }), [er, h, ed, tP, v, c, Z])),
                        tI = (0, _.useCallback)(function() {
                            if (eS) {
                                var e = S.tQ.getTree(er).getBranchFromLeaf(eS);
                                e.forEach(function(e) {
                                    E.abortAndRemoveById(e.id)
                                }), ed(function(t) {
                                    var n = new Set(t);
                                    return e.forEach(function(e) {
                                        n.delete(e.id)
                                    }), n
                                })
                            }
                        }, [eS, ed, er]),
                        tZ = ej.has(eu.PL),
                        tF = (0, _.useCallback)((O = (0, eG._)(function(e, t, n, r) {
                            var a, i, o, s, l, u, d, c, f = arguments;
                            return (0, e$.__generator)(this, function(g) {
                                switch (g.label) {
                                    case 0:
                                        if (a = !(f.length > 4) || void 0 === f[4] || f[4], i = f.length > 5 ? f[5] : void 0, o = f.length > 6 ? f[6] : void 0, (0, sZ.sb)(), r && tI(), l = S.tQ.getTree(er), e !== tH.Os.Continue && ti(l.getTextFromNode(t))) return [2];
                                        if (u = i ? th : tm, d = null === (s = tp.get(u)) || void 0 === s ? void 0 : s.tags.includes(a_.S.GPT_4), !(tZ && d)) return [3, 2];
                                        return [4, rc.Z.getEnforcementToken()];
                                    case 1:
                                        c = g.sent(), g.label = 2;
                                    case 2:
                                        return tS({
                                            model: u,
                                            completionType: e,
                                            parentNodeId: t,
                                            metadata: n,
                                            focusOnNewCompletion: a,
                                            completionMetadata: o,
                                            arkoseToken: null != c ? c : null
                                        }), [2]
                                }
                            })
                        }), function(e, t, n, r) {
                            return O.apply(this, arguments)
                        }), [er, ti, th, tm, tp, tZ, tS, tI]),
                        tD = (0, _.useCallback)(function(e, t, n, r) {
                            S.tQ.updateTree(er, function(a) {
                                a.addNode(e, n, t, tH.Jq.Prompt, void 0, r)
                            })
                        }, [er]),
                        tE = (0, _.useCallback)(function(e, t, n) {
                            var r = t.content,
                                a = t.attachments,
                                i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                            tD(e, eS, r, a.length > 0 ? {
                                attachments: a
                            } : {}), tF(tH.Os.Next, e, n, !0, void 0, void 0, i)
                        }, [eS, tD, tF]),
                        tR = (0, _.useRef)(!1),
                        tB = (0, ev.kP)().session,
                        tA = (0, a_.B8)();
                    (0, _.useEffect)(function() {
                        if (tB && void 0 !== tv && (void 0 === tv.enabledTools || !(tv.enabledTools.length > 0)) && ej.has(eu.Yj) && 0 !== tA.enabledModelsInCategoriesById.size && !tR.current && void 0 === S.tQ.getServerThreadId(er)) {
                            var e, t = eM.query,
                                n = t.m,
                                r = (0, y._)(t, ["m"]);
                            if (void 0 !== n) {
                                e = Array.isArray(n) ? n[0] : n;
                                var a = (0, tq.Z)();
                                tR.current = !0, tE(a, {
                                    content: e,
                                    attachments: []
                                }, {
                                    eventSource: "url"
                                }), eM.replace({
                                    pathname: eM.pathname,
                                    query: r
                                })
                            }
                        }
                    }, [tv, eM, tE, tB, tA, ej, er]);
                    var tL = (0, S.nh)(er, eS),
                        tU = (0, _.useMemo)(function() {
                            var e, t, n = tL.type === tH.Jq.Prompt,
                                r = (null === (e = tL.metadata) || void 0 === e ? void 0 : e.err) && (null === (t = tL.metadata) || void 0 === t ? void 0 : t.errCode) !== rf.Dd;
                            return !!(n || r) && 0 === eo.size
                        }, [eo.size, tL]),
                        tO = (0, sT.Y8)(function(e) {
                            return e.isoDate
                        }),
                        tz = (0, _.useMemo)(function() {
                            var e, t = (null === (e = tL.metadata) || void 0 === e ? void 0 : e.errCode) === sT.uU;
                            return tU && t && null != tO && "" !== tO
                        }, [null === (ee = tL.metadata) || void 0 === ee ? void 0 : ee.errCode, tU, tO]),
                        tV = (0, _.useCallback)(function(e, t) {
                            var n = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
                                r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "none",
                                a = arguments.length > 4 ? arguments[4] : void 0,
                                i = S.tQ.getTree(er).getParentPromptNode(e).id;
                            tF(tH.Os.Variant, i, t, !1, n, a, {
                                variantPurpose: r
                            })
                        }, [tF, er]),
                        tQ = (0, _.useCallback)(function(e) {
                            es.o.logEvent(el.a.continueCompletion), tF(tH.Os.Continue, e, {
                                eventSource: "mouse"
                            }, !1)
                        }, [tF]),
                        tG = (0, _.useCallback)(function(e) {
                            var t = S.tQ.getTree(er).getLeafFromNode(e);
                            S.tQ.setThreadCurrentLeafId(er, t.id)
                        }, [er]),
                        t$ = (0, _.useCallback)(function(e, t) {
                            S.tQ.updateTree(er, function(n) {
                                n.updateNodeText(e, t)
                            })
                        }, [er]),
                        tY = (0, _.useCallback)(function(e, t, n) {
                            var r = S.tQ.getServerThreadId(er);
                            if (es.o.logEvent(el.a.thumbRating, {
                                    id: t,
                                    threadId: r,
                                    rating: n,
                                    model: tm
                                }), void 0 !== r && P.ZP.submitMessageFeedback({
                                    message_id: t,
                                    conversation_id: r,
                                    rating: n
                                }), e2(e), e4(t), eX(n), S.tQ.updateTree(er, function(t) {
                                    var r = t.getMetadata(e);
                                    t.updateNode(e, {
                                        metadata: {
                                            $set: (0, V._)((0, b._)({}, r), {
                                                rating: n
                                            })
                                        }
                                    })
                                }), "thumbsDown" === n && ek) {
                                var a = S.tQ.getTree(er).getConversationTurns(e || "root");
                                aY(a[a.length - 1]) && tV(e, {
                                    eventSource: "mouse",
                                    intent: "comparison"
                                }, !1, "comparison")
                            }
                        }, [er, tm, ek, tV]),
                        tJ = (0, _.useCallback)(function(e, t) {
                            if (eK && null != e1 && "" !== e1 && (e || t.length > 0)) {
                                var n = S.tQ.getServerThreadId(er);
                                es.o.logEvent(el.a.reportResult, {
                                    id: e5,
                                    threadId: n,
                                    content: e,
                                    model: tm,
                                    rating: eK,
                                    tags: t
                                }), er && e5 && P.ZP.submitMessageFeedback({
                                    message_id: e5,
                                    conversation_id: n,
                                    rating: eK,
                                    text: e,
                                    tags: t
                                })
                            }
                        }, [eK, e1, er, e5, tm]),
                        tK = (0, _.useCallback)(function(e, t) {
                            if (eB && null != ez && "" !== ez) {
                                var n = S.tQ.getServerThreadId(er);
                                es.o.logEvent(el.a.reportResult, {
                                    id: e5,
                                    threadId: n,
                                    content: e,
                                    model: tm,
                                    rating: eK,
                                    tags: t
                                }), P.ZP.submitSharedConversationReportFeedback({
                                    message_id: ez,
                                    shared_conversation_id: n,
                                    text: e,
                                    tags: t
                                }), eO(!0)
                            }
                        }, [eK, eB, ez, er, e5, tm]),
                        tX = (0, _.useCallback)((q = (0, eG._)(function(e, t, n, r, a, i, o, s, l, u, d) {
                            return (0, e$.__generator)(this, function(c) {
                                switch (c.label) {
                                    case 0:
                                        return [4, P.ZP.submitMessageComparisonFeedback({
                                            feedback_version: "comparison_feedback_modal:a:1.0",
                                            original_message_id: e,
                                            new_message_id: t,
                                            rating: n,
                                            conversation_id: S.tQ.getServerThreadId(er),
                                            text: u,
                                            tags: d.map(function(e) {
                                                return e.replace("feedback-", "")
                                            }),
                                            completion_comparison_rating: r,
                                            new_completion_placement: a,
                                            feedback_start_time: i,
                                            compare_step_start_time: o,
                                            new_completion_load_start_time: s,
                                            new_completion_load_end_time: l,
                                            frontend_submission_time: Date.now(),
                                            timezone_offset_min: new Date().getTimezoneOffset()
                                        })];
                                    case 1:
                                        return c.sent(), [2]
                                }
                            })
                        }), function(e, t, n, r, a, i, o, s, l, u, d) {
                            return q.apply(this, arguments)
                        }), [er]),
                        t0 = (0, _.useCallback)(function(e, t) {
                            var n = S.tQ.getTree(er).getConversationTurns(e),
                                r = null == n ? void 0 : n[(null == n ? void 0 : n.length) - 1].variantIds,
                                a = (null == r ? void 0 : r.length) === 1;
                            tV(e, a ? (0, V._)((0, b._)({}, t), {
                                intent: "comparison_implicit"
                            }) : t, !0, a ? "comparison_implicit" : "none")
                        }, [tV, er]),
                        t1 = (0, _.useCallback)(function(e) {
                            S.tQ.updateTree(er, function(t) {
                                t.deleteNode(e)
                            })
                        }, [er]),
                        t2 = (0, _.useCallback)(function() {
                            R.vm.closeModal(R.B.AccountPortal)
                        }, []),
                        t3 = (0, nE.t)(function(e) {
                            return {
                                setShowAccountPaymentModal: e.setShowAccountPaymentModal,
                                showAccountPaymentModal: e.showAccountPaymentModal
                            }
                        }),
                        t5 = t3.showAccountPaymentModal,
                        t4 = t3.setShowAccountPaymentModal,
                        t8 = (0, _.useCallback)(function() {
                            t4(!1)
                        }, [t4]),
                        t7 = (0, _.useCallback)(function(e, t) {
                            var n = S.tQ.getTree(er);
                            if (n.isFirstCompletion && !e_) {
                                var r, a = n.getParent(t);
                                (null === (r = a.metadata) || void 0 === r ? void 0 : r.errCode) !== rf.Dd && setTimeout(function() {
                                    tw(a.message.id)
                                }, 500)
                            }
                            E.abortAndRemoveById(t), eo.has(t) && (S.tQ.updateTree(er, function(e) {
                                e.updateNodeMessageMetadata(t, {
                                    finish_details: {
                                        type: "interrupted"
                                    }
                                })
                            }), ed(function(e) {
                                var n = new Set(e);
                                return n.delete(t), n
                            }))
                        }, [tw, e_, eo, ed, er]),
                        t6 = (0, _.useCallback)(function() {
                            tc(!0)
                        }, []);
                    (0, _.useEffect)(function() {
                        var e = rd().subscribe("AbortCompletion", t7),
                            t = rd().subscribe("UnrecoverableError", t6);
                        return function() {
                            rd().unsubscribe(e), rd().unsubscribe(t)
                        }
                    }, [t7, t6]);
                    var t9 = (0, S.Zz)(er) && !tk,
                        ne = (0, _.useCallback)(function() {
                            tl(!0), ex.m.setItem("oai/librarian/hasSeenWarning", "true")
                        }, []),
                        nt = (0, _.useCallback)(function() {
                            tn(!1)
                        }, []),
                        nn = (0, S.lA)(er, eS),
                        nr = (0, S.dz)(er, eS),
                        na = F(function(e) {
                            return null != e.aborters[eZ]
                        }),
                        no = (0, _.useRef)(null),
                        ns = (0, _.useMemo)(function() {
                            return !na && !nn && nr
                        }, [nn, nr, na]),
                        nl = (0, R.tN)(function(e) {
                            return e.activeModals.has(R.B.AccountPortal)
                        }),
                        nu = (0, sS.Z)(),
                        nd = (0, S.XK)(er),
                        nc = (0, R.tN)(function(e) {
                            return e.sharingModalThreadId === nd
                        });
                    H = (z = {
                        clientThreadId: er,
                        currentModelId: tm
                    }).clientThreadId, W = z.currentModelId, t = (0, o3.i0)(W, o3.dN.CODE_INTERPRETER), n = (0, _.useContext)(A.gB), r = (0, ev.kP)().session, a = S.tQ.getServerThreadId(H), (0, ng.a)({
                        queryKey: ["interpreterState", a],
                        queryFn: sF,
                        enabled: !!(t && a && !n && (null == r ? void 0 : r.accessToken)),
                        cacheTime: 0
                    });
                    var nf = (0, S.r7)(er);
                    return (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsxs)(rl(), {
                            children: [null != tj && (0, w.jsx)("title", {
                                children: tj
                            }), eb && (0, w.jsxs)(w.Fragment, {
                                children: [(0, w.jsx)("meta", {
                                    property: "og:site_name",
                                    content: "ChatGPT"
                                }), (0, w.jsx)("meta", {
                                    name: "robots",
                                    content: "noindex,nofollow"
                                }, "robots"), (0, w.jsx)("meta", {
                                    property: "og:title",
                                    content: null != tj ? tj : "Shared Chat on ChatGPT"
                                }, "og:title"), (0, w.jsx)("meta", {
                                    property: "og:decription",
                                    content: "Shared " + (null != eI ? "by ".concat(eI, " ") : "") + "via ChatGPT"
                                }, "og:description"), (0, w.jsx)("meta", {
                                    property: "og:image",
                                    content: "/images/chatgpt-share-og.png"
                                }, "og:image")]
                            })]
                        }), ej.has(eu.i) ? (0, w.jsx)(a3, {}) : null, !ts && (0, w.jsx)(eg.Z, {
                            isOpen: !0,
                            onClose: ne,
                            icon: ro.Z,
                            title: ey.formatMessage(sU.doNotShareSensitive),
                            primaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: ne,
                                title: ey.formatMessage(sU.acknowledge)
                            }),
                            type: "danger"
                        }, "OnboardingModal"), ta && tt && (0, w.jsx)(eg.Z, {
                            isOpen: !0,
                            onClose: nt,
                            icon: M.U0j,
                            title: ey.formatMessage(sU.contentPolicyViolation),
                            primaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: nt,
                                title: ey.formatMessage(sU.acknowledge)
                            }),
                            type: "danger"
                        }, "RestrictedTerms"), nc && null != nd && (0, w.jsx)(sf, {
                            serverThreadId: nd,
                            activeRequests: eo,
                            currentThreadModel: en.lastModelUsed
                        }), null != eK && (0, w.jsx)(aJ, {
                            ratingModalNodeId: e1,
                            ratingModalOpen: eK,
                            onCloseRatingModal: function() {
                                return eX(void 0)
                            },
                            handleSubmitFeedback: tJ,
                            onHandleChangeFeedbackComparisonRating: tX,
                            currentModelId: tm,
                            feedbackTextareaRef: e8,
                            clientThreadId: er,
                            activeRequests: eo,
                            onChangeItemInView: tG,
                            onRequestMoreCompletions: tV,
                            onUpdateNode: t$,
                            onChangeRating: tY,
                            onDeleteNode: t1,
                            onRequestCompletion: tF
                        }), eB && (0, w.jsx)(aJ, {
                            ratingModalNodeId: ez,
                            ratingModalOpen: "report",
                            onCloseRatingModal: function() {
                                return eA(!1)
                            },
                            handleSubmitFeedback: tK,
                            onHandleChangeFeedbackComparisonRating: function() {},
                            currentModelId: tm,
                            feedbackTextareaRef: e8,
                            clientThreadId: er,
                            activeRequests: eo,
                            onChangeItemInView: tG,
                            onRequestMoreCompletions: tV,
                            onUpdateNode: t$,
                            onChangeRating: tY,
                            onDeleteNode: t1,
                            onRequestCompletion: tF
                        }), eU && (0, w.jsx)(eg.Z, {
                            onClose: function() {
                                return eO(!1)
                            },
                            isOpen: !0,
                            icon: ro.Z,
                            title: ey.formatMessage(sU.reportModalThankYouTitle),
                            description: ey.formatMessage(sU.reportModalThankYouDescription),
                            primaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: function() {
                                    return eO(!1)
                                },
                                title: ey.formatMessage(sU.reportModalThankYouDismiss)
                            }),
                            type: "danger"
                        }), eV && (0, w.jsx)(aJ, {
                            ratingModalNodeId: eS,
                            ratingModalOpen: "moderate",
                            onCloseRatingModal: function() {
                                return eY(!1)
                            },
                            handleSubmitFeedback: ea(),
                            onHandleChangeFeedbackComparisonRating: function() {},
                            currentModelId: tm,
                            feedbackTextareaRef: e8,
                            clientThreadId: er,
                            activeRequests: eo,
                            onChangeItemInView: tG,
                            onRequestMoreCompletions: tV,
                            onUpdateNode: t$,
                            onChangeRating: tY,
                            onDeleteNode: t1,
                            onRequestCompletion: tF
                        }), (0, w.jsx)(sH, {
                            children: !eP && (t9 || tk) && (Q = (0, w.jsx)(se, {
                                onChangeItemInView: tG,
                                onRequestMoreCompletions: tV,
                                onUpdateNode: t$,
                                onChangeRating: tY,
                                onDeleteNode: t1,
                                onRequestCompletion: tF,
                                isNewThread: t9,
                                clientThreadId: er,
                                activeRequests: eo,
                                currentThreadModel: en.lastModelUsed,
                                initiallyHighlightedMessageId: em,
                                inlineEmbeddedDisplay: !1,
                                promptTextareaRef: no
                            }, er), eb ? (0, w.jsx)("div", {
                                className: "h-full overflow-auto dark:bg-gray-800",
                                children: Q
                            }) : (0, w.jsx)(sB, {
                                children: Q
                            }))
                        }), (0, w.jsxs)(sW, {
                            children: [e7 && t9 && (null == tv ? void 0 : tv.tags.includes(a_.S.GPT_4)) && (0, w.jsx)("div", {
                                className: "stretch mx-2 mb-2 text-center text-xs text-gray-600 dark:text-gray-200 md:mx-4 md:text-sm lg:mx-auto lg:max-w-3xl",
                                children: nu.textareaDisclaimer
                            }), !tz && !eb && (0, w.jsx)(a2.Z, {
                                children: (0, w.jsx)(a9.ZP, {
                                    clientThreadId: er,
                                    canRegenerateResponse: eE,
                                    onRequestMoreCompletions: t0,
                                    onCreateNewCompletion: tE,
                                    onAbortCompletion: t7,
                                    onContinueGenerating: tQ,
                                    currentModelId: tm,
                                    isCompletionInProgress: eo.has(eZ),
                                    className: (0, G.Z)("stretch mx-2 flex flex-row gap-3 last:mb-2 md:mx-4 md:last:mb-6 lg:mx-auto", e9 ? "mx-auto max-w-[44rem] px-2 sm:px-0" : "lg:max-w-2xl xl:max-w-3xl"),
                                    shouldRetry: tU,
                                    canContinue: ns,
                                    suggestions: null != tM ? tM : [],
                                    disabled: !tf.size,
                                    canPause: na,
                                    isInteractableSharedThread: nf,
                                    ref: no
                                }, er)
                            }), eb && (0, w.jsx)(w.Fragment, {
                                children: (0, w.jsxs)("div", {
                                    className: "relative flex h-full w-full flex-1 items-center justify-center gap-2",
                                    children: [(0, w.jsx)(ec.z, {
                                        as: "link",
                                        to: ep,
                                        children: ey.formatMessage(sU.sharedConversationContinueConversation)
                                    }), eT && (0, w.jsx)(ec.z, {
                                        onClick: function() {
                                            eY(!0)
                                        },
                                        children: ey.formatMessage(sU.sharedConversationModerateConversation)
                                    })]
                                })
                            }), (0, w.jsx)("div", {
                                className: "pb-3 pt-2 text-center text-xs text-gray-600 dark:text-gray-300 md:px-[60px] md:pb-6 md:pt-3",
                                children: eb ? (0, w.jsx)(sO, {
                                    onClickReportSharedConversation: function() {
                                        eH(eS), eA(!0)
                                    }
                                }) : e7 ? (0, w.jsx)("span", {
                                    children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, sU.mayProduceInaccurateInformation), {
                                        values: {
                                            link: function(e) {
                                                return (0, w.jsx)("a", {
                                                    href: "https://help.openai.com/en/articles/6825453-chatgpt-release-notes",
                                                    target: "_blank",
                                                    rel: "noreferrer",
                                                    className: "underline",
                                                    children: e
                                                })
                                            }
                                        }
                                    }))
                                }) : (0, w.jsx)("span", {
                                    children: (0, w.jsx)(T.Z, (0, V._)((0, b._)({}, sU.freeResearchPreview), {
                                        values: {
                                            link: function(e) {
                                                return (0, w.jsx)("a", {
                                                    href: "https://help.openai.com/en/articles/6825453-chatgpt-release-notes",
                                                    target: "_blank",
                                                    rel: "noreferrer",
                                                    className: "underline",
                                                    children: e
                                                })
                                            }
                                        }
                                    }))
                                })
                            }), (0, w.jsx)(sz, {})]
                        }), e6 && (0, w.jsx)(a6.Z, {
                            isOpen: t5,
                            onClose: t8
                        }), void 0 !== e7 && e7 && (0, w.jsx)(a7, {
                            isOpen: nl,
                            onClose: t2
                        }), td && (0, w.jsx)(eg.Z, {
                            onClose: ea(),
                            isOpen: !0,
                            icon: ro.Z,
                            title: ey.formatMessage(sU.somethingWentWrong),
                            description: ey.formatMessage(sU.tryAgainLater),
                            primaryButton: (0, w.jsx)(ef.ZP.Button, {
                                onClick: function() {
                                    eh(), tc(!1)
                                },
                                title: ey.formatMessage(sU.resetThread)
                            }),
                            type: "danger"
                        }, "UnrecoverableErrorModal")]
                    })
                },
                sz = function() {
                    return (0, B.hz)().has(eu.rk) ? (0, w.jsxs)(nU.v, {
                        as: "div",
                        className: "group absolute bottom-5 right-4 z-10",
                        children: [(0, w.jsx)(nU.v.Button, {
                            className: "invisible flex items-center justify-center rounded-full border border-gray-200 bg-gray-50 text-gray-600 dark:border-white/10 dark:bg-white/10 dark:text-gray-200 md:visible",
                            children: (0, w.jsx)("div", {
                                className: "h-6 w-6",
                                children: "?"
                            })
                        }), (0, w.jsx)(nG, {
                            children: (0, w.jsxs)(nU.v.Items, {
                                className: "absolute bottom-full right-0 z-20 mb-2 w-full min-w-[175px] overflow-hidden rounded-md bg-gray-950 pb-1.5 pt-1 outline-none",
                                children: [(0, w.jsxs)(nL.ZP, {
                                    as: "a",
                                    href: "https://help.openai.com/en/collections/3742473-chatgpt",
                                    target: "_blank",
                                    onClick: function() {
                                        es.o.logEvent(el.a.clickFaqLink)
                                    },
                                    children: [(0, w.jsx)(eh.ZP, {
                                        icon: M.AlO
                                    }), (0, w.jsx)("span", {
                                        className: "text-xs",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, sU.helpAndFaq))
                                    })]
                                }), (0, w.jsxs)(nL.ZP, {
                                    onClick: function() {
                                        R.vm.openModal(R.B.KeyboardActions)
                                    },
                                    children: [(0, w.jsx)(eh.ZP, {
                                        icon: M.aCJ
                                    }), (0, w.jsx)("span", {
                                        className: "text-xs",
                                        children: (0, w.jsx)(T.Z, (0, b._)({}, sU.keyboardShortcutsMenu))
                                    })]
                                })]
                            })
                        })]
                    }) : null
                },
                sH = eo.Z.div(sA()),
                sW = eo.Z.div(sL());

            function sV(e) {
                var t, n = e.clientThreadId,
                    r = null !== (t = S.tQ.getTitle(n)) && void 0 !== t ? t : "New chat",
                    a = O(n, r, !0),
                    i = a.resolvedTitle,
                    o = a.isTypingEffect,
                    s = (0, _.useContext)(A.QL),
                    l = s.historyDisabled,
                    u = s.toggleHistoryDisabled;
                return (0, w.jsx)(w.Fragment, {
                    children: l ? (0, w.jsxs)("button", {
                        className: "flex cursor-pointer flex-row place-items-center items-center justify-center gap-3",
                        onClick: function() {
                            return u()
                        },
                        children: [(0, w.jsx)(eh.ZP, {
                            icon: M.$IY
                        }), (0, w.jsx)(T.Z, (0, b._)({}, sG.enableChatHistory))]
                    }) : o && null != i ? (0, w.jsx)(H, {
                        text: i
                    }) : null != i ? i : (0, w.jsx)(T.Z, (0, b._)({}, sG.newChat))
                })
            }
            var sQ = (d = function(e) {
                    var t = e.clientThreadId,
                        n = e.setClientThreadId,
                        r = (0, y._)(e, ["clientThreadId", "setClientThreadId"]),
                        a = (0, _.useContext)(A.gB),
                        i = (0, S.UL)(t),
                        o = r.setActiveRequests,
                        s = (0, S.XK)(t),
                        l = (0, k.useRouter)(),
                        u = (0, B.hz)(),
                        d = (0, _.useContext)(A.QL).historyDisabled,
                        c = (0, a_.Xy)(i.lastModelUsed, t),
                        f = (0, C.NL)();
                    (0, _.useEffect)(function() {
                        return S.tQ.retainThread(t),
                            function() {
                                setTimeout(function() {
                                    f.invalidateQueries(["conversation", t])
                                }, 0), S.tQ.releaseThread(t)
                            }
                    }, [t, f]), (0, _.useEffect)(function() {
                        R.vm.closeSharingModal()
                    }, [t, s]);
                    var g = (0, _.useCallback)(function() {
                        n((0, S.OX)()), c.tags.includes(a_.S.GPT_4) ? l.replace("/", void 0, {
                            shallow: !0
                        }) : l.replace("/?model=".concat(c.id))
                    }, [n, c.tags, c.id, l]);
                    (0, L.yx)({
                        resetThreadAction: g,
                        clientThreadId: t
                    });
                    var h = (0, R.tN)(function(e) {
                            return e.activeSidebar
                        }),
                        m = (0, U.w$)();
                    (0, _.useEffect)(function() {
                        return function() {
                            E.abortAllAndReset(), o(new Set)
                        }
                    }, [o, t]);
                    var p = ew(),
                        v = (0, _.useCallback)(function() {
                            P.ZP.deleteConversations().then(function() {
                                p()
                            }), g(), "/" !== l.asPath && l.replace({
                                pathname: "/"
                            })
                        }, [g, p, l]);
                    return (0, w.jsxs)(ri.Z, {
                        showNavigation: !a,
                        renderTitle: (0, w.jsx)(sV, {
                            clientThreadId: t
                        }),
                        renderMobileHeaderRightContent: (0, w.jsx)(nR.js, {
                            onClick: g,
                            children: (0, w.jsx)(eh.ZP, {
                                icon: d ? M.Bw1 : M.OvN,
                                size: "medium"
                            })
                        }),
                        renderSidebar: (0, w.jsx)(rn, {
                            onDeleteHistory: v,
                            onNewThread: g,
                            children: (0, w.jsx)(eD, {
                                activeId: d ? void 0 : s,
                                onNewThread: g,
                                setActiveRequests: o
                            })
                        }),
                        children: [(0, w.jsx)(sq, (0, b._)({
                            initialThreadData: i,
                            clientThreadId: t,
                            handleResetThread: g
                        }, r), t), (0, w.jsxs)(ri.Z.Sidebars, {
                            children: [u.has("debug") && "debug" === h && (0, w.jsx)(tR, {
                                clientThreadId: t,
                                slideOver: !m,
                                onClose: function() {
                                    return R.vm.toggleActiveSidebar("debug")
                                },
                                isOpen: !0
                            }), u.has("tools3_dev") && (0, w.jsx)(nd, {
                                slideOver: !m
                            })]
                        })]
                    })
                }, function(e) {
                    var t = e.clientThreadId;
                    (0, S.ax)(t);
                    var n = (0, S.UL)(t),
                        r = (0, j._)((0, _.useState)(new Set), 2),
                        a = r[0],
                        i = r[1];
                    return (0, _.useEffect)(function() {
                        R.vm.setActiveSidebar(!1), E.reset(), i(new Set)
                    }, [n.threadId]), (0, w.jsx)(d, (0, b._)({}, e, {
                        activeRequests: a,
                        setActiveRequests: i
                    }))
                }),
                sG = (0, N.vU)({
                    enableChatHistory: {
                        id: "navigation.enableChatHistory",
                        defaultMessage: "Enable chat history",
                        description: "Enable chat history button label"
                    },
                    newChat: {
                        id: "navigation.newChat",
                        defaultMessage: "New chat",
                        description: "New chat header title"
                    }
                })
        },
        66570: function(e, t, n) {
            n.d(t, {
                $: function() {
                    return y
                },
                Z: function() {
                    return b
                }
            });
            var r = n(4337),
                a = n(35250),
                i = n(70079),
                o = n(21389),
                s = n(11084),
                l = n(32877),
                u = n(78931),
                d = n(28512);

            function c() {
                var e = (0, r._)(["bg-black rounded-md"]);
                return c = function() {
                    return e
                }, e
            }

            function f() {
                var e = (0, r._)(["flex items-center relative text-gray-200 bg-gray-800 px-4 py-2 text-xs font-sans justify-between rounded-t-md ", ""]);
                return f = function() {
                    return e
                }, e
            }

            function g() {
                var e = (0, r._)(["p-4 overflow-y-auto"]);
                return g = function() {
                    return e
                }, e
            }

            function h() {
                var e = (0, r._)(["", ""]);
                return h = function() {
                    return e
                }, e
            }
            var m = o.Z.div(c()),
                p = o.Z.div(f(), function(e) {
                    return e.$isMessageRedesign && "dark:bg-gray-900"
                }),
                v = o.Z.div(g()),
                x = o.Z.code(h(), function(e) {
                    return e.$shouldWrap ? "!whitespace-pre-wrap" : "!whitespace-pre"
                });

            function b(e) {
                var t = e.children,
                    n = e.className,
                    r = e.language,
                    o = e.content,
                    l = (0, i.useCallback)(function() {
                        (0, s.S)(o)
                    }, [o]);
                return (0, a.jsx)(y, {
                    title: r,
                    headerDecoration: (0, a.jsx)(d.Z, {
                        buttonText: "Copy code",
                        onCopy: l
                    }),
                    className: "mb-4",
                    codeClassName: n,
                    children: t
                })
            }

            function y(e) {
                var t = e.children,
                    n = e.title,
                    r = e.headerDecoration,
                    i = e.shouldWrapCode,
                    o = e.className,
                    s = e.codeClassName,
                    d = (0, u.hz)().has(l.FZ);
                return (0, a.jsxs)(m, {
                    className: o,
                    children: [(0, a.jsxs)(p, {
                        $isMessageRedesign: d,
                        children: [n && (0, a.jsx)("span", {
                            children: n
                        }), r]
                    }), (0, a.jsx)(v, {
                        children: (0, a.jsx)(x, {
                            $shouldWrap: void 0 !== i && i,
                            className: s,
                            children: t
                        })
                    })]
                })
            }
        },
        28512: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return f
                }
            });
            var r = n(22830),
                a = n(4337),
                i = n(35250),
                o = n(70079),
                s = n(1454),
                l = n(21389),
                u = n(19012),
                d = n(88327);

            function c() {
                var e = (0, a._)(["flex ml-auto gap-2"]);
                return c = function() {
                    return e
                }, e
            }

            function f(e) {
                var t = e.buttonText,
                    n = e.onCopy,
                    a = e.className,
                    l = (0, r._)((0, o.useState)(!1), 2),
                    c = l[0],
                    f = l[1],
                    h = (0, u.Z)(),
                    m = (0, o.useCallback)(function() {
                        n(), f(!0), setTimeout(function() {
                            h() && f(!1)
                        }, 2e3)
                    }, [h, n]);
                return (0, i.jsxs)(i.Fragment, {
                    children: [!c && (0, i.jsxs)(g, {
                        onClick: m,
                        className: a,
                        children: [(0, i.jsx)(d.ZP, {
                            icon: s.j4u
                        }), t]
                    }), c && (0, i.jsxs)(g, {
                        className: a,
                        children: [(0, i.jsx)(d.ZP, {
                            icon: s.UgA
                        }), t && "Copied!"]
                    })]
                })
            }
            var g = l.Z.button(c())
        },
        1568: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(35250);

            function a(e) {
                var t, n = e.url,
                    a = e.size,
                    i = void 0 === a ? 16 : a,
                    o = e.className;
                try {
                    t = new URL(n)
                } catch (e) {
                    return console.error(e), null
                }
                return (0, r.jsx)("img", {
                    src: "https://icons.duckduckgo.com/ip3/".concat(t.hostname, ".ico"),
                    alt: "Favicon",
                    width: i,
                    height: i,
                    className: o
                })
            }
        },
        78018: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return m
                }
            });
            var r = n(22830),
                a = n(35250),
                i = n(39217),
                o = n(19841),
                s = n(70079),
                l = n(1454),
                u = n(70671),
                d = n(94968),
                c = n(45635),
                f = n(88327);

            function g(e) {
                var t = e.percentage,
                    n = e.className,
                    r = 2 * Math.PI * 45;
                return (0, a.jsxs)("svg", {
                    width: "120",
                    height: "120",
                    viewBox: "0 0 120 120",
                    className: n,
                    children: [(0, a.jsx)("circle", {
                        className: "origin-[50%_50%] -rotate-90 stroke-gray-200 transition-[stroke-dashoffset] duration-1000 ease-in-out",
                        strokeWidth: "20",
                        fill: "transparent",
                        r: 45,
                        cx: "60",
                        cy: "60"
                    }), (0, a.jsx)("circle", {
                        className: "origin-[50%_50%] -rotate-90 transition-[stroke-dashoffset]",
                        stroke: "currentColor",
                        strokeWidth: "20",
                        strokeDashoffset: r - t / 100 * r,
                        strokeDasharray: "".concat(r, " ").concat(r),
                        fill: "transparent",
                        r: 45,
                        cx: "60",
                        cy: "60"
                    })]
                })
            }

            function h(e) {
                return e instanceof File
            }

            function m(e) {
                var t, n, d, m, v = e.onRemoveFileClick,
                    x = e.file,
                    b = e.loadingPercentage,
                    y = e.onDownloadClick,
                    j = (0, u.Z)(),
                    w = null != y,
                    C = h(x) ? x.name : x,
                    k = !!h(x) && x.type.startsWith("image/"),
                    _ = (t = h(x) ? x : null, d = (n = (0, r._)((0, s.useState)(void 0), 2))[0], m = n[1], (0, s.useEffect)(function() {
                        if (t && t.type.startsWith("image/")) {
                            var e = new FileReader;
                            e.addEventListener("load", function() {
                                var t = e.result;
                                m("string" == typeof t ? t : void 0)
                            }), e.readAsDataURL(t)
                        } else m(void 0)
                    }, [t]), d);
                return (0, a.jsxs)("div", {
                    className: "group relative inline-block text-xs text-gray-900",
                    children: [(0, a.jsx)(w ? "button" : "span", {
                        className: "flex items-stretch justify-center",
                        onClick: function() {
                            return w && (null == y ? void 0 : y())
                        },
                        children: k && null != _ ? (0, a.jsx)("span", {
                            className: (0, o.Z)("box-border h-10 w-10 rounded-md border border-black/5 bg-cover bg-center dark:border-white/20", w && "group-hover:bg-black"),
                            style: {
                                backgroundImage: void 0 !== _ ? "url(".concat(_, ")") : "none"
                            },
                            children: w && (0, a.jsx)(f.ZP, {
                                icon: l._hL,
                                className: (0, o.Z)("h-5 w-5", "hidden group-hover:block")
                            })
                        }) : (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsxs)("span", {
                                className: (0, o.Z)("rounded-l-md bg-gray-500 px-2 py-2 text-white transition-colors dark:bg-gray-500", w && "group-hover:bg-black"),
                                children: [(0, a.jsx)(f.ZP, {
                                    icon: i.Z,
                                    className: (0, o.Z)("h-5 w-5", w && "group-hover:hidden")
                                }), w && (0, a.jsx)(f.ZP, {
                                    icon: l._hL,
                                    className: (0, o.Z)("h-5 w-5", "hidden group-hover:block")
                                })]
                            }), (0, a.jsx)("span", {
                                className: "flex max-w-xs items-center truncate rounded-r-md bg-gray-50 px-3 py-2 font-medium",
                                children: (0, a.jsx)("span", {
                                    className: "truncate",
                                    children: C
                                })
                            })]
                        })
                    }), void 0 !== b && b < 100 && (0, a.jsx)("div", {
                        className: "absolute right-1 top-1 -translate-y-1/2 translate-x-1/2 rounded-full border border-white bg-white p-0.5 text-blue-700 dark:border-gray-700",
                        children: (0, a.jsx)(g, {
                            percentage: b,
                            className: "h-4 w-4"
                        })
                    }), null != v && (0, a.jsx)("button", {
                        onClick: v,
                        className: "absolute right-1 top-1 -translate-y-1/2 translate-x-1/2 rounded-full border border-white bg-gray-500 p-0.5 text-white transition-colors hover:bg-black hover:opacity-100 group-hover:opacity-100 md:opacity-0",
                        children: (0, a.jsx)(c.u, {
                            label: j.formatMessage(p.removeFile),
                            side: "top",
                            sideOffset: 4,
                            children: (0, a.jsx)(f.ZP, {
                                icon: l.q5L
                            })
                        })
                    })]
                })
            }
            var p = (0, d.vU)({
                removeFile: {
                    id: "FileTile.removeFile",
                    defaultMessage: "Remove file",
                    description: "Tooltip label for removing a file from the textarea"
                }
            })
        },
        40058: function(e, t, n) {
            n.d(t, {
                Y: function() {
                    return m
                },
                Z: function() {
                    return p
                }
            });
            var r = n(81949),
                a = n(35250),
                i = n(77311),
                o = n(70079),
                s = n(50795),
                l = n(82081),
                u = n(88327),
                d = n(35588),
                c = n(15610),
                f = n(98076),
                g = n(44510),
                h = n(16592),
                m = "gpt-4-upsell";

            function p(e) {
                var t = e.onModelChange,
                    n = e.shouldShowPlusUpsell,
                    p = e.currentModel,
                    v = (0, f.BT)(),
                    x = (0, h.ZP)(),
                    b = (0, g.xT)(),
                    y = (0, d.t)(function(e) {
                        return {
                            setShowAccountPaymentModal: e.setShowAccountPaymentModal,
                            showAccountPaymentModal: e.showAccountPaymentModal
                        }
                    }).setShowAccountPaymentModal,
                    j = (0, o.useCallback)(function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "upgrade-hover-button";
                        s.o.logEvent(l.a.openModalAccountPaymentfromModelPicker, {
                            content: e
                        }), y(!0)
                    }, [y]),
                    w = (0, o.useMemo)(function() {
                        return {
                            categoryId: "gpt_4",
                            value: m,
                            name: "GPT-4",
                            description: "Our most capable model, great for tasks that require creativity and advanced reasoning.",
                            disclaimer: "Available exclusively to Plus users",
                            buttonActiveClass: "text-brand-purple",
                            buttonHoverClass: "group-hover/button:text-brand-purple",
                            iconClass: "group-hover/option:!text-brand-purple group-hover/options:text-gray-500",
                            icon: u.Bj,
                            iconAfter: i.Z,
                            iconAfterClass: "group-hover/options:text-gray-500 !text-gray-500 -ml-2",
                            options: [],
                            disabled: !1,
                            showSelectedValueBelow: !1,
                            ctaContentText: "Upgrade to ChatGPT Plus",
                            onCtaContentClick: j
                        }
                    }, [j]),
                    C = (0, o.useCallback)(function(e) {
                        if (v !== e) {
                            if (n && e === m) {
                                j("gpt-4-lock-button");
                                return
                            }
                            t(e), b(e), s.o.logEvent(l.a.toggleModel, {
                                model: e
                            })
                        }
                    }, [v, b, t, j, n]),
                    k = (0, o.useMemo)(function() {
                        return x ? x.some(function(e) {
                            return "gpt_4" === e.categoryId
                        }) ? x : n ? (0, r._)(x).concat([w]) : x : []
                    }, [x, w, n]);
                return 1 === k.length ? null : (0, a.jsx)(c.Z, {
                    value: null == p ? void 0 : p.id,
                    onChange: C,
                    items: k
                })
            }
        },
        63857: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return g
                }
            });
            var r = n(4337),
                a = n(35250),
                i = n(95182),
                o = n.n(i),
                s = n(1454),
                l = n(21389),
                u = n(88327);

            function d() {
                var e = (0, r._)(["text-xs flex items-center justify-center gap-1"]);
                return d = function() {
                    return e
                }, e
            }

            function c() {
                var e = (0, r._)(["dark:text-white disabled:text-gray-300 dark:disabled:text-gray-400"]);
                return c = function() {
                    return e
                }, e
            }

            function f() {
                var e = (0, r._)(["flex-grow flex-shrink-0"]);
                return f = function() {
                    return e
                }, e
            }

            function g(e) {
                var t = e.currentPage,
                    n = e.onChangeIndex,
                    r = e.length,
                    i = e.className,
                    l = function(e) {
                        n(o()(t + e, 0, r - 1))
                    };
                return (0, a.jsxs)(h, {
                    className: i,
                    children: [(0, a.jsx)(m, {
                        onClick: function() {
                            return l(-1)
                        },
                        disabled: 0 === t,
                        children: (0, a.jsx)(u.ZP, {
                            size: "xsmall",
                            icon: s.YFh
                        })
                    }), (0, a.jsx)(p, {
                        children: "".concat(t + 1, " / ").concat(r)
                    }), (0, a.jsx)(m, {
                        onClick: function() {
                            return l(1)
                        },
                        disabled: t === r - 1,
                        children: (0, a.jsx)(u.ZP, {
                            size: "xsmall",
                            icon: s.Tfp
                        })
                    })]
                })
            }
            var h = l.Z.div(d()),
                m = l.Z.button(c()),
                p = l.Z.span(f())
        },
        43019: function(e, t, n) {
            n.d(t, {
                ZP: function() {
                    return e_
                },
                go: function() {
                    return eR
                }
            });
            var r, a, i, o, s = n(39324),
                l = n(71209),
                u = n(22830),
                d = n(4337),
                c = n(35250),
                f = n(19841),
                g = n(70079),
                h = n(76483),
                m = n(97296),
                p = n(2827),
                v = n(1454),
                x = n(70671),
                b = n(32004),
                y = n(94968),
                j = n(21389),
                w = n(50795),
                C = n(82081),
                k = n(16920),
                _ = n(75641),
                M = n(95954),
                T = n(31621),
                N = n(46020),
                P = n(54118),
                S = n(32542),
                I = n(33669),
                Z = n(67273),
                F = n(45635),
                D = n(47428),
                E = n(27009),
                R = n(88327),
                B = n(73610);

            function A(e) {
                var t = e.disabled,
                    n = e.getInputProps,
                    r = e.openFileDialog,
                    a = e.attachmentsType,
                    i = e.onSelectRecentFile,
                    o = (0, x.Z)(),
                    l = a === _.Cd.Retrieval,
                    u = (0, c.jsx)(Z.z, {
                        onClick: l ? void 0 : function(e) {
                            e.preventDefault(), r()
                        },
                        disabled: t,
                        color: "none",
                        className: "rounded-full bg-gray-500 p-0 text-white outline-none hover:bg-black",
                        "aria-label": o.formatMessage(U.uploadFile),
                        children: (0, c.jsx)(R.ZP, {
                            icon: v.OvN,
                            size: "small"
                        })
                    }),
                    d = (0, c.jsx)("input", (0, s._)({}, n({
                        className: "hidden"
                    })));
                return l ? (0, c.jsxs)(c.Fragment, {
                    children: [(0, c.jsxs)(D.fC, {
                        children: [(0, c.jsx)(D.xz, {
                            disabled: t,
                            asChild: !0,
                            children: u
                        }), (0, c.jsx)(D.Uv, {
                            children: (0, c.jsx)(L, {
                                openFileDialog: r,
                                onSelectRecentFile: i
                            })
                        })]
                    }), d]
                }) : (0, c.jsxs)(F.u, {
                    label: o.formatMessage(U.uploadFile),
                    side: "top",
                    sideOffset: 4,
                    children: [u, d]
                })
            }

            function L(e) {
                var t, n = e.openFileDialog,
                    r = e.onSelectRecentFile,
                    a = (0, B.W)().data,
                    i = (null !== (t = null == a ? void 0 : a.files) && void 0 !== t ? t : []).filter(function(e) {
                        return e.use_case === _.Ei.MyFiles && e.retrieval_index_status === _.Xf.Success
                    }).reverse().slice(0, 4),
                    o = i.map(function(e) {
                        return (0, c.jsx)(D.ck, {
                            className: "cursor-pointer px-3 py-2.5 outline-none focus:bg-green-600 focus:text-white",
                            onSelect: function() {
                                return r({
                                    id: e.id,
                                    name: e.name,
                                    size: e.size
                                })
                            },
                            children: (0, c.jsx)("div", {
                                className: "line-clamp-1",
                                children: e.name
                            })
                        }, e.id)
                    });
                return (0, c.jsxs)(D.VY, {
                    side: "top",
                    sideOffset: 8,
                    align: "start",
                    alignOffset: -20,
                    className: "w-64 rounded-xl border border-gray-100 bg-white text-sm shadow-xxs dark:border-gray-800 dark:bg-gray-900 dark:text-gray-100 dark:shadow-xs",
                    children: [i.length > 0 && (0, c.jsx)(D.__, {
                        className: "px-3 pb-1 pt-3 font-medium",
                        children: (0, c.jsx)(b.Z, (0, s._)({}, U.recentFiles))
                    }), o, (0, c.jsx)(D.ck, {
                        className: "group cursor-pointer p-1 outline-none",
                        onSelect: n,
                        children: (0, c.jsxs)("div", {
                            className: "flex items-center gap-2 rounded-lg bg-black px-3 py-2.5 text-white group-radix-highlighted:bg-green-600",
                            children: [(0, c.jsx)(R.ZP, {
                                icon: v.iRh
                            }), (0, c.jsx)("div", {
                                children: (0, c.jsx)(b.Z, (0, s._)({}, U.upload))
                            })]
                        })
                    })]
                })
            }
            var U = (0, y.vU)({
                    uploadFile: {
                        id: "PromptFilePicker.uploadFile",
                        defaultMessage: "Upload file",
                        description: "Tooltip label for uploading a file button"
                    },
                    errorFileTooLarge: {
                        id: "PromptFilePicker.errorFileTooLarge",
                        defaultMessage: "File is too large. Maximum file size is {size}MB",
                        description: "Error message when file is too large"
                    },
                    errorTooManyFiles: {
                        id: "PromptFilePicker.errorTooManyFiles",
                        defaultMessage: "Only one file upload at a time is supported",
                        description: "Error message when too many files are uploaded"
                    },
                    recentFiles: {
                        id: "PromptFilePicker.recentFiles",
                        defaultMessage: "Recent files",
                        description: "Header text for the list of recent files"
                    },
                    upload: {
                        id: "PromptFilePicker.upload",
                        defaultMessage: "Upload",
                        description: "Button text for uploading a file"
                    }
                }),
                O = n(21722),
                q = n(39889),
                z = n(5268),
                H = n(99486),
                W = n(68993),
                V = n(88798),
                Q = n(63031),
                G = {
                    duration: 20,
                    hasCloseButton: !0
                },
                $ = Math.floor(Math.log(1201) / Math.log(2)),
                Y = {
                    duration: 20,
                    hasCloseButton: !0
                },
                J = n(78018),
                K = n(3511),
                X = n(42569),
                ee = n(16592),
                et = n(58268),
                en = n(6013),
                er = n(32148),
                ea = n(54655);

            function ei() {
                return (0, z.a)(["visionContent"], (0, O._)(function() {
                    return (0, q.__generator)(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, H.ZP.getContent("vision").catch(function() {
                                    return V.m.danger("Failed to load content"), {
                                        onboarding: {
                                            title: "",
                                            content: []
                                        }
                                    }
                                })];
                            case 1:
                                return [2, e.sent()]
                        }
                    })
                }))
            }

            function eo(e) {
                var t = e.onPick,
                    n = (0, u._)((0, g.useState)(!1), 2),
                    r = n[0],
                    a = n[1],
                    i = (0, g.useCallback)(function(e, n) {
                        a(!1), t(e, n)
                    }, [t]),
                    o = (0, x.Z)(),
                    l = ei().data,
                    d = (null == l ? void 0 : l.examples) || [];
                return 0 === d.length ? null : (0, c.jsxs)(en.fC, {
                    onOpenChange: a,
                    open: r,
                    children: [(0, c.jsx)(en.xz, {
                        asChild: !0,
                        children: (0, c.jsx)("div", {
                            className: "cursor-pointer",
                            children: (0, c.jsx)(F.u, {
                                label: o.formatMessage(el.tryAnExample),
                                side: "top",
                                sideOffset: 4,
                                open: !0 !== r && void 0,
                                children: (0, c.jsxs)("div", {
                                    children: [(0, c.jsx)(R.ZP, {
                                        className: "text-gray-500 dark:text-gray-300",
                                        icon: ea.DcN
                                    }), (0, c.jsx)(er.T, {
                                        children: o.formatMessage(el.tryAnExample)
                                    })]
                                })
                            })
                        })
                    }), (0, c.jsx)(en.h_, {
                        children: (0, c.jsxs)(en.VY, {
                            side: "top",
                            sideOffset: 8,
                            className: "relative max-w-md animate-slideUpAndFade select-none rounded-xl border-gray-100 bg-white p-3 text-sm text-gray-600 shadow-xs dark:bg-gray-900 dark:text-white",
                            children: [(0, c.jsxs)("div", {
                                className: "mb-3 flex items-center justify-center gap-2 text-center text-sm font-medium",
                                children: [(0, c.jsx)(R.ZP, {
                                    className: "text-gray-500 dark:text-gray-300",
                                    icon: ea.DcN
                                }), (0, c.jsx)(b.Z, (0, s._)({}, el.tryAnExample))]
                            }), (0, c.jsx)("div", {
                                className: "flex flex-col gap-2",
                                children: d.map(function(e) {
                                    return (0, c.jsx)(es, {
                                        imageUrl: e.imageUrl,
                                        thumbnailUrl: e.thumbnailUrl,
                                        label: e.label,
                                        prompt: e.prompt,
                                        onPick: i
                                    }, e.imageUrl)
                                })
                            })]
                        })
                    })]
                })
            }

            function es(e) {
                var t = e.imageUrl,
                    n = e.thumbnailUrl,
                    r = e.label,
                    a = e.prompt,
                    i = e.onPick,
                    o = (0, g.useCallback)((0, O._)(function() {
                        var e, n, r, o, s;
                        return (0, q.__generator)(this, function(l) {
                            switch (l.label) {
                                case 0:
                                    return l.trys.push([0, 3, , 4]), [4, fetch(t)];
                                case 1:
                                    if (!(e = l.sent()).ok) throw Error("Failed to load example image");
                                    return [4, e.blob()];
                                case 2:
                                    return n = l.sent(), o = (r = t.split("/"))[r.length - 1], i(new File([n], o, {
                                        type: null !== (s = e.headers.get("Content-Type")) && void 0 !== s ? s : void 0
                                    }), a), [3, 4];
                                case 3:
                                    return l.sent(), V.m.danger("Failed to load example image"), [3, 4];
                                case 4:
                                    return [2]
                            }
                        })
                    }), [t, i, a]);
                return (0, c.jsxs)("button", {
                    className: "group flex h-14 w-64 flex-row items-stretch overflow-hidden rounded text-left",
                    onClick: o,
                    children: [(0, c.jsx)("div", {
                        className: "w-14 flex-none bg-cover bg-center",
                        style: {
                            backgroundImage: "url(".concat(n, ")")
                        }
                    }), (0, c.jsxs)("div", {
                        className: "items-left flex min-w-0 flex-auto flex-col justify-center bg-gray-50 px-3 transition group-hover:bg-gray-100 dark:bg-gray-800 dark:group-hover:bg-gray-700",
                        children: [(0, c.jsx)("div", {
                            className: "font-medium leading-none",
                            children: r
                        }), (0, c.jsx)("div", {
                            className: "mt-2 truncate text-xs leading-none text-gray-600 dark:text-gray-300",
                            children: a
                        })]
                    })]
                })
            }
            var el = (0, y.vU)({
                    tryAnExample: {
                        id: "VisionExamplePicker.tryAnExample",
                        defaultMessage: "Try an example",
                        description: "Label for examples popover"
                    }
                }),
                eu = n(13002),
                ed = n(6948),
                ec = n(97747),
                ef = n(89368),
                eg = "oai/apps/hasSeenVisionOnboarding";

            function eh(e) {
                var t, n = e.currentModelConfig,
                    r = e.disabled,
                    a = (0, u._)((0, g.useState)(function() {
                        var e = ed.m.getItem(eg);
                        return "number" == typeof e && e
                    }), 2),
                    i = a[0],
                    o = a[1];
                return (null === (t = null == n ? void 0 : n.product_features.attachments) || void 0 === t ? void 0 : t.type) !== _.Cd.Multimodal || r || !1 !== i ? null : (0, c.jsx)(ep, {
                    onDismiss: function() {
                        var e = Date.now();
                        ed.m.setItem(eg, e), o(e)
                    }
                })
            }
            var em = {
                lock: eu.Zp7,
                use_cases: eu.dvR
            };

            function ep(e) {
                var t = e.onDismiss,
                    n = ei().data,
                    r = null == n ? void 0 : n.onboarding;
                return r ? (0, c.jsx)(ef.Z, {
                    isOpen: !0,
                    onClose: t,
                    type: "success",
                    primaryButton: (0, c.jsx)(ec.ZP.Button, {
                        title: "Continue",
                        color: "primary",
                        onClick: t
                    }),
                    title: r.title,
                    size: "custom",
                    className: "max-w-[510px] text-gray-800 outline-none dark:text-gray-300",
                    children: r.content.map(function(e, t) {
                        if ("paragraph" === e.type) return (0, c.jsx)("p", {
                            children: e.text
                        }, t);
                        if ("callout" === e.type) {
                            var n;
                            return (0, c.jsx)(ev, {
                                icon: null !== (n = em[e.icon]) && void 0 !== n ? n : em.beaker,
                                title: e.title,
                                text: e.text,
                                color: e.color || 0
                            }, t)
                        }
                        return null
                    })
                }) : null
            }

            function ev(e) {
                var t = e.icon,
                    n = e.title,
                    r = e.text,
                    a = e.color;
                return (0, c.jsxs)("div", {
                    className: "my-4 flex flex-row",
                    children: [(0, c.jsx)("div", {
                        className: (0, f.Z)("w-14 flex-none pl-2 pt-2", 0 === a ? "text-brand-green" : "text-brand-purple"),
                        children: (0, c.jsx)(t, {
                            size: 32
                        })
                    }), (0, c.jsxs)("div", {
                        className: "max-w-60 flex-auto",
                        children: [(0, c.jsx)("div", {
                            className: "font-bold text-black dark:text-white",
                            children: n
                        }), (0, c.jsx)("div", {
                            children: r
                        })]
                    })]
                })
            }

            function ex() {
                var e = (0, d._)(["absolute inset-0 bg-gray-100 opacity-80 flex gap-2 justify-center items-center rounded-xl dark:bg-gray-800 dark:text-gray-100"]);
                return ex = function() {
                    return e
                }, e
            }

            function eb() {
                var e = (0, d._)(["mb-3 mx-[10px] md:mx-0"]);
                return eb = function() {
                    return e
                }, e
            }

            function ey() {
                var e = (0, d._)(["absolute p-1 rounded-md bottom-[10px] md:bottom-3 md:p-2 md:right-3 dark:hover:bg-gray-900 dark:disabled:hover:bg-transparent right-2 disabled:text-gray-400 enabled:bg-brand-purple text-white"]);
                return ey = function() {
                    return e
                }, e
            }

            function ej() {
                var e = (0, d._)(["absolute left-4 bottom-2 md:left-4 md:bottom-3.5"]);
                return ej = function() {
                    return e
                }, e
            }

            function ew() {
                var e = (0, d._)(["absolute p-1 bottom-[10px] md:bottom-3 md:p-2 right-12 transition-opacity ", ""]);
                return ew = function() {
                    return e
                }, e
            }

            function eC() {
                var e = (0, d._)(["\nflex flex-col w-full py-[10px] flex-grow md:py-4 md:pl-4 relative border border-black/10 bg-white dark:border-gray-900/50 dark:text-white dark:bg-gray-700 rounded-xl shadow-xs dark:shadow-xs\n", "\n", "\n"]);
                return eC = function() {
                    return e
                }, e
            }

            function ek() {
                var e = (0, d._)(["", " flex ml-1 md:w-full md:m-auto md:mb-4 gap-0 md:gap-2 justify-center"]);
                return ek = function() {
                    return e
                }, e
            }(r = i || (i = {}))[r.None = 0] = "None", r[r.Multimodal = 1] = "Multimodal", r[r.Interpreter = 2] = "Interpreter", r[r.Retrieval = 3] = "Retrieval", (a = o || (o = {}))[a.Upload = 0] = "Upload", a[a.Existing = 1] = "Existing";
            var e_ = (0, g.forwardRef)(function(e, t) {
                var n, r, a, i, d, m, b, y, j, Z, D, B, L, K, en, er, ea, ei, es, el, eu, ed, ec, ef, eg, em, ep, ev, ex, eb, ey, ej, ew, eC, ek, e_, eN, eP, eS, eI, eZ, eF, eD, eR, ez, eW, eV, eQ, eG, e$, eY, eJ, eK, eX, e0, e1, e2, e3, e5 = e.onAbortCompletion,
                    e4 = e.onCreateNewCompletion,
                    e8 = e.onRequestMoreCompletions,
                    e7 = e.onContinueGenerating,
                    e6 = e.canRegenerateResponse,
                    e9 = e.currentModelId,
                    te = e.clientThreadId,
                    tt = e.isCompletionInProgress,
                    tn = e.className,
                    tr = e.disabled,
                    ta = void 0 !== tr && tr,
                    ti = e.shouldRetry,
                    to = e.canPause,
                    ts = void 0 !== to && to,
                    tl = e.canContinue,
                    tu = e.suggestions,
                    td = e.isInteractableSharedThread,
                    tc = (0, x.Z)(),
                    tf = (0, T.oq)(te),
                    tg = (0, T.Hk)(te),
                    th = (0, ee.Ri)(e9),
                    tm = (0, I.w$)(),
                    tp = (0, g.useContext)(S.QL).historyDisabled,
                    tv = (0, g.useRef)(null),
                    tx = (0, u._)((0, g.useState)(""), 2),
                    tb = tx[0],
                    ty = tx[1],
                    tj = (0, u._)((0, g.useState)(null), 2),
                    tw = tj[0],
                    tC = tj[1],
                    tk = (0, X.B9)(),
                    t_ = null !== e9 ? tk.get(e9) : void 0,
                    tM = (0, P.Fl)().isCodeInterpreterAvailable,
                    tT = 0;
                tM && (null === (e0 = null == t_ ? void 0 : t_.product_features.attachments) || void 0 === e0 ? void 0 : e0.type) === _.Cd.CodeInterpreter ? tT = 2 : (null === (e1 = null == t_ ? void 0 : t_.product_features.attachments) || void 0 === e1 ? void 0 : e1.type) === _.Cd.Multimodal || (null == t_ ? void 0 : null === (e2 = t_.enabledTools) || void 0 === e2 ? void 0 : e2.includes("Hi Jane, come visit us for lunch at OpenAI? \uD83D\uDC9C")) ? tT = 1 : (null === (e3 = null == t_ ? void 0 : t_.product_features.attachments) || void 0 === e3 ? void 0 : e3.type) === _.Cd.Retrieval && (tT = 3);
                var tN = 0 !== tT,
                    tP = (0, g.useCallback)(function(e, t) {
                        if (null === t ? w.o.logEvent(C.a.uploadFile, {
                                eventSource: "mouse"
                            }) : w.o.logEvent(C.a.uploadFile, {
                                eventSource: "drag"
                            }), e.length > 0) {
                            var n = e[0];
                            tC({
                                type: o.Upload,
                                file: n
                            })
                        }
                    }, []),
                    tS = (0, g.useCallback)(function(e) {
                        e[0].errors.forEach(function(e) {
                            var t = function(e) {
                                var t = e.code,
                                    n = e.message;
                                switch (t) {
                                    case E.jK.FileTooLarge:
                                        return U.errorFileTooLarge;
                                    case E.jK.TooManyFiles:
                                        return U.errorTooManyFiles;
                                    default:
                                        return n
                                }
                            }(e);
                            "string" == typeof t ? V.m.danger(t) : V.m.danger(tc.formatMessage(t, {
                                size: 512
                            }))
                        })
                    }, [tc]),
                    tI = (0, g.useCallback)(function() {
                        tC(null), tL(new Date().toString())
                    }, []),
                    tZ = (0, h.uI)((0, s._)({
                        maxFiles: 1,
                        disabled: ta || !tN,
                        noClick: !0,
                        onDropAccepted: tP,
                        onDropRejected: tS,
                        multiple: !1,
                        maxSize: 536870912
                    }, (0, g.useMemo)(function() {
                        var e, t = null === (e = null == t_ ? void 0 : t_.product_features.attachments) || void 0 === e ? void 0 : e.accepted_mime_types;
                        if (void 0 === t) return {};
                        var n = {
                            "image/jpeg": [".jpg", ".jpeg"],
                            "image/svg+xml": [".svg"],
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
                            "application/vnd.openxmlformats-officedocument.presentationml.presentation": [".pptx"]
                        };
                        return {
                            accept: t.reduce(function(e, t) {
                                return t in n ? e[t] = n[t] : t.includes("/") && (e[t] = [".".concat(t.split("/")[1])]), e
                            }, {})
                        }
                    }, [t_]))),
                    tF = tZ.getRootProps,
                    tD = tZ.getInputProps,
                    tE = tZ.isDragActive,
                    tR = tZ.open,
                    tB = (0, u._)((0, g.useState)(function() {
                        return new Date().toString()
                    }), 2),
                    tA = tB[0],
                    tL = tB[1],
                    tU = (null == tw ? void 0 : tw.type) === o.Upload ? tw.file : null,
                    tO = null !== tU ? JSON.stringify({
                        file: tU.name,
                        modified: tU.lastModified,
                        size: tU.size,
                        fileUploadQueryHash: tA
                    }) : null,
                    tq = (i = 2 === tT ? tU : null, b = (d = (0, Q.VF)(), m = (0, z.a)({
                        queryKey: ["interpreterUploadLink", tO],
                        queryFn: (0, O._)(function() {
                            return (0, q.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, H.ZP.createFile(i.name, i.size, _.Ei.AceUpload).catch(function(e) {
                                            var t = d("default_create_entry_error", {
                                                fileName: null == i ? void 0 : i.name
                                            });
                                            throw void 0 !== e.code && (t = d(e.code)), V.m.danger(t, G), e
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            })
                        }),
                        enabled: !!i
                    })).data, y = m.isLoading, j = m.isError, Z = (null == b ? void 0 : b.status) === "success" ? b.upload_url : void 0, er = (B = (D = (0, u._)((0, g.useState)(0), 2))[0], L = D[1], (0, g.useEffect)(function() {
                        L(0)
                    }, [tO]), K = (0, z.a)({
                        queryKey: ["startFileUpload", tO],
                        queryFn: (0, O._)(function() {
                            return (0, q.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, H.ZP.uploadFileToAzureStorage(i, Z, L).then(function(e) {
                                            if (201 === e.status) return Z
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            })
                        }),
                        enabled: !!(i && Z)
                    }), en = (0, g.useMemo)(function() {
                        return (0, l._)((0, s._)({}, K), {
                            progress: B
                        })
                    }, [K, B])).data, ea = en.isLoading, ei = en.isError, es = en.progress, el = (null == b ? void 0 : b.status) === "success" ? b.file_id : null, ef = (eu = T.tQ.getServerThreadId(te), ed = (0, Q.VF)(), ec = (0, z.a)({
                        queryKey: ["processCodeInterpeterUpload", tO],
                        queryFn: (0, O._)(function() {
                            return (0, q.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, H.ZP.processCodeInterpeterUpload(null != eu ? eu : null, el, i.name).catch(function(e) {
                                            var t = ed("default_download_link_error", {
                                                fileName: null == i ? void 0 : i.name
                                            });
                                            throw void 0 !== e.code && (t = ed(e.code)), V.m.danger(t, G), new W.gK(t, void 0, e.code)
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            })
                        }),
                        enabled: !!(null !== el && null !== i && void 0 !== er)
                    })).data, eg = ec.isLoading, em = ec.isError, ep = (0, g.useMemo)(function() {
                        return b ? 10 + 80 * es : 10
                    }, [b, es]), ev = j || ei || em, ex = y || ea || eg, (0, g.useEffect)(function() {
                        ev && tI()
                    }, [ev, tI]), (0, g.useMemo)(function() {
                        var e = null !== i && !!(null == i ? void 0 : i.name) && (null == ef ? void 0 : ef.status) === "success" && void 0 !== er && null !== el,
                            t = e ? {
                                name: i.name,
                                id: el,
                                size: i.size
                            } : null;
                        return {
                            isLoading: ex,
                            loadingPercentage: ev || e ? void 0 : ep,
                            isError: ev,
                            uploadedFile: t
                        }
                    }, [i, null == ef ? void 0 : ef.status, er, ev, ex, ep, el])),
                    tz = (eb = 0 !== tT && 2 !== tT ? tU : null, ey = 1 === tT ? _.Ei.Multimodal : _.Ei.MyFiles, ew = (ej = (0, z.a)({
                        queryKey: ["createFile", tO],
                        queryFn: (0, O._)(function() {
                            return (0, q.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, H.ZP.createFile(eb.name, eb.size, ey).catch(function(e) {
                                            throw console.error("Failed to create file for ".concat(null == eb ? void 0 : eb.name), e.message), e
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            })
                        }),
                        enabled: !!eb
                    })).data, eC = ej.isLoading, ek = ej.isError, e_ = null == ew ? void 0 : ew.file_id, eN = null == ew ? void 0 : ew.upload_url, eS = (eP = (0, z.a)({
                        queryKey: ["uploadFile", tO],
                        queryFn: (0, O._)(function() {
                            var e, t, n, r;
                            return (0, q.__generator)(this, function(a) {
                                switch (a.label) {
                                    case 0:
                                        return a.trys.push([0, 7, , 8]), [4, H.ZP.uploadFileToAzureStorage(eb, eN)];
                                    case 1:
                                        if (!(201 !== (e = a.sent()).status)) return [3, 6];
                                        t = "Unknown error", a.label = 2;
                                    case 2:
                                        return a.trys.push([2, 4, , 5]), [4, e.data];
                                    case 3:
                                        return t = a.sent(), [3, 5];
                                    case 4:
                                        return a.sent(), [3, 5];
                                    case 5:
                                        return console.error("File upload failed at blobstore upload step", e.status, t), H.ZP.markFileUploadFailed(e_, t), [2, {
                                            success: !1
                                        }];
                                    case 6:
                                        return [3, 8];
                                    case 7:
                                        throw console.error("File upload failed due to a network error", n = a.sent()), r = "Unknown error", n instanceof Error && (r = n.message), H.ZP.markFileUploadFailed(e_, r), n;
                                    case 8:
                                        return [4, H.ZP.markFileUploadComplete(e_)];
                                    case 9:
                                        return a.sent(), [2, {
                                            success: !0
                                        }]
                                }
                            })
                        }),
                        enabled: !!(eb && e_ && eN)
                    })).data, eI = eP.isLoading, eZ = eP.isError, ez = (eF = function(e) {
                        var t = eD("default_download_link_error", {
                            fileName: null == eb ? void 0 : eb.name
                        });
                        void 0 !== e.code && (t = eD(e.code)), V.m.danger(t, Y)
                    }, eD = (0, Q.VF)(), eR = (0, z.a)({
                        queryKey: ["pollForFileReady", tO],
                        queryFn: (0, O._)(function() {
                            return (0, q.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        if (ey !== _.Ei.MyFiles) return [3, 2];
                                        return [4, H.ZP.getRetrievalStatus(e_).catch(function(e) {
                                            throw eF(e), e
                                        })];
                                    case 1:
                                        return [2, e.sent().retrieval_index_status === _.Xf.Success];
                                    case 2:
                                        return [4, H.ZP.getFileDownloadLink(e_).catch(function(e) {
                                            throw eF(e), e
                                        })];
                                    case 3:
                                        return [2, e.sent().status === _.KF.Success];
                                    case 4:
                                        return [2]
                                }
                            })
                        }),
                        enabled: !!(eS && eb && e_),
                        refetchInterval: function(e, t) {
                            if (!e) {
                                if (ey === _.Ei.MyFiles) return 1e3;
                                var n = t.state.dataUpdateCount;
                                return n > $ ? (tI(), !1) : 500 * Math.pow(2, n)
                            }
                            return !1
                        }
                    })).data, eW = eR.isLoading, eV = eR.isError, eQ = null !== eb && ez && null != e_, eG = ek || eZ || eV, e$ = eC || eI || eW || !ez, eY = (0, g.useMemo)(function() {
                        return eQ ? 100 : eS && !ez ? 80 : eS ? 50 : ew ? 10 : 0
                    }, [eQ, eS, ew, ez]), (0, g.useEffect)(function() {
                        eG && (V.m.danger("File upload failed", Y), tI())
                    }, [null == eb ? void 0 : eb.name, eG, tI]), eK = (eJ = (0, u._)((r = (n = (0, u._)((0, g.useState)([null, null]), 2))[0], a = n[1], (0, g.useEffect)(function() {
                        if (!eb) {
                            a([null, null]);
                            return
                        }
                        var e = new FileReader;
                        e.onload = function() {
                            var t = new Image;
                            t.onload = function() {
                                a([t.width, t.height])
                            }, t.src = e.result
                        }, e.readAsDataURL(eb)
                    }, [eb]), r), 2))[0], eX = eJ[1], (0, g.useMemo)(function() {
                        var e = eQ ? null !== eK && null !== eX ? {
                            id: e_,
                            name: eb.name,
                            size: eb.size,
                            width: eK,
                            height: eX
                        } : {
                            id: e_,
                            name: eb.name,
                            size: eb.size
                        } : null;
                        return {
                            isLoading: e$,
                            loadingPercentage: eG || eQ ? void 0 : eY,
                            isError: eG,
                            uploadedFile: e
                        }
                    }, [eQ, eb, e_, eG, e$, eY, eK, eX])),
                    tH = 2 === tT ? tq : tz,
                    tW = tH.isLoading,
                    tV = tH.isError,
                    tQ = tH.loadingPercentage,
                    tG = tH.uploadedFile,
                    t$ = (0, g.useCallback)(function() {
                        ty(""), tC(null), (0, et.sb)(), (0, p.SI)(1, tv.current)
                    }, []),
                    tY = (null == tw ? void 0 : tw.type) !== o.Upload || !tW && !tV,
                    tJ = null === tw ? "" !== tb : tY,
                    tK = tJ && !ta && !tt,
                    tX = (0, g.useCallback)(function(e) {
                        if (null == e || e.preventDefault(), !ta) {
                            var t, n, r, a = null === (t = tv.current) || void 0 === t ? void 0 : t.value,
                                i = "".concat(null === (n = tv.current) || void 0 === n ? void 0 : n.dataset.id, "-nextPrompt");
                            if (tJ) {
                                var s = null != a ? a : "",
                                    l = [];
                                if (tw) {
                                    if (2 === tT || 3 === tT) {
                                        switch (tw.type) {
                                            case o.Upload:
                                                tG && (r = {
                                                    id: tG.id,
                                                    name: tG.name,
                                                    size: tG.size
                                                });
                                                break;
                                            case o.Existing:
                                                r = tw.file
                                        }
                                        r && l.push(r)
                                    } else 1 === tT && tG && "width" in tG && (s = {
                                        content_type: M.PX.MultimodalText,
                                        parts: [{
                                            asset_pointer: (0, Q.L8)(tG.id),
                                            size_bytes: tG.size,
                                            width: tG.width,
                                            height: tG.height
                                        }, null != a ? a : ""]
                                    })
                                }
                                N.vm.hideThreadHeader(), e4(i, {
                                    content: s,
                                    attachments: l
                                }, {
                                    eventSource: e ? "mouse" : "keyboard"
                                }, {
                                    suggestions: tu
                                }), t$(), void 0 !== tu && k.m.logEvent("chatgpt_prompt_ignore_suggestions")
                            }
                        }
                    }, [ta, t$, tJ, e4, tu, tw, tG, tT]),
                    t0 = (0, g.useMemo)(function() {
                        return {
                            Enter: {
                                validator: function() {
                                    return tK
                                },
                                handler: function(e) {
                                    (e.metaKey || tm && !e.shiftKey && !e.nativeEvent.isComposing) && (e.preventDefault(), tX())
                                }
                            },
                            Escape: {
                                validator: function() {
                                    return ts && tt
                                },
                                handler: function() {
                                    e5("", tg), w.o.logEvent(C.a.pauseCompletion, {
                                        threadId: T.tQ.getServerThreadId(te),
                                        eventSource: "keyboard"
                                    })
                                }
                            }
                        }
                    }, [tK, tm, tt, tX, ts, e5, tg, te]),
                    t1 = (0, g.useCallback)(function(e) {
                        var t;
                        (null === (t = t0[e.key]) || void 0 === t ? void 0 : t.validator(e)) && t0[e.key].handler(e)
                    }, [t0]),
                    t2 = (0, g.useCallback)(function(e) {
                        if (e.clipboardData.files.length > 0 && 1 === tT) {
                            var t, n = e.clipboardData.files[0],
                                r = null === (t = null == t_ ? void 0 : t_.product_features.attachments) || void 0 === t ? void 0 : t.accepted_mime_types;
                            if (void 0 !== r && !r.includes(n.type)) {
                                V.m.danger(tc.formatMessage(eH.unsupportedFileType, {
                                    file_type: n.type
                                })), e.preventDefault();
                                return
                            }
                            N.vm.hideThreadHeader(), tC({
                                type: o.Upload,
                                file: n
                            })
                        }
                    }, [t_, tT, tc]),
                    t3 = (0, g.useCallback)(function(e, t) {
                        tC({
                            type: o.Upload,
                            file: e
                        }), ty(t)
                    }, []);
                (0, g.useEffect)(function() {
                    var e;
                    null === (e = tv.current) || void 0 === e || e.focus()
                }, []), (0, g.useEffect)(function() {
                    tC(null)
                }, [e9]);
                var t5 = (0, c.jsx)(eT, {
                    clientThreadId: te,
                    currentLeafId: tf,
                    currentRequestId: tg,
                    shouldRetry: ti,
                    canRegenerateResponse: void 0 !== e6 && e6,
                    canContinue: void 0 !== tl && tl,
                    canPause: ts,
                    suggestions: tu,
                    isCompletionInProgress: tt,
                    onAbortCompletion: e5,
                    onCreateNewCompletion: e4,
                    onRequestMoreCompletions: e8,
                    onContinueGenerating: e7,
                    onResetState: t$
                });
                (0, g.useImperativeHandle)(t, function() {
                    return {
                        setInputValue: ty
                    }
                });
                var t4 = tK ? {
                    backgroundColor: null == th ? void 0 : th.backgroundColor
                } : {};
                return (0, c.jsxs)(c.Fragment, {
                    children: [(0, c.jsx)("form", {
                        className: tn,
                        onSubmit: tX,
                        children: (0, c.jsxs)("div", (0, l._)((0, s._)({
                            className: "relative flex h-full flex-1 items-stretch md:flex-col"
                        }, tF()), {
                            children: [tm && t5, !ti && (0, c.jsxs)(eq, {
                                $disabled: ti,
                                $historyDisabled: tp,
                                children: [tw && (0, c.jsx)(eA, {
                                    children: (0, c.jsx)(J.Z, {
                                        onRemoveFileClick: function() {
                                            return tC(null)
                                        },
                                        file: tw.file.name,
                                        loadingPercentage: tw.type === o.Upload ? tQ : void 0
                                    })
                                }), (0, c.jsx)(p.ZP, {
                                    id: eE,
                                    tabIndex: 0,
                                    value: tb,
                                    "data-id": tf,
                                    ref: tv,
                                    style: {
                                        maxHeight: "200px"
                                    },
                                    rows: 1,
                                    onKeyDown: t1,
                                    onChange: function(e) {
                                        N.vm.hideThreadHeader(), ty(e.target.value)
                                    },
                                    onPaste: t2,
                                    placeholder: td ? tc.formatMessage(eH.continueSharedConversationPlaceholder) : tc.formatMessage(eH.placeholder),
                                    className: (0, f.Z)("m-0 w-full resize-none border-0 bg-transparent p-0 pr-10 focus:ring-0 focus-visible:ring-0 dark:bg-transparent md:pr-12", !tw && tN ? "pl-12 md:pl-[30px]" : "pl-3 md:pl-0"),
                                    disabled: ti
                                }), !tw && tN && (0, c.jsx)(eU, {
                                    children: (0, c.jsx)(A, {
                                        openFileDialog: tR,
                                        disabled: ti,
                                        getInputProps: tD,
                                        attachmentsType: t_.product_features.attachments.type,
                                        onSelectRecentFile: function(e) {
                                            return tC({
                                                type: o.Existing,
                                                file: e
                                            })
                                        }
                                    })
                                }), 1 === tT && (0, c.jsx)(eO, {
                                    $visible: !tJ && !tw && !tt,
                                    children: (0, c.jsx)(eo, {
                                        onPick: t3
                                    })
                                }), (0, c.jsx)(eL, {
                                    disabled: !tK || ti,
                                    style: t4,
                                    className: (0, f.Z)("bottom-1.5", tt ? "disabled:bottom-0.5 md:disabled:bottom-0" : "transition-colors disabled:opacity-40"),
                                    children: tt ? (0, c.jsx)("div", {
                                        className: "text-2xl",
                                        children: (0, c.jsx)(eM, {})
                                    }) : (0, c.jsx)(F.u, {
                                        label: tc.formatMessage(eH.sendMessageTooltip),
                                        children: (0, c.jsx)(R.ZP, {
                                            icon: R.IX,
                                            size: "small",
                                            className: "m-1 md:m-0"
                                        })
                                    })
                                }), tE && (0, c.jsxs)(eB, {
                                    children: [(0, c.jsx)(R.ZP, {
                                        icon: v.tHe
                                    }), tc.formatMessage(eH.dragInstructions)]
                                })]
                            }), !tm && t5]
                        }))
                    }), (0, c.jsx)(eh, {
                        currentModelConfig: t_,
                        disabled: td
                    })]
                })
            });

            function eM() {
                var e = (0, u._)((0, g.useState)(0), 2),
                    t = e[0],
                    n = e[1];
                (0, g.useEffect)(function() {
                    var e = setInterval(function() {
                        n(function(e) {
                            return (e + 1) % 3
                        })
                    }, 350);
                    return function() {
                        return clearInterval(e)
                    }
                }, []);
                for (var r = [], a = 0; a < 3; a++) r.push((0, c.jsx)("span", {
                    className: a <= t ? "" : "invisible",
                    children: "\xb7"
                }, a));
                return (0, c.jsx)(c.Fragment, {
                    children: r
                })
            }

            function eT(e) {
                var t = e.clientThreadId,
                    n = e.currentLeafId,
                    r = e.currentRequestId,
                    a = e.shouldRetry,
                    i = e.canRegenerateResponse,
                    o = e.canContinue,
                    s = e.canPause,
                    l = e.suggestions,
                    u = e.isCompletionInProgress,
                    d = e.onAbortCompletion,
                    f = e.onCreateNewCompletion,
                    h = e.onRequestMoreCompletions,
                    m = e.onContinueGenerating,
                    p = e.onResetState,
                    v = (0, g.useCallback)(function() {
                        d("", r), h(n, {
                            eventSource: "mouse"
                        }), eR()
                    }, [d, h, r, n]),
                    x = (0, g.useCallback)(function() {
                        d("", r), w.o.logEvent(C.a.pauseCompletion, {
                            threadId: T.tQ.getServerThreadId(t),
                            eventSource: "mouse"
                        }), eR()
                    }, [d, t, r]),
                    b = (0, g.useCallback)(function() {
                        m(n), eR()
                    }, [m, n]),
                    y = (0, g.useCallback)(function(e, t) {
                        N.vm.hideThreadHeader(), f("".concat(n, "-nextPrompt"), {
                            content: (0, K.bf)(e),
                            attachments: []
                        }, {
                            eventSource: "mouse"
                        }, {
                            suggestions: l
                        }), p(), k.m.logEvent("chatgpt_prompt_use_suggestion", (0, K.bf)(e), {
                            index: "".concat(t),
                            type: (0, K.QO)(e) ? "reply" : "starter"
                        }), eR()
                    }, [p, n, f, l]);
                return a || i || o || s || void 0 !== l ? a ? (0, c.jsx)(eD, {
                    canRegenerateResponse: i,
                    onRegenerateResponse: v
                }) : (0, c.jsx)(eP, {
                    canContinue: o,
                    canPause: s,
                    canRegenerateResponse: i,
                    isCompletionInProgress: u,
                    onHandleContinueGenerating: b,
                    onRegenerateResponse: v,
                    onSelectingSuggestedReply: y,
                    onStopGenerating: x,
                    suggestions: l
                }) : null
            }
            var eN = function(e) {
                    var t = e.children;
                    return (0, c.jsx)(m.E.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0,
                            transition: {
                                duration: .1,
                                delay: 0
                            }
                        },
                        transition: {
                            type: "tween",
                            duration: .3,
                            delay: .2
                        },
                        children: t
                    })
                },
                eP = function(e) {
                    var t = e.canContinue,
                        n = e.canPause,
                        r = e.canRegenerateResponse,
                        a = e.isCompletionInProgress,
                        i = e.onRegenerateResponse,
                        o = e.onStopGenerating,
                        s = e.onHandleContinueGenerating,
                        l = e.onSelectingSuggestedReply,
                        u = e.suggestions;
                    return (0, c.jsx)("div", {
                        children: (0, c.jsxs)(ez, {
                            children: [(0, c.jsx)("div", {
                                className: "grow",
                                children: void 0 !== u && (0, c.jsx)(K.Gt, {
                                    suggestions: u,
                                    onSelectingSuggestedReply: l
                                })
                            }), (0, c.jsx)(eS, {
                                canContinue: t,
                                canPause: n,
                                canRegenerateResponse: r,
                                isCompletionInProgress: a,
                                onHandleContinueGenerating: s,
                                onRegenerateResponse: i,
                                onStopGenerating: o
                            })]
                        })
                    })
                },
                eS = function(e) {
                    var t = e.canContinue,
                        n = e.canPause,
                        r = e.canRegenerateResponse,
                        a = e.isCompletionInProgress,
                        i = e.onHandleContinueGenerating,
                        o = e.onRegenerateResponse,
                        s = e.onStopGenerating;
                    return t ? (0, c.jsx)("div", {
                        className: "flex items-center md:items-end",
                        children: (0, c.jsx)(eI, {
                            onHandleContinueGenerating: i
                        })
                    }) : n && a ? (0, c.jsx)("div", {
                        className: "flex items-center md:items-end",
                        children: (0, c.jsx)(eZ, {
                            onStopGenerating: s
                        })
                    }) : r ? (0, c.jsx)("div", {
                        className: "flex items-center md:items-end",
                        children: (0, c.jsx)(eF, {
                            onRegenerateResponse: o
                        })
                    }) : null
                },
                eI = function(e) {
                    var t = e.onHandleContinueGenerating,
                        n = (0, I.w$)();
                    return (0, c.jsx)(eN, {
                        children: (0, c.jsxs)(Z.z, {
                            as: "button",
                            color: "neutral",
                            onClick: t,
                            className: "whitespace-nowrap border-0 md:border",
                            children: [(0, c.jsx)(R.ZP, {
                                icon: v.lV_,
                                className: "-rotate-180",
                                size: n ? "xsmall" : "small"
                            }), n && (0, c.jsx)(b.Z, (0, s._)({}, eH.continueGenerating))]
                        })
                    })
                },
                eZ = function(e) {
                    var t = e.onStopGenerating,
                        n = (0, I.w$)();
                    return (0, c.jsx)(eN, {
                        children: (0, c.jsxs)(Z.z, {
                            as: "button",
                            color: "neutral",
                            onClick: t,
                            className: "whitespace-nowrap border-0 md:border",
                            children: [(0, c.jsx)(R.ZP, {
                                icon: v.jxP,
                                size: n ? "xsmall" : "small"
                            }), n && (0, c.jsx)(b.Z, (0, s._)({}, eH.stopGenerating))]
                        })
                    })
                },
                eF = function(e) {
                    var t = e.shouldRetry,
                        n = void 0 !== t && t,
                        r = e.onRegenerateResponse,
                        a = (0, I.w$)();
                    return (0, c.jsx)(eN, {
                        children: (0, c.jsxs)(Z.z, {
                            as: "button",
                            color: n ? "primary" : a ? "neutral" : "none",
                            onClick: r,
                            className: (0, f.Z)("whitespace-nowrap", n ? "m-auto" : "-z-0 border-0 md:border"),
                            children: [(0, c.jsx)(R.ZP, {
                                icon: v.Qxo,
                                size: a ? "xsmall" : "small",
                                className: "flex-shrink-0"
                            }), (a || n) && (0, c.jsx)(b.Z, (0, s._)({}, eH.regenerateResponse))]
                        })
                    })
                },
                eD = function(e) {
                    var t = e.canRegenerateResponse,
                        n = e.onRegenerateResponse;
                    return (0, c.jsxs)("div", {
                        className: "w-full",
                        children: [(0, c.jsx)("div", {
                            className: "mb-3 text-center text-xs",
                            children: (0, c.jsx)(b.Z, (0, s._)({}, eH.errorGeneratingResponse))
                        }), (0, c.jsx)(ez, {
                            $shouldRetry: !0,
                            children: t && (0, c.jsx)("div", {
                                className: "flex flex-col justify-end",
                                children: (0, c.jsx)(eF, {
                                    onRegenerateResponse: n,
                                    shouldRetry: !0
                                })
                            })
                        })]
                    })
                },
                eE = "prompt-textarea";

            function eR() {
                var e;
                null === (e = document.getElementById(eE)) || void 0 === e || e.focus()
            }
            var eB = j.Z.div(ex()),
                eA = j.Z.div(eb()),
                eL = j.Z.button(ey()),
                eU = j.Z.div(ej()),
                eO = j.Z.div(ew(), function(e) {
                    return e.$visible ? "opacity-100" : "opacity-0 pointer-events-none"
                }),
                eq = j.Z.div(eC(), function(e) {
                    return e.$historyDisabled ? "bg-gray-900 text-white shadow-xs dark:bg-gray-900 dark:text-white dark:shadow-xs" : ""
                }, function(e) {
                    return e.$disabled && "bg-gray-100"
                }),
                ez = j.Z.div(ek(), function(e) {
                    return e.$shouldRetry ? "" : "h-full"
                }),
                eH = (0, y.vU)({
                    errorGeneratingResponse: {
                        id: "PromptTextarea.errorGeneratingResponse",
                        defaultMessage: "There was an error generating a response",
                        description: "Error message shown when the response generation fails"
                    },
                    regenerateResponse: {
                        id: "PromptTextarea.regenerateResponse",
                        defaultMessage: "Regenerate",
                        description: "Button label for regenerating response"
                    },
                    continueGenerating: {
                        id: "PromptTextarea.continueGenerating",
                        defaultMessage: "Continue generating",
                        description: "Button label for continuing response generation"
                    },
                    stopGenerating: {
                        id: "PromptTextarea.stopGenerating",
                        defaultMessage: "Stop generating",
                        description: "Button label for stopping response generation"
                    },
                    placeholder: {
                        id: "PromptTextarea.placeholder",
                        defaultMessage: "Send a message",
                        description: "Placeholder text for the input field"
                    },
                    continueSharedConversationPlaceholder: {
                        id: "PromptTextarea.continueSharedConversationPlaceholder",
                        defaultMessage: "Send a message to continue the conversation.",
                        description: "Placeholder text for the input field when viewing a shared chat"
                    },
                    sendMessageTooltip: {
                        id: "PromptTextarea.sendMessageTooltip",
                        defaultMessage: "Send message",
                        description: "Tooltip for the send message button"
                    },
                    pauseTooltip: {
                        id: "PromptTextarea.pauseTooltip",
                        defaultMessage: "Pause",
                        description: "Tooltip for the pause button"
                    },
                    dragInstructions: {
                        id: "PromptTextarea.dragInstructions",
                        defaultMessage: "Upload file",
                        description: "Instructions for dragging and dropping a file to upload"
                    },
                    unsupportedFileType: {
                        id: "PromptTextarea.unsupportedFileType",
                        defaultMessage: 'Uploads with file type "{file_type}" are not supported, please try another file.',
                        description: "Error shown when an invalid file type is uploaded"
                    }
                })
        },
        50921: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return u
                }
            });
            var r = n(35250),
                a = n(47103),
                i = n(19841),
                o = n(70079),
                s = n(1454),
                l = n(88327);

            function u(e) {
                var t = e.onChange,
                    n = e.enabled,
                    u = e.label,
                    d = e.disabled,
                    c = e.withLockIcon,
                    f = (0, o.useCallback)(function() {
                        t(!n)
                    }, [n, t]);
                return (0, r.jsx)(a.fC, {
                    checked: n,
                    disabled: d,
                    onCheckedChange: f,
                    "aria-label": u,
                    className: (0, i.Z)(d ? "cursor-not-allowed opacity-50" : "cursor-pointer", "bg-gray-200 radix-state-checked:bg-green-600", "relative h-[25px] w-[42px] rounded-full"),
                    children: (0, r.jsx)(a.bU, {
                        className: (0, i.Z)("flex h-[21px] w-[21px] items-center justify-center rounded-full", "translate-x-0.5 transition-transform duration-100 will-change-transform radix-state-checked:translate-x-[19px]", "bg-white shadow-[0_1px_2px_rgba(0,0,0,0.45)]"),
                        children: void 0 !== c && c ? (0, r.jsx)(l.ZP, {
                            icon: s.UIZ,
                            size: "xsmall"
                        }) : null
                    })
                })
            }
        },
        15610: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return F
                },
                Z: function() {
                    return _
                }
            });
            var r = n(96237),
                a = n(39324),
                i = n(71209),
                o = n(22830),
                s = n(4337),
                l = n(35250),
                u = n(90209),
                d = n(47428),
                c = n(19841),
                f = n(70079),
                g = n(7137),
                h = n(1454),
                m = n(21389),
                p = n(33669),
                v = n(67273),
                x = n(88327),
                b = n(43019);

            function y() {
                var e = (0, s._)(["absolute w-[2.5px] h-5 -rotate-45 -top-0.5 left-1.5 bg-gray-500 border-[0.5px] border-gray-100 group-hover/toggle:bg-red-500 dark:border-[#4E4F60]"]);
                return y = function() {
                    return e
                }, e
            }

            function j() {
                var e = (0, s._)(["group/options flex flex-col rounded-xl border border-gray-100 bg-white text-left shadow-xxs dark:text-gray-100 dark:bg-gray-900 dark:border-gray-800 dark:shadow-xs mx-2 sm:mx-1 overflow-hidden"]);
                return j = function() {
                    return e
                }, e
            }

            function w() {
                var e = (0, s._)(["px-5 flex gap-2.5 flex-col py-4 whitespace-pre-line"]);
                return w = function() {
                    return e
                }, e
            }

            function C() {
                var e = (0, s._)(["block dark:text-white text-gray-900"]);
                return C = function() {
                    return e
                }, e
            }

            function k() {
                var e = (0, s._)(["block text-xs text-gray-500"]);
                return k = function() {
                    return e
                }, e
            }

            function _(e) {
                var t = e.items,
                    n = e.value,
                    s = e.onChange,
                    u = I(),
                    d = (0, o._)((0, f.useState)(function() {
                        return t.reduce(function(e, t) {
                            if (t.options.length > 0) {
                                var r = t.options.find(function(e) {
                                    return e.value === n
                                });
                                if (r) return e[t.value] = r.value, e;
                                e[t.value] = t.options[0].value
                            }
                            return e
                        }, {})
                    }), 2),
                    c = d[0],
                    g = d[1],
                    h = (0, f.useCallback)(function(e, o) {
                        var l, d = n,
                            f = t.find(function(t) {
                                return t.value === e
                            }),
                            h = (null == c ? void 0 : c[e]) !== void 0,
                            m = h && t.some(function(t) {
                                return t.value === e && t.options.some(function(t) {
                                    return t.value === c[e]
                                })
                            }),
                            p = o;
                        u && void 0 === o && (p = h ? c[e] : null !== (l = null == f ? void 0 : f.options[0].value) && void 0 !== l ? l : void 0), (d = void 0 !== p ? p : m ? c[e] : e) !== n && (s(d), g(function(t) {
                            return (0, i._)((0, a._)({}, t), (0, r._)({}, e, d))
                        }))
                    }, [u, t, c, s, n]),
                    m = (0, o._)((0, f.useState)(new Set), 2),
                    p = m[0],
                    v = m[1],
                    x = (0, f.useCallback)(function(e, t) {
                        t ? v(function(t) {
                            var n = new Set(t);
                            return n.add(e), n
                        }) : v(function(t) {
                            var n = new Set(t);
                            return n.delete(e), n
                        })
                    }, []);
                return (0, l.jsx)("div", {
                    className: "relative flex rounded-xl bg-gray-100 p-1 text-gray-900 dark:bg-gray-900",
                    children: (0, l.jsx)("ul", {
                        className: "flex w-full list-none gap-1 sm:w-auto",
                        children: t.map(function(e, r) {
                            var a, i, o, s, u, d, f = n === e.value || e.options.some(function(e) {
                                    return e.value === n
                                }),
                                g = f ? n : null == c ? void 0 : c[e.value],
                                m = null != g ? g : null === (i = e.options) || void 0 === i ? void 0 : null === (o = i[0]) || void 0 === o ? void 0 : o.value,
                                v = null !== (s = e.options.find(function(e) {
                                    return e.value === m
                                })) && void 0 !== s ? s : e.options[0],
                                b = null !== (u = null == v ? void 0 : v.icon) && void 0 !== u ? u : null;
                            return (0, l.jsx)(T, {
                                onToggleItemOpenChanged: x,
                                item: e,
                                isSelected: f,
                                isOtherToggleDropdownOpen: p.size > 0 && !p.has(e.categoryId),
                                currentValue: n,
                                defaultOption: null == v ? void 0 : v.value,
                                onChange: h,
                                currentIcon: b,
                                displayCurrentValue: f && e.showSelectedValueBelow && null !== (d = null == v ? void 0 : v.name) && void 0 !== d ? d : "",
                                contentAlign: (a = t.length, 0 === r ? "start" : r === a - 1 ? "end" : "center")
                            }, r)
                        })
                    })
                })
            }

            function M(e) {
                var t = e.item,
                    n = e.isSelected,
                    r = e.isOtherToggleDropdownOpen,
                    a = e.isOpen,
                    i = e.currentIcon,
                    o = e.displayCurrentValue,
                    s = null != i ? i : t.icon,
                    u = t.options.length > 1 || t.alwaysShowOptions,
                    d = I();
                return (0, l.jsxs)("div", {
                    className: (0, c.Z)("group/button", "relative flex w-full items-center justify-center gap-1 rounded-lg border py-3 outline-none transition-opacity duration-100 sm:w-auto sm:min-w-[148px] md:gap-2 md:py-2.5", n ? "border-black/10 bg-white text-gray-900 shadow-[0_1px_7px_0px_rgba(0,0,0,0.06)] hover:!opacity-100 dark:border-[#4E4F60] dark:bg-gray-700 dark:text-gray-100" : "border-transparent text-gray-500 hover:text-gray-800 hover:dark:text-gray-100", void 0 !== a && a && "text-gray-800 dark:text-gray-100", r && n && "opacity-50"),
                    children: [(0, l.jsxs)("span", {
                        className: (0, c.Z)("relative max-[370px]:hidden", t.disabled && "group-hover/button:text-red-500"),
                        children: [null != s && (0, l.jsx)(x.ZP, {
                            icon: s,
                            className: (0, c.Z)("transition-colors", n ? t.buttonActiveClass : t.buttonHoverClass)
                        }), t.disabled && (0, l.jsx)(D, {})]
                    }), (0, l.jsx)("span", {
                        className: (0, c.Z)("truncate text-sm font-medium md:pr-1.5", !d && "pr-1.5"),
                        children: t.name
                    }), null != t.iconAfter && (0, l.jsx)(x.ZP, {
                        icon: t.iconAfter,
                        className: (0, c.Z)("ml-0.5 h-4 w-4 transition-colors sm:ml-0", t.iconAfterClass, n ? t.buttonActiveClass : t.buttonHoverClass)
                    }), d && (n || u) && (0, l.jsx)(x.ZP, {
                        icon: u ? h.bTu : g.DAO,
                        className: "toggle-item-button-open ml-0.5 text-gray-500"
                    }), d && (0, l.jsx)(x.ZP, {
                        icon: h.rH8,
                        className: "toggle-item-button-closed ml-0.5 text-gray-500"
                    }), null != o && "" !== o && (0, l.jsx)("span", {
                        className: "absolute left-0 top-full mt-4 w-full truncate overflow-ellipsis text-sm text-gray-500",
                        children: o
                    })]
                })
            }

            function T(e) {
                var t = e.item,
                    n = e.isSelected,
                    r = e.defaultOption,
                    a = e.onChange,
                    i = e.currentIcon,
                    s = e.currentValue,
                    u = e.displayCurrentValue,
                    g = e.contentAlign,
                    h = e.onToggleItemOpenChanged,
                    m = e.isOtherToggleDropdownOpen,
                    p = (0, o._)((0, f.useState)(void 0), 2),
                    v = p[0],
                    x = p[1],
                    y = (0, f.useRef)(null),
                    j = t.options.length > 1 || t.alwaysShowOptions,
                    w = !(void 0 === t.description && void 0 === t.disclaimer),
                    C = I(),
                    k = (0, f.useCallback)(function(e) {
                        x(e), h(t.categoryId, !!e)
                    }, [t.categoryId, h]);
                return (0, l.jsx)(d.fC, {
                    open: v,
                    modal: !1,
                    onOpenChange: function(e) {
                        C && e && !n && j && a(t.value)
                    },
                    children: (0, l.jsxs)("li", {
                        className: "group/toggle w-full",
                        "data-testid": t.value,
                        onMouseEnter: function() {
                            return !C && k(!0)
                        },
                        onMouseLeave: function() {
                            return !C && k(void 0)
                        },
                        children: [(0, l.jsx)(d.xz, {
                            ref: y,
                            className: "w-full cursor-pointer",
                            onClick: function() {
                                t.disabled || a(t.value)
                            },
                            children: (0, l.jsx)(M, {
                                isOpen: !!v,
                                isOtherToggleDropdownOpen: m,
                                item: t,
                                isSelected: n,
                                currentIcon: i,
                                displayCurrentValue: u
                            })
                        }), (0, l.jsx)(d.Uv, {
                            children: (0, l.jsx)(d.VY, {
                                className: (0, c.Z)("w-full min-w-[100vw] max-w-[100vw] select-none pt-3 font-medium sm:w-[312px] sm:min-w-[312px] md:max-w-none", "will-change-[opacity,transform] radix-side-bottom:animate-slideDownAndFade radix-side-left:animate-slideLeftAndFade radix-side-right:animate-slideRightAndFade radix-side-top:animate-slideUpAndFade", {
                                    "sm:min-w-[420px]": "Alpha" === t.name
                                }),
                                align: g,
                                onCloseAutoFocus: function(e) {
                                    v || e.preventDefault()
                                },
                                onEscapeKeyDown: function(e) {
                                    var t;
                                    e.preventDefault(), null === (t = y.current) || void 0 === t || t.focus()
                                },
                                children: (0, l.jsxs)(E, {
                                    children: [w && (0, l.jsx)(N, {
                                        item: t
                                    }), (j || !v && !C) && (0, l.jsx)(P, {
                                        defaultOption: n ? s : r,
                                        item: t,
                                        currentValue: s,
                                        onChange: function(e, t) {
                                            a(e, t), k(void 0), (0, b.go)()
                                        },
                                        className: (0, c.Z)("text-sm", w && "mb-1 border-t border-gray-100 dark:border-gray-800")
                                    })]
                                })
                            })
                        }, t.categoryId)]
                    })
                })
            }

            function N(e) {
                var t = e.item;
                return (0, l.jsxs)(R, {
                    className: "text-sm sm:text-base",
                    children: [void 0 !== t.description && (0, l.jsx)(B, {
                        children: t.description
                    }), void 0 !== t.disclaimer && (0, l.jsx)(A, {
                        children: t.disclaimer
                    }), t.onCtaContentClick && t.ctaContentText && (0, l.jsx)("div", {
                        className: "mt-2",
                        children: (0, l.jsx)(v.z, {
                            onClick: function() {
                                return t.onCtaContentClick && t.onCtaContentClick("info-button")
                            },
                            color: "primary",
                            className: "w-full !bg-brand-purple py-3 text-xs hover:bg-brand-purple hover:brightness-90",
                            children: t.ctaContentText
                        })
                    })]
                })
            }

            function P(e) {
                var t = e.item,
                    n = e.className,
                    r = e.onChange,
                    a = e.currentValue,
                    i = e.defaultOption;
                return (0, l.jsx)(d.Ee, {
                    defaultValue: i,
                    value: a,
                    className: n,
                    children: t.options.map(function(e, n) {
                        return (0, l.jsx)(S, {
                            option: e,
                            selected: a === e.value,
                            active: i === e.value,
                            iconClass: t.iconClass,
                            iconActiveClass: t.buttonActiveClass,
                            showBorder: n !== t.options.length - 1,
                            isDisabled: e.disabled,
                            onChange: function() {
                                e.disabled || r(t.value, e.value)
                            }
                        }, e.value)
                    })
                })
            }

            function S(e) {
                var t, n = e.option,
                    r = e.selected,
                    a = e.active,
                    i = e.iconClass,
                    o = e.iconActiveClass,
                    s = e.isDisabled,
                    f = e.onChange,
                    g = e.showBorder,
                    h = null !== (t = n.activeIcon) && void 0 !== t ? t : n.icon;
                return (0, l.jsx)(d.Rk, {
                    disabled: s,
                    asChild: !0,
                    value: n.value,
                    onClick: f,
                    className: "select-none outline-none",
                    children: (0, l.jsxs)("div", {
                        className: (0, c.Z)("group/option relative flex w-full items-center gap-2 px-5 py-3 pr-11 font-medium focus:bg-gray-50 focus:dark:bg-gray-700", s ? "text-gray-500" : "text-gray-900 dark:text-gray-100", {
                            "cursor-pointer hover:!bg-gray-50 dark:hover:!bg-gray-700": !s,
                            "bg-gray-50 group-hover/options:bg-transparent dark:bg-gray-700": a && !r,
                            "text-gray-800 dark:text-gray-100": r || a,
                            "border-b border-gray-100 dark:border-gray-800": g
                        }),
                        children: [null != n.icon && null != h ? (0, l.jsx)(x.ZP, {
                            icon: r ? n.icon : h,
                            className: (0, c.Z)("max-[370px]:hidden", !s && !r && i, r || a ? o : "text-gray-500")
                        }) : null, (0, l.jsx)("span", {
                            title: "string" == typeof n.name && n.name ? n.name : "",
                            className: (0, c.Z)("truncate", {
                                "group-hover/option:text-gray-800 dark:group-hover/option:text-gray-100": !s,
                                "text-gray-800 dark:text-gray-100": a && !s
                            }),
                            children: n.name
                        }), n.tags.map(function(e) {
                            return F(e)
                        }), (0, l.jsx)("span", {
                            className: (0, c.Z)({
                                "absolute right-3 rounded-full p-1 text-blue-400": !0,
                                "opacity-0 group-hover/options:opacity-0": !r && !s,
                                "text-red-500": s
                            }),
                            children: (0, l.jsx)(x.ZP, {
                                icon: s ? u.Z : x.nQ,
                                className: "h-5 w-5"
                            })
                        })]
                    })
                })
            }
            var I = function() {
                    return !(0, p.w$)()
                },
                Z = new Set(["beta", "confidential", "alpha"]),
                F = function(e) {
                    return Z.has(e) && (0, l.jsx)("span", {
                        className: (0, c.Z)("py-0.25 rounded px-1 text-sm capitalize", "beta" === e && "bg-blue-200 text-blue-500", "alpha" === e && "bg-blue-200 text-blue-500", "confidential" === e && "bg-red-200 text-red-800"),
                        children: e
                    }, e)
                },
                D = m.Z.span(y()),
                E = m.Z.div(j()),
                R = m.Z.div(w()),
                B = m.Z.span(C()),
                A = m.Z.span(k())
        },
        86273: function(e, t, n) {
            n.d(t, {
                iW: function() {
                    return U
                },
                wm: function() {
                    return z
                },
                sY: function() {
                    return L
                }
            });
            var r = n(21722),
                a = n(39324),
                i = n(71209),
                o = n(22830),
                s = n(39889),
                l = n(35250),
                u = n(6013),
                d = n(13995),
                c = n(74686),
                f = n(5268),
                g = n(19841),
                h = n(70737),
                m = n(97296),
                p = n(70079),
                v = n(1454),
                x = n(94968),
                b = n(70671),
                y = n(32004),
                j = n(62509),
                w = n(16920),
                C = n(99486),
                k = n(46020),
                _ = n(33669),
                M = n(97747),
                T = n(89368),
                N = n(45635),
                P = n(88327),
                S = n(1821),
                I = n(88798),
                Z = n(50921),
                F = n(80691),
                D = n(61888),
                E = n(6948),
                R = "".concat("oai/apps/hasUserContextFirstTime", "/").concat("2023-06-29"),
                B = function(e) {
                    var t = e.onClose,
                        n = (0, b.Z)(),
                        r = (0, p.useCallback)(function() {
                            E.m.setItem(R, !0), t()
                        }, [t]);
                    return (0, l.jsxs)(T.Z, {
                        isOpen: !0,
                        onClose: D.noop,
                        size: "custom",
                        className: "max-w-xl",
                        type: "success",
                        title: n.formatMessage(A.title),
                        primaryButton: (0, l.jsx)(M.ZP.Button, {
                            onClick: r,
                            title: n.formatMessage(A.ok),
                            color: "primary"
                        }),
                        children: [(0, l.jsxs)("div", {
                            className: "mb-6 flex flex-col gap-3",
                            children: [(0, l.jsx)("p", {
                                children: (0, l.jsx)(y.Z, (0, a._)({}, A.body1))
                            }), (0, l.jsx)("p", {
                                children: (0, l.jsx)(y.Z, (0, a._)({}, A.body2))
                            })]
                        }), (0, l.jsx)("div", {
                            className: "flex flex-col gap-3 text-sm text-gray-500",
                            children: (0, l.jsx)("p", {
                                children: (0, l.jsx)(y.Z, (0, i._)((0, a._)({}, A.legal1), {
                                    values: {
                                        strong: function(e) {
                                            return (0, l.jsx)("strong", {
                                                children: e
                                            })
                                        },
                                        article: function(e) {
                                            return (0, l.jsx)("a", {
                                                href: U,
                                                target: "_blank",
                                                className: "underline",
                                                rel: "noopener noreferrer",
                                                children: e
                                            })
                                        }
                                    }
                                }))
                            })
                        })]
                    })
                },
                A = (0, x.vU)({
                    title: {
                        id: "UserContextFirstTimeModal.title",
                        defaultMessage: "Introducing Custom instructions",
                        description: "Title of the UserContextFirstTimeModal"
                    },
                    body1: {
                        id: "UserContextFirstTimeModal.body1",
                        defaultMessage: "Custom instructions let you share anything you'd like ChatGPT to consider in its response.",
                        description: "Body of the first paragraph UserContextFirstTimeModal"
                    },
                    body2: {
                        id: "UserContextFirstTimeModal.body2",
                        defaultMessage: "Your instructions will be added to new conversations going forward, and you can edit or delete them at any time.",
                        description: "Body of the second paragraph UserContextFirstTimeModal"
                    },
                    legal1: {
                        id: "UserContextFirstTimeModal.legal1",
                        defaultMessage: "<strong>Note:</strong> This information will be used to improve model performance unless you’ve opted out and may also be shared with the plugins you’ve enabled – visit our <article>Help Center</article> to learn more.",
                        description: "Legal text of the first paragraph UserContextFirstTimeModal"
                    },
                    ok: {
                        id: "UserContextFirstTimeModal.ok",
                        defaultMessage: "OK",
                        description: "Button to close the UserContextFirstTimeModal"
                    }
                }),
                L = (0, x.vU)({
                    tipsHeader: {
                        id: "userContextModal.tipsHeader",
                        defaultMessage: "Thought starters",
                        description: "header for Custom instructions tips"
                    },
                    aboutUserTip1: {
                        id: "userContextModal.aboutUserTip1",
                        defaultMessage: "Where are you based?",
                        description: "tips for Custom instructions about you"
                    },
                    aboutUserTip2: {
                        id: "userContextModal.aboutUserTip2",
                        defaultMessage: "What do you do for work?",
                        description: "tips for Custom instructions about you"
                    },
                    aboutUserTip3: {
                        id: "userContextModal.aboutUserTip3",
                        defaultMessage: "What are your hobbies and interests?",
                        description: "tips for Custom instructions about you"
                    },
                    aboutUserTip4: {
                        id: "userContextModal.aboutUserTip4",
                        defaultMessage: "What subjects can you talk about for hours?",
                        description: "tips for Custom instructions about you"
                    },
                    aboutUserTip5: {
                        id: "userContextModal.aboutUserTip5",
                        defaultMessage: "What are some goals you have?",
                        description: "tips for Custom instructions about you"
                    },
                    modelTip1: {
                        id: "userContextModal.modelTip1",
                        defaultMessage: "How formal or casual should ChatGPT be?",
                        description: "tips for Custom instructions about model"
                    },
                    modelTip2: {
                        id: "userContextModal.modelTip2",
                        defaultMessage: "How long or short should responses generally be?",
                        description: "tips for Custom instructions about model"
                    },
                    modelTip3: {
                        id: "userContextModal.modelTip3",
                        defaultMessage: "How do you want to be addressed?",
                        description: "tips for Custom instructions about model"
                    },
                    modelTip4: {
                        id: "userContextModal.modelTip4",
                        defaultMessage: "Should ChatGPT have opinions on topics or remain neutral?",
                        description: "tips for Custom instructions about model"
                    },
                    save: {
                        id: "userContextModal.save",
                        defaultMessage: "Save",
                        description: "save button for my profile modal"
                    },
                    chatPreferencesIsEnabled: {
                        id: "userContextModal.chatPreferencesIsEnabled",
                        defaultMessage: "Enabled for new chats",
                        description: "chat preferences is enabled"
                    },
                    chatPreferencesIsDisabled: {
                        id: "userContextModal.chatPreferencesIsDisabled",
                        defaultMessage: "Disabled for new chats",
                        description: "chat preferences is disabled"
                    },
                    enableToggleLabel: {
                        id: "userContextModal.enableToggleLabel",
                        defaultMessage: "Enable chat preferences",
                        description: "enable chat preferences toggle label"
                    },
                    disableToggleLabel: {
                        id: "userContextModal.disableToggleLabel",
                        defaultMessage: "Disable chat preferences",
                        description: "disable chat preferences toggle label"
                    },
                    cancel: {
                        id: "userContextModal.cancel",
                        defaultMessage: "Cancel",
                        description: "Cancel button for Custom instructions modal"
                    },
                    aboutYouHelpText: {
                        id: "userContextModal.aboutYouHelpText",
                        defaultMessage: "What would you like ChatGPT to know about you to provide better responses?",
                        description: "help text for about you section of Custom instructions"
                    },
                    modelHelpText: {
                        id: "userContextModal.modelHelpText",
                        defaultMessage: "How would you like ChatGPT to respond?",
                        description: "help text for about you section of Custom instructions"
                    },
                    profileTitle: {
                        id: "userContextModal.title",
                        defaultMessage: "Custom instructions",
                        description: "title for Custom instructions modal"
                    },
                    profileSubhead: {
                        id: "userContextModal.subhead",
                        defaultMessage: "<article>Learn more</article> about Custom instructions and how they’re used to help ChatGPT provide better responses.",
                        description: "subhead for Custom instructions modal"
                    },
                    messageLimitError: {
                        id: "userContextModal.messageLimitError",
                        defaultMessage: "Please limit your responses to {limit} characters or less.",
                        description: "error message for Custom instructions modal"
                    },
                    showTips: {
                        id: "userContextModal.showTips",
                        defaultMessage: "Show tips",
                        description: "show tips button for Custom instructions modal"
                    },
                    hideTips: {
                        id: "userContextModal.hideTips",
                        defaultMessage: "Hide tips",
                        description: "hide tips button for Custom instructions modal"
                    },
                    confirmCloseTitle: {
                        id: "userContextModal.confirmCloseTitle",
                        defaultMessage: "You have unsaved changes.",
                        description: "title for confirm close modal"
                    },
                    confirmCloseBody: {
                        id: "userContextModal.confirmCloseBody",
                        defaultMessage: "Are you sure you want to exit? Any changes you made will be permanently lost.",
                        description: "confirm close modal"
                    },
                    confirmCloseCancel: {
                        id: "userContextModal.confirmCloseCancel",
                        defaultMessage: "Back",
                        description: "cancel button for confirm close modal"
                    },
                    confirmCloseOk: {
                        id: "userContextModal.confirmCloseOk",
                        defaultMessage: "Exit",
                        description: "ok button for confirm close modal"
                    },
                    modApiVoilation: {
                        id: "userContextModal.modApiVoilation",
                        defaultMessage: "This content may violate our <policyLink>content policy</policyLink>. If you believe this to be in error, please <feedbackLink>submit your feedback</feedbackLink> — your input will aid our research in this area.",
                        description: "error message for mod api voilation"
                    }
                }),
                U = "https://help.openai.com/en/articles/8096356-custom-instructions-for-chatgpt",
                O = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return ["userContext", e]
                },
                q = {
                    aboutUserMessage: void 0,
                    aboutModelMessage: void 0,
                    enabled: void 0
                };

            function z() {
                var e, t, n, u, g, h, m, v, x, _, D, A = (0, b.Z)(),
                    z = !1 == !!E.m.getItem(R),
                    G = (0, o._)((0, p.useState)(!1), 2),
                    $ = G[0],
                    Y = G[1],
                    J = (0, j.kP)().loading,
                    K = (0, k.tN)(function(e) {
                        return e.activeModals.has(k.B.UserContext)
                    }),
                    X = (e = (0, j.kP)().session, t = (0, F.Z)(), (0, f.a)(O(null == e ? void 0 : e.accessToken), function() {
                        return C.ZP.getUserSystemMessage((null == e ? void 0 : e.accessToken) || "").catch(function() {
                            I.m.danger("Failed to get your Custom Instructions")
                        })
                    }, {
                        enabled: !!(K && !J && (null == e ? void 0 : e.accessToken) && t),
                        select: function(e) {
                            var t, n, r;
                            return {
                                aboutUserMessage: null !== (t = null == e ? void 0 : e.about_user_message) && void 0 !== t ? t : "",
                                aboutModelMessage: null !== (n = null == e ? void 0 : e.about_model_message) && void 0 !== n ? n : "",
                                enabled: null === (r = null == e ? void 0 : e.enabled) || void 0 === r || r
                            }
                        }
                    })),
                    ee = X.isLoading,
                    et = X.data,
                    en = null != et ? et : {},
                    er = en.aboutUserMessage,
                    ea = void 0 === er ? "" : er,
                    ei = en.aboutModelMessage,
                    eo = void 0 === ei ? "" : ei,
                    es = en.enabled,
                    el = (0, o._)((0, p.useState)(q), 2),
                    eu = el[0],
                    ed = el[1],
                    ec = eu.aboutUserMessage,
                    ef = eu.aboutModelMessage,
                    eg = eu.enabled,
                    eh = null != eg ? eg : !!es,
                    em = (0, o._)((0, p.useState)(null), 2),
                    ep = em[0],
                    ev = em[1],
                    ex = (0, p.useCallback)(function() {
                        k.vm.closeModal(k.B.UserContext), ed(q), ev(null)
                    }, []),
                    eb = (u = (n = {
                        onSuccess: function() {
                            ex()
                        },
                        onError: function(e) {
                            var t, n, r, a;
                            return (null === (t = e.response) || void 0 === t ? void 0 : t.reason) === "content_policy" && (null === (n = e.response) || void 0 === n ? void 0 : n.field) ? ev(null === (r = e.response) || void 0 === r ? void 0 : r.field) : I.m.danger(null !== (a = e.message) && void 0 !== a ? a : "Failed to update Custom Instructions."), e
                        }
                    }).onSuccess, g = n.onError, h = (0, j.kP)().session, m = (0, d.NL)(), (0, c.D)({
                        mutationFn: function(e) {
                            var t = e.userContext;
                            return C.ZP.createOrUpdateUserSystemMessage((null == h ? void 0 : h.accessToken) || "", t)
                        },
                        onSettled: function(e, t) {
                            var n = O(null == h ? void 0 : h.accessToken);
                            null === e || t ? m.invalidateQueries({
                                queryKey: n
                            }) : m.setQueryData(n, e)
                        },
                        onSuccess: u,
                        onError: g
                    })),
                    ey = eb.isLoading,
                    ej = eb.mutate,
                    ew = (0, o._)((0, p.useState)(!1), 2),
                    eC = ew[0],
                    ek = ew[1],
                    e_ = V(null != ec ? ec : "") || V(null != ef ? ef : ""),
                    eM = void 0 !== ef && ef !== eo || void 0 !== ec && ec !== ea || void 0 !== eg && eg !== es,
                    eT = (0, p.useCallback)(function() {
                        eM ? ek(!0) : ex()
                    }, [ex, eM]),
                    eN = (0, p.useCallback)((0, r._)(function() {
                        return (0, s.__generator)(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    if (ey) return [3, 2];
                                    return ev(null), [4, ej({
                                        userContext: {
                                            aboutUserMessage: null != ec ? ec : "",
                                            aboutModelMessage: null != ef ? ef : "",
                                            enabled: !!eg
                                        }
                                    })];
                                case 1:
                                    e.sent(), e.label = 2;
                                case 2:
                                    return [2]
                            }
                        })
                    }), [ey, ef, ec, eg, ej]),
                    eP = (0, p.useCallback)(function() {
                        if (e_) {
                            var e, t, n = V(null != ec ? ec : ""),
                                r = V(null != ef ? ef : "");
                            n && w.m.logEvent("chatgpt_user_context_modal__message_past_limit", void 0, {
                                type: "about_user_message",
                                limit: W.toString(),
                                character_length: null !== (e = null == ec ? void 0 : ec.length.toString()) && void 0 !== e ? e : ""
                            }), r && w.m.logEvent("chatgpt_user_context_modal__message_past_limit", void 0, {
                                type: "about_model_message",
                                limit: W.toString(),
                                character_length: null !== (t = null == ef ? void 0 : ef.length.toString()) && void 0 !== t ? t : ""
                            }), I.m.danger(A.formatMessage(L.messageLimitError, {
                                limit: W
                            }), {
                                duration: 4,
                                hasCloseButton: !0
                            });
                            return
                        }
                        eN()
                    }, [A, e_, ef, ec, eN]);
                if (K && z && !$) return (0, l.jsx)(B, {
                    onClose: function() {
                        Y(!0)
                    }
                });
                if (K && eC) {
                    var eS = function() {
                        ek(!1)
                    };
                    return (0, l.jsx)(T.Z, {
                        isOpen: !0,
                        onClose: eS,
                        type: "success",
                        title: A.formatMessage(L.confirmCloseTitle),
                        primaryButton: (0, l.jsx)(M.ZP.Button, {
                            title: A.formatMessage(L.confirmCloseOk),
                            color: "danger",
                            onClick: function() {
                                ex(), eS()
                            }
                        }),
                        secondaryButton: (0, l.jsx)(M.ZP.Button, {
                            title: A.formatMessage(L.confirmCloseCancel),
                            color: "neutral",
                            onClick: eS
                        }),
                        children: (0, l.jsx)("div", {
                            className: "text-sm",
                            children: (0, l.jsx)(y.Z, (0, a._)({}, L.confirmCloseBody))
                        })
                    }, "confirm-close")
                }
                return (0, l.jsxs)(T.Z, {
                    isOpen: K,
                    onClose: eT,
                    type: "success",
                    size: "custom",
                    className: "max-w-lg xl:max-w-xl",
                    title: (0, l.jsxs)("div", {
                        className: "flex flex-row gap-2",
                        children: [(0, l.jsx)(y.Z, (0, a._)({}, L.profileTitle)), (0, l.jsx)(N.u, {
                            sideOffset: 4,
                            interactive: !0,
                            delayDuration: 0,
                            label: (0, l.jsx)("div", {
                                children: (0, l.jsx)(y.Z, (0, i._)((0, a._)({}, L.profileSubhead), {
                                    values: {
                                        article: function(e) {
                                            return (0, l.jsx)("a", {
                                                href: U,
                                                target: "_blank",
                                                className: "underline",
                                                rel: "noreferrer",
                                                children: e
                                            })
                                        }
                                    }
                                }))
                            }),
                            side: "bottom",
                            children: (0, l.jsx)(P.HV, {
                                className: "h-6 w-6 flex-shrink-0 text-gray-500"
                            })
                        })]
                    }),
                    children: [J || ee ? (0, l.jsx)("div", {
                        className: "flex h-14 items-center justify-center",
                        children: (0, l.jsx)(S.Z, {})
                    }) : (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("p", {
                            className: "text-muted pb-3 pt-2 text-sm text-gray-600",
                            children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutYouHelpText))
                        }), (0, l.jsx)(Q, {
                            className: "mb-3",
                            onSubmit: eP,
                            disabled: !eh,
                            tip: (0, l.jsx)(H, {
                                children: (0, l.jsxs)("ul", {
                                    className: "list-disc pl-5",
                                    children: [(0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutUserTip1))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutUserTip2))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutUserTip3))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutUserTip4))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.aboutUserTip5))
                                    })]
                                })
                            }),
                            hasModError: "about_user_message" === ep,
                            value: null != ec ? ec : ea,
                            onChange: function(e) {
                                return ed(function(t) {
                                    return {
                                        aboutModelMessage: null !== (v = t.aboutModelMessage) && void 0 !== v ? v : eo,
                                        aboutUserMessage: e.target.value,
                                        enabled: null !== (x = t.enabled) && void 0 !== x ? x : eh
                                    }
                                })
                            }
                        }), (0, l.jsx)("p", {
                            className: "text-muted py-3 text-sm text-gray-600",
                            children: (0, l.jsx)(y.Z, (0, a._)({}, L.modelHelpText))
                        }), (0, l.jsx)(Q, {
                            onSubmit: eP,
                            disabled: !eh,
                            tip: (0, l.jsx)(H, {
                                children: (0, l.jsxs)("ul", {
                                    className: "list-disc pl-5",
                                    children: [(0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.modelTip1))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.modelTip2))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.modelTip3))
                                    }), (0, l.jsx)("li", {
                                        children: (0, l.jsx)(y.Z, (0, a._)({}, L.modelTip4))
                                    })]
                                })
                            }),
                            hasModError: "about_model_message" === ep,
                            value: null != ef ? ef : eo,
                            onChange: function(e) {
                                return ed(function(t) {
                                    return {
                                        aboutUserMessage: null !== (_ = t.aboutUserMessage) && void 0 !== _ ? _ : ea,
                                        aboutModelMessage: e.target.value,
                                        enabled: null !== (D = t.enabled) && void 0 !== D ? D : eh
                                    }
                                })
                            }
                        })]
                    }), (0, l.jsx)("div", {
                        className: "mt-5 sm:mt-4",
                        children: (0, l.jsxs)("div", {
                            className: "flex flex-grow flex-col items-stretch justify-between gap-0 sm:flex-row sm:items-center sm:gap-3",
                            children: [(0, l.jsxs)("label", {
                                className: "mt-5 flex cursor-pointer flex-row justify-between gap-2 sm:mt-4",
                                children: [(0, l.jsx)("div", {
                                    className: "self-center text-sm text-gray-600",
                                    children: eh ? (0, l.jsx)(y.Z, (0, a._)({}, L.chatPreferencesIsEnabled)) : (0, l.jsx)(y.Z, (0, a._)({}, L.chatPreferencesIsDisabled))
                                }), (0, l.jsx)(Z.Z, {
                                    enabled: eh,
                                    onChange: function(e) {
                                        var t, n;
                                        ed(function(r) {
                                            return {
                                                aboutUserMessage: null !== (t = r.aboutUserMessage) && void 0 !== t ? t : ea,
                                                aboutModelMessage: null !== (n = r.aboutModelMessage) && void 0 !== n ? n : eo,
                                                enabled: e
                                            }
                                        })
                                    },
                                    label: eh ? A.formatMessage(L.disableToggleLabel) : A.formatMessage(L.enableToggleLabel)
                                })]
                            }), (0, l.jsx)(M.ZP.Actions, {
                                secondaryButton: (0, l.jsx)(M.ZP.Button, {
                                    onClick: eT,
                                    children: (0, l.jsx)(y.Z, (0, a._)({}, L.cancel))
                                }),
                                primaryButton: (0, l.jsx)(M.ZP.Button, {
                                    loading: ey,
                                    onClick: eP,
                                    color: "primary",
                                    visuallyDisabled: e_,
                                    disabled: !eM,
                                    children: (0, l.jsx)(y.Z, (0, a._)({}, L.save))
                                })
                            })]
                        })
                    })]
                }, "user-context")
            }
            var H = function(e) {
                    var t = e.children;
                    return (0, l.jsx)("div", {
                        className: "whitespace-pre-line",
                        children: t
                    })
                },
                W = 1500,
                V = function(e) {
                    return e.length > W
                },
                Q = function(e) {
                    var t = e.disabled,
                        n = e.onChange,
                        r = e.onSubmit,
                        s = e.placeholder,
                        d = e.value,
                        c = e.tip,
                        f = e.hasModError,
                        x = e.className,
                        j = (0, b.Z)(),
                        w = (0, p.useRef)(null),
                        C = (0, _.x_)(),
                        k = (0, _.aj)(),
                        N = !C,
                        S = (0, o._)((0, p.useState)(!1), 2),
                        I = S[0],
                        Z = S[1],
                        F = (0, o._)((0, p.useState)(N), 2),
                        D = F[0],
                        E = F[1],
                        R = V(d);
                    return (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)(T.Z, {
                            isOpen: N && !D,
                            type: "success",
                            size: "custom",
                            className: "max-w-lg",
                            title: j.formatMessage(L.tipsHeader),
                            closeButton: (0, l.jsx)(M.ZP.CloseButton, {
                                onClose: function() {
                                    E(!0)
                                }
                            }),
                            onClose: function() {
                                E(!0)
                            },
                            children: c
                        }), (0, l.jsxs)(u.fC, {
                            open: !N && I && !D,
                            children: [(0, l.jsxs)("div", {
                                className: x,
                                children: [(0, l.jsx)(u.xz, {
                                    asChild: !0,
                                    children: (0, l.jsx)("textarea", {
                                        ref: w,
                                        className: (0, g.Z)("w-full	resize-none rounded p-4 placeholder:text-gray-300 dark:bg-gray-800", {
                                            "border-orange-400 focus:border-orange-400": f,
                                            "border-red-500 focus:border-red-500": R && !f,
                                            "border-gray-100 focus:border-brand-green": !R && !f,
                                            "bg-gray-50 text-gray-300": t
                                        }),
                                        disabled: t,
                                        placeholder: s,
                                        onKeyDown: function(e) {
                                            t || "Enter" !== e.key || !e.metaKey || e.shiftKey || e.nativeEvent.isComposing || (e.preventDefault(), r())
                                        },
                                        rows: C && !k ? 8 : 7,
                                        value: d,
                                        onChange: n,
                                        onBlur: function() {
                                            Z(!1)
                                        },
                                        onFocus: function() {
                                            Z(!0)
                                        }
                                    })
                                }), (0, l.jsx)("div", {
                                    className: (0, g.Z)("flex items-center justify-between px-1 text-xs", R ? "text-red-600" : "text-gray-400"),
                                    children: f ? (0, l.jsx)("div", {
                                        className: "visible mt-2 text-left text-xs text-orange-400 ",
                                        children: (0, l.jsx)(y.Z, (0, i._)((0, a._)({}, L.modApiVoilation), {
                                            values: {
                                                policyLink: function(e) {
                                                    return (0, l.jsx)("a", {
                                                        href: "https://platform.openai.com/docs/usage-policies/content-policy",
                                                        className: "underline",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: e
                                                    })
                                                },
                                                feedbackLink: function(e) {
                                                    return (0, l.jsx)("a", {
                                                        href: "https://forms.gle/3gyAMj5r5rTEcgbs5",
                                                        className: "underline",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: e
                                                    })
                                                }
                                            }
                                        }))
                                    }) : (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsxs)("div", {
                                            children: [d.length, "/", W]
                                        }), (0, l.jsx)("button", {
                                            className: (0, g.Z)("flex items-center gap-1", I ? "text-gray-400" : "text-gray-200"),
                                            onClick: function() {
                                                var e;
                                                null === (e = w.current) || void 0 === e || e.focus(), E(!D)
                                            },
                                            tabIndex: -1,
                                            children: (0, l.jsx)(h.M, {
                                                initial: !1,
                                                children: I && (0, l.jsx)(m.E.div, {
                                                    className: "flex items-center gap-1",
                                                    initial: {
                                                        opacity: 0
                                                    },
                                                    animate: {
                                                        opacity: 1,
                                                        transition: {
                                                            duration: .2,
                                                            ease: "easeIn"
                                                        }
                                                    },
                                                    exit: {
                                                        opacity: 0,
                                                        transition: {
                                                            duration: .2,
                                                            ease: "easeIn"
                                                        }
                                                    },
                                                    children: D ? (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(y.Z, (0, a._)({}, L.showTips)), (0, l.jsx)(P.ZP, {
                                                            size: "xsmall",
                                                            icon: v.rDJ
                                                        })]
                                                    }) : (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(y.Z, (0, a._)({}, L.hideTips)), (0, l.jsx)(P.ZP, {
                                                            size: "xsmall",
                                                            icon: v.rzC
                                                        })]
                                                    })
                                                }, "show-hide")
                                            })
                                        })]
                                    })
                                })]
                            }), (0, l.jsx)(u.h_, {
                                children: (0, l.jsx)(u.VY, {
                                    side: "right",
                                    align: "start",
                                    sideOffset: 12,
                                    className: "relative max-w-[220px] animate-slideLeftAndFade select-none rounded-xl border-gray-100 bg-white p-4 text-sm text-gray-600 shadow-[0px_4px_14px_rgba(0,0,0,0.06)] dark:bg-gray-900 dark:text-white xl:max-w-xs",
                                    onOpenAutoFocus: function(e) {
                                        e.preventDefault()
                                    },
                                    onCloseAutoFocus: function(e) {
                                        e.preventDefault()
                                    },
                                    children: (0, l.jsxs)("div", {
                                        className: "flex flex-col gap-1",
                                        children: [(0, l.jsx)("strong", {
                                            children: (0, l.jsx)(y.Z, (0, a._)({}, L.tipsHeader))
                                        }), c]
                                    })
                                })
                            })]
                        })]
                    })
                }
        },
        92720: function(e, t, n) {
            var r = n(39324),
                a = n(71209),
                i = n(70216),
                o = n(35250),
                s = n(47428),
                l = n(70079),
                u = n(89705),
                d = {
                    Root: s.fC,
                    Trigger: function(e) {
                        return (0, o.jsx)(u.J7, (0, r._)({
                            $as: s.xz
                        }, e))
                    },
                    Portal: s.Uv,
                    Content: function(e) {
                        return (0, o.jsx)(u.ay, (0, r._)({
                            $as: s.VY,
                            sideOffset: 4,
                            align: "start"
                        }, e))
                    },
                    Item: l.forwardRef(function(e, t) {
                        var n = e.children,
                            l = e.onSelect,
                            d = (0, i._)(e, ["children", "onSelect"]);
                        return (0, o.jsx)(u.mS, (0, a._)((0, r._)({
                            $as: s.ck,
                            ref: t,
                            onSelect: l
                        }, d), {
                            children: n
                        }))
                    })
                };
            t.Z = d
        },
        10580: function(e, t, n) {
            var r = n(39324),
                a = n(71209),
                i = n(70216),
                o = n(35250),
                s = n(48349),
                l = n(70079),
                u = n(1454),
                d = n(88327),
                c = n(89705),
                f = {
                    Root: s.fC,
                    Trigger: function(e) {
                        return (0, o.jsx)(c.J7, (0, r._)({
                            $as: s.xz
                        }, e))
                    },
                    Value: s.B4,
                    Icon: function() {
                        return (0, o.jsx)(s.JO, {
                            children: (0, o.jsx)(d.ZP, {
                                icon: u.bTu,
                                size: "small"
                            })
                        })
                    },
                    Portal: s.h_,
                    Content: function(e) {
                        var t = e.children,
                            n = (0, i._)(e, ["children"]);
                        return (0, o.jsxs)(c.ay, (0, a._)((0, r._)({
                            $as: s.VY,
                            side: "bottom",
                            sideOffset: 4,
                            position: "popper"
                        }, n), {
                            children: [(0, o.jsx)(s.u_, {
                                className: "flex h-8 cursor-default items-center justify-center bg-white text-gray-700 dark:bg-gray-900 dark:text-gray-200",
                                children: (0, o.jsx)(d.ZP, {
                                    icon: u.rH8
                                })
                            }), (0, o.jsx)(s.l_, {
                                children: t
                            }), (0, o.jsx)(s.$G, {
                                className: "flex h-8 cursor-default items-center justify-center bg-white text-gray-700 dark:bg-gray-900 dark:text-gray-200",
                                children: (0, o.jsx)(d.ZP, {
                                    icon: u.bTu
                                })
                            })]
                        }))
                    },
                    Item: l.forwardRef(function(e, t) {
                        var n = e.children,
                            l = (0, i._)(e, ["children"]);
                        return (0, o.jsx)(c.mS, (0, a._)((0, r._)({
                            $as: s.ck,
                            ref: t
                        }, l), {
                            children: (0, o.jsx)(s.eT, {
                                children: n
                            })
                        }))
                    })
                };
            t.Z = f
        },
        55629: function(e, t, n) {
            var r = n(39324),
                a = n(71209),
                i = n(22830),
                o = n(35250),
                s = n(19841),
                l = n(70079);
            t.Z = {
                Root: function(e) {
                    var t = e.children,
                        n = e.fixed,
                        r = e.className,
                        a = e.size,
                        u = (0, l.useRef)(null),
                        d = (0, l.useRef)(null),
                        c = (0, i._)((0, l.useState)(!1), 2),
                        f = c[0],
                        g = c[1];
                    return (0, l.useEffect)(function() {
                        var e = u.current,
                            t = d.current;
                        if (e && t) {
                            var n = new ResizeObserver(function() {
                                g(t.scrollHeight > e.clientHeight)
                            });
                            return n.observe(e),
                                function() {
                                    return n.disconnect()
                                }
                        }
                    }, []), (0, o.jsx)("div", {
                        className: (0, s.Z)("overflow-y-auto text-gray-600 dark:text-gray-300", "normal" === (void 0 === a ? "normal" : a) ? "text-base" : "text-sm", f && "pr-1", r),
                        ref: u,
                        children: (0, o.jsx)("table", {
                            className: (0, s.Z)("w-full border-separate border-spacing-0", void 0 !== n && n && "table-fixed"),
                            ref: d,
                            children: t
                        })
                    })
                },
                Header: function(e) {
                    var t = e.children;
                    return (0, o.jsx)("thead", {
                        children: (0, o.jsx)("tr", {
                            children: t
                        })
                    })
                },
                HeaderCell: function(e) {
                    var t = e.textAlign,
                        n = e.children,
                        r = e.className;
                    return (0, o.jsx)("th", {
                        className: (0, s.Z)("sticky top-0 z-10 border-b border-black/10 bg-white py-2 pr-4 font-medium last:pr-0 dark:border-white/10", "left" === (void 0 === t ? "left" : t) ? "text-left" : "text-right", void 0 === r ? "dark:bg-gray-900" : r),
                        children: n
                    })
                },
                Body: function(e) {
                    var t = e.children;
                    return (0, o.jsx)("tbody", {
                        children: t
                    })
                },
                Row: function(e) {
                    var t = e.children,
                        n = e.disabled,
                        i = void 0 !== n && n;
                    return (0, o.jsx)("tr", (0, a._)((0, r._)({}, i ? {
                        "data-disabled": !0
                    } : {}), {
                        className: (0, s.Z)(i ? "pointer-events-none" : ""),
                        children: t
                    }))
                },
                Cell: function(e) {
                    var t = e.textAlign,
                        n = e.children,
                        r = e.className;
                    return (0, o.jsx)("td", {
                        className: (0, s.Z)("border-b border-black/10  pr-4 last:pr-0 dark:border-white/10 [tr:last-child_&]:border-b-0", "left" === (void 0 === t ? "left" : t) ? "text-left" : "text-right", r),
                        children: (0, o.jsx)("div", {
                            className: "py-2 [tr[data-disabled=true]_&]:opacity-50",
                            children: n
                        })
                    })
                },
                Actions: function(e) {
                    var t = e.children;
                    return (0, o.jsx)("div", {
                        className: "text-md flex items-center justify-end gap-2",
                        children: t
                    })
                }
            }
        },
        89705: function(e, t, n) {
            n.d(t, {
                J7: function() {
                    return l
                },
                ay: function() {
                    return d
                },
                mS: function() {
                    return u
                }
            });
            var r = n(4337),
                a = n(21389);

            function i() {
                var e = (0, r._)(["\ntext-gray-700 border border-transparent inline-flex h-9 items-center justify-center gap-4 rounded-md bg-white px-3 text-sm\ndark:text-gray-200 dark:transparent dark:bg-transparent\nleading-none outline-none cursor-pointer\nhover:bg-gray-50 dark:hover:bg-[#494A54]\nfocus-visible:border-blue-500 dark:focus-visible:border-blue-500\nradix-state-active:text-gray-600 dark:radix-state-active::text-gray-400\nradix-disabled:cursor-auto radix-disabled:bg-transparent radix-disabled:text-gray-500 dark:radix-disabled:bg-transparent dark:radix-disabled:text-gray-500\n"]);
                return i = function() {
                    return e
                }, e
            }

            function o() {
                var e = (0, r._)(["\nrelative flex h-8 cursor-pointer select-none items-center rounded-md pl-3 pr-7 text-sm leading-none text-gray-700 hover:bg-gray-50 radix-disabled:pointer-events-none radix-highlighted:bg-gray-50 radix-disabled:text-gray-300 radix-highlighted:outline-none dark:text-gray-200 dark:hover:bg-[#2E2F33] dark:radix-highlighted:bg-[#2E2F33] dark:radix-disabled:text-gray-600 dark:radix-highlighted:hover:bg-[#2E2F33]\n"]);
                return o = function() {
                    return e
                }, e
            }

            function s() {
                var e = (0, r._)(["\nmin-w-[220px] rounded-lg bg-white dark:bg-gray-900 p-[5px] shadow-xs will-change-[opacity,transform] radix-side-bottom:animate-slideUpAndFade radix-side-left:animate-slideRightAndFade radix-side-right:animate-slideLeftAndFade radix-side-top:animate-slideDownAndFade\n"]);
                return s = function() {
                    return e
                }, e
            }
            var l = a.Z.button(i()),
                u = a.Z.div(o()),
                d = a.Z.div(s())
        },
        63031: function(e, t, n) {
            n.d(t, {
                $H: function() {
                    return g
                },
                Iy: function() {
                    return c
                },
                L8: function() {
                    return f
                },
                O6: function() {
                    return m
                },
                VF: function() {
                    return h
                },
                qS: function() {
                    return p
                }
            });
            var r = n(21722),
                a = n(39889),
                i = n(70079),
                o = n(70671),
                s = n(94968),
                l = n(62509),
                u = n(99486),
                d = n(88798);

            function c(e) {
                return e.replace("file-service://", "")
            }

            function f(e) {
                return "file-service://" + e
            }

            function g(e) {
                return e.startsWith("file-service://")
            }

            function h() {
                var e = (0, o.Z)();
                return (0, i.useCallback)(function(t, n) {
                    switch (t) {
                        case "file_too_large":
                            return e.formatMessage(v.fileTooLarge, n);
                        case "over_user_quota":
                            return e.formatMessage(v.overUserQuota, n);
                        case "file_not_found":
                            return e.formatMessage(v.fileNotFound, n);
                        case "file_timed_out":
                            return e.formatMessage(v.fileTimedOut, n);
                        case "ace_pod_expired":
                            return e.formatMessage(v.codeInterpreterSessionTimeout, n);
                        case "default_create_entry_error":
                            return e.formatMessage(v.defaultCreateEntryError, n);
                        case "default_download_link_error":
                            return e.formatMessage(v.defaultDownloadLinkError, n);
                        default:
                            return e.formatMessage(v.unknownError)
                    }
                }, [e])
            }

            function m() {
                var e, t = (0, l.kP)().session,
                    n = (0, o.Z)();
                return e = (0, r._)(function(e, r) {
                        var i, o, s, l, c;
                        return (0, a.__generator)(this, function(a) {
                            switch (a.label) {
                                case 0:
                                    if (null == t) return d.m.danger(n.formatMessage(v.fileDownloadFailed)), [2, !1];
                                    a.label = 1;
                                case 1:
                                    return a.trys.push([1, 4, , 5]), [4, u.ZP.getFileDownloadLink(e, t.accessToken)];
                                case 2:
                                    if (!(i = a.sent()).download_url) throw Error("File is not ready to download: " + JSON.stringify(i));
                                    return [4, fetch(i.download_url).then(function(e) {
                                        return e.blob()
                                    })];
                                case 3:
                                    return o = a.sent(), s = URL.createObjectURL(o), (l = window.open(s, "_blank")) && l.addEventListener("beforeunload", function() {
                                        URL.revokeObjectURL(s)
                                    }), (c = document.createElement("a")).href = s, c.download = r, c.style.display = "none", c.click(), URL.revokeObjectURL(s), [3, 5];
                                case 4:
                                    return a.sent(), d.m.danger(n.formatMessage(v.fileDownloadFailed)), [2, !1];
                                case 5:
                                    return [2, !0]
                            }
                        })
                    }),
                    function(t, n) {
                        return e.apply(this, arguments)
                    }
            }

            function p() {
                var e, t = (0, l.kP)().session,
                    n = m();
                return e = (0, r._)(function(e, r) {
                        var i;
                        return (0, a.__generator)(this, function(a) {
                            switch (a.label) {
                                case 0:
                                    if (null == t) return [2];
                                    i = 0, a.label = 1;
                                case 1:
                                    if (!(i < e.length)) return [3, 4];
                                    return [4, Promise.all(e.slice(i, i + r).map(function(e) {
                                        return n(e.id, e.name)
                                    }))];
                                case 2:
                                    a.sent(), a.label = 3;
                                case 3:
                                    return i += r, [3, 1];
                                case 4:
                                    return [2]
                            }
                        })
                    }),
                    function(t, n) {
                        return e.apply(this, arguments)
                    }
            }
            var v = (0, s.vU)({
                defaultCreateEntryError: {
                    id: "fileUpload.defaultCreateEntryError",
                    defaultMessage: "Unable to upload file",
                    description: "Error message when file upload fails"
                },
                defaultDownloadLinkError: {
                    id: "fileUpload.defaultDownloadLinkError",
                    defaultMessage: "Failed to get upload status for {fileName}",
                    description: "Error message when file download link fails"
                },
                unknownError: {
                    id: "fileUpload.unknownError",
                    defaultMessage: "Unknown error occurred",
                    description: "Error message when file upload fails"
                },
                fileTooLarge: {
                    id: "fileUpload.fileTooLarge",
                    defaultMessage: "File is too large",
                    description: "Error message when file is too large to upload"
                },
                overUserQuota: {
                    id: "fileUpload.overUserQuota",
                    defaultMessage: "User quota exceeded",
                    description: "Error message when user storage space (quote) has been exceeded"
                },
                fileNotFound: {
                    id: "fileUpload.fileNotFound",
                    defaultMessage: "File not found",
                    description: "Error message when file was not found"
                },
                fileTimedOut: {
                    id: "fileUpload.fileTimedOut",
                    defaultMessage: "File upload timed out. Please try again.",
                    description: "Error message when file upload timed out"
                },
                codeInterpreterSessionTimeout: {
                    id: "fileUpload.codeInterpreterSessionTimeout",
                    defaultMessage: "Code interpreter session expired",
                    description: "Error message when code interpreter session expired"
                },
                fileDownloadFailed: {
                    id: "filesModal.fileDownloadFailed",
                    defaultMessage: "File download failed. Please try again.",
                    description: "Error message when file download fails"
                }
            })
        },
        67576: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return eu
                }
            });
            var r = n(39324),
                a = n(71209),
                i = n(70216),
                o = n(35250),
                s = n(31636),
                l = n(19841),
                u = n(77997),
                d = n(70079),
                c = n(47567),
                f = n(54118),
                g = n(32542),
                h = n(96237),
                m = n(61110),
                p = n(55975),
                v = n(46050),
                x = n(29874),
                b = n(8449),
                y = n(15472),
                j = {
                    tokenize: function(e, t, n) {
                        var r = function(t) {
                                return t === p.q.eof || (0, x.Ch)(t) ? a(t) : (e.enter("mathFlowFenceMeta"), e.enter(y.V.chunkString, {
                                    contentType: b._.contentTypeString
                                }), function t(r) {
                                    return r === p.q.eof || (0, x.Ch)(r) ? (e.exit(y.V.chunkString), e.exit("mathFlowFenceMeta"), a(r)) : r === p.q.rightSquareBracket ? n(r) : (e.consume(r), t)
                                }(t))
                            },
                            a = function(n) {
                                return e.exit("mathFlowFence"), s.interrupt ? t(n) : function t(n) {
                                    return n === p.q.eof ? i(n) : (0, x.Ch)(n) ? e.attempt(w, e.attempt({
                                        tokenize: o,
                                        partial: !0
                                    }, i, u ? (0, v.f)(e, t, y.V.linePrefix, u + 1) : t), i)(n) : (e.enter("mathFlowValue"), function n(r) {
                                        return r === p.q.eof || (0, x.Ch)(r) ? (e.exit("mathFlowValue"), t(r)) : (e.consume(r), n)
                                    }(n))
                                }(n)
                            },
                            i = function(n) {
                                return e.exit("mathFlow"), t(n)
                            },
                            o = function(e, t, n) {
                                var r = [];
                                return (0, v.f)(e, function(t) {
                                    return e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"),
                                        function t(i) {
                                            return i === p.q.backslash && 0 === r.length || i === p.q.rightSquareBracket && r[0] === p.q.backslash ? (e.consume(i), r.push(i), t) : r < d ? n(i) : (e.exit("mathFlowFenceSequence"), (0, v.f)(e, a, y.V.whitespace)(i))
                                        }(t)
                                }, y.V.linePrefix, b._.tabSize);

                                function a(r) {
                                    return r === p.q.eof || (0, x.Ch)(r) ? (e.exit("mathFlowFence"), t(r)) : n(r)
                                }
                            },
                            s = this,
                            l = this.events[this.events.length - 1],
                            u = l && l[1].type === y.V.linePrefix ? l[2].sliceSerialize(l[1], !0).length : 0,
                            d = [];
                        return function(t) {
                            return p.q.backslash, e.enter("mathFlow"), e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"),
                                function t(a) {
                                    return a === p.q.backslash || a === p.q.leftSquareBracket && d[0] === p.q.backslash ? (e.consume(a), d.push(a), t) : (e.exit("mathFlowFenceSequence"), d.length < 2 ? n(a) : (0, v.f)(e, r, y.V.whitespace)(a))
                                }(t)
                        }
                    },
                    concrete: !0
                },
                w = {
                    tokenize: function(e, t, n) {
                        var r = function(e) {
                                return a.parser.lazy[a.now().line] ? n(e) : t(e)
                            },
                            a = this;
                        return function(t) {
                            return e.enter(y.V.lineEnding), e.consume(t), e.exit(y.V.lineEnding), r
                        }
                    },
                    partial: !0
                },
                C = {
                    tokenize: function(e, t, n) {
                        var r = function(t) {
                                return t === p.q.eof || (0, x.Ch)(t) ? a(t) : (e.enter("mathFlowFenceMeta"), e.enter(y.V.chunkString, {
                                    contentType: b._.contentTypeString
                                }), function t(r) {
                                    return r === p.q.eof || (0, x.Ch)(r) ? (e.exit(y.V.chunkString), e.exit("mathFlowFenceMeta"), a(r)) : r === p.q.dollarSign ? n(r) : (e.consume(r), t)
                                }(t))
                            },
                            a = function(n) {
                                return e.exit("mathFlowFence"), s.interrupt ? t(n) : function t(n) {
                                    return n === p.q.eof ? i(n) : (0, x.Ch)(n) ? e.attempt(k, e.attempt({
                                        tokenize: o,
                                        partial: !0
                                    }, i, u ? (0, v.f)(e, t, y.V.linePrefix, u + 1) : t), i)(n) : (e.enter("mathFlowValue"), function n(r) {
                                        return r === p.q.eof || (0, x.Ch)(r) ? (e.exit("mathFlowValue"), t(r)) : (e.consume(r), n)
                                    }(n))
                                }(n)
                            },
                            i = function(n) {
                                return e.exit("mathFlow"), t(n)
                            },
                            o = function(e, t, n) {
                                var r = 0;
                                return (0, v.f)(e, function(t) {
                                    return e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"),
                                        function t(i) {
                                            return i === p.q.dollarSign ? (e.consume(i), r++, t) : r < d ? n(i) : (e.exit("mathFlowFenceSequence"), (0, v.f)(e, a, y.V.whitespace)(i))
                                        }(t)
                                }, y.V.linePrefix, b._.tabSize);

                                function a(r) {
                                    return r === p.q.eof || (0, x.Ch)(r) ? (e.exit("mathFlowFence"), t(r)) : n(r)
                                }
                            },
                            s = this,
                            l = s.events[s.events.length - 1],
                            u = l && l[1].type === y.V.linePrefix ? l[2].sliceSerialize(l[1], !0).length : 0,
                            d = 0;
                        return function(t) {
                            return p.q.dollarSign, e.enter("mathFlow"), e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"),
                                function t(a) {
                                    return a === p.q.dollarSign ? (e.consume(a), d++, t) : (e.exit("mathFlowFenceSequence"), d < 2 ? n(a) : (0, v.f)(e, r, y.V.whitespace)(a))
                                }(t)
                        }
                    },
                    concrete: !0
                },
                k = {
                    tokenize: function(e, t, n) {
                        var r = function(e) {
                                return a.parser.lazy[a.now().line] ? n(e) : t(e)
                            },
                            a = this;
                        return function(t) {
                            return (0, x.Ch)(t), e.enter(y.V.lineEnding), e.consume(t), e.exit(y.V.lineEnding), r
                        }
                    },
                    partial: !0
                };

            function _(e) {
                var t, n, r = e.length - 4,
                    a = 3;
                if ((e[3][1].type === y.V.lineEnding || "space" === e[a][1].type) && (e[r][1].type === y.V.lineEnding || "space" === e[r][1].type)) {
                    for (t = a; ++t < r;)
                        if ("mathTextData" === e[t][1].type) {
                            e[r][1].type = "mathTextPadding", e[a][1].type = "mathTextPadding", a += 2, r -= 2;
                            break
                        }
                }
                for (t = a - 1, r++; ++t <= r;) void 0 === n ? t !== r && e[t][1].type !== y.V.lineEnding && (n = t) : (t === r || e[t][1].type === y.V.lineEnding) && (e[n][1].type = "mathTextData", t !== n + 2 && (e[n][1].end = e[t - 1][1].end, e.splice(n + 2, t - n - 2), r -= t - n - 2, t = n + 2), n = void 0);
                return e
            }

            function M(e) {
                return e !== p.q.backslash || this.events[this.events.length - 1][1].type === y.V.characterEscape
            }

            function T(e) {
                var t, n, r = e.length - 4,
                    a = 3;
                if ((e[3][1].type === y.V.lineEnding || "space" === e[a][1].type) && (e[r][1].type === y.V.lineEnding || "space" === e[r][1].type)) {
                    for (t = a; ++t < r;)
                        if ("mathTextData" === e[t][1].type) {
                            e[r][1].type = "mathTextPadding", e[a][1].type = "mathTextPadding", a += 2, r -= 2;
                            break
                        }
                }
                for (t = a - 1, r++; ++t <= r;) void 0 === n ? t !== r && e[t][1].type !== y.V.lineEnding && (n = t) : (t === r || e[t][1].type === y.V.lineEnding) && (e[n][1].type = "mathTextData", t !== n + 2 && (e[n][1].end = e[t - 1][1].end, e.splice(n + 2, t - n - 2), r -= t - n - 2, t = n + 2), n = void 0);
                return e
            }

            function N(e) {
                return e !== p.q.dollarSign || this.events[this.events.length - 1][1].type === y.V.characterEscape
            }

            function P(e) {
                var t, n, r = e.length - 4,
                    a = 3;
                if ((e[3][1].type === y.V.lineEnding || "space" === e[a][1].type) && (e[r][1].type === y.V.lineEnding || "space" === e[r][1].type)) {
                    for (t = a; ++t < r;)
                        if ("mathTextData" === e[t][1].type) {
                            e[r][1].type = "mathTextPadding", e[a][1].type = "mathTextPadding", a += 2, r -= 2;
                            break
                        }
                }
                for (t = a - 1, r++; ++t <= r;) void 0 === n ? t !== r && e[t][1].type !== y.V.lineEnding && (n = t) : (t === r || e[t][1].type === y.V.lineEnding) && (e[n][1].type = "mathTextData", t !== n + 2 && (e[n][1].end = e[t - 1][1].end, e.splice(n + 2, t - n - 2), r -= t - n - 2, t = n + 2), n = void 0);
                return e
            }

            function S(e) {
                return e !== p.q.backslash || this.events[this.events.length - 1][1].type === y.V.characterEscape
            }
            var I = n(67726),
                Z = n(63395),
                F = n(93362),
                D = n(45369),
                E = n(42426),
                R = n(65028),
                B = n(88366),
                A = n(52738),
                L = n(66570),
                U = n(21722),
                O = n(22830),
                q = n(39889),
                z = n(13995),
                H = n(5268),
                W = n(70671),
                V = n(32004),
                Q = n(94968),
                G = n(99486),
                $ = n(31621),
                Y = n(45635),
                J = n(63031),
                K = n(1821),
                X = n(88798),
                ee = "sandbox:";

            function et(e) {
                var t, n, s, l = e.messageId,
                    u = e.clientThreadId,
                    c = e.href,
                    f = (0, i._)(e, ["messageId", "clientThreadId", "href"]),
                    h = (0, d.useContext)(g.gB),
                    m = (0, z.NL)(),
                    p = (0, O._)((0, d.useState)(!1), 2),
                    v = p[0],
                    x = p[1],
                    b = c.substring(ee.length),
                    y = $.tQ.getServerThreadId(u),
                    j = (0, W.Z)(),
                    w = (0, d.useCallback)(function(e) {
                        var t = document.createElement("a");
                        t.href = e, t.click(), x(!1)
                    }, []),
                    C = (t = (0, d.useCallback)(function(e) {
                        x(!1), X.m.danger(e)
                    }, []), n = (0, J.VF)(), (0, H.a)({
                        queryKey: er(l, b),
                        queryFn: function() {
                            return G.ZP.downloadFromInterpreter(l, y, b).then(function(e) {
                                return (null == e ? void 0 : e.status) === "success" && w(e.download_url), e
                            }).catch(function(e) {
                                var r = n("default_download_link_error", {
                                    fileName: b
                                });
                                throw void 0 !== e.code && (r = n(e.code)), null == t || t(r), e
                            })
                        },
                        enabled: !!(v && !h && l && y && b)
                    })).data,
                    k = (0, d.useCallback)((s = (0, U._)(function(e) {
                        return (0, q.__generator)(this, function(t) {
                            return void 0 !== u && (e.preventDefault(), (void 0 === C || (null == C ? void 0 : C.status) === "error") && m.invalidateQueries({
                                queryKey: er(l, b)
                            }), (null == C ? void 0 : C.status) == "success" && (null == C ? void 0 : C.download_url) ? w(C.download_url) : x(!0)), [2]
                        })
                    }), function(e) {
                        return s.apply(this, arguments)
                    }), [u, C, m, l, b, w]);
                return (0, o.jsx)(Y.u, {
                    closeOnOutsideClick: !1,
                    delayDuration: 0,
                    label: (0, o.jsxs)("span", {
                        className: "flex items-center gap-1",
                        children: [v ? j.formatMessage(ea.startingDownload) : j.formatMessage(ea.downloadFile), v && (0, o.jsx)(K.Z, {})]
                    }),
                    side: "top",
                    sideOffset: 4,
                    children: (0, o.jsx)("a", (0, a._)((0, r._)({}, f), {
                        className: "cursor-pointer",
                        onClick: function(e) {
                            return !v && k(e)
                        }
                    }))
                })
            }

            function en(e) {
                return (0, o.jsx)(Y.u, {
                    closeOnOutsideClick: !1,
                    delayDuration: 0,
                    label: (0, o.jsx)("span", {
                        className: "flex items-center gap-1",
                        children: (0, o.jsx)(V.Z, (0, r._)({}, ea.downloadUnavailable))
                    }),
                    side: "top",
                    sideOffset: 4,
                    children: (0, o.jsx)("span", (0, a._)((0, r._)({}, e), {
                        className: "font-semibold text-gray-500 underline dark:text-gray-300"
                    }))
                })
            }

            function er(e, t) {
                return ["downloadSandboxLink", e, t]
            }
            var ea = (0, Q.vU)({
                    downloadFile: {
                        id: "SandboxDownload.downloadFile",
                        defaultMessage: "Download file",
                        description: "Tooltip label for downloading a file button"
                    },
                    startingDownload: {
                        id: "SandboxDownload.startingDownload",
                        defaultMessage: "Starting download",
                        description: "Tooltip label for downloading started for file button"
                    },
                    downloadUnavailable: {
                        id: "SandboxDownload.downloadUnavailable",
                        defaultMessage: "File download not supported in a shared chat",
                        description: "Tooltip label indicating file is unavailable to download for shared conversations"
                    }
                }),
                ei = function(e) {
                    return e.startsWith(ee) ? e : (0, Z.A)(e)
                },
                eo = [R.Z, [function() {
                    var e, t, n = function(e, t) {
                            (r[e] ? r[e] : r[e] = []).push(t)
                        },
                        r = this.data();
                    n("micromarkExtensions", {
                        flow: (e = {}, (0, h._)(e, p.q.dollarSign, C), (0, h._)(e, p.q.backslash, j), e),
                        text: (t = {}, (0, h._)(t, p.q.dollarSign, {
                            tokenize: function(e, t, n) {
                                var r, a, i = 0;
                                return function(t) {
                                    return e.enter("mathText"), e.enter("mathTextSequence"),
                                        function t(r) {
                                            return r === p.q.dollarSign ? (e.consume(r), i++, t) : i < 2 ? n(r) : (e.exit("mathTextSequence"), o(r))
                                        }(t)
                                };

                                function o(l) {
                                    return l === p.q.eof ? n(l) : l === p.q.dollarSign ? (a = e.enter("mathTextSequence"), r = 0, function n(o) {
                                        return o === p.q.dollarSign ? (e.consume(o), r++, n) : r === i ? (e.exit("mathTextSequence"), e.exit("mathText"), t(o)) : (a.type = "mathTextData", s(o))
                                    }(l)) : l === p.q.space ? (e.enter("space"), e.consume(l), e.exit("space"), o) : (0, x.Ch)(l) ? (e.enter(y.V.lineEnding), e.consume(l), e.exit(y.V.lineEnding), o) : (e.enter("mathTextData"), s(l))
                                }

                                function s(t) {
                                    return t === p.q.eof || t === p.q.space || t === p.q.dollarSign || (0, x.Ch)(t) ? (e.exit("mathTextData"), o(t)) : (e.consume(t), s)
                                }
                            },
                            resolve: T,
                            previous: N
                        }), (0, h._)(t, p.q.backslash, [{
                            tokenize: function(e, t, n) {
                                var r, a = [],
                                    i = [],
                                    o = this;
                                return function(t) {
                                    return p.q.backslash, M.call(o, o.previous) && o.previous, e.enter("mathText"), e.enter("mathTextSequence"),
                                        function t(r) {
                                            return (a.join(","), r === p.q.backslash && 0 === a.length || r === p.q.leftParenthesis && 1 === a.length) ? (e.consume(r), a.push(r), t) : a.length < 2 ? n(r) : (e.exit("mathTextSequence"), s(r))
                                        }(t)
                                };

                                function s(o) {
                                    return o === p.q.eof ? n(o) : o === p.q.backslash ? (r = e.enter("mathTextSequence"), i = [], function n(o) {
                                        return (a.join(","), o === p.q.backslash && 0 === i.length || o === p.q.rightParenthesis && 1 === i.length) ? (e.consume(o), i.push(o), n) : i.length === a.length ? (e.exit("mathTextSequence"), e.exit("mathText"), t(o)) : (r.type = "mathTextData", l(o))
                                    }(o)) : o === p.q.space ? (e.enter("space"), e.consume(o), e.exit("space"), s) : (0, x.Ch)(o) ? (e.enter(y.V.lineEnding), e.consume(o), e.exit(y.V.lineEnding), s) : (e.enter("mathTextData"), l(o))
                                }

                                function l(t) {
                                    return t === p.q.eof || t === p.q.space || t === p.q.backslash || (0, x.Ch)(t) ? (e.exit("mathTextData"), s(t)) : (e.consume(t), l)
                                }
                            },
                            resolve: _,
                            previous: M
                        }, {
                            tokenize: function(e, t, n) {
                                var r, a = [],
                                    i = [],
                                    o = this;
                                return function(t) {
                                    return p.q.backslash, S.call(o, o.previous) && o.previous, e.enter("mathText"), e.enter("mathTextSequence"),
                                        function t(r) {
                                            return (a.join(","), r === p.q.backslash && 0 === a.length || r === p.q.leftSquareBracket && 1 === a.length) ? (e.consume(r), a.push(r), t) : a.length < 2 ? n(r) : (e.exit("mathTextSequence"), s(r))
                                        }(t)
                                };

                                function s(o) {
                                    return o === p.q.eof ? n(o) : o === p.q.backslash ? (r = e.enter("mathTextSequence"), i = [], function n(o) {
                                        return (a.join(","), o === p.q.backslash && 0 === i.length || o === p.q.rightSquareBracket && 1 === i.length) ? (e.consume(o), i.push(o), n) : i.length === a.length ? (e.exit("mathTextSequence"), e.exit("mathText"), t(o)) : (r.type = "mathTextData", l(o))
                                    }(o)) : o === p.q.space ? (e.enter("space"), e.consume(o), e.exit("space"), s) : (0, x.Ch)(o) ? (e.enter(y.V.lineEnding), e.consume(o), e.exit(y.V.lineEnding), s) : (e.enter("mathTextData"), l(o))
                                }

                                function l(t) {
                                    return t === p.q.eof || t === p.q.space || t === p.q.backslash || (0, x.Ch)(t) ? (e.exit("mathTextData"), s(t)) : (e.consume(t), l)
                                }
                            },
                            resolve: P,
                            previous: S
                        }]), t)
                    }), n("fromMarkdownExtensions", (0, m.N)()), n("toMarkdownExtensions", (0, m.O)())
                }, {
                    singleDollarTextMath: !1
                }]],
                es = [
                    [F.Z, {
                        languages: {
                            mathematica: I.Z
                        },
                        detect: !0,
                        subset: ["arduino", "bash", "c", "cpp", "csharp", "css", "diff", "go", "graphql", "java", "javascript", "json", "kotlin", "latex", "less", "lua", "makefile", "makefile", "markdown", "matlab", "mathematica", "nginx", "objectivec", "perl", "pgsql", "php-template", "php", "plaintext", "python-repl", "python", "r", "ruby", "rust", "scss", "shell", "sql", "swift", "typescript", "vbnet", "wasm", "xml", "yaml"],
                        ignoreMissing: !0,
                        aliases: {
                            mathematica: "wolfram"
                        }
                    }], D.Z, [E.Z, {
                        newlines: !0
                    }]
                ],
                el = {
                    code: function(e) {
                        var t = e.inline,
                            n = e.node,
                            s = e.className,
                            l = e.children,
                            u = (0, i._)(e, ["inline", "node", "className", "children"]);
                        if (t) {
                            var d = (0, B.B)(n),
                                c = (0, A.T$)(d);
                            return c ? (0, o.jsx)(A.s8, {
                                displayInfo: c
                            }) : (0, o.jsx)("code", (0, a._)((0, r._)({
                                className: s
                            }, u), {
                                children: l
                            }))
                        }
                        var f, g = null === (f = null == s ? void 0 : s.split(" ").filter(function(e) {
                                return e.startsWith("language-")
                            })) || void 0 === f ? void 0 : f[0],
                            h = g ? g.split("-")[1] : "";
                        return (0, o.jsx)(L.Z, {
                            language: h,
                            className: s,
                            content: (0, B.B)(n),
                            children: l
                        })
                    }
                };

            function eu(e) {
                var t = e.size,
                    n = e.children,
                    h = e.className,
                    m = e.clientThreadId,
                    p = e.messageId,
                    v = (0, u.F)().theme,
                    x = (0, f.Fl)().isCodeInterpreterAvailable,
                    b = (0, d.useContext)(g.gB),
                    y = (0, d.useMemo)(function() {
                        return (0, a._)((0, r._)({}, el), {
                            a: function(e) {
                                var t = e.node,
                                    n = (0, i._)(e, ["node"]);
                                return t.properties.href.startsWith(ee) ? b ? (0, o.jsx)(en, (0, r._)({}, n)) : x ? (0, o.jsx)(et, (0, r._)({
                                    clientThreadId: m,
                                    messageId: p
                                }, n)) : null : (0, o.jsx)("a", (0, r._)({}, n))
                            },
                            img: function(e) {
                                var t = e.node,
                                    n = (0, i._)(e, ["node"]),
                                    a = t.properties.src;
                                return a.startsWith(ee) || a.startsWith("attachment:") ? null : (0, o.jsx)("img", (0, r._)({}, n))
                            }
                        })
                    }, [m, x, b, p]);
                return (0, o.jsx)(s.SV, {
                    fallback: function() {
                        return (0, o.jsx)(o.Fragment, {
                            children: n
                        })
                    },
                    children: (0, o.jsx)(c.D, {
                        rehypePlugins: es,
                        remarkPlugins: eo,
                        linkTarget: "_new",
                        className: (0, l.Z)(h, "markdown prose w-full break-words dark:prose-invert", "dark" === v ? "dark" : "light", "small" === (void 0 === t ? "medium" : t) && "prose-xs"),
                        transformLinkUri: ei,
                        components: y,
                        children: n
                    })
                })
            }
        },
        31541: function(e, t, n) {
            n.d(t, {
                Cf: function() {
                    return eM
                },
                ZP: function() {
                    return e_
                },
                xz: function() {
                    return eT
                }
            });
            var r, a = n(39324),
                i = n(70216),
                o = n(4337),
                s = n(35250),
                l = n(19841),
                u = n(60554),
                d = n(70079),
                c = n(21389),
                f = n(16600),
                g = n(32877),
                h = n(31621),
                m = n(78931),
                p = n(52738),
                v = n(68993),
                x = n(52787),
                b = n(67273),
                y = n(78018),
                j = n(67576),
                w = n(22830),
                C = n(2827),
                k = n(50795),
                _ = n(82081),
                M = n(95954);

            function T() {
                var e = (0, o._)(["text-center mt-2 flex justify-center"]);
                return T = function() {
                    return e
                }, e
            }

            function N() {
                var e = (0, o._)(["flex gap-2 flex-wrap mt-2"]);
                return N = function() {
                    return e
                }, e
            }
            var P = c.Z.div(T());

            function S(e) {
                var t = e.initialText,
                    n = e.role,
                    r = e.clientThreadId,
                    a = e.currentLeaf,
                    i = e.onUpdateNode,
                    o = e.onChangeItemInView,
                    l = e.onExitEdit,
                    u = e.onDeleteNode,
                    c = e.onRequestCompletion,
                    f = e.onCreateEditNode,
                    g = e.disabled,
                    m = e.attachments,
                    p = (0, d.useId)(),
                    v = "".concat(a, "-").concat(p),
                    x = (0, w._)((0, d.useState)(null != t ? t : ""), 2),
                    j = x[0],
                    T = x[1],
                    N = (0, d.useRef)(null);
                (0, d.useEffect)(function() {
                    f(a, v, null != t ? t : "", m ? {
                        attachments: m
                    } : void 0)
                }, []);
                var S = (0, d.useCallback)(function(e) {
                        T(e.currentTarget.value)
                    }, []),
                    Z = (0, d.useCallback)(function() {
                        i(v, j), o(v), c(M.Os.Next, v, {
                            eventSource: "mouse"
                        }, !0), l(), k.o.logEvent(_.a.changeNode, {
                            intent: "edit_save"
                        })
                    }, [i, v, j, o, c, l]),
                    F = (0, d.useCallback)(function() {
                        u(v), o(a), k.o.logEvent(_.a.changeNode, {
                            intent: "edit_cancel"
                        }), l();
                        var e = n === M.uU.User ? _.a.cancelEditPrompt : _.a.cancelEditCompletion;
                        k.o.logEvent(e, {
                            threadId: h.tQ.getServerThreadId(r)
                        })
                    }, [v, a, o, u, l, n, r]);
                (0, d.useEffect)(function() {
                    var e = N.current,
                        t = function(e) {
                            "Enter" === e.key && e.metaKey ? Z() : "Escape" === e.key && F()
                        };
                    return e && e.addEventListener("keydown", t),
                        function() {
                            e && e.removeEventListener("keydown", t)
                        }
                }, [F, Z]);
                var D = m && m.length > 0;
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)(C.ZP, {
                        ref: N,
                        value: j,
                        onChange: S,
                        className: "m-0 resize-none border-0 bg-transparent p-0 focus:ring-0 focus-visible:ring-0"
                    }), D && (0, s.jsx)(I, {
                        children: m.map(function(e) {
                            return (0, s.jsx)(y.Z, {
                                file: e.name
                            }, e.id)
                        })
                    }), (0, s.jsxs)(P, {
                        children: [(0, s.jsx)(b.z, {
                            as: "button",
                            onClick: Z,
                            className: "mr-2",
                            disabled: g,
                            children: "Save & Submit"
                        }), (0, s.jsx)(b.z, {
                            as: "button",
                            color: "neutral",
                            onClick: F,
                            children: "Cancel"
                        })]
                    })]
                })
            }
            var I = c.Z.div(N()),
                Z = n(21722),
                F = n(39889),
                D = n(30644),
                E = n(47635),
                R = n(62509),
                B = n(99486),
                A = n(91809),
                L = n(1568);

            function U() {
                var e = (0, o._)(["text-xs text-black\n", ""]);
                return U = function() {
                    return e
                }, e
            }

            function O() {
                var e = (0, o._)(["relative w-full overflow-hidden pt-[67%]"]);
                return O = function() {
                    return e
                }, e
            }

            function q(e) {
                var t, n = e.title,
                    r = e.url,
                    a = e.imageUrl,
                    i = e.logoUrl,
                    o = e.className,
                    u = e.mini,
                    c = !!a,
                    f = (0, d.useCallback)(function() {
                        k.o.logEvent(_.a.carouselCardClick, {
                            content: r
                        })
                    }, [r]);
                try {
                    t = E.get(new URL(r).hostname)
                } catch (e) {
                    return console.error("Invalid card url: ", e), null
                }
                return (0, s.jsxs)(r ? "a" : "div", {
                    className: (0, l.Z)("flex h-full w-full flex-col overflow-hidden rounded-md border border-black/10 bg-gray-50 shadow-[0_2px_24px_rgba(0,0,0,0.05)]", o),
                    href: r,
                    target: r ? "_blank" : "",
                    onClick: f,
                    children: [c && (0, s.jsx)(H, {
                        children: (0, s.jsx)("div", {
                            className: "absolute inset-0",
                            children: (0, s.jsx)("img", {
                                src: a,
                                alt: "image of ".concat(n),
                                className: "h-full w-full border-b border-black/10 object-cover"
                            })
                        })
                    }), (0, s.jsxs)("div", {
                        className: "flex flex-1 flex-col justify-between gap-1.5 p-3",
                        children: [(0, s.jsx)(z, {
                            $clamp: void 0 !== u && u || c,
                            children: n
                        }), (0, s.jsxs)("div", {
                            className: "flex items-center gap-1",
                            children: [i ? (0, s.jsx)(A.Z, {
                                url: i,
                                name: t,
                                size: 13
                            }) : (0, s.jsx)(L.Z, {
                                url: r,
                                size: 13
                            }), (0, s.jsx)("div", {
                                className: "text-[10px] leading-3 text-gray-500 line-clamp-1",
                                children: t
                            })]
                        })]
                    })]
                })
            }
            var z = c.Z.div(U(), function(e) {
                    return e.$clamp && "line-clamp-2"
                }),
                H = c.Z.div(O()),
                W = n(96237),
                V = n(33554),
                Q = n(46244),
                G = n(95182),
                $ = n.n(G),
                Y = n(1454),
                J = n(33669),
                K = n(88327);

            function X(e) {
                var t = e.disabled,
                    n = e.onClick,
                    r = e.left,
                    a = e.children;
                return (0, s.jsx)("button", {
                    disabled: t,
                    onClick: n,
                    "aria-disabled": t,
                    className: (0, l.Z)("flex h-6 w-[30px] items-center justify-center rounded-full", "bg-gray-900 text-white shadow-sm hover:bg-gray-700 disabled:hover:bg-gray-900 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200 dark:disabled:hover:bg-white", "transition-opacity disabled:opacity-20", "cursor-pointer disabled:cursor-auto", "absolute top-full translate-y-3 lg:top-1/2 lg:-translate-y-1/2", void 0 !== r && r ? "left-1/2 -translate-x-[calc(100%+4px)] lg:-left-3 lg:-translate-x-full" : "left-1/2 translate-x-1 lg:-right-3 lg:left-auto lg:translate-x-full", t && "lg:hidden"),
                    children: a
                })
            }
            var ee = n(97296),
                et = function(e) {
                    var t = e.x,
                        n = e.children,
                        r = e.className;
                    return (0, s.jsx)(ee.E.div, {
                        className: (0, l.Z)("mr-3 h-full w-full flex-none sm:w-[calc((100%-12px)/2)] lg:w-[calc((100%-24px)/3)]", r),
                        style: {
                            x: t
                        },
                        children: n
                    })
                },
                en = {
                    type: "spring",
                    bounce: 0
                },
                er = (0, d.forwardRef)(function(e, t) {
                    return (0, s.jsx)("div", {
                        ref: t,
                        className: (0, l.Z)("relative flex h-full w-full overflow-hidden", e.className),
                        children: e.children
                    })
                });
            er.displayName = "CarouselContainer";
            var ea = (r = {}, (0, W._)(r, J._G.Mobile, 1), (0, W._)(r, J._G.Small, 2), (0, W._)(r, J._G.Medium, 2), (0, W._)(r, J._G.Large, 3), (0, W._)(r, J._G.XLarge, 3), r);

            function ei(e) {
                var t = e.children,
                    n = e.loop,
                    r = void 0 === n || n,
                    a = e.className,
                    i = (0, V.c)(0),
                    o = (0, d.useRef)(null),
                    u = (0, w._)((0, d.useState)(0), 2),
                    c = u[0],
                    f = u[1],
                    g = ea[(0, J.dQ)()] || 1,
                    h = d.Children.count(t) > g,
                    m = d.Children.toArray(t),
                    p = (0, d.useCallback)(function() {
                        var e, t = null === (e = o.current) || void 0 === e ? void 0 : e.clientWidth;
                        return t ? -Math.floor(c / g) * (t + 12) : 0
                    }, [g, c]),
                    v = (0, d.useCallback)(function(e) {
                        var t = g * e;
                        r ? f(function(e) {
                            return (e + t) % m.length - 1
                        }) : f(function(e) {
                            return $()(e + t, 0, m.length - 1)
                        })
                    }, [m.length, r, g]),
                    x = (0, d.useCallback)(function() {
                        v(1)
                    }, [v]),
                    b = (0, d.useCallback)(function() {
                        v(-1)
                    }, [v]),
                    y = (0, w._)((0, d.useMemo)(function() {
                        if (r) return [!0, !0];
                        var e = c < m.length - g;
                        return [c > 0, e]
                    }, [m.length, c, r, g]), 2),
                    j = y[0],
                    C = y[1];
                return (0, d.useEffect)(function() {
                    return (0, Q.j)(i, p(), en).stop
                }, [p, c, i]), (0, s.jsxs)("div", {
                    className: (0, l.Z)("relative h-full w-full", a, h && "mb-12 lg:mb-0"),
                    children: [(0, s.jsx)(er, {
                        ref: o,
                        children: m.map(function(e, t) {
                            return (0, s.jsx)(et, {
                                x: i,
                                children: e
                            }, t)
                        })
                    }), h && (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(X, {
                            onClick: b,
                            left: !0,
                            disabled: !j,
                            children: (0, s.jsx)(K.ZP, {
                                icon: Y.YFh
                            })
                        }), (0, s.jsx)(X, {
                            onClick: x,
                            disabled: !C,
                            children: (0, s.jsx)(K.ZP, {
                                icon: Y.Tfp
                            })
                        })]
                    })]
                })
            }
            var eo = n(28531),
                es = new Set(["og:site_name", "og:title", "og:description", "og:image", "og:url"]),
                el = {
                    "og:site_name": "metadataTitle",
                    "og:title": "title",
                    "og:description": "description",
                    "og:image": "imageUrl",
                    "og:url": "url"
                },
                eu = /https:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/g,
                ed = d.memo(function(e) {
                    var t, n, r = e.urls,
                        a = (0, eo.v)(),
                        i = (t = (0, R.kP)().session, n = (0, D.h)({
                            queries: r.map(function(e) {
                                return {
                                    queryKey: ["opengraph", e],
                                    queryFn: (0, Z._)(function() {
                                        return (0, F.__generator)(this, function(t) {
                                            switch (t.label) {
                                                case 0:
                                                    return [4, B.ZP.getPageMetadata({
                                                        url: e
                                                    })];
                                                case 1:
                                                    return [2, t.sent()]
                                            }
                                        })
                                    }),
                                    enabled: !!(e && (null == t ? void 0 : t.accessToken)),
                                    retry: !1
                                }
                            })
                        }), (0, d.useMemo)(function() {
                            return n.map(function(e, t) {
                                var n = e.data,
                                    a = e.isError,
                                    i = e.isLoading,
                                    o = r[t];
                                if (a || i) return null;
                                var s = n.tags.reduce(function(e, t) {
                                    return es.has(t.type) && (e[el[t.type]] = t.value), e
                                }, {});
                                try {
                                    var l, u = o.split(/[#?]/)[0],
                                        d = null === (l = s.url) || void 0 === l ? void 0 : l.endsWith("/login"),
                                        c = s.url && "/" === new URL(s.url || "").pathname;
                                    if (u !== s.url && (d || c)) return null
                                } catch (e) {
                                    return null
                                }
                                return s.url = o, s
                            }).filter(Boolean)
                        }, [n, r])),
                        o = (0, d.useMemo)(function() {
                            return !i.some(function(e) {
                                return !!(null == e ? void 0 : e.imageUrl)
                            })
                        }, [i]),
                        l = (0, d.useMemo)(function() {
                            return a.reduce(function(e, t) {
                                return e[E.get(t.domain)] = t.manifest.logo_url, e
                            }, {})
                        }, [a]),
                        u = (0, d.useMemo)(function() {
                            return i.map(function(e) {
                                var t, n;
                                if (!e) return null;
                                try {
                                    t = E.get(new URL(e.url).hostname)
                                } catch (e) {
                                    return console.error("Invalid card url: ", e), null
                                }
                                return t in l && (n = l[t]), (0, s.jsx)(q, {
                                    title: e.title || "",
                                    url: e.url,
                                    imageUrl: e.imageUrl,
                                    logoUrl: n,
                                    mini: o
                                }, e.url)
                            })
                        }, [i, o, l]);
                    return 0 === i.length ? null : (0, s.jsx)(ei, {
                        loop: !1,
                        children: u
                    })
                }),
                ec = n(98076),
                ef = n(5268),
                eg = n(19579),
                eh = n.n(eg),
                em = n(70671),
                ep = n(94968),
                ev = n(63031),
                ex = n(1821);

            function eb() {
                var e = (0, o._)(["w-full max-w-lg dark:bg-gray-700 dark:text-gray-400 bg-gray-100 text-gray-500 h-auto rounded-md overflow-hidden flex items-center justify-center"]);
                return eb = function() {
                    return e
                }, e
            }

            function ey(e) {
                var t, n = e.asset,
                    r = n.asset_pointer,
                    a = n.width,
                    i = n.height,
                    o = (0, em.Z)(),
                    u = (t = (0, ev.Iy)(r), (0, ef.a)({
                        queryKey: ["getFileDownloadLink", t],
                        queryFn: (0, Z._)(function() {
                            return (0, F.__generator)(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, B.ZP.getFileDownloadLink(t).catch(function(e) {
                                            throw console.error("Could not fetch file with ID ".concat(t, " from file service"), e.message), e
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            })
                        })
                    })),
                    c = u.data,
                    f = u.isLoading,
                    g = null == c ? void 0 : c.download_url,
                    h = (0, d.useRef)(null),
                    m = (0, w._)((0, d.useState)(!1), 2),
                    p = m[0],
                    v = m[1];
                (0, d.useEffect)(function() {
                    var e;
                    (null === (e = h.current) || void 0 === e ? void 0 : e.complete) || v(!1)
                }, [r]);
                var x = f || !p;
                return "string" == typeof g ? (0, s.jsx)(ej, {
                    children: (0, s.jsx)(eh(), {
                        alt: o.formatMessage(ew.alt),
                        src: g,
                        width: a,
                        height: i,
                        unoptimized: !0,
                        ref: h,
                        onLoadingComplete: function() {
                            return v(!0)
                        },
                        className: (0, l.Z)("max-w-full rounded-md transition-opacity duration-300", p ? "opacity-100" : "opacity-0")
                    })
                }) : (0, s.jsx)(ej, {
                    style: {
                        aspectRatio: "".concat(a, " / ").concat(i),
                        width: a
                    },
                    title: x ? o.formatMessage(ew.loading) : o.formatMessage(ew.error),
                    children: x ? (0, s.jsx)(ex.Z, {}) : (0, s.jsx)(Y.BJv, {})
                })
            }
            var ej = c.Z.div(eb()),
                ew = (0, ep.vU)({
                    loading: {
                        id: "imageAsset.loading",
                        defaultMessage: "Loading...",
                        description: "Text that describes a loading image"
                    },
                    error: {
                        id: "imageAsset.error",
                        defaultMessage: "Could not load image",
                        description: "Text that describes an image that failed to load"
                    },
                    alt: {
                        id: "imageAsset.alt",
                        defaultMessage: "Uploaded image",
                        description: "Alt text for image asset"
                    }
                });

            function eC() {
                var e = (0, o._)(["flex gap-2 flex-wrap"]);
                return eC = function() {
                    return e
                }, e
            }

            function ek() {
                var e = (0, o._)(["\npy-2 px-3 border text-gray-600 rounded-md text-sm dark:text-gray-100\n", "\n", "\n", "\n"]);
                return ek = function() {
                    return e
                }, e
            }
            var e_ = d.memo(function(e) {
                var t, n, r, o = e.message,
                    l = e.isEditing,
                    u = e.format,
                    c = e.isCompletionInProgress,
                    f = e.className,
                    g = e.isCompletion,
                    h = e.isResponseToPluginMessage,
                    m = (0, i._)(e, ["message", "isEditing", "format", "isCompletionInProgress", "className", "isCompletion", "isResponseToPluginMessage"]),
                    p = (0, d.useMemo)(function() {
                        return "parts" in o.message.content ? o.message.content.parts : [(0, x.RR)(o.message)]
                    }, [o]);
                return l ? (0, s.jsx)(S, (0, a._)({
                    currentLeaf: o.nodeId,
                    initialText: (0, x.RR)(o.message),
                    role: o.message.author.role,
                    attachments: null === (r = o.message.metadata) || void 0 === r ? void 0 : r.attachments
                }, m)) : (0, s.jsx)(eM, {
                    parts: p,
                    errCode: o.errCode,
                    err: o.err,
                    flag: o.errType,
                    isCompletionInProgress: c,
                    format: u,
                    className: f,
                    citations: null === (t = o.message.metadata) || void 0 === t ? void 0 : t.citations,
                    attachments: null === (n = o.message.metadata) || void 0 === n ? void 0 : n.attachments,
                    isCompletion: g,
                    id: o.nodeId,
                    onRequestMoreCompletions: m.onRequestMoreCompletions,
                    clientThreadId: m.clientThreadId,
                    showExtractedLinkCards: h
                })
            });

            function eM(e) {
                var t, n, r, a = e.attachments,
                    i = e.citations,
                    o = e.className,
                    u = e.err,
                    c = e.errCode,
                    h = e.flag,
                    x = e.format,
                    b = e.isCompletionInProgress,
                    w = e.size,
                    C = void 0 === w ? "medium" : w,
                    k = e.parts,
                    _ = e.isCompletion,
                    M = e.id,
                    T = e.onRequestMoreCompletions,
                    N = e.clientThreadId,
                    P = e.showExtractedLinkCards,
                    S = !k.some(function(e) {
                        return "" !== e
                    }),
                    I = u && S,
                    Z = c === f.Dd,
                    F = (n = (t = {
                        text: k.map(function(e) {
                            return "string" == typeof e ? e : ""
                        }).join(""),
                        isCompletionInProgress: b
                    }).text, r = t.isCompletionInProgress, (0, d.useMemo)(function() {
                        if (r) return [];
                        var e = n.match(eu);
                        return Array.from(new Set(e))
                    }, [r, n])),
                    D = (0, d.useMemo)(function() {
                        switch (c) {
                            case f.Dd:
                                return (0, s.jsx)(eI, {
                                    $flag: h,
                                    children: (0, s.jsx)(eP, {})
                                });
                            case ec.uU:
                                return (0, s.jsx)(eN, {
                                    id: M,
                                    onRequestMoreCompletions: T,
                                    flag: h,
                                    clientThreadId: N
                                });
                            case v.wp:
                                return (0, s.jsx)(eI, {
                                    $flag: h,
                                    children: "Sorry, conversations created when Chat History is off expire after 6 hours of inactivity. Please start a new conversation to continue using ChatGPT."
                                });
                            default:
                                return (0, s.jsx)(eI, {
                                    $flag: h,
                                    children: u
                                })
                        }
                    }, [u, c, h, M, T, N]),
                    E = (0, m.hz)().has(g.FZ),
                    R = a && a.length > 0 && !_;
                return (0, s.jsxs)("div", {
                    className: (0, l.Z)(o, "flex items-start overflow-x-auto whitespace-pre-wrap break-words", "danger" === h ? "flex-row gap-2 text-red-500" : "flex-col gap-4", "warning" === h && "text-orange-500", E && "text-base"),
                    children: [k.map(function(e, t) {
                        return "string" == typeof e ? I || Z || !x ? (0, s.jsx)("div", {
                            className: "empty:hidden",
                            children: "danger" === h && Z ? null : e
                        }, t) : (0, s.jsx)(j.Z, {
                            clientThreadId: N,
                            messageId: M,
                            size: C,
                            className: (0, l.Z)("danger" !== h && b && "result-streaming", "danger" === h && "text-red-500", "warning" === h && "text-orange-500"),
                            children: "" === e ? "&#8203;" : (0, p.Qd)(e, i)
                        }, t) : (0, s.jsx)(ey, {
                            asset: e
                        }, t)
                    }), R && (0, s.jsx)(eS, {
                        children: a.map(function(e) {
                            return (0, s.jsx)(y.Z, {
                                file: e.name
                            }, e.id)
                        })
                    }), _ && P && F.length > 0 && (0, s.jsx)(ed, {
                        urls: F
                    }), h && D]
                })
            }

            function eT(e) {
                var t = e && new Date(e),
                    n = t && new Date(t);
                return n ? "after ".concat(n.getHours() % 12 || 12, ":").concat(10 > n.getMinutes() ? "0" : "").concat(n.getMinutes(), " ").concat(n.getHours() >= 12 ? "PM" : "AM") : "later"
            }

            function eN(e) {
                var t = e.id,
                    n = e.onRequestMoreCompletions,
                    r = e.flag,
                    a = e.clientThreadId,
                    i = (0, u.useRouter)(),
                    o = (0, ec.Y8)(function(e) {
                        return e.isoDate
                    }),
                    l = eT(o),
                    c = (0, d.useCallback)(function() {
                        n(t, {
                            eventSource: "mouse"
                        }, !0, "none", !1)
                    }, [t, n]),
                    f = (0, d.useCallback)(function() {
                        var e = void 0 !== a ? h.tQ.getServerThreadId(a) : void 0;
                        void 0 === e ? i.replace("/", void 0, {
                            shallow: !0
                        }) : (0, ec.m0)(e), n(t, {
                            eventSource: "mouse"
                        }, !0, "none", !0)
                    }, [t, n, i, a]),
                    g = o ? (0, s.jsxs)("span", {
                        children: ["You've reached the current usage cap for GPT-4. You can continue with the default model now, or try again ".concat(l, "."), " ", (0, s.jsx)("a", {
                            href: "https://share.hsforms.com/16d0ZZVM3QZirXnCD_q7u1Q4sk30",
                            target: "_blank",
                            rel: "noreferrer",
                            className: "underline",
                            children: "Learn more"
                        })]
                    }) : "You previously reached your usage cap for GPT-4, but you can now try sending your message again";
                return (0, s.jsx)(eI, {
                    $flag: !!o && r,
                    children: (0, s.jsxs)("div", {
                        className: "flex items-center gap-6",
                        children: [g, !o && (0, s.jsx)(b.z, {
                            color: "light",
                            className: "flex-shrink-0 bg-white",
                            onClick: c,
                            children: "Try again"
                        }), o && (0, s.jsx)(b.z, {
                            color: "light",
                            className: "flex-shrink-0 bg-white",
                            onClick: f,
                            children: "Use default model"
                        })]
                    })
                })
            }

            function eP() {
                return (0, s.jsxs)(s.Fragment, {
                    children: ["This content may violate our", " ", (0, s.jsx)("a", {
                        target: "_blank",
                        href: "https://platform.openai.com/docs/usage-policies/content-policy",
                        rel: "noreferrer",
                        className: "bold underline",
                        children: "content policy"
                    }), ". If you believe this to be in error, please", " ", (0, s.jsx)("a", {
                        target: "_blank",
                        href: "https://forms.gle/3gyAMj5r5rTEcgbs5",
                        rel: "noreferrer",
                        className: "bold underline",
                        children: "submit your feedback"
                    }), " ", "— your input will aid our research in this area."]
                })
            }
            var eS = c.Z.div(eC()),
                eI = c.Z.div(ek(), function(e) {
                    return "warning" === e.$flag && "border-orange-500 bg-orange-500/10"
                }, function(e) {
                    return "danger" === e.$flag && "border-red-500 bg-red-500/10"
                }, function(e) {
                    return !e.$flag && "border-green-500 bg-green-500/10"
                })
        },
        7614: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return h
                },
                Z: function() {
                    return d
                }
            });
            var r = n(4337),
                a = n(35250),
                i = n(21389);

            function o() {
                var e = (0, r._)(["flex p-4 bg-gray-50 dark:bg-white/5 rounded-md items-center gap-4 min-h-[71px]"]);
                return o = function() {
                    return e
                }, e
            }

            function s() {
                var e = (0, r._)(["w-10 text-2xl text-center"]);
                return s = function() {
                    return e
                }, e
            }

            function l() {
                var e = (0, r._)(["flex-1 leading-5"]);
                return l = function() {
                    return e
                }, e
            }

            function u() {
                var e = (0, r._)(["flex gap-4 flex-col text-sm"]);
                return u = function() {
                    return e
                }, e
            }

            function d(e) {
                var t = e.icon,
                    n = e.children;
                return (0, a.jsxs)(c, {
                    children: [(0, a.jsx)(f, {
                        children: t
                    }), (0, a.jsx)(g, {
                        children: n
                    })]
                })
            }
            var c = i.Z.div(o()),
                f = i.Z.div(s()),
                g = i.Z.div(l()),
                h = i.Z.div(u())
        },
        35101: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return l
                },
                Z: function() {
                    return u
                }
            });
            var r = n(81949),
                a = n(5268),
                i = n(62509),
                o = n(99486),
                s = n(54118),
                l = ["approvedAip"];

            function u(e) {
                var t = e.category,
                    n = e.search,
                    u = e.offset,
                    d = e.limit,
                    c = (0, i.kP)().session,
                    f = (0, s.Fl)().isPluginsAvailable;
                return (0, a.a)((0, r._)(l).concat([{
                    category: t,
                    search: n
                }, {
                    limit: d,
                    offset: u
                }]), function() {
                    return o.ZP.getApprovedPlugins({
                        offset: u,
                        limit: d,
                        category: t,
                        search: n,
                        accessToken: null == c ? void 0 : c.accessToken
                    })
                }, {
                    enabled: f && (null == c ? void 0 : c.accessToken) != null,
                    keepPreviousData: !0,
                    onError: function(e) {
                        console.error(e)
                    }
                })
            }
        },
        28531: function(e, t, n) {
            n.d(t, {
                v: function() {
                    return m
                }
            });
            var r = n(21722),
                a = n(20485),
                i = n(39889),
                o = n(13995),
                s = n(5268),
                l = n(70079),
                u = n(99486),
                d = n(32542),
                c = n(35101),
                f = n(14444);

            function g(e) {
                return h.apply(this, arguments)
            }

            function h() {
                return (h = (0, r._)(function(e) {
                    var t;
                    return (0, i.__generator)(this, function(n) {
                        switch (n.label) {
                            case 0:
                                return t = e.queryKey, [4, u.ZP.publicGetPluginsById({
                                    ids: t
                                })];
                            case 1:
                                return [2, n.sent().items]
                        }
                    })
                })).apply(this, arguments)
            }

            function m() {
                var e, t, n;
                return null !== (e = (t = (0, l.useContext)(d.XA), n = (0, o.NL)(), (0, s.a)({
                    queryKey: t,
                    queryFn: g,
                    select: void 0,
                    initialData: function() {
                        var e = null === (u = n.getQueryData(f.Z)) || void 0 === u ? void 0 : u.items,
                            r = null === (d = n.getQueryData(c.V)) || void 0 === d ? void 0 : d.items,
                            i = [],
                            o = !0,
                            s = !1,
                            l = void 0;
                        try {
                            for (var u, d, g, h = t[Symbol.iterator](); !(o = (g = h.next()).done); o = !0) {
                                var m = function() {
                                    var t, n = g.value,
                                        a = null !== (t = null == e ? void 0 : e.find(function(e) {
                                            return e.id === n
                                        })) && void 0 !== t ? t : null == r ? void 0 : r.find(function(e) {
                                            return e.id === n
                                        });
                                    if (null == a) return {
                                        v: void 0
                                    };
                                    i.push(a)
                                }();
                                if ("object" === (0, a._)(m)) return m.v
                            }
                        } catch (e) {
                            s = !0, l = e
                        } finally {
                            try {
                                o || null == h.return || h.return()
                            } finally {
                                if (s) throw l
                            }
                        }
                        return i
                    }
                })).data) && void 0 !== e ? e : []
            }
        },
        14444: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return u
                },
                Z: function() {
                    return l
                }
            });
            var r = n(5268),
                a = n(70079),
                i = n(62509),
                o = n(99486),
                s = n(54118),
                l = ["installedAip"];

            function u() {
                var e = (0, i.kP)().session,
                    t = (0, s.Fl)().isPluginsAvailable,
                    n = (0, r.a)(l, function() {
                        return o.ZP.getPlugins({
                            offset: 0,
                            limit: 250,
                            isInstalled: !0,
                            accessToken: null == e ? void 0 : e.accessToken
                        })
                    }, {
                        enabled: t && !!(null == e ? void 0 : e.accessToken),
                        onError: function(e) {
                            console.error(e)
                        }
                    }),
                    u = n.data,
                    d = n.isLoading;
                return (0, a.useMemo)(function() {
                    return {
                        installedPlugins: u ? u.items : [],
                        isLoading: d
                    }
                }, [u, d])
            }
        },
        35588: function(e, t, n) {
            n.d(t, {
                t: function() {
                    return u
                }
            });
            var r = n(39324),
                a = n(71209),
                i = n(91530),
                o = n.n(i),
                s = n(78103),
                l = {
                    showAccountPaymentModal: !1
                },
                u = (0, s.ZP)()(function(e) {
                    return (0, a._)((0, r._)({}, l), {
                        setShowAccountPaymentModal: function(t) {
                            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : o();
                            e({
                                showAccountPaymentModal: t
                            }), n && n()
                        }
                    })
                })
        },
        80691: function(e, t, n) {
            var r = n(54118);
            t.Z = function() {
                var e = (0, r.Fl)(),
                    t = e.isChatPreferencesAvailable,
                    n = e.isChatPreferencesEnabled;
                return t && n
            }
        },
        98076: function(e, t, n) {
            n.d(t, {
                BT: function() {
                    return u
                },
                Y8: function() {
                    return d
                },
                kc: function() {
                    return s
                },
                m0: function() {
                    return l
                },
                uU: function() {
                    return o
                }
            });
            var r = n(81949),
                a = n(78103),
                i = n(25229),
                o = "model_cap_exceeded",
                s = (0, a.ZP)(function() {
                    return {
                        serverThreadIds: new Set
                    }
                });

            function l(e) {
                s.setState(function(t) {
                    return {
                        serverThreadIds: new Set((0, r._)(t.serverThreadIds).concat([e]))
                    }
                })
            }

            function u() {
                var e = d(function(e) {
                        return e.isoDate
                    }),
                    t = d(function(e) {
                        return e.clearCapTimeout
                    }),
                    n = Date.now(),
                    r = e && new Date(e).getTime();
                return e && r && r <= n ? (t(), null) : e ? "gpt-4" : null
            }
            var d = (0, a.ZP)()((0, i.tJ)(function(e) {
                return {
                    isoDate: "",
                    setCapTimeout: function(t) {
                        e(function() {
                            return {
                                isoDate: t
                            }
                        })
                    },
                    clearCapTimeout: function() {
                        e(function() {
                            return {
                                isoDate: ""
                            }
                        })
                    }
                }
            }, {
                name: "oai/apps/capExpiresAt"
            }))
        },
        73610: function(e, t, n) {
            n.d(t, {
                W: function() {
                    return g
                }
            });
            var r = n(21722),
                a = n(39889),
                i = n(5268),
                o = n(94968),
                s = n(70671),
                l = n(62509),
                u = n(99486),
                d = n(78931),
                c = n(88798),
                f = (0, o.vU)({
                    errorLoadingFiles: {
                        id: "filesModal.errorLoadingFiles",
                        defaultMessage: "Failed to load files",
                        description: "Error message when loading files fails"
                    }
                });

            function g() {
                var e = (0, l.kP)(),
                    t = e.session,
                    n = e.loading,
                    o = (0, d.hz)(),
                    g = (0, s.Z)();
                return (0, i.a)(["files"], (0, r._)(function() {
                    return (0, a.__generator)(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, u.ZP.listFiles(t.accessToken).catch(function() {
                                    return c.m.danger(g.formatMessage(f.errorLoadingFiles)), {
                                        files: []
                                    }
                                })];
                            case 1:
                                return [2, e.sent()]
                        }
                    })
                }), {
                    enabled: !n && (null == t ? void 0 : t.accessToken) != null && o.has("files_list_ui")
                })
            }
        },
        44510: function(e, t, n) {
            n.d(t, {
                _C: function() {
                    return l
                },
                xT: function() {
                    return u
                }
            });
            var r = n(70079),
                a = n(62509),
                i = n(6948),
                o = n(78931),
                s = function(e, t) {
                    return "oai/apps/".concat(t, "/").concat(e, "/lastModelUsed")
                };

            function l() {
                var e, t = (0, o.hz)(),
                    n = (0, a.kP)().session,
                    r = null == n ? void 0 : null === (e = n.user) || void 0 === e ? void 0 : e.id,
                    l = (0, o.ec)(function(e) {
                        return {
                            currentWorkspace: e.currentWorkspace
                        }
                    }).currentWorkspace,
                    u = null == l ? void 0 : l.id;
                return t.has("persist_last_used_model") ? i.m.getItem("".concat(s(u, r))) : null
            }

            function u() {
                var e, t = (0, a.kP)().session,
                    n = null == t ? void 0 : null === (e = t.user) || void 0 === e ? void 0 : e.id,
                    l = (0, o.ec)(function(e) {
                        return {
                            currentWorkspace: e.currentWorkspace
                        }
                    }).currentWorkspace,
                    u = null == l ? void 0 : l.id;
                return (0, r.useCallback)(function(e) {
                    if (!e) return null;
                    var t = Date.now();
                    i.m.setItem("".concat(s(u, n)), {
                        modelId: e,
                        updatedAt: t
                    })
                }, [u, n])
            }
        },
        65642: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return c
                }
            });
            var r = n(5268),
                a = n(70079),
                i = n(62509),
                o = n(99486),
                s = n(78931),
                l = n(31541),
                u = n(98076),
                d = {
                    textarea: "",
                    "model-switcher": ""
                };

            function c() {
                var e = (0, i.kP)().session,
                    t = (0, s.WY)(),
                    n = (0, u.Y8)(function(e) {
                        return e.isoDate
                    }),
                    c = (0, l.xz)(n),
                    f = (0, r.a)(["modelMessageCap"], function() {
                        return o.ZP.getModelMessageCap()
                    }, {
                        enabled: (null == e ? void 0 : e.accessToken) != null && t
                    }).data;
                return (0, a.useMemo)(function() {
                    var e = (null == f ? void 0 : f.message_cap) || 0,
                        t = (null == f ? void 0 : f.message_cap_window) || 1,
                        n = function(e) {
                            if (e < 60) return e < 2 ? "minute" : "".concat(e, " minutes");
                            var t = Math.floor(e / 60);
                            if (t < 24) return t < 2 ? "hour" : "".concat(t, " hours");
                            var n = Math.floor(t / 24);
                            if (n < 7) return n < 2 ? "day" : "".concat(n, " days")
                        }(t),
                        r = (null == f ? void 0 : f.message_disclaimer) || d;
                    return n ? f && t && e ? {
                        textareaDisclaimer: r.textarea.replaceAll("%FORMATTED_TIME%", c).replaceAll("%NUMERATOR%", "".concat(e)).replaceAll("%DENOMINATOR%", n),
                        modelSwitcherDisclaimer: r["model-switcher"].replaceAll("%FORMATTED_TIME%", c).replaceAll("%NUMERATOR%", "".concat(e)).replaceAll("%DENOMINATOR%", n)
                    } : {
                        textareaDisclaimer: d.textarea,
                        modelSwitcherDisclaimer: d["model-switcher"]
                    } : {
                        textareaDisclaimer: r.textarea,
                        modelSwitcherDisclaimer: r["model-switcher"]
                    }
                }, [f, c])
            }
        },
        16592: function(e, t, n) {
            n.d(t, {
                Ri: function() {
                    return N
                },
                ZP: function() {
                    return S
                },
                dN: function() {
                    return a
                },
                i0: function() {
                    return P
                }
            });
            var r, a, i, o, s, l, u, d, c, f, g = n(96237),
                h = n(39324),
                m = n(81949),
                p = n(35250),
                v = n(41170),
                x = n(70079),
                b = n(54118),
                y = n(78931),
                j = n(88327),
                w = n(40058),
                C = n(98076),
                k = n(65642),
                _ = n(42569);
            (r = a || (a = {})).BROWSING = "browsing_model", r.CODE_INTERPRETER = "code_interpreter_model", r.PLUGINS = "plugins_model";
            var M = (i = {}, (0, g._)(i, "gpt_3.5", {
                    icon: j.jr,
                    activeIcon: j.jr,
                    backgroundColor: "#19c37d",
                    buttonActiveClass: "text-brand-green",
                    buttonHoverClass: "group-hover/button:text-brand-green",
                    iconClass: "group-hover/option:!text-brand-green group-hover/options:text-gray-500",
                    disclaimer: "Available to Free and Plus users",
                    showSelectedValueBelow: !1
                }), (0, g._)(i, "gpt_4", {
                    icon: j.Bj,
                    activeIcon: j.MP,
                    backgroundColor: "#AB68FF",
                    buttonActiveClass: "text-brand-purple",
                    buttonHoverClass: "group-hover/button:text-brand-purple",
                    iconClass: "group-hover/option:!text-brand-purple group-hover/options:text-gray-500",
                    disclaimer: "Available exclusively to Plus users",
                    showSelectedValueBelow: !1
                }), (0, g._)(i, "other", {
                    icon: v.Z,
                    activeIcon: v.Z,
                    backgroundColor: "#E06C2B",
                    buttonActiveClass: "text-orange-500",
                    buttonHoverClass: "group-hover/button:text-orange-500",
                    showSelectedValueBelow: !0
                }), i),
                T = (f = {}, (0, g._)(f, a.BROWSING, {
                    iconByCategory: (o = {}, (0, g._)(o, "gpt_3.5", j.O1), (0, g._)(o, "gpt_4", j.Fz), o),
                    activeIconByCategory: (s = {}, (0, g._)(s, "gpt_3.5", j.X7), (0, g._)(s, "gpt_4", j.Ae), s),
                    name: (0, p.jsxs)("span", {
                        children: ["Browse with", " ", (0, p.jsx)(j.ZP, {
                            icon: j.jE,
                            className: "-mt-[3px] inline-block"
                        }), " ", "Bing"]
                    })
                }), (0, g._)(f, a.CODE_INTERPRETER, {
                    iconByCategory: (l = {}, (0, g._)(l, "gpt_3.5", j.lv), (0, g._)(l, "gpt_4", j.Q$), l),
                    activeIconByCategory: (u = {}, (0, g._)(u, "gpt_3.5", j.vy), (0, g._)(u, "gpt_4", j.$V), u),
                    name: "Code Interpreter"
                }), (0, g._)(f, a.PLUGINS, {
                    iconByCategory: (d = {}, (0, g._)(d, "gpt_3.5", j.AQ), (0, g._)(d, "gpt_4", j.IT), d),
                    activeIconByCategory: (c = {}, (0, g._)(c, "gpt_3.5", j.Np), (0, g._)(c, "gpt_4", j.j3), c),
                    name: "Plugins"
                }), f);

            function N(e) {
                var t = S();
                return (0, x.useMemo)(function() {
                    return function(e, t) {
                        if (t)
                            for (var n = 0; n < e.length; n++) {
                                var r = e[n];
                                if (r.options.length > 0) {
                                    var a, i, o = r.options.find(function(e) {
                                        return e.value === t
                                    });
                                    if (o) return {
                                        item: o,
                                        categoryId: r.categoryId,
                                        backgroundColor: M[r.categoryId].backgroundColor,
                                        icon: null !== (i = null !== (a = o.icon) && void 0 !== a ? a : r.icon) && void 0 !== i ? i : M[r.categoryId].icon
                                    }
                                }
                            }
                    }(t, e)
                }, [t, e])
            }

            function P(e, t) {
                return (0, _.OX)().some(function(n) {
                    return n[t] === e
                })
            }

            function S() {
                var e = (0, _.OX)(),
                    t = (0, _.B9)(),
                    n = (0, C.BT)(),
                    r = (0, b.Fl)(),
                    i = (0, y.ec)(y.F_.isBusinessWorkspace),
                    o = (0, k.Z)().modelSwitcherDisclaimer,
                    s = (0, y.hz)(),
                    l = (0, _.B8)(),
                    u = l.enabledModelsInCategoriesById,
                    d = l.enabledModelsNotInCategoriesById;
                return (0, x.useMemo)(function() {
                    var l = [],
                        c = !0,
                        f = !1,
                        g = void 0;
                    try {
                        for (var h, p = e[Symbol.iterator](); !(c = (h = p.next()).done); c = !0) {
                            var v = h.value;
                            if (u.has(v.default_model)) {
                                var x = M[v.category] || {},
                                    b = n === v.default_model,
                                    y = t.get(v.default_model),
                                    j = b ? [] : function(e, t, n, r, i) {
                                        var o = e.isBrowsingEnabled,
                                            s = e.isPluginsEnabled,
                                            l = e.isCodeInterpreterEnabled,
                                            u = [];
                                        if (o && null != n[a.BROWSING] && r.has(n[a.BROWSING])) {
                                            var d = T[a.BROWSING];
                                            u.push(I(i.get(n[a.BROWSING]), {
                                                icon: d.iconByCategory[n.category],
                                                name: d.name,
                                                activeIcon: d.activeIconByCategory[n.category],
                                                disabled: t.has("browsing_disabled")
                                            }))
                                        }
                                        if (l && null != n[a.CODE_INTERPRETER] && r.has(n[a.CODE_INTERPRETER])) {
                                            var c = T[a.CODE_INTERPRETER];
                                            u.push(I(i.get(n[a.CODE_INTERPRETER]), {
                                                icon: c.iconByCategory[n.category],
                                                name: c.name,
                                                activeIcon: c.activeIconByCategory[n.category],
                                                disabled: t.has("code_interpreter_disabled")
                                            }))
                                        }
                                        if (s && null != n[a.PLUGINS] && r.has(n[a.PLUGINS])) {
                                            var f = T[a.PLUGINS];
                                            u.push(I(i.get(n[a.PLUGINS]), {
                                                icon: f.iconByCategory[n.category],
                                                name: f.name,
                                                activeIcon: f.activeIconByCategory[n.category],
                                                disabled: t.has("plugins_disabled")
                                            }))
                                        }
                                        return u
                                    }(r, s, v, u, t);
                                l.push({
                                    categoryId: v.category,
                                    value: y.id,
                                    name: v.human_category_name,
                                    description: b ? o : y.description,
                                    disclaimer: i ? void 0 : x.disclaimer,
                                    buttonActiveClass: x.buttonActiveClass,
                                    buttonHoverClass: x.buttonHoverClass,
                                    iconClass: x.iconClass,
                                    icon: x.icon,
                                    activeIcon: x.activeIcon,
                                    options: [I(y, {
                                        icon: x.icon,
                                        activeIcon: x.activeIcon,
                                        name: "Default"
                                    })].concat((0, m._)(j)),
                                    disabled: b,
                                    showSelectedValueBelow: !1
                                })
                            }
                        }
                    } catch (e) {
                        f = !0, g = e
                    } finally {
                        try {
                            c || null == p.return || p.return()
                        } finally {
                            if (f) throw g
                        }
                    }
                    var C = Array.from(d).map(function(e) {
                            return t.get(e)
                        }),
                        k = C.some(function(e) {
                            return e.id === w.Y
                        });
                    if (C.length > 0 && !k) {
                        var _ = C[0],
                            N = M.other;
                        l.push({
                            categoryId: "other",
                            value: null == _ ? void 0 : _.id,
                            name: "Alpha",
                            buttonActiveClass: N.buttonActiveClass,
                            buttonHoverClass: N.buttonHoverClass,
                            options: C.map(function(e) {
                                return I(e)
                            }),
                            showSelectedValueBelow: !0,
                            icon: N.icon,
                            activeIcon: N.activeIcon,
                            alwaysShowOptions: !0
                        })
                    }
                    return l
                }, [d, e, u, n, t, r, i, s, o])
            }

            function I(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, h._)({
                    value: e.id,
                    name: e.title,
                    tags: e.tags
                }, t)
            }
        },
        42569: function(e, t, n) {
            n.d(t, {
                B8: function() {
                    return E
                },
                B9: function() {
                    return S
                },
                Bv: function() {
                    return F
                },
                Gg: function() {
                    return I
                },
                H6: function() {
                    return R
                },
                OX: function() {
                    return N
                },
                Q_: function() {
                    return T
                },
                S: function() {
                    return a
                },
                Xy: function() {
                    return D
                },
                ZL: function() {
                    return M
                },
                fm: function() {
                    return Z
                },
                iu: function() {
                    return P
                },
                n2: function() {
                    return k
                }
            });
            var r, a, i = n(21722),
                o = n(39324),
                s = n(71209),
                l = n(81949),
                u = n(39889),
                d = n(5268),
                c = n(60554),
                f = n(70079),
                g = n(62509),
                h = n(99486),
                m = n(31621),
                p = n(54118),
                v = n(78931),
                x = n(32542),
                b = n(98076),
                y = n(44510),
                j = n(16592),
                w = "text-davinci-002-render-sha";
            (r = a || (a = {})).GPT_3_5 = "gpt3.5", r.GPT_4 = "gpt4", r.MOBILE = "mobile";
            var C = R({
                    slug: w,
                    max_tokens: 4097,
                    title: "Default",
                    description: "",
                    tags: [a.GPT_3_5],
                    product_features: {}
                }),
                k = new Set(["text-davinci-002-render-paid"]);

            function _(e) {
                var t = (0, f.useContext)(x.QL).historyDisabled,
                    n = (0, g.kP)(),
                    r = n.session,
                    a = n.loading,
                    o = null == r ? void 0 : r.accessToken;
                return (0, d.a)({
                    retry: 5,
                    queryKey: ["models", {
                        isHistoryDisabled: !t
                    }],
                    queryFn: (0, i._)(function() {
                        return (0, u.__generator)(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, h.ZP.getModels(o, t)];
                                case 1:
                                    return [2, e.sent()]
                            }
                        })
                    }),
                    enabled: !a && null != o,
                    select: e
                })
            }

            function M() {
                return _().isLoading
            }

            function T() {
                return _().isSuccess
            }

            function N() {
                var e = _(function(e) {
                    return e.categories
                }).data;
                return null != e ? e : []
            }

            function P() {
                var e = _(function(e) {
                    return e.models
                }).data;
                return (0, f.useMemo)(function() {
                    return new Set(e ? e.map(function(e) {
                        return e.slug
                    }) : [w])
                }, [e])
            }

            function S() {
                var e = _(function(e) {
                    return e.models
                }).data;
                return (0, f.useMemo)(function() {
                    return new Map(e ? e.map(function(e) {
                        return [e.slug, R(e)]
                    }) : [
                        [w, C]
                    ])
                }, [e])
            }

            function I(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = function(e) {
                        var t, n, r = o.get(e);
                        return null !== (n = null == r ? void 0 : null === (t = r.tags) || void 0 === t ? void 0 : t.includes(a.GPT_3_5)) && void 0 !== n && n
                    },
                    r = (0, v.hz)(),
                    i = (0, l._)(e),
                    o = S();
                if (!t && r.has("priority_driven_models_list")) return i[0];
                var s = (0, l._)(i).find(function(e) {
                    return n(e)
                });
                return null != s ? s : i[0]
            }

            function Z() {
                var e = (0, c.useRouter)(),
                    t = e.query;
                return (0, f.useCallback)(function(n) {
                    e.replace({
                        pathname: e.basePath,
                        query: (0, s._)((0, o._)({}, t), {
                            model: encodeURIComponent(n)
                        })
                    }, void 0, {
                        shallow: !0
                    })
                }, [t, e])
            }

            function F(e, t) {
                var n, r = decodeURIComponent(null !== (n = (0, c.useRouter)().query.model) && void 0 !== n ? n : ""),
                    a = (0, m.XK)(t),
                    i = E().enabledModelsById,
                    o = (0, p.Fl)().isBetaFeaturesUiEnabled,
                    s = (0, b.kc)().serverThreadIds,
                    l = P(),
                    u = (0, y._C)(),
                    d = o ? i : l,
                    g = I(d);
                return (0, f.useMemo)(function() {
                    if (0 !== d.size) {
                        var t, n = void 0 !== a && s.has(a);
                        return !n && null != e && l.has(e) ? null != e ? e : void 0 : !n && r && d.has(r) ? null != r ? r : void 0 : u && d.has(u.modelId) ? null !== (t = u.modelId) && void 0 !== t ? t : void 0 : null != g ? g : void 0
                    }
                }, [l, g, e, r, u, d, a, s])
            }

            function D(e, t) {
                var n = F(e, t),
                    r = S();
                return (0, f.useMemo)(function() {
                    var e;
                    return null == n ? C : null !== (e = r.get(n)) && void 0 !== e ? e : C
                }, [n, r])
            }

            function E() {
                var e = N(),
                    t = P(),
                    n = S(),
                    r = (0, p.Fl)();
                return (0, f.useMemo)(function() {
                    var i, o = e.reduce(function(e, a) {
                            var i, o, s, l, u, d, c = e.enabledModelsInCategoriesById,
                                f = e.availableModelsInCategoriesById,
                                g = t.has(a.default_model) ? a.default_model : null;
                            null != g && (f.add(g), c.add(g));
                            var h = t.has(null !== (i = a[j.dN.BROWSING]) && void 0 !== i ? i : "") ? n.get(null !== (o = a[j.dN.BROWSING]) && void 0 !== o ? o : "") : null;
                            h && (f.add(h.id), r.isBrowsingEnabled && c.add(h.id));
                            var m = t.has(null !== (s = a[j.dN.CODE_INTERPRETER]) && void 0 !== s ? s : "") ? n.get(null !== (l = a[j.dN.CODE_INTERPRETER]) && void 0 !== l ? l : "") : null;
                            m && (f.add(m.id), r.isCodeInterpreterEnabled && c.add(m.id));
                            var p = t.has(null !== (u = a[j.dN.PLUGINS]) && void 0 !== u ? u : "") ? n.get(null !== (d = a[j.dN.PLUGINS]) && void 0 !== d ? d : "") : null;
                            return p && (f.add(p.id), r.isPluginsEnabled && c.add(p.id)), e
                        }, {
                            enabledModelsInCategoriesById: new Set,
                            availableModelsInCategoriesById: new Set
                        }),
                        s = o.enabledModelsInCategoriesById,
                        u = o.availableModelsInCategoriesById,
                        d = new Set(Array.from(t).filter(function(e) {
                            return !u.has(e)
                        })),
                        c = new Set(Array.from(d).filter(function(e) {
                            var t;
                            return !(null === (t = n.get(e)) || void 0 === t ? void 0 : t.tags.includes(a.MOBILE))
                        }));
                    return {
                        enabledModelsInCategoriesById: s,
                        availableModelsInCategoriesById: u,
                        enabledModelsNotInCategoriesById: c,
                        enabledModelsById: new Set((0, l._)(s).concat((0, l._)(c)))
                    }
                }, [e, t, r, n])
            }

            function R(e) {
                return {
                    id: e.slug,
                    maxTokens: e.max_tokens,
                    title: e.title,
                    description: e.description,
                    tags: e.tags,
                    enabledTools: e.enabled_tools,
                    product_features: e.product_features
                }
            }
        },
        58268: function(e, t, n) {
            n.d(t, {
                sb: function() {
                    return h
                },
                x0: function() {
                    return f
                },
                yu: function() {
                    return g
                }
            });
            var r, a = n(21722),
                i = n(39324),
                o = n(39889),
                s = n(78103),
                l = n(99486),
                u = {
                    data: void 0
                },
                d = (0, s.ZP)()(function() {
                    return (0, i._)({}, u)
                });

            function c(e) {
                if (null == e.data) return d.setState(e);
                var t = e.data.suggestions.map(function(e) {
                    return {
                        text: e
                    }
                });
                d.setState({
                    data: {
                        messageId: e.data.messageId,
                        suggestions: t
                    }
                })
            }

            function f() {
                return d(function(e) {
                    return e.data
                })
            }
            var g = (r = (0, a._)(function(e, t, n) {
                    return (0, o.__generator)(this, function(r) {
                        switch (r.label) {
                            case 0:
                                c({
                                    data: void 0
                                }), r.label = 1;
                            case 1:
                                return r.trys.push([1, 3, , 4]), [4, l.ZP.generateSuggestions(e, t, n)];
                            case 2:
                                return c({
                                    data: {
                                        messageId: t,
                                        suggestions: r.sent().suggestions
                                    }
                                }), [3, 4];
                            case 3:
                                return console.error(r.sent()), [3, 4];
                            case 4:
                                return [2]
                        }
                    })
                }), function(e, t, n) {
                    return r.apply(this, arguments)
                }),
                h = function() {
                    c(u)
                }
        },
        31621: function(e, t, n) {
            n.d(t, {
                tQ: function() {
                    return B
                },
                iN: function() {
                    return R
                },
                _L: function() {
                    return a
                },
                OX: function() {
                    return S
                },
                Zz: function() {
                    return I
                },
                aS: function() {
                    return ea
                },
                ax: function() {
                    return A
                },
                r7: function() {
                    return ei
                },
                XK: function() {
                    return L
                },
                je: function() {
                    return K
                },
                Uy: function() {
                    return J
                },
                GD: function() {
                    return Q
                },
                JI: function() {
                    return V
                },
                U0: function() {
                    return W
                },
                oq: function() {
                    return z
                },
                Hk: function() {
                    return G
                },
                UL: function() {
                    return U
                },
                Kt: function() {
                    return O
                },
                cj: function() {
                    return eo
                },
                Ro: function() {
                    return H
                },
                GR: function() {
                    return q
                },
                qA: function() {
                    return $
                },
                XL: function() {
                    return Y
                },
                u9: function() {
                    return en
                },
                nh: function() {
                    return X
                },
                lA: function() {
                    return ee
                },
                dz: function() {
                    return et
                },
                Qi: function() {
                    return er
                },
                qN: function() {
                    return F
                }
            });
            var r, a, i = n(39324),
                o = n(71209),
                s = n(5268),
                l = n(61888),
                u = n(60554),
                d = n(70079),
                c = n(78103),
                f = n(10301),
                g = n(62509),
                h = n(70216);
            n(68993);
            var m = n(77370),
                p = n(16600);
            n(44675).env.INTERNAL_API_URL;
            var v = n(11084),
                x = n(50795),
                b = n(82081),
                y = n(16920),
                j = n(75641),
                w = n(95954),
                C = n(88798),
                k = n(42569);
            n(86273);
            var _ = n(99486),
                M = n(32542),
                T = n(52787),
                N = "NEW:",
                P = 0;

            function S() {
                return "".concat(N).concat(P++)
            }

            function I(e) {
                return e.startsWith(N)
            }(r = a || (a = {})).NewChat = "NewChat", r.Server = "Server", r.User = "User", r.Generated = "Generated", r.Unknown = "Unknown";
            var Z = {},
                F = (0, c.ZP)((0, f.n)(function() {
                    return {
                        threads: {},
                        clientNewThreadIdToServerIdMapping: {},
                        threadRetainCounts: {}
                    }
                })),
                D = F.getState,
                E = F.setState,
                R = {
                    resolveThreadId: function(e) {
                        var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : D();
                        return null !== (t = n.clientNewThreadIdToServerIdMapping[e]) && void 0 !== t ? t : e
                    },
                    getThreadCustomTitle: function(e) {
                        var t, n, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : D(),
                            a = R.resolveThreadId(e, r);
                        return null !== (n = null === (t = r.threads[a]) || void 0 === t ? void 0 : t.title) && void 0 !== n ? n : void 0
                    },
                    getThreadDataTitle: function(e) {
                        var t, n, r, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : D(),
                            i = R.resolveThreadId(e, a);
                        return null !== (r = null === (t = a.threads[i]) || void 0 === t ? void 0 : null === (n = t.initialThreadData) || void 0 === n ? void 0 : n.title) && void 0 !== r ? r : void 0
                    },
                    getThreadTitleSource: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : D(),
                            n = R.resolveThreadId(e, t);
                        return null != t.threads[n] ? t.threads[n].titleSource : a.Unknown
                    },
                    getThreadCreateTime: function(e) {
                        var t, n, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : D(),
                            a = R.resolveThreadId(e, r);
                        return null === (t = r.threads[a]) || void 0 === t ? void 0 : null === (n = t.initialThreadData) || void 0 === n ? void 0 : n.createTime
                    }
                },
                B = {
                    getOrInitThread: function(e) {
                        var t = B.resolveThreadId(e);
                        return null != D().threads[t] ? D().threads[t] : (B.resetThread(e), D().threads[e])
                    },
                    getServerThreadId: function(e) {
                        return I(e) ? D().clientNewThreadIdToServerIdMapping[e] : e
                    },
                    setServerIdForNewThread: function(e, t) {
                        void 0 === D().clientNewThreadIdToServerIdMapping[e] && E(function(n) {
                            n.threads[t] = n.threads[e], delete n.threads[e], n.clientNewThreadIdToServerIdMapping[e] = t
                        })
                    },
                    initThreadFromServerData: function(e, t) {
                        var n, r, s, l, u, d, c, f, g, v, x, b = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                            y = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0,
                            j = B.resolveThreadId(e);
                        if (null != D().threads[j] || b) {
                            var w = (r = null === (n = Object.values(t.mapping).find(function(e) {
                                return null === e.parent
                            })) || void 0 === n ? void 0 : n.id, s = new Set, l = new Set, (t.moderation_results || []).forEach(function(e) {
                                e.blocked ? l.add(e.message_id) : e.flagged && s.add(e.message_id)
                            }), {
                                rootId: r,
                                mapping: Object.keys(t.mapping).reduce(function(e, n) {
                                    var r, a = t.mapping[n],
                                        u = a.parent,
                                        d = a.children,
                                        c = (0, h._)(a, ["parent", "children"]),
                                        f = t.mapping[n].message || m.Cv.createRootMessage();
                                    return l.has(f.id) ? r = p.sK : s.has(f.id) && (r = p.Mf), e[n] = (0, i._)((0, o._)((0, i._)({}, c), {
                                        message: f,
                                        children: d || [],
                                        parentId: u || "",
                                        type: m.uV[f.author.role]
                                    }), r && {
                                        metadata: r
                                    }), e
                                }, {}),
                                initialCurrentLeafId: t.current_node,
                                authorName: t.author_name
                            });
                            if ((null === (u = D().threads[j]) || void 0 === u ? void 0 : u.isLoading) !== !1) {
                                var C = null !== (d = w.mapping) && void 0 !== d ? d : m.Cv.createTree(),
                                    _ = {
                                        thread: C,
                                        initialCurrentLeafId: null !== (f = null !== (c = w.initialCurrentLeafId) && void 0 !== c ? c : w.rootId) && void 0 !== f ? f : "root",
                                        threadId: j,
                                        title: null !== (g = t.title) && void 0 !== g ? g : null,
                                        lastModelUsed: function e(t, n) {
                                            var r, a, i = t[n];
                                            return (null == i ? void 0 : null === (r = i.message) || void 0 === r ? void 0 : null === (a = r.metadata) || void 0 === a ? void 0 : a.model_slug) ? i.message.metadata.model_slug : (null == i ? void 0 : i.parentId) ? e(t, i.parentId) : null
                                        }(w.mapping, w.initialCurrentLeafId),
                                        hasUserEditableContextFlag: null !== (v = t.has_user_editable_context) && void 0 !== v && v,
                                        pluginIds: null !== (x = t.plugin_ids) && void 0 !== x ? x : [],
                                        authorName: w.authorName,
                                        model: "model" in t && null != t.model ? (0, k.H6)(t.model) : void 0,
                                        createTime: "create_time" in t ? new Date(1e3 * t.create_time) : void 0
                                    },
                                    M = new m.Cv(C),
                                    T = _.initialCurrentLeafId;
                                E(function(e) {
                                    var t;
                                    e.threads[j] = (0, o._)((0, i._)({}, null !== (t = e.threads[j]) && void 0 !== t ? t : {}), {
                                        initialThreadData: _,
                                        title: _.title,
                                        titleSource: a.Server,
                                        tree: M,
                                        currentLeafId: T,
                                        isLoading: !1,
                                        continuingFromSharedConversationId: y
                                    })
                                }), B.recomputeConversationTurns(j, D().threads[j].currentLeafId, [])
                            }
                        }
                    },
                    resetThread: function(e) {
                        var t = {
                            thread: m.Cv.createTree(),
                            initialCurrentLeafId: "root",
                            threadId: null,
                            title: null,
                            lastModelUsed: null,
                            pluginIds: [],
                            authorName: void 0
                        };
                        B.deleteThread(e), E(function(n) {
                            n.threads[e] = {
                                initialThreadData: t,
                                tree: new m.Cv(t.thread),
                                title: t.title,
                                titleSource: a.NewChat,
                                currentLeafId: t.initialCurrentLeafId,
                                conversationTurns: [],
                                isLoading: !I(e)
                            }
                        })
                    },
                    updateInitialThreadDataForNewThread: function(e, t, n) {
                        E(function(r) {
                            r.threads[e].initialThreadData.lastModelUsed = t, r.threads[e].initialThreadData.pluginIds = n
                        })
                    },
                    getThreadCurrentLeafId: function(e) {
                        var t, n, r = B.resolveThreadId(e);
                        return null !== (n = null === (t = D().threads[r]) || void 0 === t ? void 0 : t.currentLeafId) && void 0 !== n ? n : "root"
                    },
                    setThreadCurrentLeafId: function(e, t) {
                        var n, r, a = B.resolveThreadId(e);
                        if (null != D().threads[a]) {
                            E(function(e) {
                                e.threads[a].currentLeafId = t
                            });
                            var i = D();
                            B.recomputeConversationTurns(a, t, null !== (r = null === (n = i.threads[a]) || void 0 === n ? void 0 : n.conversationTurns) && void 0 !== r ? r : [])
                        }
                    },
                    setTitle: function(e, t, n) {
                        var r = B.resolveThreadId(e);
                        null != D().threads[r] && E(function(e) {
                            e.threads[r].title = t, e.threads[r].titleSource = n
                        })
                    },
                    getTitle: function(e) {
                        var t;
                        return null !== (t = R.getThreadCustomTitle(e)) && void 0 !== t ? t : R.getThreadDataTitle(e)
                    },
                    getTitleAndSource: function(e) {
                        var t;
                        return {
                            title: null !== (t = R.getThreadCustomTitle(e)) && void 0 !== t ? t : R.getThreadDataTitle(e),
                            titleSource: R.getThreadTitleSource(e)
                        }
                    },
                    updateTree: function(e, t) {
                        var n, r, a, i, o = B.resolveThreadId(e);
                        if (!(null != D().threads[o])) {
                            console.warn("Thread does not exist, cannot update tree: ", o);
                            return
                        }
                        t(B.getTree(e));
                        var s = D(),
                            l = null !== (a = null === (n = s.threads[o]) || void 0 === n ? void 0 : n.currentLeafId) && void 0 !== a ? a : "root",
                            u = null !== (i = null === (r = s.threads[o]) || void 0 === r ? void 0 : r.conversationTurns) && void 0 !== i ? i : [];
                        B.recomputeConversationTurns(o, l, u)
                    },
                    getTree: function(e) {
                        var t, n, r = B.resolveThreadId(e);
                        return null !== (n = null === (t = D().threads[r]) || void 0 === t ? void 0 : t.tree) && void 0 !== n ? n : new m.Cv
                    },
                    resolveThreadId: function(e) {
                        return R.resolveThreadId(e)
                    },
                    recomputeConversationTurns: function(e, t, n) {
                        var r = B.resolveThreadId(e);
                        E(function(e) {
                            if (e.threads[r]) {
                                var a = B.computeThreadConversationTurns(r, t, n);
                                e.threads[r].conversationTurns = a
                            }
                        })
                    },
                    computeThreadConversationTurns: function(e, t, n) {
                        var r = B.resolveThreadId(e);
                        return B.getTree(r).getConversationTurns(t).map(function(e, t) {
                            var r = null == n ? void 0 : n[t];
                            return (0, l.isEqual)(r, e) ? r : e
                        })
                    },
                    getThreadConversationTurns: function(e, t, n) {
                        var r, a, i, o, s = B.resolveThreadId(e),
                            l = null !== (i = null === (r = D().threads[s]) || void 0 === r ? void 0 : r.currentLeafId) && void 0 !== i ? i : "root";
                        return null != t && t !== l ? B.computeThreadConversationTurns(s, t, null != n ? n : []) : null !== (o = null === (a = D().threads[s]) || void 0 === a ? void 0 : a.conversationTurns) && void 0 !== o ? o : []
                    },
                    getThreadModel: function(e) {
                        var t, n = B.resolveThreadId(e);
                        return null === (t = D().threads[n]) || void 0 === t ? void 0 : t.initialThreadData.model
                    },
                    removeContinuingFromSharedConversationId: function(e) {
                        var t = B.resolveThreadId(e);
                        E(function(e) {
                            var n;
                            (null === (n = e.threads[t]) || void 0 === n ? void 0 : n.continuingFromSharedConversationId) != null && delete e.threads[t].continuingFromSharedConversationId
                        })
                    },
                    copyLastMessageToClipboard: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "mouse",
                            n = B.getThreadCurrentLeafId(e),
                            r = B.getThreadConversationTurns(e, n);
                        return B.copyMessageToClipboard(e, r.length - 1, t)
                    },
                    copyMessageToClipboard: function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "mouse",
                            r = B.getThreadCurrentLeafId(e),
                            a = B.getThreadConversationTurns(e, r)[t];
                        if (a) {
                            var i = a.messages,
                                o = i.reduce(function(e, t) {
                                    return t.err || t.message.author.role !== w.uU.Assistant || "all" !== t.message.recipient ? e : e + (e ? "\n\n" : "") + (0, T.RR)(t.message)
                                }, "");
                            (0, v.S)(o), x.o.logEvent(b.a.copyToClipboard, {
                                threadId: B.getServerThreadId(e),
                                id: i[0].message.id,
                                eventSource: n
                            }), y.m.logEvent("chatgpt_copy_to_clipboard")
                        }
                    },
                    deleteThread: function(e) {
                        E(function(t) {
                            delete t.threads[e], delete t.clientNewThreadIdToServerIdMapping[e]
                        })
                    },
                    retainThread: function(e) {
                        E(function(t) {
                            var n;
                            t.threadRetainCounts[e] = (null !== (n = t.threadRetainCounts[e]) && void 0 !== n ? n : 0) + 1
                        }), clearTimeout(Z[e])
                    },
                    releaseThread: function(e) {
                        null != D().threads[e] && (E(function(t) {
                            var n;
                            t.threadRetainCounts[e] = Math.max((null !== (n = t.threadRetainCounts[e]) && void 0 !== n ? n : 0) - 1, 0)
                        }), D().threadRetainCounts[e] > 0 || (clearTimeout(Z[e]), Z[e] = setTimeout(function() {
                            null == D().threads[e] || D().threadRetainCounts[e] > 0 || B.deleteThread(e)
                        }, 3e4)))
                    }
                },
                A = function(e) {
                    var t = (0, u.useRouter)(),
                        n = (0, g.kP)().session,
                        r = (0, d.useContext)(M.QL).historyDisabled,
                        a = (0, d.useContext)(M.gB);
                    (0, s.a)(["conversation", e], function() {
                        return _.ZP.getConversation(e, null == n ? void 0 : n.accessToken)
                    }, {
                        enabled: !I(e) && (null == n ? void 0 : n.accessToken) !== void 0 && !r && !a,
                        onError: function() {
                            t.replace("/"), C.m.danger("Unable to load conversation ".concat(e))
                        },
                        onSuccess: function(t) {
                            t && B.initThreadFromServerData(e, t)
                        }
                    }), (0, d.useEffect)(function() {
                        B.getOrInitThread(e)
                    }, [e, t])
                },
                L = function(e) {
                    return F(function(t) {
                        return I(e) ? t.clientNewThreadIdToServerIdMapping[e] : e
                    })
                },
                U = function(e) {
                    return F(function(t) {
                        var n, r, a = B.resolveThreadId(e);
                        return null !== (r = null === (n = t.threads[a]) || void 0 === n ? void 0 : n.initialThreadData) && void 0 !== r ? r : Object.freeze({
                            thread: m.Cv.createTree(),
                            threadId: null,
                            initialCurrentLeafId: "root",
                            title: null,
                            lastModelUsed: null
                        })
                    })
                },
                O = function(e) {
                    return F(function(t) {
                        var n, r, a = B.resolveThreadId(e);
                        return null !== (r = null === (n = t.threads[a]) || void 0 === n ? void 0 : n.isLoading) && void 0 !== r && r
                    })
                },
                q = function(e) {
                    var t = F(function(t) {
                        var n, r, a = B.resolveThreadId(e);
                        return null === (n = t.threads[a]) || void 0 === n ? void 0 : null === (r = n.initialThreadData) || void 0 === r ? void 0 : r.pluginIds
                    });
                    return (0, d.useMemo)(function() {
                        return null != t ? t : []
                    }, [t])
                },
                z = function(e) {
                    return F(function() {
                        return B.getThreadCurrentLeafId(e)
                    })
                },
                H = function(e) {
                    return F(function() {
                        return B.getThreadModel(e)
                    })
                },
                W = function(e, t) {
                    var n = (0, d.useRef)([]);
                    return F(function() {
                        var r, a = B.getThreadConversationTurns(e, t, n.current);
                        return n.current = a, null !== (r = null == a ? void 0 : a.length) && void 0 !== r ? r : 0
                    })
                },
                V = function(e, t) {
                    var n = (0, d.useRef)([]);
                    return F(function() {
                        var r = B.getThreadConversationTurns(e, t, n.current);
                        return n.current = r, r
                    })
                },
                Q = function(e, t, n) {
                    var r = (0, d.useRef)([]);
                    return F(function() {
                        var a = B.getThreadConversationTurns(e, n, r.current);
                        return r.current = a, a[t]
                    })
                },
                G = function(e) {
                    var t = z(e);
                    return (0, d.useMemo)(function() {
                        var n, r, a = B.getThreadConversationTurns(e, t, []),
                            i = null !== (n = null == a ? void 0 : a.length) && void 0 !== n ? n : 0,
                            o = null !== (r = null == a ? void 0 : a[i - 1]) && void 0 !== r ? r : null;
                        return 0 === i ? t : m.Cv.getRequestIdFromConversationTurn(o)
                    }, [t, e])
                },
                $ = function(e) {
                    return F(function() {
                        return B.getTitle(e)
                    })
                },
                Y = function(e) {
                    return F(function() {
                        return B.getTitleAndSource(e)
                    })
                },
                J = function(e) {
                    return F(function() {
                        var t, n = B.resolveThreadId(e);
                        return null === (t = D().threads[n]) || void 0 === t ? void 0 : t.continuingFromSharedConversationId
                    })
                },
                K = function(e) {
                    return F(function() {
                        var t, n, r = B.resolveThreadId(e);
                        return null === (t = D().threads[r]) || void 0 === t ? void 0 : null === (n = t.initialThreadData) || void 0 === n ? void 0 : n.authorName
                    })
                },
                X = function(e, t) {
                    return F(function() {
                        return B.getTree(e).getNode(t)
                    })
                },
                ee = function(e, t) {
                    return F(function() {
                        var n, r;
                        return null !== (r = null === (n = B.getTree(e)) || void 0 === n ? void 0 : n.getHasErrorFromNode(t)) && void 0 !== r && r
                    })
                },
                et = function(e, t) {
                    return F(function() {
                        var n, r;
                        return null !== (r = null === (n = B.getTree(e)) || void 0 === n ? void 0 : n.isMessageIncomplete(t)) && void 0 !== r && r
                    })
                },
                en = function(e, t) {
                    return F(function() {
                        var n = B.getTree(e);
                        return null == n ? [] : n.getBranchFromLeaf(t).filter(function(e) {
                            return e.type !== w.Jq.Root
                        }).map(function(e) {
                            return e.message
                        })
                    })
                },
                er = function(e) {
                    var t = B.getTree(e).getUserContext();
                    if (null == t) return null;
                    var n = t.message,
                        r = null !== (o = null === (a = n.metadata) || void 0 === a ? void 0 : a.shared_conversation_id) && void 0 !== o ? o : null;
                    if ((null === (i = n.metadata) || void 0 === i ? void 0 : i.user_context_message_data) != null) {
                        var a, i, o, s, l, u = n.metadata.user_context_message_data,
                            d = u.about_user_message,
                            c = u.about_model_message;
                        return {
                            aboutUserMessage: null !== (s = null == d ? void 0 : d.trim()) && void 0 !== s ? s : "",
                            aboutModelMessage: null !== (l = null == c ? void 0 : c.trim()) && void 0 !== l ? l : "",
                            fallback: null,
                            shareId: r
                        }
                    }
                    return {
                        aboutUserMessage: null,
                        aboutModelMessage: null,
                        fallback: (0, T.RR)(n),
                        shareId: r
                    }
                },
                ea = function(e) {
                    var t = F(function(t) {
                        var n, r, a = B.resolveThreadId(e);
                        return null === (n = t.threads[a]) || void 0 === n ? void 0 : null === (r = n.initialThreadData) || void 0 === r ? void 0 : r.hasUserEditableContextFlag
                    });
                    return null != er(e) || !!t
                },
                ei = function(e) {
                    return F(function() {
                        var t, n = B.resolveThreadId(e);
                        return (null === (t = D().threads[n]) || void 0 === t ? void 0 : t.continuingFromSharedConversationId) != null
                    })
                },
                eo = function(e) {
                    var t, n, r, a = U(e),
                        i = null !== (r = null == a ? void 0 : null === (t = a.model) || void 0 === t ? void 0 : t.id) && void 0 !== r ? r : null == a ? void 0 : a.lastModelUsed,
                        o = (0, k.B9)(),
                        s = void 0 != i ? o.get(i) : void 0;
                    return (null === (n = null == s ? void 0 : s.product_features.attachments) || void 0 === n ? void 0 : n.type) === j.Cd.Multimodal
                }
        },
        54118: function(e, t, n) {
            n.d(t, {
                DN: function() {
                    return M
                },
                Fl: function() {
                    return T
                },
                N2: function() {
                    return _
                },
                tr: function() {
                    return a
                }
            });
            var r, a, i, o = n(96237),
                s = n(39324),
                l = n(71209),
                u = n(22830),
                d = n(13995),
                c = n(5268),
                f = n(70079),
                g = n(78103),
                h = n(62509),
                m = n(6948),
                p = n(99486),
                v = n(32877),
                x = n(46020),
                b = n(78931),
                y = {
                    isBetaFeaturesUiEnabled: !1,
                    isBrowsingAvailable: !1,
                    isBrowsingEnabled: !1,
                    isChatPreferencesAvailable: !1,
                    isChatPreferencesEnabled: !1,
                    isPluginsAvailable: !1,
                    isPluginsEnabled: !1,
                    isCodeInterpreterAvailable: !1,
                    isCodeInterpreterEnabled: !1
                };
            (r = a || (a = {})).BROWSING = "browsing", r.CODE_INTERPRETER = "code_interpreter", r.PLUGINS = "plugins", r.CHAT_PREFERENCES = "chat_preferences";
            var j = (i = {}, (0, o._)(i, a.BROWSING, "isBrowsingEnabled"), (0, o._)(i, a.CODE_INTERPRETER, "isCodeInterpreterEnabled"), (0, o._)(i, a.PLUGINS, "isPluginsEnabled"), (0, o._)(i, a.CHAT_PREFERENCES, "isChatPreferencesEnabled"), i),
                w = (0, g.ZP)()(function() {
                    return y
                }),
                C = {
                    updateUserSettings: function(e) {
                        w.setState(function(t) {
                            return (0, s._)({}, t, e)
                        })
                    },
                    updateUserSettingsFromFeatures: function(e) {
                        w.setState(function(t) {
                            var n = C.getUserSettingsFromFeatures(e, t);
                            return (0, s._)({}, t, n)
                        })
                    },
                    getUserSettingsFromFeatures: function(e, t) {
                        return Object.entries(e).reduce(function(e, n) {
                            var r = (0, u._)(n, 2),
                                a = r[0],
                                i = r[1],
                                d = j[a],
                                c = !1;
                            return (("isBrowsingEnabled" === d && t.isBrowsingAvailable || "isCodeInterpreterEnabled" === d && t.isCodeInterpreterAvailable || "isPluginsEnabled" === d && t.isPluginsAvailable || "isChatPreferencesEnabled" === d && t.isChatPreferencesAvailable) && (c = i), d) ? (0, l._)((0, s._)({}, e), (0, o._)({}, d, c)) : e
                        }, {})
                    }
                },
                k = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return ["userSettings", e]
                };

            function _() {
                var e = (0, h.kP)().session,
                    t = (0, d.NL)();
                return function() {
                    return t.invalidateQueries({
                        queryKey: k(null == e ? void 0 : e.accessToken)
                    })
                }
            }
            var M = "oai/apps/hasSeenBrowsingDisabledJuly2023";

            function T() {
                var e = (0, h.kP)().session,
                    t = (0, b.hz)(),
                    n = t.has("beta_features"),
                    r = (0, b.ec)(b.F_.isBusinessWorkspace);
                return (0, c.a)(k(null == e ? void 0 : e.accessToken), function() {
                    return p.ZP.getUserSettingBetaFeatures(e.accessToken).then(function(e) {
                        null != e && C.updateUserSettingsFromFeatures(e);
                        var t = !!m.m.getItem(M);
                        return e.browsing && !t && x.vm.openModal(x.B.TempBrowseToast), e
                    })
                }, {
                    enabled: n && (null == e ? void 0 : e.accessToken) != null
                }), (0, f.useEffect)(function() {
                    C.updateUserSettings({
                        isBetaFeaturesUiEnabled: n,
                        isBrowsingAvailable: !r && (null == e ? void 0 : e.user) != null && (0, h.yl)(null == e ? void 0 : e.user),
                        isCodeInterpreterAvailable: !r && (t.has("code_interpreter_available") || t.has("tools2")),
                        isPluginsAvailable: !r && (t.has("plugins_available") || t.has("tools3")),
                        isChatPreferencesAvailable: !r && (t.has(v.uo) || t.has("chat_preferences_available"))
                    })
                }, [t, n, r, null == e ? void 0 : e.user]), w(function(e) {
                    return e
                })
            }
        },
        52738: function(e, t, n) {
            n.d(t, {
                Op: function() {
                    return h
                },
                Qd: function() {
                    return c
                },
                T$: function() {
                    return f
                },
                s8: function() {
                    return g
                }
            });
            var r = n(35250),
                a = n(1454),
                i = n(45635),
                o = n(1568),
                s = n(63031),
                l = n(88327),
                u = "&#8203;",
                d = "oaicite:";

            function c(e, t) {
                if (!t) return e;
                for (var n = [], r = 1, a = {}, i = 0; i < t.length; i++) {
                    var o = t[i],
                        s = o.metadata,
                        l = o.invalid_reason;
                    if (s) {
                        var c = m(s);
                        null == a[c] && (a[c] = r, r++), n.push(a[c])
                    } else null != l && (n.push(r), r++)
                }
                for (var f = t.length - 1; f >= 0; f--) {
                    var g = t[f],
                        h = g.start_ix,
                        p = g.end_ix,
                        v = g.metadata,
                        x = g.invalid_reason,
                        b = {
                            number: n[f]
                        };
                    v ? b.metadata = v : null != x && (b.invalid_reason = x);
                    var y = !1;
                    if (f > 0) {
                        var j = t[f - 1];
                        null != j.metadata && null != v && m(j.metadata) === m(v) && 0 === e.slice(j.end_ix, g.start_ix).trim().length && (e = e.slice(0, j.end_ix) + e.slice(g.end_ix), y = !0)
                    }
                    y || (e = e.slice(0, h) + "".concat(u, "``").concat(d).concat(JSON.stringify(b), "``").concat(u) + e.slice(p))
                }
                return e
            }

            function f(e) {
                if (!e.startsWith(d)) return null;
                try {
                    return JSON.parse(e.slice(d.length))
                } catch (e) {
                    return {
                        number: -1
                    }
                }
            }

            function g(e) {
                var t = e.displayInfo,
                    n = (0, s.O6)(),
                    a = t.metadata,
                    o = (null == a ? void 0 : a.type) === "file";
                return (0, r.jsx)(i.u, {
                    label: (0, r.jsx)(h, {
                        citationMetadata: a,
                        invalidReason: t.invalid_reason
                    }),
                    side: "top",
                    sideOffset: 4,
                    withArrow: !1,
                    interactive: !0,
                    wide: !0,
                    children: o ? (0, r.jsx)("button", {
                        onClick: function() {
                            return n(a.id, a.name)
                        },
                        className: "px-0.5 text-green-600",
                        children: (0, r.jsx)("sup", {
                            children: t.number
                        })
                    }) : (0, r.jsx)("a", {
                        href: null == a ? void 0 : a.url,
                        target: "_blank",
                        rel: "noreferrer",
                        className: "px-0.5 text-green-600 !no-underline",
                        children: (0, r.jsx)("sup", {
                            children: t.number
                        })
                    })
                })
            }

            function h(e) {
                var t = e.citationMetadata,
                    n = e.invalidReason,
                    i = e.onClick,
                    u = (0, s.O6)(),
                    d = (null == t ? void 0 : t.type) === "file",
                    c = t ? (0, r.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, r.jsx)("div", {
                            className: "flex shrink-0 items-center justify-center",
                            children: d ? (0, r.jsx)(a.NOg, {}) : (0, r.jsx)(o.Z, {
                                url: t.url,
                                className: "my-0"
                            })
                        }), (0, r.jsx)("div", {
                            className: "max-w-xs truncate",
                            children: d ? t.name : t.title
                        }), (0, r.jsx)("div", {
                            className: "shrink-0",
                            children: (0, r.jsx)(l.ZP, {
                                icon: a.AlO,
                                size: "xsmall"
                            })
                        })]
                    }) : (0, r.jsx)("div", {
                        className: "text-red-500",
                        children: null != n ? n : "Invalid citation"
                    });
                return d ? (0, r.jsx)("button", {
                    onClick: function() {
                        u(t.id, t.name), null == i || i()
                    },
                    className: "text-xs",
                    children: c
                }) : (0, r.jsx)("a", {
                    href: null == t ? void 0 : t.url,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "text-xs !no-underline",
                    onClick: i,
                    children: c
                })
            }

            function m(e) {
                return "file" === e.type ? e.id : e.url
            }
        },
        26948: function(e, t, n) {
            n.d(t, {
                A3: function() {
                    return T
                },
                CN: function() {
                    return N
                },
                yx: function() {
                    return S
                }
            });
            var r, a, i, o = n(96237),
                s = n(39324),
                l = n(81949),
                u = n(63605),
                d = n(15858),
                c = n(61888),
                f = n(70079),
                g = n(11084),
                h = n(82534),
                m = n(50795),
                p = n(82081),
                v = n(95954),
                x = n(43019),
                b = n(32877),
                y = n(31621),
                j = n(46020),
                w = n(78931),
                C = n(52787),
                k = RegExp("```.*?\\n([\\s\\S]+?)\\n?```[^`]*$", "gms");
            (r = a || (a = {})).Core = "Core", r.Chat = "Chat", r.Settings = "Settings";
            var _ = (0, s._)({
                    Mod: "mod",
                    Comma: ","
                }, d.s),
                M = (i = {}, (0, o._)(i, _.Mod, /Mac|iPod|iPhone|iPad/.test(window.navigator.platform) ? "⌘" : "⌃"), (0, o._)(i, _.Comma, ","), (0, o._)(i, _.Enter, "⏎"), (0, o._)(i, _.Escape, "Esc"), (0, o._)(i, _.ArrowUp, "↑"), (0, o._)(i, _.ArrowDown, "↓"), (0, o._)(i, _.ArrowLeft, "←"), (0, o._)(i, _.ArrowRight, "→"), (0, o._)(i, _.Backspace, "⌫"), (0, o._)(i, _.Delete, "⌦"), (0, o._)(i, _.Tab, "⇥"), (0, o._)(i, _.Alt, "⌥"), (0, o._)(i, _.Control, "⌃"), (0, o._)(i, _.Shift, "⇧"), i),
                T = function(e) {
                    var t;
                    return e.map(function(e) {
                        return null !== (t = M[e]) && void 0 !== t ? t : e
                    })
                },
                N = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = e.resetThreadAction,
                        n = e.clientThreadId;
                    return [{
                        key: "newChat",
                        action: t || c.noop,
                        text: "Create new chat",
                        group: a.Core,
                        keyboardBinding: [_.Mod, _.Alt, "n"]
                    }, {
                        key: "focusPromptTextarea",
                        action: x.go,
                        text: "Focus chat input",
                        group: a.Chat,
                        keyboardBinding: [_.Shift, _.Escape]
                    }, {
                        key: "toggleCustomInstructions",
                        action: function() {
                            return j.vm.toggleModal(j.B.UserContext)
                        },
                        text: "Open custom instructions",
                        group: a.Settings,
                        keyboardBinding: [_.Mod, "i"]
                    }, {
                        key: "copyLastResponse",
                        action: function() {
                            n && y.tQ.copyLastMessageToClipboard(n, "keyboard")
                        },
                        text: "Copy last response",
                        group: a.Chat,
                        keyboardBinding: [_.Mod, _.Shift, "c"]
                    }, {
                        key: "copyLastCodeBlock",
                        action: function() {
                            if (n)
                                for (var e = y.tQ.getThreadCurrentLeafId(n), t = y.tQ.getThreadConversationTurns(n, e), r = t.length - 1; r >= 0; r--) {
                                    var a = t[r].messages.reduce(function(e, t) {
                                            return t.err || t.message.author.role !== v.uU.Assistant || "all" !== t.message.recipient ? e : e + (e ? "\n\n" : "") + (0, C.RR)(t.message)
                                        }, ""),
                                        i = (0, l._)(a.matchAll(k)),
                                        o = i.length ? i[i.length - 1][1] : null;
                                    if (null != o) {
                                        (0, g.S)(o);
                                        break
                                    }
                                }
                        },
                        text: "Copy last code block",
                        group: a.Chat,
                        keyboardBinding: [_.Mod, ";"]
                    }, {
                        key: "toggleSettings",
                        action: function() {
                            return j.vm.toggleModal(j.B.Settings)
                        },
                        text: "Open general settings",
                        group: a.Settings,
                        keyboardBinding: [_.Mod, "g"]
                    }, {
                        key: "navigationToggle",
                        action: function() {
                            return j.vm.toggleDesktopNavCollapsed()
                        },
                        text: "Toggle sidebar",
                        group: a.Core,
                        keyboardBinding: [_.Mod, _.Alt, "s"]
                    }, {
                        key: "deleteChat",
                        action: function() {
                            return j.vm.toggleModal(j.B.DeleteChatConfirmation)
                        },
                        text: "Delete chat",
                        group: a.Chat,
                        keyboardBinding: [_.Mod, _.Alt, _.Backspace],
                        altKeyboardBindings: [
                            [_.Mod, _.Alt, _.Delete]
                        ]
                    }, {
                        key: "toggleKeyboardActions",
                        action: function() {
                            return j.vm.toggleModal(j.B.KeyboardActions)
                        },
                        text: "Show shortcuts",
                        group: a.Settings,
                        keyboardBinding: [_.Mod, "/"]
                    }]
                },
                P = function(e) {
                    var t = e.keyboardBinding,
                        n = e.action,
                        r = (0, w.hz)().has(b.rk),
                        a = t.join("+");
                    return e.altKeyboardBindings && e.altKeyboardBindings.forEach(function(e) {
                        a += ", ".concat(e.join("+"))
                    }), (0, u.y1)(a, function() {
                        m.o.logEvent(p.a.keyboardShortcut, {
                            keyboardActionKey: e.key
                        }), h.U.addAction("chatgpt_keyboard_shortcut", {
                            keyboardActionKey: e.key
                        }), n()
                    }, {
                        enabled: r,
                        preventDefault: !0,
                        enableOnFormTags: ["input", "select", "textarea"]
                    })
                },
                S = function(e) {
                    var t = e.resetThreadAction,
                        n = e.clientThreadId,
                        r = (0, f.useMemo)(function() {
                            return N({
                                resetThreadAction: t,
                                clientThreadId: n
                            })
                        }, [t, n]);
                    P(r[0]), P(r[1]), P(r[2]), P(r[3]), P(r[4]), P(r[5]), P(r[6]), P(r[7]), P(r[8])
                }
        },
        52787: function(e, t, n) {
            n.d(t, {
                Cs: function() {
                    return a
                },
                Ej: function() {
                    return m
                },
                JD: function() {
                    return c
                },
                RR: function() {
                    return h
                },
                Rc: function() {
                    return g
                },
                fj: function() {
                    return p
                },
                lD: function() {
                    return d
                },
                oH: function() {
                    return u
                },
                qi: function() {
                    return l
                },
                qs: function() {
                    return f
                },
                rH: function() {
                    return s
                }
            });
            var r, a, i = n(22830),
                o = n(95954);

            function s(e) {
                if (e.author.role === o.uU.Assistant) {
                    if ("browser" === e.recipient || "browser_one_box" === e.recipient || "wiki_browser" == e.recipient) return a.Browsing;
                    if ("myfiles_browser" === e.recipient) return a.RetrievalBrowsing;
                    if ("browsing_team" === e.recipient) return a.ParallelBrowsing;
                    if ("python" === e.recipient) return a.Code;
                    else if (null != p(e.recipient)) return a.Plugin
                } else if (e.author.role === o.uU.Tool) {
                    if ("browser" === e.author.name || "browser_one_box" === e.author.name || "wiki_browser" == e.author.name) return a.BrowseTool;
                    if ("myfiles_browser" === e.author.name) return a.RetrievalBrowsingTool;
                    if ("browsing_team" === e.author.name) return a.ParallelBrowsingTool;
                    if (e.content.content_type === o.PX.ExecutionOutput) return a.CodeExecutionOutput;
                    else if (null != p(e.author.name) || "plugin_service" === e.author.name) return a.PluginTool
                } else if (e.author.role === o.uU.User && e.content.content_type === o.PX.UserEditableContext) return a.UserEditableContext;
                return e.content.content_type === o.PX.Text || e.content.content_type === o.PX.MultimodalText ? a.Text : a.Unknown
            }

            function l(e) {
                var t;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : t.finish_details) != null
            }

            function u(e) {
                var t, n;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : null === (n = t.finish_details) || void 0 === n ? void 0 : n.type) === "stop"
            }

            function d(e) {
                var t, n;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : null === (n = t.finish_details) || void 0 === n ? void 0 : n.type) === "max_tokens"
            }

            function c(e) {
                var t, n;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : null === (n = t.finish_details) || void 0 === n ? void 0 : n.type) === "interrupted"
            }

            function f(e) {
                var t;
                return (null === (t = e.metadata) || void 0 === t ? void 0 : t.message_type) === "continue"
            }

            function g(e) {
                var t;
                return null === (t = e.metadata) || void 0 === t ? void 0 : t.model_slug
            }

            function h(e) {
                switch (e.content.content_type) {
                    case o.PX.Text:
                        return e.content.parts.join("");
                    case o.PX.MultimodalText:
                        return e.content.parts.map(function(e) {
                            return "string" == typeof e ? e : '[media pointer="'.concat(e.asset_pointer, '"]')
                        }).join("\n");
                    case o.PX.TetherBrowsingDisplay:
                        return e.content.result;
                    case o.PX.TetherQuote:
                    case o.PX.TetherBrowsingCode:
                    case o.PX.Code:
                    case o.PX.ExecutionOutput:
                    case o.PX.SystemError:
                    case "system_error":
                        return e.content.text;
                    case o.PX.SystemMessage:
                        var t = e.content.text,
                            n = !0,
                            r = !1,
                            a = void 0;
                        try {
                            for (var i, s = Object.values(e.content.tools_section)[Symbol.iterator](); !(n = (i = s.next()).done); n = !0) {
                                var l = i.value;
                                t += "\n\n".concat(l)
                            }
                        } catch (e) {
                            r = !0, a = e
                        } finally {
                            try {
                                n || null == s.return || s.return()
                            } finally {
                                if (r) throw a
                            }
                        }
                        return t;
                    case o.PX.UserEditableContext:
                        return "".concat(e.content.user_profile, "\n").concat(e.content.user_instructions);
                    default:
                        return ""
                }
            }

            function m(e) {
                var t;
                return null !== (t = e.recipient) && void 0 !== t ? t : ""
            }

            function p(e) {
                if (null == e || !e.includes(".")) return null;
                var t = (0, i._)(e.split("."), 2);
                return {
                    pluginNamespace: t[0],
                    pluginFunctionName: t[1]
                }
            }(r = a || (a = {}))[r.Text = 0] = "Text", r[r.Browsing = 1] = "Browsing", r[r.BrowseTool = 2] = "BrowseTool", r[r.Code = 3] = "Code", r[r.CodeExecutionOutput = 4] = "CodeExecutionOutput", r[r.MultimodalText = 5] = "MultimodalText", r[r.Plugin = 6] = "Plugin", r[r.PluginTool = 7] = "PluginTool", r[r.RetrievalBrowsing = 8] = "RetrievalBrowsing", r[r.RetrievalBrowsingTool = 9] = "RetrievalBrowsingTool", r[r.ParallelBrowsing = 10] = "ParallelBrowsing", r[r.ParallelBrowsingTool = 11] = "ParallelBrowsingTool", r[r.UserEditableContext = 12] = "UserEditableContext", r[r.Unknown = 13] = "Unknown"
        },
        77370: function(e, t, n) {
            n.d(t, {
                Cv: function() {
                    return T
                },
                Vh: function() {
                    return j
                },
                uV: function() {
                    return C
                }
            });
            var r, a, i = n(51217),
                o = n(53596),
                s = n(66816),
                l = n(49406),
                u = n(31819),
                d = n(96237),
                c = n(39324),
                f = n(70216),
                g = n(81949),
                h = n(74050),
                m = n(84251),
                p = n.n(m),
                v = n(8844),
                x = n(16600),
                b = n(95954),
                y = n(52787),
                j = "request-",
                w = (r = {}, (0, d._)(r, b.Jq.Root, b.uU.Unknown), (0, d._)(r, b.Jq.Prompt, b.uU.User), (0, d._)(r, b.Jq.Completion, b.uU.Assistant), (0, d._)(r, b.Jq.System, b.uU.System), r),
                C = (a = {}, (0, d._)(a, b.uU.Unknown, b.Jq.Root), (0, d._)(a, b.uU.System, b.Jq.System), (0, d._)(a, b.uU.User, b.Jq.Prompt), (0, d._)(a, b.uU.Assistant, b.Jq.Completion), (0, d._)(a, b.uU.Critic, b.Jq.Completion), (0, d._)(a, b.uU.Tool, b.Jq.Completion), a);

            function k(e) {
                var t = (0, v.Z)();
                return "".concat(e).concat(t.substring(e.length))
            }
            var _ = new WeakMap,
                M = new WeakMap,
                T = function() {
                    function e(t) {
                        (0, i._)(this, e), (0, s._)(this, _, {
                            writable: !0,
                            value: void 0
                        }), (0, s._)(this, M, {
                            writable: !0,
                            value: void 0
                        }), (0, l._)(this, _, null != t ? t : e.createTree());
                        var n, r = Object.values((0, o._)(this, _)).find(function(e) {
                            return e.type === b.Jq.Root
                        });
                        (0, l._)(this, M, null !== (n = null == r ? void 0 : r.id) && void 0 !== n ? n : "root")
                    }
                    var t = e.prototype;
                    return t.getNode = function(e) {
                        return (0, o._)(this, _)[e]
                    }, t.getMessage = function(e) {
                        return (0, o._)(this, _)[e].message
                    }, t.getMessageId = function(e) {
                        try {
                            return (0, o._)(this, _)[e].message.id
                        } catch (t) {
                            throw console.error("Tree: Unable to getMessageId for node ".concat(e)), t
                        }
                    }, t.getMetadata = function(e) {
                        return (0, o._)(this, _)[e].metadata
                    }, t.getLeafFromNode = function(e) {
                        for (var t = (0, o._)(this, _)[e];;) {
                            if (0 === t.children.length) return t;
                            t = (0, o._)(this, _)[t.children.values().next().value]
                        }
                    }, t.getParent = function(e) {
                        var t = (0, o._)(this, _)[e].parentId;
                        return (0, o._)(this, _)[t]
                    }, t.getParentId = function(e) {
                        var t;
                        return (null === (t = this.getParent(e)) || void 0 === t ? void 0 : t.id) || "root"
                    }, t.getNodeByMessageId = function(e) {
                        var t = !0,
                            n = !1,
                            r = void 0;
                        try {
                            for (var a, i = Object.values((0, o._)(this, _))[Symbol.iterator](); !(t = (a = i.next()).done); t = !0) {
                                var s = a.value;
                                if (s.message.id === e) return s
                            }
                        } catch (e) {
                            n = !0, r = e
                        } finally {
                            try {
                                t || null == i.return || i.return()
                            } finally {
                                if (n) throw r
                            }
                        }
                    }, t.getBranchFromLeaf = function(e) {
                        for (var t, n = [], r = null !== (t = (0, o._)(this, _)[e]) && void 0 !== t ? t : this.getNodeByMessageId(e); null != r;) {
                            if (n.includes(r)) {
                                console.error("Infinite loop detected in getBranchFromLeaf.");
                                break
                            }
                            if (n.push(r), "root" === r.type) break;
                            r = (0, o._)(this, _)[r.parentId]
                        }
                        return n.reverse()
                    }, t.getChildrenFromNode = function(e) {
                        var t = this,
                            n = (0, o._)(this, _)[e];
                        return null == n ? [] : Array.from(n.children).map(function(e) {
                            return (0, o._)(t, _)[e]
                        })
                    }, t.getFirstPrompt = function() {
                        for (var e, t, n = this.getNode((0, o._)(this, M));;) {
                            if (null == n) return;
                            if (n.type === b.Jq.Prompt || n.type === b.Jq.System && (null === (e = n.message.metadata) || void 0 === e ? void 0 : e.upload_filename)) return n;
                            n = (0, o._)(this, _)[null === (t = n.children) || void 0 === t ? void 0 : t[0]]
                        }
                    }, t.getUserContext = function() {
                        for (var e, t, n = this.getNode((0, o._)(this, M));;) {
                            if (null == n) return;
                            if (null === (e = n.message.metadata) || void 0 === e ? void 0 : e.is_user_system_message) return n;
                            if (n.type === b.Jq.Prompt) return null;
                            n = (0, o._)(this, _)[null === (t = n.children) || void 0 === t ? void 0 : t[0]]
                        }
                    }, t.isMessageIncomplete = function(e) {
                        var t = this.getMessage(e);
                        return (0, y.lD)(t)
                    }, t.addNodeToEnd = function(e, t) {
                        if (null == (0, o._)(this, _)[e]) return (0, d._)({}, t.id, t);
                        (0, l._)(this, _, p()((0, o._)(this, _), (0, d._)({
                            $merge: (0, d._)({}, t.id, t)
                        }, e, {
                            children: {
                                $apply: function(e) {
                                    return Array.from(new Set((0, g._)(e).concat([t.id])))
                                }
                            }
                        })))
                    }, t.appendSystemMessageToRoot = function(e) {
                        var t, n, r = null === (t = this.getFirstPrompt()) || void 0 === t ? void 0 : t.parentId;
                        if (null != r) {
                            var a = this.getNode(r),
                                i = this.getNode(a.children[0]),
                                s = {
                                    id: e.id,
                                    children: a.children,
                                    parentId: a.id,
                                    message: e
                                };
                            (0, l._)(this, _, p()((0, o._)(this, _), (n = {
                                $merge: (0, d._)({}, s.id, s)
                            }, (0, d._)(n, a.id, {
                                children: {
                                    $set: [s.id]
                                }
                            }), (0, d._)(n, i.id, {
                                parentId: {
                                    $set: s.id
                                }
                            }), n)))
                        }
                    }, t.addNode = function(t, n, r, a, i, o) {
                        var s = "string" == typeof n ? e.getTextAsMessage(n, a, o) : "content_type" in n ? e.getContentAsMessage(n, a, o) : n,
                            l = (0, c._)({
                                id: t,
                                children: [],
                                parentId: r,
                                type: a,
                                message: s
                            }, i ? {
                                nodeMetadata: i
                            } : {});
                        this.addNodeToEnd(r, l)
                    }, t.updateNode = function(e, t) {
                        (0, l._)(this, _, p()((0, o._)(this, _), (0, d._)({}, e, t)))
                    }, t.updateNodeMessage = function(e, t) {
                        (0, l._)(this, _, p()((0, o._)(this, _), (0, d._)({}, e, {
                            message: {
                                $set: t
                            }
                        })))
                    }, t.updateNodeMessageMetadata = function(e, t) {
                        (0, l._)(this, _, p()((0, o._)(this, _), (0, d._)({}, e, {
                            message: {
                                metadata: {
                                    $merge: t
                                }
                            }
                        })))
                    }, t.updateNodeText = function(e, t) {
                        (0, l._)(this, _, p()((0, o._)(this, _), (0, d._)({}, e, {
                            message: {
                                content: {
                                    parts: {
                                        $set: [t]
                                    }
                                }
                            }
                        })))
                    }, t.deleteNode = function(e) {
                        var t = (0, o._)(this, _),
                            n = t[e],
                            r = (0, f._)(t, [e].map(h._)),
                            a = n.parentId;
                        (0, l._)(this, _, p()(r, (0, d._)({}, a, {
                            children: {
                                $apply: function(t) {
                                    return t.filter(function(t) {
                                        return t !== e
                                    })
                                }
                            }
                        })))
                    }, t.getTextFromNode = function(e) {
                        return (0, y.RR)(this.getMessage(e))
                    }, t.getHasErrorFromNode = function(e) {
                        var t, n, r = this.getNode(e);
                        return (null == r ? void 0 : null === (t = r.metadata) || void 0 === t ? void 0 : t.errType) === "danger" || (null == r ? void 0 : null === (n = r.metadata) || void 0 === n ? void 0 : n.errType) === "warning"
                    }, t.getIsBlockedFromNode = function(e) {
                        var t, n, r = this.getNode(e);
                        return (null == r ? void 0 : null === (t = r.metadata) || void 0 === t ? void 0 : t.errCode) === x.Dd && (null == r ? void 0 : null === (n = r.metadata) || void 0 === n ? void 0 : n.errType) === "danger"
                    }, t.getTextFromThread = function(e) {
                        return this.getBranchFromLeaf(e).filter(function(e) {
                            return e.type !== b.Jq.Root && e.type !== b.Jq.System
                        }).map(function(e) {
                            return (0, y.RR)(e.message)
                        }).join("\n\n")
                    }, t.shouldFilterNode = function(e) {
                        var t = e.message,
                            n = t.content.content_type,
                            r = e.message.author.role === b.uU.System,
                            a = e.message.author.role === b.uU.Tool,
                            i = void 0 !== t.recipient && "all" !== t.recipient;
                        return r || i || a && !("code" === n || "execution_output" === n || "system_error" === n || "tether_browsing_display" === n || "tether_quote" === n)
                    }, t.getTextFromTurnsById = function(e) {
                        var t = this;
                        return e.map(function(e) {
                            return t.getNode(e)
                        }).filter(function(e) {
                            return !t.shouldFilterNode(e)
                        }).map(function(e) {
                            return t.getTextFromNode(e.id)
                        }).join("\n\n")
                    }, t.getTextFromLastNTurns = function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                        return this.getConversationTurns(e, this.shouldFilterNode).slice(-t).map(function(e) {
                            var t = e.messages.map(function(e) {
                                return (0, y.RR)(e.message)
                            }).filter(function(e) {
                                return "" !== e
                            }).join("\n");
                            return n ? "[".concat(e.role, "]\n").concat(t) : t
                        }).join("\n")
                    }, t.getConversationTurns = function(e, t) {
                        var n = this,
                            r = [];
                        return this.getBranchFromLeaf(e).forEach(function(e) {
                            var a = e.id,
                                i = e.parentId,
                                s = e.message,
                                l = e.metadata;
                            if (null == t || !t(e)) {
                                var u = r[r.length - 1];
                                (null == u ? void 0 : u.role) === s.author.role || s.author.role === b.uU.Tool ? r[r.length - 1].messages.push((0, c._)({
                                    nodeId: a,
                                    parentId: i,
                                    message: s
                                }, l)) : r.push({
                                    role: s.author.role,
                                    messages: [(0, c._)({
                                        nodeId: a,
                                        parentId: i,
                                        message: s
                                    }, l)],
                                    variantIds: i ? Array.from((0, o._)(n, _)[i].children) : [a]
                                })
                            }
                        }), r
                    }, t.getLastValidNode = function(e) {
                        for (var t, n = this.getNode(e); null != n && null != n && (null === (t = n.metadata) || void 0 === t ? void 0 : t.err) != null;) n = this.getNode(n.parentId);
                        return n
                    }, t.getParentPromptNode = function(e) {
                        for (var t, n = this.getNode(e); null != n && null != n && (null === (t = n.message) || void 0 === t ? void 0 : t.author.role) !== b.uU.User;) n = this.getNode(n.parentId);
                        return n
                    }, t.messageIdToNodeId = function(e) {
                        if (null != (0, o._)(this, _)[e]) return e;
                        var t = !0,
                            n = !1,
                            r = void 0;
                        try {
                            for (var a, i = Object.values((0, o._)(this, _))[Symbol.iterator](); !(t = (a = i.next()).done); t = !0) {
                                var s, l = a.value;
                                if ((null === (s = l.message) || void 0 === s ? void 0 : s.id) === e) return l.id
                            }
                        } catch (e) {
                            n = !0, r = e
                        } finally {
                            try {
                                t || null == i.return || i.return()
                            } finally {
                                if (n) throw r
                            }
                        }
                        return e
                    }, t.unstable_getMapping = function() {
                        return (0, o._)(this, _)
                    }, e.createTree = function() {
                        return {
                            root: {
                                id: "root",
                                children: [],
                                parentId: "",
                                type: b.Jq.Root,
                                message: e.createRootMessage()
                            }
                        }
                    }, e.createRootMessage = function() {
                        return {
                            id: k("aaa1"),
                            author: {
                                role: w[b.Jq.Root]
                            },
                            content: {
                                content_type: b.PX.Text,
                                parts: []
                            }
                        }
                    }, e.getRequestIdFromConversationTurn = function(e) {
                        for (var t = e.messages.length - 1; t >= 0; t--) {
                            var n = e.messages[t];
                            if (n.nodeId.startsWith(j)) return n.nodeId
                        }
                        return e.messages[0].nodeId
                    }, e.getTextAsMessage = function(e, t, n) {
                        var r = {
                            content_type: b.PX.Text,
                            parts: [e]
                        };
                        return this.getContentAsMessage(r, t, n)
                    }, e.getContentAsMessage = function(e, t, n) {
                        return {
                            id: k("aaa2"),
                            author: {
                                role: w[t]
                            },
                            content: e,
                            metadata: n
                        }
                    }, (0, u._)(e, [{
                        key: "isFirstCompletion",
                        get: function() {
                            var e = this.getFirstPrompt();
                            if (e) {
                                var t = (0, o._)(this, _)[e.children[0]];
                                if ((null == t ? void 0 : t.children.length) === 0) return !0
                            }
                            return !1
                        }
                    }]), e
                }()
        },
        19012: function(e, t, n) {
            var r = n(70079);
            t.Z = function() {
                var e = (0, r.useRef)(!1);
                return (0, r.useEffect)(function() {
                    return e.current = !0,
                        function() {
                            e.current = !1
                        }
                }, []), (0, r.useCallback)(function() {
                    return e.current
                }, [])
            }
        },
        21817: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(70079);

            function a() {
                var e = (0, r.useRef)([]),
                    t = (0, r.useRef)(function(t, n) {
                        var r = setTimeout(t, n);
                        return e.current.push(r), r
                    });
                return (0, r.useEffect)(function() {
                    var t = e.current;
                    return function() {
                        t.forEach(function(e) {
                            clearTimeout(e)
                        })
                    }
                }, []), t.current
            }
        },
        11084: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return i
                }
            });
            var r = n(88798);

            function a() {
                r.m.danger("Failed to copy to clipboard.", {
                    duration: 4,
                    hasCloseButton: !0
                })
            }

            function i(e) {
                if ("undefined" == typeof navigator || !navigator.clipboard) {
                    a();
                    return
                }
                try {
                    navigator.clipboard.writeText(e)
                } catch (e) {
                    a()
                }
            }
        },
        16600: function(e, t, n) {
            n.d(t, {
                Dd: function() {
                    return r
                },
                Mf: function() {
                    return a
                },
                sK: function() {
                    return i
                }
            }), n(95182), n(99486);
            var r = "content_policy",
                a = {
                    errType: "warning",
                    errCode: r
                },
                i = {
                    err: "Contents may violate our content policy",
                    errType: "danger",
                    errCode: r
                }
        }
    }
]);